"""Command line entry points.

python -m mbdp.cli editor --workspace data/editor --port 8010     detailing editor (model forms + live drawings)
python -m mbdp.cli draw   --job data/editor/job.json --out out/   drawings + DXF + NC + lists from a job file
python -m mbdp.cli sample-job --out job.json                      write the re-modelled sample job
"""

from __future__ import annotations

import argparse


def cmd_editor(args):
    from .detail.editor.server import serve

    serve(args.workspace, args.port)


def _regenerate_frames(job):
    """Refresh derived layouts from saved frame inputs before drawing an existing job."""
    from .detail.frame import sync_frames

    sync_frames(job)


def cmd_draw(args):
    from .detail import model as DM
    from .detail.shopdata import export_package

    with open(args.job) as fh:
        job = DM.Job.loads(fh.read())
    # A saved job can contain derived frame layouts produced by an older application version.
    # Rebuild from current inputs so endpoint/per-line rules are not shadowed by stale geometry.
    _regenerate_frames(job)
    issues = DM.validate(job)
    m = export_package(job, args.out, issues)
    print(
        f"job {job.job_no} rev {m['model_revision']}: {len(m['sheets'])} sheets, {len(m['files'])} files -> {args.out}  [{m['status']}]"
    )
    for i in issues:
        print(f"  {i.severity:7s} {i.assembly:8s} {i.text}")


def cmd_sample_job(args):
    from .detail.templates import sample_job

    with open(args.out, "w") as fh:
        fh.write(sample_job().dumps())
    print(f"wrote {args.out}")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="mbdp")
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("editor", help="serve the detailing editor (model forms + live drawings)")
    e.add_argument("--workspace", default="data/editor")
    e.add_argument("--port", type=int, default=8010)
    e.set_defaults(fn=cmd_editor)
    d = sub.add_parser("draw", help="generate drawings / DXF / NC / lists from a job JSON file")
    d.add_argument("--job", required=True)
    d.add_argument("--out", required=True)
    d.set_defaults(fn=cmd_draw)
    j = sub.add_parser("sample-job", help="write the sample job (RF1-9, RF1-2, MB1-1 re-modelled) as JSON")
    j.add_argument("--out", default="sample_job.json")
    j.set_defaults(fn=cmd_sample_job)
    args = ap.parse_args(argv)
    args.fn(args)


if __name__ == "__main__":
    main()
