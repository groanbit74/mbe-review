"""Exact dimensions.

All lengths are stored as exact rational inches (``fractions.Fraction``), never
floats.  Shop-drawing strings such as ``24'-11 13/16"`` round-trip losslessly.

Documented precision: the imperial detailing convention used by the supplied
packages is 1/16".  Values are kept exact regardless; ``Dim.is_on_grid`` reports
whether a value sits on the documented precision grid.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from fractions import Fraction
from typing import Any

DOC_PRECISION = Fraction(1, 16)  # documented drawing precision (inches)

_FRAC = r"(?P<num>\d+)/(?P<den>\d+)"
# One grammar for every dimension typed into the system (specification §4
# "Dimension entry").  Accepts the shop notations below; the stored value is
# always an exact rational number of inches and ``fmt()`` is unchanged.
#
#   24'-11 13/16"   20'-2 3/8"   7 3/4"   6"   1'-0 1/4"   25'-0"   13'-3 3/16   4'   1/2"
#   1-1/2           1-1/2"       12' 3-1/2"      (hyphen between whole inches and fraction)
#   12.5            0.1875"      12.5'           (decimal inches / feet, kept exact)
#   -1/2            +3/16        -1'-6"          (signed offsets)
#   20ft            6in          20 ft 6 in      (unit words)
_DIM_RE = re.compile(
    r"""^\s*
    (?P<sign>[-+])?\s*
    (?:(?P<ft>\d+(?:\.\d+)?)\s*(?:'|ft\b|feet\b)\s*-?\s*)?                 # feet (optionally decimal)
    (?:
        (?P<in>\d+)(?:[\s-]+(?P<num>\d+)/(?P<den>\d+))?                     # whole inches [+ fraction, space or hyphen]
      | (?P<num2>\d+)/(?P<den2>\d+)                                         # fraction only
      | (?P<dec>\d*\.\d+|\d+\.\d*)                                          # decimal inches
    )?
    \s*(?:"|''|in\b|inch\b|inches\b)?\s*$""",
    re.VERBOSE,
)


@dataclass(frozen=True, order=True)
class Dim:
    """An exact length in inches."""

    inches: Fraction

    # ---- construction -------------------------------------------------
    @classmethod
    def parse(cls, text: str) -> "Dim":
        t = text.strip().replace("\u2019", "'").replace("\u201d", '"').replace("”", '"').replace("’", "'")
        t = t.replace("''", '"')
        m = _DIM_RE.match(t)
        if not m or not any(m.group(g) for g in ("ft", "in", "num2", "dec")):
            raise ValueError(f"not a dimension: {text!r}")
        if m.group("dec") and m.group("dec") in (".",):
            raise ValueError(f"not a dimension: {text!r}")
        total = Fraction(0)
        if m.group("ft"):
            total += Fraction(m.group("ft")) * 12  # Fraction("12.5") is exact
        if m.group("in"):
            total += Fraction(int(m.group("in")))
            if m.group("num"):
                if int(m.group("den")) == 0:
                    raise ValueError(f"not a dimension: {text!r}")
                total += Fraction(int(m.group("num")), int(m.group("den")))
        elif m.group("num2"):
            if int(m.group("den2")) == 0:
                raise ValueError(f"not a dimension: {text!r}")
            total += Fraction(int(m.group("num2")), int(m.group("den2")))
        elif m.group("dec"):
            total += Fraction(m.group("dec"))
        if m.group("sign") == "-":
            total = -total
        return cls(total)

    @classmethod
    def try_parse(cls, text: str) -> "Dim | None":
        try:
            return cls.parse(text)
        except (ValueError, ZeroDivisionError):
            return None

    @classmethod
    def from_feet(cls, feet: Any) -> "Dim":
        return cls(Fraction(feet) * 12)

    @classmethod
    def inch(cls, value: Any) -> "Dim":
        return cls(Fraction(value))

    # ---- arithmetic ---------------------------------------------------
    def __add__(self, other: "Dim") -> "Dim":
        return Dim(self.inches + other.inches)

    def __sub__(self, other: "Dim") -> "Dim":
        return Dim(self.inches - other.inches)

    def __mul__(self, k: Any) -> "Dim":
        return Dim(self.inches * Fraction(k))

    __rmul__ = __mul__

    def __neg__(self) -> "Dim":
        return Dim(-self.inches)

    def __abs__(self) -> "Dim":
        return Dim(abs(self.inches))

    def __bool__(self) -> bool:
        return self.inches != 0

    # ---- properties ---------------------------------------------------
    @property
    def feet(self) -> Fraction:
        return self.inches / 12

    @property
    def feet_float(self) -> float:
        return float(self.inches) / 12.0

    def is_on_grid(self, precision: Fraction = DOC_PRECISION) -> bool:
        return (self.inches / precision).denominator == 1

    # ---- formatting ---------------------------------------------------
    def fmt(self, always_feet: bool = False) -> str:
        """Format as feet-inches-fraction (``24'-11 13/16"``)."""
        neg = self.inches < 0
        v = abs(self.inches)
        ft, rem = divmod(v, 12)
        ft = int(ft)
        whole = int(rem)
        frac = rem - whole
        if ft or always_feet:
            s = f"{ft}'-{whole}"
            if frac:
                s += f" {frac.numerator}/{frac.denominator}"
            s += '"'
        else:
            if whole and frac:
                s = f'{whole} {frac.numerator}/{frac.denominator}"'
            elif frac:
                s = f'{frac.numerator}/{frac.denominator}"'
            else:
                s = f'{whole}"'
        return ("-" if neg else "") + s

    def rational(self) -> str:
        return f"{self.inches.numerator}/{self.inches.denominator}"

    def to_json(self) -> dict:
        return {"text": self.fmt(), "in": self.rational()}

    @classmethod
    def from_json(cls, d: dict | str) -> "Dim":
        if isinstance(d, str):
            return cls.parse(d)
        n, den = d["in"].split("/")
        return cls(Fraction(int(n), int(den)))

    def __str__(self) -> str:  # pragma: no cover - convenience
        return self.fmt()

    def __repr__(self) -> str:  # pragma: no cover
        return f"Dim({self.fmt()})"


def find_dims(text: str) -> list[str]:
    """Return substrings of ``text`` that look like dimensions (feet-inch strings)."""
    pat = re.compile(r"\d+'-\d+(?:\s+\d+/\d+)?\"|\d+(?:\s+\d+/\d+)?\"|\d+/\d+\"")
    return pat.findall(text)


def parse_plate_size(desc: str) -> tuple[Dim, Dim, Dim] | None:
    """Parse ``1/2"x6"x1'-0 1/4"`` -> (thickness, width, length)."""
    parts = re.split(r'"\s*[xX]\s*', desc.strip())
    if len(parts) != 3:
        return None
    dims = []
    for p in parts:
        p = p.strip()
        if not p.endswith('"'):
            p += '"'
        d = Dim.try_parse(p)
        if d is None:
            return None
        dims.append(d)
    return dims[0], dims[1], dims[2]


_PROFILE_RE = re.compile(r"^\s*([WwSsMmHh][Pp]?)\s*(\d+)\s*[xX]\s*(\d+(?:\.\d+)?)\s*$")
_ANGLE_RE = re.compile(
    r"^\s*L?\s*(\d+(?:\s\d+/\d+)?)\"?\s*[xX]\s*(\d+(?:\s\d+/\d+)?)\"?\s*[xX]\s*(\d+/\d+|\d+(?:\.\d+)?)\"?\s*$"
)


def normalize_profile(text: str) -> str | None:
    """``W12x22`` / ``W12X22`` / ``W 12 X 22`` -> ``W12X22``."""
    m = _PROFILE_RE.match(text)
    if not m:
        return None
    return f"{m.group(1).upper()}{int(m.group(2))}X{m.group(3)}"


def parse_member_desc(desc: str) -> tuple[str, Dim] | None:
    """Parse ``W14X22  X  24'-11 13/16"`` or ``W8X10 x 12'-0 7/8"`` -> (profile, length)."""
    m = re.match(r"^\s*([WwSsMm]\s*\d+\s*[xX]\s*\d+(?:\.\d+)?)\s*[xX]\s*(.+)$", desc.strip())
    if not m:
        return None
    prof = normalize_profile(m.group(1))
    length = Dim.try_parse(m.group(2))
    if prof is None or length is None:
        return None
    return prof, length
