"""Metal building detailing package (MBDP).

``__version__`` is the single in-code version string: the editor stamps it into
the page, every browser request carries it back, and the server refuses API
calls from a page of a different version (a browser-cached copy of an earlier
editor would otherwise fail with meaningless JavaScript errors).  Keep it equal
to ``pyproject.toml`` — ``tests/test_version_consistency.py`` checks.
"""

__version__ = "0.8.66"
