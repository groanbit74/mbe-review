"""Release-hold classification.

Generated text in this system falls into two classes:

* **actionable** - a concrete, input-resolvable gap ("profile not selected",
  "cut length must be positive", "CLASH", "NO VALID station") or a geometric
  failure the user must fix before the job is complete; and
* **disclaimer** - declarative policy wording ("not approved", "capacity
  unverified", "review hold", "reference only", "pending per instruction")
  that does not name anything the user can enter or change.

Only the first class may block a release.  The second class is retained in
the per-record derivation data (it is still useful as an engineering note)
but it is filtered out of the release gate, the order *pending* list, the
release report and the sheet NOTE layers.
"""

from __future__ import annotations

import re

# Vocabulary that marks a text as policy / disclaimer wording.
_DISCLAIMER = re.compile(
    r"not\s+approved|no\s+(?:structural\s+|capacity\s+|connection\s+|anchor\s+)?(?:capacity|approval|design|section\s+substitution)"
    r"|unverified|unapproved|not\s+(?:yet\s+)?(?:released|certified|verified|final|interchanged|assumed)"
    r"|require[sd]?\s+(?:review|reconciliation|approval|confirmation)|remains?\s+(?:pending|held|separate|unverified|a\s+separate)"
    r"|review\s+(?:hold|held|required|only)|reference\s+(?:cut|only)|coordination\s+only|count(?:ed)?\s+only"
    r"|set\s*out\s*/\s*coordination|for\s+reference|not\s+for\s+fabrication|proposed|draft\b|planning\s+takeoff"
    r"|per\s+user\s+instruction|unquantified|withheld|assum(?:ed|ption)|substitut|verify\s+actual|confirm\s+(?:actual|explicitly)"
    r"|is\s+not\s+(?:actual|verified)\s+thickness|capacit(?:y|ies)|load\s+path|weld\s+(?:design|procedure)|no\s+punch|punching"
    r"|held\s+values|\bHELD\b|\bPENDING\b(?!\s*(?:eave|:))|never\s+(?:cut|moved|invented)|not\s+automatically|nominal"
    r"|ordinary\s+clip|project\s+simple\s+butt|review\s+cut|fit\s+(?:remains?|held|pending)|kept\s+separate"
    r"|inferred|counted\s+once|informational|not\s+quantified|unquantified|no\s+automatic|not\s+a\s+(?:machine|fabrication|purchasable)"
    r"|verify\s+purchased|connection\s+design\s+before|section\s+fit\s*:\s*verify",
    re.IGNORECASE,
)

# Wording that names a concrete gap the user can resolve (or a hard failure).
# These win over the disclaimer vocabulary.
_ACTIONABLE = re.compile(
    r"MODEL\s+ERRORS?|\bFAIL\b|\bCLASH|NO\s+VALID|\bUPRIGHT\b.*(?:required|missing)|not\s+in\s+catalog|must\s+be\b|exceeds?\b"
    r"|\bmissing\b|\benter\b|not\s+selected|\bselect\s+(?:a|the|rafter|jamb|header)|undefined|run\s+past|needs\s+a\s+pitch"
    r"|outside\s+member|crosses\s+aperture|does\s+not\s+fit|consume[sd]?\s+bay|incomplete\b|\bzero\s+girt\s+runs"
    r"|cannot\s+be\s+switched|is\s+also\s+used\s+as|listed\s+twice|cut\s+length\s+must|quantity\s+must|lot\s+quantity\s+mismatch"
    r"|QUANTITY\s+MISMATCH|at\s+least\s+two|do\s+not\s+coincide|segmentation\s+pending|stock\s+segmentation|BASE\s+ANGLE\s+STOCK"
    r"|END\s+ROOF\s+FIT|no\s+weight|station\s+missing|unknown\s+face|y_from_top\s+missing|plate\s+size\s+incomplete|model\s+is\s+missing"
    r"|not\s+on\s+the\s+1/16|not\s+on\s+1/16|cut\s+length\s+pending|PENDING\s*:|PENDING\s+EAVE|FLUSH\s+FIT\s+PENDING"
    r"|PROFILE\s+PENDING|no\s+stock\s+quantity|differs\s+from|not\s+(?:yet\s+)?entered|not\s+provided|unresolved|removed\b",
    re.IGNORECASE,
)


def is_actionable(text) -> bool:
    """True when *text* names a concrete, user-resolvable gap or a hard failure."""
    if not text:
        return False
    return bool(_ACTIONABLE.search(str(text)))


def is_disclaimer(text) -> bool:
    """True when *text* is policy / disclaimer wording that must not block a release.

    Actionable wording always wins, so "FLUSH FIT PENDING: CEE/TUBE ATTACHMENT
    FACE NOT CONFIRMED" stays actionable even though it contains "confirm".
    """
    if not text:
        return False
    s = str(text)
    if is_actionable(s):
        return False
    return bool(_DISCLAIMER.search(s))


def actionable(texts):
    """Filter an iterable of strings down to the actionable ones (order kept)."""
    out = []
    for t in texts or []:
        if t and not is_disclaimer(t) and is_actionable(t):
            out.append(t)
    return out


def open_items(texts):
    """Open items = every text that is not a pure disclaimer.

    Unlike :func:`actionable` this keeps texts that match neither vocabulary
    (an unknown wording is treated as a real item rather than silently
    dropped).
    """
    return [t for t in (texts or []) if t and not is_disclaimer(t)]
