"""Purlin lay: stock lengths land on the rafter centres (owner, round 16).

Shop rule, in the owner's words: purlin stock lengths land on the CENTRE of a rafter (a 20 ft bay takes a
20 ft stick, a 25 ft bay a 25 ft stick).  Where the bays are short, one stock length spans two bays with no
cut (15 + 15 -> one 30 ft stick, 10 + 20 -> one 30 ft stick), running over the rafter between them with no
break.  A purlin is NEVER spliced between rafters: a Cee butts at a rafter centre, a Zee laps over a rafter,
and neither is ever joined mid-bay.  A flush run cannot pass the rafters (it sits beside each one), so it is
still ordered in stock lengths and cut square to length bay by bay.

This module only decides WHICH BAYS SHARE ONE STICK.  Piece ends, laps and terminal rules stay with
``secondary_runs`` (main roof) and ``lean_purlins`` (lean-to roofs); both hand their per-bay rows here.
"""

from fractions import Fraction

from .model import D

EPS = 1 / 32  # in: a piece this close to a stock length IS that stock length
DEFAULT_STOCK_IN = (240.0, 300.0, 360.0)  # 20 / 25 / 30 ft


def stock_for(length, stocks):
    """Shortest stock length that holds ``length`` (None when none does)."""
    return next((s for s in sorted(stocks) if s >= length - EPS), None)


def spans(rows, stocks, may_join=None):
    """Split consecutive bays into pieces; ``[(first, last), ...]`` with 0-based inclusive indexes.

    ``rows`` carry the per-bay ``start_in`` / ``end_in`` of a piece laid one to a bay; ``may_join[j]`` is
    False where the joint between bay ``j`` and ``j + 1`` cannot be passed (a flush frame, a channel).  A group
    of bays is one piece when its length still fits the longest stock length.  The split buys the least stock
    (a 15 ft piece costs a whole 20 ft stick; 15 + 15 costs one 30 ft stick), then the fewest pieces, then
    puts the longest piece first so the answer never depends on iteration order.
    """
    n = len(rows)
    stocks = sorted(float(s) for s in (stocks or ()))
    if n < 2 or not stocks:
        return [(i, i) for i in range(n)]
    may_join = list(may_join) if may_join is not None else [True] * (n - 1)
    longest = stocks[-1]
    best = [None] * (n + 1)
    best[0] = ((0.0, 0, ()), [])
    for k in range(1, n + 1):
        found = None
        for a in range(k):
            if best[a] is None or any(not may_join[j] for j in range(a, k - 1)):
                continue
            length = rows[k - 1]['end_in'] - rows[a]['start_in']
            if k - 1 > a and length > longest + EPS:
                continue
            bought = stock_for(length, stocks) or length  # one over-long bay stays a single (held) piece
            prior, groups = best[a]
            cost = (round(prior[0] + bought, 4), prior[1] + 1, prior[2] + (-(k - a),))
            if found is None or cost < found[0]:
                found = (cost, groups + [(a, k - 1)])
        best[k] = found
    return best[n][1]


def bays_text(rec):
    """'2' for a piece in one bay, '2-3' for a piece that spans bays 2 and 3."""
    last = rec.get('bay_last')
    return f"{rec['bay']}-{last}" if last and last != rec['bay'] else str(rec['bay'])


def note(first, last, length, stock):
    """Status wording for a piece that spans bays ``first``..``last`` (1-based)."""
    text = D(Fraction(round(length * 16), 16)).fmt()
    held = D(Fraction(round(stock * 16), 16)).fmt() if stock else None
    if stock and abs(stock - length) <= EPS:
        how = f'one {held} STOCK LENGTH, no cut'
    elif stock:
        how = f'{text} cut from a {held} stock length'
    else:
        how = f'{text} (longer than any stock length - exact/custom order)'
    return (
        f'SPANS BAYS {first}-{last}: {how}; it lands on the rafter centres at both ends and runs over the '
        'interior rafter' + ('s' if last - first > 1 else '') + ' with NO splice between rafters'
    )


def merge(rows, groups, stocks):
    """Collapse the rows of each multi-bay group into ONE row (start of the first, end of the last).

    Rows keep every other field of the group's first row; ``bay`` is the first bay, ``bay_last`` the last,
    ``span_bays`` the count, ``stock_length_in`` the stick it is bought as.
    """
    out = []
    for a, b in groups:
        if a == b:
            out.append(rows[a])
            continue
        first, last = rows[a], rows[b]
        start = Fraction(first['start_in'])
        end = Fraction(last['end_in'])
        length = end - start
        stock = stock_for(float(length), stocks)
        rec = dict(first)
        extra = [x for x in (first.get('fit_status'), last.get('fit_status')) if x]
        rec.update(
            start_in=float(start),
            end_in=float(end),
            cut_length_in=float(length),
            cut_length=D(length).fmt(),
            bay=first['bay'],
            bay_last=last['bay'],
            span_bays=b - a + 1,
            stock_length_in=stock,
            fit_status='; '.join([note(first['bay'], last['bay'], float(length), stock)] + list(dict.fromkeys(extra))),
        )
        out.append(rec)
    return out


def lay(rows, stocks, may_join=None):
    """Rows laid one piece to a bay -> rows laid to the stock lengths (see ``spans``)."""
    if len(rows) < 2 or not stocks:
        return rows
    if any(r.get('start_in') is None or r.get('end_in') is None for r in rows):
        return rows
    return merge(rows, spans(rows, stocks, may_join), stocks)
