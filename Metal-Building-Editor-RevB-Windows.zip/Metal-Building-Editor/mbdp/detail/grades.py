"""Column grades: the grade plane entered per column (v0.8.43, owner round 13).

Standard: every column and post bears at the SET LEVEL (0 = top of the main slab / finished
floor).  When the ground is not level - a slab poured lower under the roof-only bay, lean posts in
augered holes at the natural grade - the grade at EACH column is entered and that column is cut to
suit: a column whose grade is 1 1/2 in below the set level is 1 1/2 in longer, so the eave stays
level.  Girt lines, the eave and every elevation above the floor are unchanged.

Entries live in ``frames[fid]['grades']``::

    {"enabled": true, "datum": "SET LEVEL = top of the main slab",
     "columns": {"main|3|right": "-1 1/2", "post|EW-COL-1-O-P01": "-1 1/2", "lean|LT1|2": "-6"}}

Keys: ``main|<frame line>|<left|right>`` (main frame columns; left = back sidewall, right = front
sidewall; the mono-slope high column is the right side), ``post|<mark>`` (end-wall / cross-wall
posts and door jambs), ``lean|<lean id>|<lean line>`` (lean posts).  A slab column's grade is the
top of slab at the column; a post-hole post's grade is the ground level at the post (the hole depth
is measured down from it).  Positive = above the set level.

Shop paperwork (owner): main columns of different lengths get their own marks (COL-1, COL-1A,
COL-1B ...; the group at the set level keeps the plain mark); end-wall and lean posts already carry
one mark per post.  Wall sheets and the base angle of a bay follow the LOWEST grade of the two
columns of that bay; girt lines stay level.
"""

from __future__ import annotations

import copy
import re
from fractions import Fraction

from .model import Assembly, D

LIMIT_IN = 36.0
# Sheets / base angle of a bay whose two columns stand at DIFFERENT grades (the slab step is at a
# column line).  Owner (round 14): sheets are ORDERED LONGER - the bay follows the LOWER slab and the
# transition area is cut to fit on site (usually only one sheet), so ``lower`` is the standard;
# ``higher`` stays as the shorter-sheet option that clears the raised slab with no site cut.
MIXED_BAY = {
    'lower': 'sheets and base angle of a mixed bay are ORDERED LONGER (to the LOWER slab); the transition area is cut to fit (standard)',
    'higher': 'sheets and base angle of a mixed bay clear the HIGHER slab (option; no site cut)',
}
DEFAULT_DATUM = 'SET LEVEL (0) = top of the main slab / finished floor'
LETTERS = 'ABCDEFGHJKLMNPRSTUVWXYZ'
_KEY = re.compile(r'^(main\|\d+\|(left|right)|post\|[A-Za-z0-9@_./-]+|lean\|[A-Za-z0-9_-]+\|\d+)$')
SIDE_WORDS = {'left': 'BACK SIDEWALL', 'right': 'FRONT SIDEWALL'}
# derivation keys that describe the column piece itself (a variant carries these and nothing of the
# frame-level takeoff - cladding, end walls, runs ... - which belongs to the owner assembly only)
COLUMN_KEYS = (
    'wizard',
    'frame_id',
    'connection_style',
    'resolved_base_plate',
    'foundation',
    'embed_in',
    'column_cut_unrounded_in',
    'column_low_side_floor_in',
    'column_long_side_floor_in',
    'roof_line_at_low_side_in',
    'rafter_top_at_low_side_in',
    'welded_knee',
    'nominal_depth_correction_in',
    'nominal_depth_fit_difference_in',
    'formula',
    'girt_clip_adjustments',
    'column_low_cut_in',
    'column_cut_datum',
)


def _f(x):
    return float(D(x).inches)


def grid16(x):
    return Fraction(round(float(x) * 16), 16)


def fmt(x):
    return D(grid16(x)).fmt()


def fmt_grade(g):
    g = float(g)
    if abs(g) < 1e-9:
        return '0"'
    return ('+' if g > 0 else '-') + D(grid16(abs(g))).fmt()


# ----------------------------------------------------------------------------- inputs
def normalize(raw) -> dict:
    """Validated copy of the saved block (zero entries dropped, values in inches)."""
    raw = raw if isinstance(raw, dict) else {}
    cols = raw.get('columns') or {}
    if not isinstance(cols, dict):
        raise ValueError('Column grades must map column keys to elevations')
    out = {}
    for key, val in cols.items():
        key = str(key).strip()
        if val in (None, '') or not str(val).strip():
            continue
        if not _KEY.match(key):
            raise ValueError('Unknown column grade key: ' + key)
        try:
            g = _f(str(val).strip())
        except Exception:
            raise ValueError(key + ': enter the grade as inches, e.g. -1 1/2 or +1/4')
        if abs(g) > LIMIT_IN:
            raise ValueError(key + ': grade beyond 3 ft from the set level - check the entry')
        if abs(g) < 1e-9:
            continue
        out[key] = g
    datum = str(raw.get('datum') or DEFAULT_DATUM).strip()[:120] or DEFAULT_DATUM
    mixed = str(raw.get('mixed_bay') or 'lower').strip()
    if mixed not in MIXED_BAY:
        raise ValueError('Mixed bay rule must be lower or higher')
    return {'enabled': bool(out), 'datum': datum, 'mixed_bay': mixed, 'columns': out}


def config(p) -> dict:
    g = getattr(p, 'grades', None)
    if isinstance(g, dict) and 'columns' in g:
        return g
    return {'enabled': False, 'datum': DEFAULT_DATUM, 'mixed_bay': 'lower', 'columns': {}}


def enabled(p) -> bool:
    return bool(config(p)['columns'])


def offset(p, key) -> float:
    """Grade of the column ``key`` relative to the set level (inches, 0 when not entered)."""
    return float(config(p)['columns'].get(key, 0.0))


def main_key(line, side):
    return 'main|%d|%s' % (int(line), side)


def post_key(mark):
    return 'post|' + str(mark)


def lean_key(lean_id, line):
    return 'lean|%s|%d' % (lean_id, int(line))


# ----------------------------------------------------------------------------- model
def _shift(asm, g, base_json):
    """Rebuild ``asm`` from the standard (set level) definition ``base_json`` for grade ``g``: the
    cut length grows by -g and every station measured from the bottom moves by -g."""
    std = Assembly.from_json(base_json)
    asm.main = std.main
    asm.attachments = std.attachments
    unrounded = asm.derivation.get('column_cut_unrounded_in')
    if unrounded is None:
        unrounded = _f(std.main.cut_length)
    asm.main.cut_length = D(grid16(unrounded - g))
    for att in asm.attachments:
        if att.station is not None:
            att.station = D(Fraction(round((_f(att.station) - g) * 1000000), 1000000))
    asm.derivation['column_cut_unrounded_in'] = unrounded - g
    if asm.derivation.get('column_low_cut_in') is not None:
        asm.derivation['column_low_cut_in'] = float(asm.derivation['column_low_cut_in']) - g
    asm.derivation['grade_in'] = g
    asm.derivation['formula'] = (asm.derivation.get('formula') or '') + '; grade %s at this column: cut %s%s' % (
        fmt_grade(g),
        '+' if g < 0 else '-',
        fmt(abs(g)),
    )


def finish(job, p):
    """Schedule of every column with its grade; main-column variants by cut length; the base
    steps of each wall surface (lowest grade per bay).  Runs after end walls and lean-tos, before
    the cladding takeoff."""
    from . import foundation as FND
    from . import frame_lines as FL

    fid = p.column_mark
    a = job.assemblies[fid]
    layout = job.settings.get('frame_layouts', {}).get(fid) or {}
    cfg = config(p)
    rows = []
    used = set()
    L = FL.length_in(job, fid)
    W = float(p.width.inches)
    lines = FL.lines(job, fid)
    fnd = FND.record(p)
    fnd_words = fnd['label'] + (
        ' ' + fnd['hole_diameter'] + ' x ' + fnd['hole_depth'] if fnd['type'] == 'post_footing' else ''
    )

    # --- main frame columns: one instance per rigid frame line and side
    cols = {}
    for c in layout.get('columns') or []:
        cols.setdefault(c['side'], c)
    main_rows = []
    for rec in lines:
        if rec['kind'] != 'interior':
            continue
        for side in ('left', 'right'):
            col = cols.get(side)
            if not col:
                continue
            key = main_key(rec['index'], side)
            g = offset(p, key)
            used.add(key)
            std = float(col.get('design_length') or _f(job.assemblies[col['mark']].main.cut_length))
            main_rows.append(
                dict(
                    kind='main',
                    key=key,
                    line=rec['index'],
                    station_in=float(rec['station_in']),
                    wall=side,
                    where=SIDE_WORDS[side] + ' / ' + rec['label'],
                    mark=col['mark'],
                    shop_mark=col['mark'],
                    section=job.assemblies[col['mark']].main.section,
                    grade_in=g,
                    grade=fmt_grade(g),
                    foundation=fnd_words,
                    bottom_in=float(col['y0']) + g,
                    standard_cut_in=std,
                    cut_in=std - g,
                    cut=fmt(std - g),
                )
            )
    variants = []
    for mark in sorted({r['mark'] for r in main_rows}):
        base = job.assemblies[mark]
        for k, b in list(job.assemblies.items()):
            if (b.derivation.get('grade_variant') or {}).get('of') == mark:
                del job.assemblies[k]
        mine = [r for r in main_rows if r['mark'] == mark]
        groups = {}
        for r in mine:
            groups.setdefault(round(r['grade_in'], 6), []).append(r)
        if list(groups) == [0.0]:
            continue
        keep = 0.0 if 0.0 in groups else max(groups, key=lambda g: (len(groups[g]), g))
        order = [keep] + sorted((g for g in groups if g != keep), reverse=True)
        base_json = base.to_json()
        letters = iter(LETTERS)
        total = base.qty
        for g in order:
            rs = groups[g]
            if g == keep:
                if abs(g) > 1e-9:
                    _shift(base, g, base_json)
                base.qty = len(rs)
                base.derivation['grade_lines'] = [[r['line'], r['wall']] for r in rs]
                continue
            letter = next(letters)
            v = Assembly.from_json(base_json)
            v.mark = mark + letter
            v.derivation = {k: copy.deepcopy(base.derivation[k]) for k in COLUMN_KEYS if k in base.derivation}
            _shift(v, g, base_json)
            v.main.mark = base.main.mark + letter  # its own cut mark: a different length
            v.qty = len(rs)
            v.derivation['grade_variant'] = dict(of=mark, grade_in=g, lines=[[r['line'], r['wall']] for r in rs])
            job.assemblies[v.mark] = v
            for r in rs:
                r['shop_mark'] = v.mark
            variants.append(
                dict(
                    mark=v.mark,
                    of=mark,
                    grade=fmt_grade(g),
                    grade_in=g,
                    quantity=len(rs),
                    cut=v.main.cut_length.fmt(),
                    lines=[[r['line'], r['wall']] for r in rs],
                )
            )
        if base.qty + sum(v['quantity'] for v in variants if v['of'] == mark) != total:
            raise ValueError(mark + ': column grade groups do not add up to the frame count')
    rows += main_rows

    # --- end-wall / cross-wall posts (grade applied in endwalls.finish)
    line_of_end = {rec['wall_key']: rec for rec in lines if rec['kind'] == 'end'}
    for end_key, end in (a.derivation.get('endwalls') or {}).items():
        if not isinstance(end, dict):
            continue
        rec = line_of_end.get(end_key) or {}
        members = {m['mark']: m for m in end.get('members') or []}
        for post in end.get('posts') or []:
            key = post_key(post['mark'])
            used.add(key)
            g = float(post.get('grade_in') or 0.0)
            m = members.get(post['mark']) or {}
            cut = m.get('reference_cut_in')
            if cut is None:
                cut = float(post['top_low']) - float(post['bottom'])
            rows.append(
                dict(
                    kind='post',
                    key=key,
                    line=rec.get('index'),
                    station_in=float(end.get('station_in') or 0.0),
                    wall=end_key,
                    where=(rec.get('label') or end_key.replace('_', ' ').upper()) + ' / x=' + fmt(post['x']),
                    x_in=float(post['x']),
                    mark=post['mark'],
                    shop_mark=post['mark'],
                    section=(post.get('profile') or {}).get('id', ''),
                    grade_in=g,
                    grade=fmt_grade(g),
                    foundation=fnd_words,
                    bottom_in=float(post['bottom']),
                    standard_cut_in=float(cut) + g,
                    cut_in=float(cut),
                    cut=fmt(cut),
                    blank=m.get('blank_length') or '',
                )
            )

    # --- lean posts (grade and lean foundation applied in lean_low)
    for z in (a.derivation.get('framing_additions') or {}).get('lean_tos') or []:
        low = z.get('low_connection_detail') or {}
        marks = {m.get('station'): m['mark'] for m in z.get('members') or [] if m.get('role') == 'column'}
        lf = FND.lean_record(p, z)
        words = lf['label'] + (
            ' ' + lf['hole_diameter'] + ' x ' + lf['hole_depth'] if lf['type'] == 'post_footing' else ''
        )
        for q in low.get('lines') or []:
            key = lean_key(z['id'], q['station'])
            used.add(key)
            g = float(q.get('grade_in') or 0.0)
            st = next((s for s in z['stations'] if s.get('index') == q['station']), {})
            rows.append(
                dict(
                    kind='lean',
                    key=key,
                    line=q['station'],
                    station_in=float(st.get('x_in') or 0.0),
                    wall=z['face'],
                    where=z['id'] + ' LEAN-TO / lean line %d @ %s' % (q['station'], fmt(st.get('x_in') or 0.0)),
                    lean_id=z['id'],
                    mark=marks.get(q['station'], z['id'] + '-' + str(q['station'])),
                    shop_mark=marks.get(q['station'], ''),
                    section=z.get('column', ''),
                    grade_in=g,
                    grade=fmt_grade(g),
                    foundation=words,
                    bottom_in=float(q.get('column_bottom_in') or 0.0),
                    standard_cut_in=float(q['column_low_cut_in']) + g,
                    cut_in=float(q['column_low_cut_in']),
                    cut=fmt(q['column_low_cut_in']),
                    blank=fmt(q['column_long_blank_in']),
                )
            )

    ignored = sorted(k for k in cfg['columns'] if k not in used)
    notes = []
    if cfg['columns']:
        notes.append(
            'COLUMN GRADES: %d column(s) off the set level (%s); each cut to its grade, eave and girt lines level - see the COLUMN GRADE SCHEDULE.'
            % (sum(1 for r in rows if abs(r['grade_in']) > 1e-9), cfg['datum'])
        )
    for k in ignored:
        notes.append('Column grade entry ' + k + ' no longer matches a column of this building; ignored.')
    result = dict(
        enabled=bool(cfg['columns']),
        datum=cfg['datum'],
        rows=rows,
        variants=variants,
        ignored_keys=ignored,
        mixed_bay=cfg.get('mixed_bay', 'lower'),
        mixed_bay_rule=MIXED_BAY[cfg.get('mixed_bay', 'lower')],
        base_steps=_base_steps(rows, lines, L, W, cfg.get('mixed_bay', 'lower')),
        notes=notes,
    )
    _step_base_angles(a, result['base_steps'], L, result['mixed_bay'])
    a.derivation['column_grades'] = result
    if layout:
        layout['column_grades'] = result
    return result


def _step_base_angles(a, steps, L, mixed='lower'):
    """Base angle pieces follow the bay offset: sidewall pieces of the secondary runs (one per bay
    already) drop by the bay offset; sheet-support pieces are split at a step.  Under the standard
    ``lower`` rule the pieces are ordered to the LOWER slab and cut to fit at the step."""
    if not steps:
        return
    runs = a.derivation.get('secondary_runs') or {}
    for piece in runs.get('pieces') or []:
        if piece.get('role') != 'base_angle' or piece.get('side') not in steps:
            continue
        x0, x1 = float(piece['support_start_in']), float(piece['support_end_in'])
        if piece['side'] == 'left':
            x0, x1 = L - x1, L - x0
        g = step_offset(steps[piece['side']], x0, x1)
        if abs(g) > 1e-9:
            piece['floor_y_in'] = float(piece['floor_y_in']) + g
            piece['grade_offset_in'] = g
            piece['status'] = str(piece.get('status', '')) + (
                '; ORDERED LONG - on the LOWER slab of the mixed bay (%s); cut to fit at the step' % fmt_grade(g)
                if mixed == 'lower'
                else '; CLEARS THE HIGHER slab of the mixed bay (%s)' % fmt_grade(g)
            )
    model = a.derivation.get('framing_additions') or {}
    out = []
    for rec in model.get('base_supports') or []:
        face = rec.get('face')
        key = face if face in ('front', 'rear', 'left', 'right') else 'lean_' + str(rec.get('owner')) + '_outer'
        st = steps.get(key)
        if not st or face in ('start_end', 'finish_end') or 'x_start_in' not in rec:
            out.append(rec)
            continue
        parts = split_runs(st, float(rec['x_start_in']), float(rec['x_end_in']))
        for j, (x0, x1, g) in enumerate(parts):
            r = dict(rec)
            if len(parts) > 1:
                r['mark'] = rec['mark'] + LETTERS[j].lower()
                r['x_start_in'], r['x_end_in'], r['length_in'] = x0, x1, x1 - x0
                r['status'] = rec['status'] + '; CUT AT THE SLAB STEP'
            if abs(g) > 1e-9:
                r['y_in'] = g
                r['status'] = r['status'] + (
                    '; ORDERED LONG - on the LOWER slab (%s); cut to fit at the step' % fmt_grade(g)
                    if mixed == 'lower'
                    else '; CLEARS THE HIGHER slab (%s)' % fmt_grade(g)
                )
            out.append(r)
    if 'base_supports' in model:
        model['base_supports'] = out


# ----------------------------------------------------------------------------- wall base steps
def _base_steps(rows, lines, L, W, mixed='lower'):
    """Per wall surface (outside-view datum of the cladding takeoff): ``[x0, x1, offset]`` runs
    with the base offset of each bay - the grade shared by its two columns, or the lower / higher
    one of a mixed bay (``MIXED_BAY``; ``lower`` = ordered longer, the standard); only runs with a
    non-zero offset are listed."""
    pick = min if mixed == 'lower' else max
    main = {(r['line'], r['wall']): r['grade_in'] for r in rows if r['kind'] == 'main'}
    posts = {}
    for r in rows:
        if r['kind'] == 'post':
            posts.setdefault(r['wall'], []).append(r)
    steps = {}

    def side_grade(rec, side):
        if rec['kind'] == 'interior':
            return main.get((rec['index'], side), 0.0)
        ps = sorted(posts.get(rec['wall_key']) or [], key=lambda r: r['x_in'])
        if not ps:
            return 0.0
        return (ps[-1] if side == 'right' else ps[0])['grade_in']

    for side in ('left', 'right'):
        runs = []
        for r0, r1 in zip(lines, lines[1:]):
            g = pick(side_grade(r0, side), side_grade(r1, side))
            if abs(g) < 1e-9:
                continue
            s0, s1 = float(r0['station_in']), float(r1['station_in'])
            if side == 'left':
                s0, s1 = L - s1, L - s0
            runs.append([s0, s1, g])
        if runs:
            steps[side] = runs
    for surface, end_key, mirror in (('front', 'front_end', False), ('rear', 'rear_end', True)):
        ps = sorted(posts.get(end_key) or [], key=lambda r: r['x_in'])
        runs = []
        for p0, p1 in zip(ps, ps[1:]):
            g = pick(p0['grade_in'], p1['grade_in'])
            if abs(g) < 1e-9:
                continue
            x0, x1 = p0['x_in'], p1['x_in']
            if mirror:
                x0, x1 = W - x1, W - x0
            runs.append([x0, x1, g])
        if runs:
            steps[surface] = runs
    leans = {}
    for r in rows:
        if r['kind'] == 'lean':
            leans.setdefault(r['lean_id'], []).append(r)
    for lid, rs in leans.items():
        rs = sorted(rs, key=lambda r: r['station_in'])
        runs = []
        for p0, p1 in zip(rs, rs[1:]):
            g = pick(p0['grade_in'], p1['grade_in'])
            if abs(g) < 1e-9:
                continue
            runs.append([p0['station_in'] - rs[0]['station_in'], p1['station_in'] - rs[0]['station_in'], g])
        if runs:
            steps['lean_' + lid + '_outer'] = runs
    return steps


def step_offset(steps, x0, x1):
    """Lowest base offset over the strip ``x0..x1`` (0 when no step touches it)."""
    best = 0.0
    for a, b, g in steps or []:
        if a < x1 - 1e-6 and b > x0 + 1e-6:
            best = min(best, float(g))
    return best


def split_runs(steps, x0, x1):
    """``x0..x1`` cut at the step boundaries: ``[(a, b, offset), ...]`` left to right."""
    cuts = sorted({x0, x1} | {v for a, b, g in steps or [] for v in (a, b) if x0 < v < x1})
    return [(a, b, step_offset(steps, a, b)) for a, b in zip(cuts, cuts[1:])]


# ----------------------------------------------------------------------------- drawing helpers
def line_columns(layout, index):
    """``{side: schedule row}`` of the main-frame columns on frame line ``index``."""
    rows = (layout.get('column_grades') or {}).get('rows') or []
    return {r['wall']: r for r in rows if r['kind'] == 'main' and r.get('line') == index}


def line_signature(layout, index):
    """Hashable grade signature of frame line ``index`` (lines with different grades are drawn
    on their own sheets)."""
    return tuple(sorted((side, round(r['grade_in'], 4)) for side, r in line_columns(layout, index).items()))


def base_note(g):
    return 'BASE %s (GRADE)' % fmt_grade(g)
