"""Product model for drawing generation.

Everything on a sheet is *derived* from this model: geometry, dimensions,
callouts, BOM rows and weights.  Nothing is typed onto the drawing by hand.

Conventions
-----------
* All lengths are exact ``Dim`` (rational inches).  Angles are floats (degrees).
* An assembly is drawn horizontally.  ``station`` is measured from the member's
  LEFT end (the shop's "Tape (Typ)" datum) to the attachment's reference point.
* Faces: ``top`` / ``bottom`` (flanges), ``web``, ``left_end`` / ``right_end``.
* A ``Part`` is a piece mark (PC8D, EP12, MB-2, BR14HE1 ...) defined once per job
  and referenced by attachments.  ``kind`` decides geometry:
  ``plate`` (thk x width x length, optional holes), ``clip`` (a plate that stands on
  a flange), ``stub`` (short rolled section with its own attachments),
  ``bracket`` (weldment with its own drawing – weight from that drawing).
* Weights follow the shop's documented rounding (see ``WeightPolicy``); the sample
  packages truncate member weights to 0.01 lb and plate weights to 0.1 lb.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
from dataclasses import dataclass, field
from decimal import ROUND_DOWN, ROUND_HALF_UP, Decimal
from fractions import Fraction
from typing import Any, Iterable, Optional

from ..dims import Dim
from . import sections

FACES = ("top", "bottom", "web", "left_end", "right_end")
SIDES = ("NS", "FS", "both")
PART_KINDS = ("plate", "clip", "stub", "bracket")
ASSEMBLY_KINDS = ("COLUMN", "RAFTER", "BEAM", "GIRT", "PURLIN", "BRACKET", "MISC")


# --------------------------------------------------------------------------- helpers
def D(v: Any) -> Dim:
    """Coerce str / number / Dim / json-dict to Dim."""
    if isinstance(v, Dim):
        return v
    if isinstance(v, dict):
        return Dim.from_json(v)
    if isinstance(v, (int, Fraction)):
        return Dim(Fraction(v))
    if isinstance(v, float):
        return Dim(Fraction(v).limit_denominator(64))
    if isinstance(v, str):
        s = v.strip()
        if not s:
            raise ValueError("empty dimension")
        return Dim.parse(s)
    raise TypeError(f"cannot convert {v!r} to Dim")


def dim_json(d: Optional[Dim]) -> Optional[str]:
    return None if d is None else d.fmt()


# --------------------------------------------------------------------------- weights
@dataclass
class WeightPolicy:
    """Documented rounding used for BOM weights (matches the sample packages)."""

    member_decimals: int = 2
    member_mode: str = "truncate"  # truncate | round
    plate_decimals: int = 1
    plate_mode: str = "truncate"
    density_lb_in3: Decimal = sections.STEEL_DENSITY_LB_PER_IN3

    def _q(self, value: Decimal, decimals: int, mode: str) -> Decimal:
        q = Decimal(1).scaleb(-decimals)
        return value.quantize(q, rounding=ROUND_DOWN if mode == "truncate" else ROUND_HALF_UP)

    def member(self, plf: Decimal, length: Dim) -> Decimal:
        if plf is None:
            return None
        exact = plf * Decimal(length.inches.numerator) / Decimal(length.inches.denominator) / Decimal(12)
        return self._q(exact, self.member_decimals, self.member_mode)

    def plate(self, thk: Dim, w: Dim, l: Dim) -> Decimal:
        vol = thk.inches * w.inches * l.inches
        exact = self.density_lb_in3 * Decimal(vol.numerator) / Decimal(vol.denominator)
        return self._q(exact, self.plate_decimals, self.plate_mode)

    def to_json(self) -> dict:
        return {
            "member_decimals": self.member_decimals,
            "member_mode": self.member_mode,
            "plate_decimals": self.plate_decimals,
            "plate_mode": self.plate_mode,
            "density_lb_in3": str(self.density_lb_in3),
        }

    @classmethod
    def from_json(cls, d: dict | None) -> "WeightPolicy":
        d = d or {}
        return cls(
            member_decimals=int(d.get("member_decimals", 2)),
            member_mode=d.get("member_mode", "truncate"),
            plate_decimals=int(d.get("plate_decimals", 1)),
            plate_mode=d.get("plate_mode", "truncate"),
            density_lb_in3=Decimal(str(d.get("density_lb_in3", sections.STEEL_DENSITY_LB_PER_IN3))),
        )


# --------------------------------------------------------------------------- parts
@dataclass
class Hole:
    x: Dim  # along the part's length, from the part's left/bottom edge in its face view
    y: Dim  # across the part's width
    dia: Dim

    def to_json(self) -> dict:
        return {"x": self.x.fmt(), "y": self.y.fmt(), "dia": self.dia.fmt()}

    @classmethod
    def from_json(cls, d: dict) -> "Hole":
        return cls(D(d["x"]), D(d["y"]), D(d["dia"]))


@dataclass
class Attachment:
    """A part positioned on a member (or on a stub)."""

    part: str
    face: str = "top"
    station: Optional[Dim] = None  # from left end; None for end faces
    side: str = "both"  # NS | FS | both (web parts and clips that come in pairs)
    angle: float = 90.0  # angle between part and member axis, degrees
    ref: str = "center"  # which point of the part sits at the station: center | left | right
    y_from_top: Optional[Dim] = None  # web parts: distance from top of member to the part's hole/centre
    tilt: float = 0.0  # brackets: drawn tilt (roof slope), degrees
    show_first_hole_ref: bool = False  # draw the "1st hole Ref." dimension on this one
    label: str = ""  # callout override
    note: str = ""  # free note shown next to the callout (e.g. "FS/NS")

    def to_json(self) -> dict:
        return {
            "part": self.part,
            "face": self.face,
            "station": dim_json(self.station),
            "side": self.side,
            "angle": self.angle,
            "ref": self.ref,
            "y_from_top": dim_json(self.y_from_top),
            "tilt": float(self.tilt),
            "show_first_hole_ref": self.show_first_hole_ref,
            "label": self.label,
            "note": self.note,
        }

    @classmethod
    def from_json(cls, d: dict) -> "Attachment":
        return cls(
            part=d["part"],
            face=d.get("face", "top"),
            station=D(d["station"]) if d.get("station") not in (None, "") else None,
            side=d.get("side", "both"),
            angle=float(d.get("angle", 90.0)),
            ref=d.get("ref", "center"),
            y_from_top=D(d["y_from_top"]) if d.get("y_from_top") not in (None, "") else None,
            tilt=float(d.get("tilt", 0.0)),
            show_first_hole_ref=bool(d.get("show_first_hole_ref", False)),
            label=d.get("label", ""),
            note=d.get("note", ""),
        )


@dataclass
class Part:
    mark: str
    kind: str  # plate | clip | stub | bracket | mark (weld location only, no material)
    thk: Optional[Dim] = None  # plate/clip
    width: Optional[Dim] = None
    length: Optional[Dim] = None
    holes: list[Hole] = field(default_factory=list)
    section: Optional[str] = None  # stub
    cut_length: Optional[Dim] = None  # stub
    attachments: list[Attachment] = field(default_factory=list)  # stub sub-parts (station from stub root)
    unit_weight: Optional[Decimal] = None  # override / catalog weight (brackets, formed clips)
    description: str = ""  # override of the BOM description
    symbol: dict = field(default_factory=dict)  # bracket schematic: {"w": in, "h": in}
    drawing_ref: str = ""
    source: str = "shop-standard"  # provenance of the definition
    notes: str = ""

    # ---- derived -----------------------------------------------------
    def bom_description(self) -> str:
        if self.description:
            return self.description
        if self.kind in ("plate", "clip"):
            return f'{self.thk.fmt()}x{self.width.fmt()}x{self.length.fmt()}'
        if self.kind == "stub":
            return f"{self.section} X {self.cut_length.fmt()}"
        if self.kind == "bracket":
            return "BRACKET"
        return self.mark

    def weight(self, policy: WeightPolicy) -> Decimal:
        if self.unit_weight is not None:
            return self.unit_weight
        if self.kind in ("plate", "clip"):
            if self.symbol.get("cut_contour") or self.symbol.get("contour"):
                pts = [
                    (D(x).inches, D(y).inches) for x, y in (self.symbol.get("cut_contour") or self.symbol["contour"])
                ]
                area = abs(sum(x1 * y2 - x2 * y1 for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]))) / 2
                vol = area * self.thk.inches
                return policy._q(
                    policy.density_lb_in3 * Decimal(vol.numerator) / Decimal(vol.denominator),
                    policy.plate_decimals,
                    policy.plate_mode,
                )
            return policy.plate(self.thk, self.width, self.length)
        if self.kind == "stub":
            s = sections.get_section(self.section)
            return policy.member(s.plf, self.cut_length)
        raise ValueError(f"part {self.mark}: no weight available (brackets need unit_weight from their drawing)")

    def has_weight(self) -> bool:
        try:
            self.weight(WeightPolicy())
            return True
        except Exception:
            return False

    def hole_dia(self) -> Optional[Dim]:
        return self.holes[0].dia if self.holes else None

    def to_json(self) -> dict:
        return {
            "mark": self.mark,
            "kind": self.kind,
            "thk": dim_json(self.thk),
            "width": dim_json(self.width),
            "length": dim_json(self.length),
            "holes": [h.to_json() for h in self.holes],
            "section": self.section,
            "cut_length": dim_json(self.cut_length),
            "attachments": [a.to_json() for a in self.attachments],
            "unit_weight": None if self.unit_weight is None else str(self.unit_weight),
            "description": self.description,
            "symbol": self.symbol,
            "drawing_ref": self.drawing_ref,
            "source": self.source,
            "notes": self.notes,
        }

    @classmethod
    def from_json(cls, d: dict) -> "Part":
        def od(k):
            v = d.get(k)
            return D(v) if v not in (None, "") else None

        uw = d.get("unit_weight")
        return cls(
            mark=d["mark"],
            kind=d.get("kind", "plate"),
            thk=od("thk"),
            width=od("width"),
            length=od("length"),
            holes=[Hole.from_json(h) for h in d.get("holes", [])],
            section=(sections.normalize(d["section"]) if d.get("section") else None),
            cut_length=od("cut_length"),
            attachments=[Attachment.from_json(a) for a in d.get("attachments", [])],
            unit_weight=Decimal(str(uw)) if uw not in (None, "") else None,
            description=d.get("description", ""),
            symbol=dict(d.get("symbol") or {}),
            drawing_ref=d.get("drawing_ref", ""),
            source=d.get("source", "shop-standard"),
            notes=d.get("notes", ""),
        )


def rect_holes(dia: Any, xs: Iterable[Any], ys: Iterable[Any]) -> list[Hole]:
    """Grid hole pattern helper: every x with every y."""
    dia = D(dia)
    return [Hole(D(x), D(y), dia) for y in ys for x in xs]


# --------------------------------------------------------------------------- members / assemblies
@dataclass
class EndCut:
    type: str = "square"  # square | bevel
    angle: float = 0.0  # bevel angle from square, degrees (positive = long point at top)

    def to_json(self) -> dict:
        return {"type": self.type, "angle": self.angle}

    @classmethod
    def from_json(cls, d: dict | None) -> "EndCut":
        d = d or {}
        return cls(d.get("type", "square"), float(d.get("angle", 0.0)))


@dataclass
class WebHoles:
    """A rectangular group of holes through the web."""

    station: Dim  # to the first hole column
    y_from_top: Dim  # to the first hole row
    dia: Dim
    cols: int = 1
    rows: int = 1
    pitch_x: Optional[Dim] = None
    pitch_y: Optional[Dim] = None
    note: str = ""

    def positions(self) -> list[tuple[Dim, Dim]]:
        px = self.pitch_x or Dim(Fraction(0))
        py = self.pitch_y or Dim(Fraction(0))
        return [(self.station + px * c, self.y_from_top + py * r) for r in range(self.rows) for c in range(self.cols)]

    def to_json(self) -> dict:
        return {
            "station": self.station.fmt(),
            "y_from_top": self.y_from_top.fmt(),
            "dia": self.dia.fmt(),
            "cols": self.cols,
            "rows": self.rows,
            "pitch_x": dim_json(self.pitch_x),
            "pitch_y": dim_json(self.pitch_y),
            "note": self.note,
        }

    @classmethod
    def from_json(cls, d: dict) -> "WebHoles":
        return cls(
            D(d["station"]),
            D(d["y_from_top"]),
            D(d["dia"]),
            int(d.get("cols", 1)),
            int(d.get("rows", 1)),
            D(d["pitch_x"]) if d.get("pitch_x") else None,
            D(d["pitch_y"]) if d.get("pitch_y") else None,
            d.get("note", ""),
        )


@dataclass
class MainMember:
    mark: str  # cut mark, e.g. RF-100
    section: str
    cut_length: Dim
    left_cut: EndCut = field(default_factory=EndCut)
    right_cut: EndCut = field(default_factory=EndCut)
    web_holes: list[WebHoles] = field(default_factory=list)
    derivation: str = ""  # how cut_length was obtained (wizard formula or "entered")

    @property
    def sec(self) -> sections.WSection:
        return sections.get_section(self.section)

    def to_json(self) -> dict:
        return {
            "mark": self.mark,
            "section": self.section,
            "cut_length": self.cut_length.fmt(),
            "left_cut": self.left_cut.to_json(),
            "right_cut": self.right_cut.to_json(),
            "web_holes": [w.to_json() for w in self.web_holes],
            "derivation": self.derivation,
        }

    @classmethod
    def from_json(cls, d: dict) -> "MainMember":
        return cls(
            mark=d["mark"],
            section=sections.normalize(d["section"]),
            cut_length=D(d["cut_length"]),
            left_cut=EndCut.from_json(d.get("left_cut")),
            right_cut=EndCut.from_json(d.get("right_cut")),
            web_holes=[WebHoles.from_json(w) for w in d.get("web_holes", [])],
            derivation=d.get("derivation", ""),
        )


@dataclass
class Assembly:
    mark: str  # shop/assembly mark, e.g. RF1-9
    kind: str  # COLUMN | RAFTER | BEAM ...
    qty: int
    main: MainMember
    attachments: list[Attachment] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    derivation: dict = field(default_factory=dict)  # wizard parameters if generated
    date: str = ""  # sheet date override

    def to_json(self) -> dict:
        return {
            "mark": self.mark,
            "kind": self.kind,
            "qty": self.qty,
            "main": self.main.to_json(),
            "attachments": [a.to_json() for a in self.attachments],
            "notes": list(self.notes),
            "derivation": self.derivation,
            "date": self.date,
        }

    @classmethod
    def from_json(cls, d: dict) -> "Assembly":
        return cls(
            mark=d["mark"],
            kind=d.get("kind", "BEAM"),
            qty=int(d.get("qty", 1)),
            main=MainMember.from_json(d["main"]),
            attachments=[Attachment.from_json(a) for a in d.get("attachments", [])],
            notes=list(d.get("notes", [])),
            derivation=dict(d.get("derivation") or {}),
            date=d.get("date", ""),
        )


@dataclass
class Job:
    job_no: str
    customer: str
    building: str = "Main Bldg."
    date: str = ""
    checked_by: str = ""
    parts: dict[str, Part] = field(default_factory=dict)
    assemblies: dict[str, Assembly] = field(default_factory=dict)
    weights: WeightPolicy = field(default_factory=WeightPolicy)
    settings: dict = field(default_factory=dict)

    # ---- lookups -------------------------------------------------------
    def part(self, mark: str) -> Part:
        try:
            return self.parts[mark]
        except KeyError:
            raise KeyError(f"part {mark!r} is not defined in job {self.job_no}") from None

    def to_json(self) -> dict:
        return {
            "job_no": self.job_no,
            "customer": self.customer,
            "building": self.building,
            "date": self.date,
            "checked_by": self.checked_by,
            "parts": {k: p.to_json() for k, p in self.parts.items()},
            "assemblies": {k: a.to_json() for k, a in self.assemblies.items()},
            "weights": self.weights.to_json(),
            "settings": self.settings,
        }

    @classmethod
    def from_json(cls, d: dict) -> "Job":
        return cls(
            job_no=str(d.get("job_no", "")),
            customer=d.get("customer", ""),
            building=d.get("building", "Main Bldg."),
            date=d.get("date", ""),
            checked_by=d.get("checked_by", ""),
            parts={k: Part.from_json(v) for k, v in (d.get("parts") or {}).items()},
            assemblies={k: Assembly.from_json(v) for k, v in (d.get("assemblies") or {}).items()},
            weights=WeightPolicy.from_json(d.get("weights")),
            settings=dict(d.get("settings") or {}),
        )

    def dumps(self) -> str:
        return json.dumps(self.to_json(), indent=2)

    @classmethod
    def loads(cls, s: str) -> "Job":
        return cls.from_json(json.loads(s))

    def revision(self) -> str:
        return "M-" + hashlib.sha256(json.dumps(self.to_json(), sort_keys=True).encode()).hexdigest()[:10]


# --------------------------------------------------------------------------- BOM
@dataclass
class BOMLine:
    part: str
    qty: int
    description: str
    unit_weight: Decimal
    kind: str

    @property
    def total(self) -> Decimal:
        if self.unit_weight is None:
            return None
        return (self.unit_weight * self.qty).quantize(Decimal("0.01"))

    def weight_text(self) -> str:
        """Sample convention: line weight printed with the part's own precision."""
        if self.unit_weight is None:
            return "UNKNOWN"
        t = self.unit_weight * self.qty
        return f"{t.normalize():f}" if t == t.to_integral() else f"{t.normalize():f}"


KIND_ORDER = {"main": 0, "bracket": 1, "plate": 2, "clip": 3, "stub": 4}


def _collect(job: Job, a: Assembly) -> list[tuple[str, int]]:
    """Flatten attachments (including stub sub-attachments) into (part, count)."""
    out: list[tuple[str, int]] = []
    for att in a.attachments:
        n = 2 if (att.side == "both" and att.face == "web") else 1
        out.append((att.part, n))
        p = job.part(att.part)
        if p.kind == "stub":
            for sub in p.attachments:
                m = 2 if (sub.side == "both" and sub.face == "web") else 1
                out.append((sub.part, m * n))
    return out


def bom(job: Job, a: Assembly) -> list[BOMLine]:
    pol = job.weights
    main_sec = a.main.sec
    lines: list[BOMLine] = [
        BOMLine(
            a.main.mark,
            1,
            f"{a.main.section}  X  {D(a.derivation['column_low_cut_in']).fmt()} LOW / BLANK {a.main.cut_length.fmt()}"
            if "column_low_cut_in" in a.derivation
            else f"{a.main.section}  X  {a.main.cut_length.fmt()}",
            pol.member(main_sec.plf, a.main.cut_length),
            "main",
        )
    ]
    counts: dict[str, int] = {}
    order: list[str] = []
    for mark, n in _collect(job, a):
        if mark not in counts:
            order.append(mark)
        counts[mark] = counts.get(mark, 0) + n
    rest = []
    for mark in order:
        p = job.part(mark)
        if p.kind == 'mark':
            continue  # weld location only (flush girt welded to the web): no part, nothing to list
        rest.append(BOMLine(mark, counts[mark], p.bom_description(), p.weight(pol), p.kind))
    # sample ordering: brackets, end/base plates, clips, stubs (stable within a kind)
    rest.sort(key=lambda l: KIND_ORDER.get(l.kind, 9))
    return lines + rest


def total_weight(lines: list[BOMLine]) -> Decimal:
    if any(l.total is None for l in lines):
        return None
    return sum((l.total for l in lines), Decimal("0")).quantize(Decimal("0.01"))


def fmt_weight(v: Decimal, kind: str) -> str:
    """Print like the samples: members 2 decimals, plates 1 decimal (2 when needed), brackets as given."""
    if v is None:
        return "UNKNOWN"
    if kind in ("main", "stub"):
        return f"{v:.2f}"
    s = f"{v.normalize():f}"
    if "." not in s:
        s += ".0"
    return s


# --------------------------------------------------------------------------- validation
@dataclass
class ModelIssue:
    severity: str  # error | warning | info
    assembly: str
    text: str

    def to_json(self) -> dict:
        return dataclasses.asdict(self)


def validate(job: Job) -> list[ModelIssue]:
    out: list[ModelIssue] = []
    for a in job.assemblies.values():
        L = a.main.cut_length
        if not sections.has_section(a.main.section):
            out.append(ModelIssue("error", a.mark, f"main member section {a.main.section!r} not in catalog"))
        if L.inches <= 0:
            out.append(ModelIssue("error", a.mark, "cut length must be positive"))
        if not L.is_on_grid():
            out.append(ModelIssue("warning", a.mark, f"cut length {L.fmt()} is not on the 1/16\" grid"))
        for check in a.derivation.get("clip_clearances", []):
            for warning in check["warnings"]:
                out.append(ModelIssue("warning", check["owner"], warning))
        for end, wall in a.derivation.get('endwalls', {}).items():
            if wall.get('config', {}).get('supplier_fit_retired'):
                out.append(
                    ModelIssue(
                        'warning',
                        a.mark + ' ' + end,
                        'Prior channel fit confirmation retired after supplier change; confirm actual new product fit explicitly.',
                    )
                )
            if wall.get('roof_depth_fit', {}).get('status') == 'FAIL':
                out.append(
                    ModelIssue(
                        'error',
                        a.mark + ' ' + end,
                        'END ROOF FIT FAIL: selected purlin plus total clearance exceeds available channel/rafter depth. See endwall fit record.',
                    )
                )
        additions = a.derivation.get('framing_additions', {})
        for lean in additions.get('lean_tos', []):
            for warning in lean['issues']:
                out.append(ModelIssue('warning', a.mark + ' ' + lean['id'], warning))
        for opening in additions.get('openings', []):
            for warning in opening['issues']:
                out.append(
                    ModelIssue(
                        'error' if warning.startswith(('NO VALID', 'CLASH', 'UPRIGHT')) else 'warning',
                        a.mark + ' ' + opening['id'],
                        warning,
                    )
                )
            if opening['moves']:
                out.append(
                    ModelIssue(
                        'warning',
                        a.mark + ' ' + opening['id'],
                        'OPENING AUTO-RELOCATED from '
                        + str(opening['requested_x_in'])
                        + ' to '
                        + str(opening['x_in'])
                        + ' inches. Uprights unchanged.',
                    )
                )
        for warning in a.derivation.get("secondary_warnings", []):
            out.append(ModelIssue("warning", a.mark, warning))
        seen_end = set()
        for att in a.attachments:
            if att.part not in job.parts:
                out.append(ModelIssue("error", a.mark, f"attachment references undefined part {att.part!r}"))
                continue
            p = job.parts[att.part]
            if att.face not in FACES:
                out.append(ModelIssue("error", a.mark, f"{att.part}: unknown face {att.face!r}"))
            if att.face in ("left_end", "right_end"):
                if att.face in seen_end:
                    out.append(ModelIssue("warning", a.mark, f"more than one part on {att.face}"))
                seen_end.add(att.face)
            else:
                if att.station is None:
                    out.append(ModelIssue("error", a.mark, f"{att.part} on {att.face}: station missing"))
                elif att.station.inches < 0 or att.station.inches > L.inches:
                    out.append(
                        ModelIssue(
                            "warning" if att.note.startswith("peak ") else "error",
                            a.mark,
                            f"{att.part}: station {att.station.fmt()} outside member length {L.fmt()}",
                        )
                    )
                elif not att.station.is_on_grid() and not a.derivation.get("frame_id"):
                    # generated frames carry derived (plate-thickness) stations at full precision
                    out.append(
                        ModelIssue("warning", a.mark, f"{att.part}: station {att.station.fmt()} not on 1/16\" grid")
                    )
            if att.face == "web" and att.y_from_top is None and p.kind != "bracket":
                out.append(ModelIssue("error", a.mark, f"{att.part} on web: y_from_top missing"))
            if not p.has_weight():
                out.append(
                    ModelIssue("error", a.mark, f"{att.part}: no weight (bracket weight must come from its drawing)")
                )
            if p.kind == "stub" and not sections.has_section(p.section or ""):
                out.append(ModelIssue("error", a.mark, f"stub {att.part}: section {p.section!r} not in catalog"))
            if p.kind in ("plate", "clip") and None in (p.thk, p.width, p.length):
                out.append(ModelIssue("error", a.mark, f"{att.part}: plate size incomplete"))
        for wh in a.main.web_holes:
            last = wh.station + (wh.pitch_x or Dim(Fraction(0))) * (wh.cols - 1)
            if last.inches > L.inches:
                out.append(ModelIssue("error", a.mark, f"web holes at {wh.station.fmt()} run past the member end"))
            if wh.rows > 1 and wh.pitch_y is None or wh.cols > 1 and wh.pitch_x is None:
                out.append(ModelIssue("error", a.mark, "web hole group needs a pitch for multiple rows/cols"))
        if a.qty <= 0:
            out.append(ModelIssue("error", a.mark, "quantity must be >= 1"))
        # duplicate attachment at the same place
        seen_pos: set[tuple] = set()
        for att in a.attachments:
            key = (att.part, att.face, str(att.station.inches) if att.station else "", att.side)
            if att.face not in ("left_end", "right_end") and key in seen_pos:
                out.append(
                    ModelIssue("warning", a.mark, f"{att.part} listed twice on {att.face} at {att.station.fmt()}")
                )
            seen_pos.add(key)
    # one cut mark = one section + one length across the job
    cuts: dict[str, tuple[str, Dim, str]] = {}
    for a in job.assemblies.values():
        key = a.main.mark
        if key in cuts:
            sec0, len0, where = cuts[key]
            if sec0 != a.main.section or len0 != a.main.cut_length:
                out.append(
                    ModelIssue(
                        "error",
                        a.mark,
                        f"cut mark {key} is {a.main.section} {a.main.cut_length.fmt()} here but "
                        f"{sec0} {len0.fmt()} in {where} - use a different cut mark",
                    )
                )
        else:
            cuts[key] = (a.main.section, a.main.cut_length, a.mark)
    for mark in job.settings.get("connections", {}):
        p = job.parts.get(mark)
        if not p:
            out.append(ModelIssue("error", mark, "Connection model is missing"))
            continue
        for note in p.symbol.get("pending", []):
            out.append(ModelIssue("warning", mark, note))
    # part marks that are also cut marks or assembly marks
    for mark in job.parts:
        if mark in cuts or mark in job.assemblies:
            out.append(ModelIssue("warning", "-", f"part mark {mark} is also used as a cut or assembly mark"))
    # Policy / disclaimer wording never blocks or clutters the issue list;
    # it stays available in the derivation records themselves.
    from . import holds

    return [i for i in out if i.severity == 'error' or not holds.is_disclaimer(i.text)]


def has_errors(issues: list[ModelIssue]) -> bool:
    return any(i.severity == "error" for i in issues)
