"""Editable endwall setout and geometric contacts. No capacity or weld schedule."""

import copy
import math

from .cladding import fmt, inch
from .opening_rules import section_for


def normalize(rec):
    mode = rec.get('post_layout', 'bays')
    if mode not in ('standard', 'bays', 'stations'):
        raise ValueError('Endwall post layout must be standard, bays or stations')
    values = rec.get('post_stations', [])
    if isinstance(values, str):
        values = [v.strip() for v in values.split(',') if v.strip()]
    if not isinstance(values, list):
        raise ValueError('Post stations must be a list or comma-separated dimensions')
    values = [inch(v) for v in values]
    if any(not math.isfinite(v) for v in values):
        raise ValueError('Post stations must be finite')
    if len(values) > 39 or len(set(values)) != len(values):
        raise ValueError('At most39 distinct interior post stations')
    return dict(post_layout=mode, post_stations=values)


def plans(p, end, cfg, positions, outer, inner, tag):
    """Return physical post definitions in canonical endwall coordinates.
    User stations and opening X are outside-view coordinates; reverse rear once.
    """
    W = float(p.width.inches)
    reverse = end == 'rear_end'
    face = 'rear' if reverse else 'front'
    out = [
        dict(x=positions[0], profile=outer, mark=tag + '-P01', role='outer column'),
        dict(x=positions[-1], profile=outer, mark=tag + '-P' + str(len(positions)).zfill(2), role='outer column'),
    ]
    if cfg['post_layout'] == 'stations':
        # U-index follows the entered list, not the spatial sort, so moving a station
        # without inserting/deleting entries retains its mark.
        for i, x in enumerate(cfg['post_stations']):
            out.append(
                dict(
                    x=W - x if reverse else x,
                    profile=inner,
                    mark=tag + '-U' + str(i + 1).zfill(2),
                    role='bearing post' if cfg['type'] == 'bearing_endwall' else 'wall post (nonbearing)',
                )
            )
    else:
        for i, x in enumerate(positions[1:-1], 2):
            out.append(
                dict(
                    x=x,
                    profile=inner,
                    mark=tag + '-P' + str(i).zfill(2),
                    role='bearing post' if cfg['type'] == 'bearing_endwall' else 'wall post (nonbearing)',
                )
            )
    for o in [] if end == 'outer_front_end' else p.cladding.get('openings', []):
        rec = p.additions.get('opening_members', {}).get(o['id'], {})
        if o['surface'] != face or rec.get('jamb_role') != 'roof_bearing':
            continue
        pr = section_for(p, rec, 'jamb', 'endwall_girt')
        pr = dict(pr, web=None, flange=None)
        x = o['x_in']
        w = o['width_in']
        jw = pr['width']
        for side, pos in [('JL', x - jw / 2), ('JR', x + w + jw / 2)]:
            out.append(
                dict(
                    x=W - pos if reverse else pos,
                    profile=copy.deepcopy(pr),
                    mark=p.column_mark + '-OP-' + o['id'] + '-' + side,
                    role='roof-bearing opening jamb',
                    opening_id=o['id'],
                    opening_side=side,
                    roles=['endwall roof post', 'opening jamb', 'direct girt receiver'],
                )
            )
    out.sort(key=lambda r: r['x'])
    for r in out:
        if r['role'] != 'outer column' and not positions[0] < r['x'] < positions[-1]:
            raise ValueError(r['mark'] + ': interior post must lie between the corner posts')
    for a, b in zip(out, out[1:]):
        wa = a['profile'].get('along_wall_in', a['profile']['width'])
        wb = b['profile'].get('along_wall_in', b['profile']['width'])
        if a['x'] + wa / 2 > b['x'] - wb / 2 + 1e-8:
            raise ValueError(
                'Endwall post envelopes overlap: '
                + a['mark']
                + ' / '
                + b['mark']
                + '. Move the unrelated post explicitly; no duplicate post removed automatically.'
            )
    return out


def girt_between(p, a, b, y):
    """A shared-jamb opening removes its own through-girt/base angle below head.
    Above head the bay remains. Unrelated posts are never removed.
    """
    if not a.get('opening_id') or a.get('opening_id') != b.get('opening_id'):
        return True
    o = next(o for o in p.cladding['openings'] if o['id'] == a['opening_id'])
    return not o['y_in'] - 1e-8 <= y < o['y_in'] + o['height_in'] - 1e-8


def endpoint_records(row, a, b, p):
    row.update(left_support=a['mark'], right_support=b['mark'])
    if not (a.get('opening_id') or b.get('opening_id')):
        return
    # Envelope endpoints at the sides of the post facing this run. These are
    # setout references, not verified contact/web planes for machining.
    x0 = a['x'] + a['width'] / 2 if a.get('opening_id') else a['x']
    x1 = b['x'] - b['width'] / 2 if b.get('opening_id') else b['x']
    insertions = []
    receiver_faces = []
    if row['role'] == 'endwall girt':
        for post, side in [(a, 'left'), (b, 'right')]:
            if not post.get('opening_id'):
                continue
            o = next(o for o in p.cladding['openings'] if o['id'] == post['opening_id'])
            amount = (
                inch(p.additions['opening_members'][o['id']].get('girt_insertion', '0'))
                if row['role'] == 'endwall girt' and row['y0_in'] < o['y_in'] + o['height_in']
                else 0
            )
            face_x = a['x'] + a['width'] / 2 if side == 'left' else b['x'] - b['width'] / 2
            profile = post['profile']
            open_channel = profile.get('family') == 'Channel' or bool(profile.get('open_face'))
            end_gap = 0.25 if open_channel and amount > 0 else 0.0
            if side == 'left':
                x0 -= amount
                x0 += end_gap
            else:
                x1 += amount
                x1 -= end_gap
            if amount:
                insertions.append(
                    dict(
                        side=side,
                        opening_id=o['id'],
                        insertion_in=amount,
                        entry_plane_in=face_x,
                    )
                )
            receiver_faces.append(
                dict(
                    endpoint_side=side,
                    opening_id=o['id'],
                    jamb_mark=post['mark'],
                    jamb_side=post.get('opening_side', ''),
                    jamb_family=profile.get('family', ''),
                    receiver_face_x_in=face_x,
                    face_basis='SELECTED HSS OUTSIDE FACE'
                    if profile.get('family') == 'HSS'
                    else 'SELECTED OPEN-FACE CHANNEL WEB DATUM'
                    if open_channel
                    else 'SELECTED MEMBER NOMINAL ENVELOPE FACE',
                    requested_insertion_in=amount,
                    physical_end_gap_in=end_gap,
                    connection_geometry='1/4 IN CLEAR TO CHANNEL WEB' if end_gap else 'DIRECT TOUCH / ZERO GAP',
                    interface_status='GEOMETRY RESOLVED / 1/4 IN CHANNEL-WEB GAP'
                    if end_gap
                    else 'GEOMETRY RESOLVED / DIRECT CONTACT',
                )
            )
    if insertions:
        row['jamb_insertions'] = insertions
    if x1 <= x0:
        raise ValueError('Bearing-jamb girt receiving envelopes consume the span')
    row.update(x0_in=x0, x1_in=x1, reference_span_in=x1 - x0)
    contact_cut_resolved = False
    if row['role'] == 'endwall girt':
        for contact in row.get('end_contact_geometry', []):
            receiver = next((face for face in receiver_faces if face['jamb_mark'] == contact['support_mark']), None)
            if receiver:
                contact.update(
                    member_end_x_in=x0 if receiver['endpoint_side'] == 'left' else x1,
                    support_face=receiver['face_basis'],
                    physical_gap_in=receiver['physical_end_gap_in'],
                    geometry_status='1/4 IN GAP INSIDE OPEN-FACE CHANNEL'
                    if receiver['physical_end_gap_in'] == 0.25
                    else 'DIRECT CONTACT / ZERO GAP',
                )
        contacts = row.get('end_contact_geometry', [])
        if len(contacts) >= 2 and all(item.get('member_end_x_in') is not None for item in contacts[:2]):
            row['blank_length_in'] = max(item['member_end_x_in'] for item in contacts[:2]) - min(
                item['member_end_x_in'] for item in contacts[:2]
            )
            row['blank_length'] = fmt(row['blank_length_in'])
            contact_cut_resolved = True
    hss_jambs = [r for r in (a, b) if r.get('opening_id') and r['profile'].get('family') == 'HSS']
    if hss_jambs:
        # Endwall tube interfaces terminate at the selected outside face, square-cut,
        # with direct contact and no general end allowance. Flush girt lengths already
        # include both support-face deductions; bypass and base-angle blanks start from
        # the bay blank and therefore need the tube half-width removed.
        cut = row.get('blank_length_in')
        insertion = sum(x['insertion_in'] for x in insertions)
        channel_gaps = sum(face['physical_end_gap_in'] for face in receiver_faces)
        if cut is not None:
            if not contact_cut_resolved:
                if row['role'] == 'base angle' or p.girt_mode != 'flush':
                    cut -= sum(r['width'] / 2 for r in hss_jambs)
                cut += insertion - channel_gaps
            cut = math.floor(cut * 16 + 1e-9) / 16
        if cut is not None and cut > 0:
            row.update(
                reference_cut_in=cut,
                reference_cut=fmt(cut),
                blank_length_in=cut,
                blank_length=fmt(cut),
                estimated_weight_lb=round(cut / 12 * row['weight_lb_ft'], 2)
                if row.get('weight_lb_ft') is not None
                else None,
                status=(
                    'ENDWALL GIRT: SQUARE CUT TO SELECTED HSS OUTSIDE FACE; NO COPE; DIRECT TOUCH / ZERO GAP; '
                    + ('flush face deductions included' if p.girt_mode == 'flush' else 'tube half-width included')
                )
                if row['role'] == 'endwall girt'
                else 'BASE ANGLE: square cut to selected HSS outside face; no cope; tube half-width/end fit included',
                support_topology='DIRECT TO SHARED HSS BEARING JAMB OUTSIDE FACE; no ordinary jamb duplicate',
            )
        else:
            row.update(
                reference_cut_in=None,
                reference_cut='',
                blank_length_in=None,
                blank_length='',
                estimated_weight_lb=None,
                status='HSS JAMB CUT LENGTH NOT RESOLVED FROM SUPPORT ENVELOPES',
                support_topology='DIRECT TO SHARED HSS BEARING JAMB OUTSIDE FACE; no ordinary jamb duplicate',
            )
    else:
        cut = row.get('blank_length_in') if row['role'] == 'endwall girt' else None
        if cut is not None:
            insertion = sum(x['insertion_in'] for x in insertions)
            channel_gaps = sum(face['physical_end_gap_in'] for face in receiver_faces)
            if not contact_cut_resolved:
                cut += insertion - channel_gaps
            has_open_channel = any(
                face['face_basis'] == 'SELECTED OPEN-FACE CHANNEL WEB DATUM' for face in receiver_faces
            )
            row.update(
                reference_cut_in=cut,
                reference_cut=fmt(cut),
                blank_length_in=cut,
                blank_length=fmt(cut),
                estimated_weight_lb=round(cut / 12 * row['weight_lb_ft'], 2)
                if row.get('weight_lb_ft') is not None
                else None,
                status=(
                    'ENDWALL GIRT: CUT TO SHARED-JAMB ENVELOPE; DIRECT CONTACT AT BUTTED FACE; '
                    + ('1/4 IN WEB GAP ONLY INSIDE OPEN-FACE CHANNEL' if has_open_channel else 'ZERO-GAP CONTACT')
                ),
                support_topology='DIRECT TO SHARED BEARING JAMB; no ordinary jamb duplicate',
            )
        else:
            row.update(
                reference_cut_in=None,
                reference_cut='',
                blank_length_in=None,
                blank_length='',
                estimated_weight_lb=None,
                status='ENDWALL GIRT CUT NOT RESOLVED FROM SELECTED RECEIVER SETOUT',
                support_topology='DIRECT TO SHARED BEARING JAMB; no ordinary jamb duplicate',
            )
    if receiver_faces:
        total_fit = 0.0 if row['role'] == 'endwall girt' else None
        for face in receiver_faces:
            is_hss = face['jamb_family'] == 'HSS'
            face.update(
                specified_total_fit_allowance_in=total_fit,
                member_reference_cut_in=row.get('reference_cut_in'),
                member_cut_status=row['status'],
                fit_status=(
                    'Selected HSS outside face; square-cut end set to direct contact with a 0 in gap.'
                    if is_hss and row.get('reference_cut_in') is not None
                    else 'Selected nominal receiver envelope; cut setout resolved, with a 1/4 in gap only when entering an open-face channel.'
                    if row.get('reference_cut_in') is not None
                    else 'Receiver envelope is not available for this selected member.'
                ),
            )
        row['girt_receiving_interfaces'] = receiver_faces


def coordinate_opening_runs(job, p, model):
    """Segment endwall girt runs at opening jambs and set cut lengths from the actual contact planes.
    Work after relocation; remove old through-runs from counts. The specified insertion is retained;
    the only end gap is 1/4 in when a girt enters an open-face channel receiver.
    """
    for key, wall in job.assemblies[p.column_mark].derivation.get('endwalls', {}).items():
        if key == 'outer_front_end':
            continue
        face = 'front' if key == 'front_end' else 'rear'
        W = wall['width_in']
        new = []
        changed = False
        opening_contact_specs = {}
        openings = [
            o
            for o in model['openings']
            if o['face'] == face
            and p.additions['opening_members'][o['id']].get('coordinate_girts', False)
            and not o.get('connection_detail')
        ]
        for r in wall['members']:
            if r['role'] not in ('endwall girt', 'base angle'):
                new.append(r)
                continue
            spans = [(r['x0_in'], r['x1_in'], r.get('left_support'), r.get('right_support'))]
            affected = []
            for o in openings:
                if any(s.startswith(('CLASH', 'NO VALID', 'UPRIGHT')) for s in o['issues']):
                    continue
                if not o['y_in'] - 1e-8 <= r['y0_in'] < o['y_in'] + o['height_in'] - 1e-8:
                    continue
                opening_spec = p.additions['opening_members'][o['id']]
                amount = inch(opening_spec.get('girt_insertion', '0')) if r['role'] == 'endwall girt' else 0
                jamb_profile = section_for(p, opening_spec, 'jamb', 'endwall_girt')
                channel_gap = (
                    0.25 if r['role'] == 'endwall girt' and amount > 0 and jamb_profile.get('open_face') else 0.0
                )
                edge_face = o['jamb_face']
                if r['role'] == 'base angle' and opening_spec.get('opening_mode') == 'walk_slip_in':
                    edge_face = inch(opening_spec.get('walk_jamb_face', edge_face))
                lo = o['x_in'] - edge_face + amount - channel_gap
                hi = o['x_in'] + o['width_in'] + edge_face - amount + channel_gap
                lm = p.column_mark + '-OP-' + o['id'] + '-JL'
                rm = p.column_mark + '-OP-' + o['id'] + '-JR'
                if face == 'rear':
                    lo, hi = W - hi, W - lo
                    lm, rm = rm, lm
                opening_contact_specs[lm] = dict(
                    opening_id=o['id'],
                    gap_in=channel_gap,
                    support_face='OPEN-FACE CHANNEL WEB DATUM' if channel_gap else 'JAMB INSIDE FACE',
                )
                opening_contact_specs[rm] = dict(
                    opening_id=o['id'],
                    gap_in=channel_gap,
                    support_face='OPEN-FACE CHANNEL WEB DATUM' if channel_gap else 'JAMB INSIDE FACE',
                )
                updated = []
                for a, b, left, right in spans:
                    if b <= lo or a >= hi:
                        updated.append((a, b, left, right))
                        continue
                    if a < lo:
                        updated.append((a, lo, left, lm))
                    if b > hi:
                        updated.append((hi, b, rm, right))
                if updated != spans:
                    affected.append(o)
                spans = updated
            if not affected:
                new.append(r)
                continue
            changed = True
            for i, (a, b, left, right) in enumerate(spans, 1):
                row = copy.deepcopy(r)
                mark = r['mark'] + '-OPEN' + str(i)
                girt_cut = b - a if r['role'] == 'endwall girt' else None
                contacts = []
                if girt_cut is not None:
                    existing_contacts = {x['support_mark']: x for x in r.get('end_contact_geometry', [])}
                    endpoint_x = {'left': a, 'right': b}
                    for endpoint_side, support in (('left', left), ('right', right)):
                        spec = opening_contact_specs.get(support)
                        old_contact = existing_contacts.get(support)
                        if spec:
                            gap = spec['gap_in']
                            contacts.append(
                                dict(
                                    endpoint_side=endpoint_side,
                                    support_mark=support,
                                    opening_id=spec['opening_id'],
                                    support_face=spec['support_face'],
                                    member_end_x_in=endpoint_x[endpoint_side],
                                    physical_gap_in=gap,
                                    geometry_status='1/4 IN GAP INSIDE OPEN-FACE CHANNEL'
                                    if gap
                                    else 'DIRECT CONTACT / ZERO GAP',
                                )
                            )
                        elif old_contact:
                            contacts.append(dict(old_contact, endpoint_side=endpoint_side))
                    if len(contacts) == 2:
                        girt_cut = abs(contacts[1]['member_end_x_in'] - contacts[0]['member_end_x_in'])
                girt_status = (
                    'ENDWALL GIRT: CUT TO JAMB CONTACT SETOUT; ZERO GAP AT BUTTED SUPPORTS; '
                    '1/4 IN GAP ONLY INSIDE OPEN-FACE CHANNEL'
                    if girt_cut is not None
                    else 'BASE ANGLE SEGMENTED TO OPENING/JAMB ENVELOPE; GEOMETRIC LENGTH HELD'
                )
                row.update(
                    mark=mark,
                    parent_piece=r['mark'],
                    x0_in=a,
                    x1_in=b,
                    left_support=left,
                    right_support=right,
                    reference_span_in=b - a,
                    reference_cut_in=girt_cut,
                    reference_cut=fmt(girt_cut) if girt_cut is not None else '',
                    blank_length_in=girt_cut,
                    blank_length=fmt(girt_cut) if girt_cut is not None else '',
                    estimated_weight_lb=round(girt_cut / 12 * row['weight_lb_ft'], 2)
                    if girt_cut is not None and row.get('weight_lb_ft') is not None
                    else None,
                    end_contact_geometry=contacts,
                    status=girt_status,
                    girt_insertion_rule='Specified insertion retained; 1/4 in is the only gap to an open-face channel web.'
                    if girt_cut is not None
                    else 'Base-angle end detail outside this girt connection setout.',
                )
                new.append(row)
                model['girt_interruptions'].append(
                    dict(
                        mark=mark,
                        parent_piece=r['mark'],
                        face=face,
                        y_in=r['y0_in'],
                        x0_in=a if face == 'front' else W - b,
                        x1_in=b if face == 'front' else W - a,
                        cut_length_in=girt_cut,
                        reference_length_in=b - a,
                        opening_ids=[o['id'] for o in affected],
                        status=row['status'],
                    )
                )
            for o in affected:
                o['issues'] = [s for s in o['issues'] if not s.startswith('GIRT at ')]
                if r['role'] == 'base angle':
                    note = (
                        'Base-angle cut ends follow the opening/door-frame outside edge to the adjacent upright edge; '
                        'no connection design is specified, and anchors are by others.'
                    )
                    if note not in o['issues']:
                        o['issues'].append(note)
                    o['status'] = 'BASE-ANGLE EDGE SETOUT RESOLVED'
        if changed:
            wall['members'] = new
            groups = {}
            for r in new:
                key = (
                    r['role'],
                    r['profile_id'],
                    r['finish'],
                    r['reference_cut_in'],
                    r['blank_length_in'],
                    r['status'],
                )
                if key not in groups:
                    groups[key] = {
                        k: r[k]
                        for k in (
                            'role',
                            'profile_id',
                            'finish',
                            'reference_cut',
                            'reference_cut_in',
                            'blank_length',
                            'blank_length_in',
                            'status',
                        )
                    }
                    groups[key].update(cut_group='EW-SET-' + face + '-' + str(len(groups) + 1), quantity=0)
                groups[key]['quantity'] += r['quantity']
                r['cut_group'] = groups[key]['cut_group']
            wall['cuts'] = list(groups.values())
