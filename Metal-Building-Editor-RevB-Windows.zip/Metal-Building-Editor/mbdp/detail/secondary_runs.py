"""Equal-bay planning takeoff. Verified MBCI lap extents, not bolt/structural design."""

import copy
import hashlib
import json
import math
from decimal import Decimal
from fractions import Fraction

from . import sections
from .connections import f
from .model import D
from .purlin_lay import bays_text
from .secondary_catalog import get

SOURCE = dict(
    original_sha256='b0c31103e4ae6f6c8cb4ac718244b3259fe7d7b4ef327934b9f26d073ca78d0a',
    excerpt_sha256='5acbd168ac45332c90e2cc57021009760fb4332bed3b6420668ff8669764c873',
    title='MBCI Commercial/Industrial Technical Information',
    revision='00.02',
    publication_date=None,
    url='https://www.mbci.com/wp-content/uploads/Widen%20Assets/ManualsCI-Manual.pdf',
    scope='CI-20/21 lap LENGTH geometry only; no punching, fastener schedule or structural approval',
)
# back = right-hand piece projection LEFT of support CL; forward = left-hand
# piece projection RIGHT. Offset patterns follow the printed positive direction.
END_TYPES = {
    'bearing_endwall': 'Post-supported load-bearing endwall',
    'reduced_rigid': 'Reduced rigid frame (separate end-frame sections)',
    'rigid_frame': 'Main rigid frame (same as interior, counted in the frame lot)',
}

PATTERNS = {
    # Owner shop standard (v0.8.31): simple-span purlins and girts butt at the interior support
    # centreline (welded to the clip / the web), terminal bays keep the end clearance - 20 ft
    # bay with a bypass interior rafter and an open-face channel end rafter = 20'-0 less 1/4 in.
    'A_butt': dict(
        label='Simple span — butt at the support centreline (shop standard)', back=0, forward=0, page='', lap=0
    ),
    'A_simple': dict(
        label='A — Simple span (MBCI 1/4 in cutback each end)', back=-0.25, forward=-0.25, page='CI-20', lap=0
    ),
    'A_short': dict(label='A — Short lap 7 1/2 in', back=3.75, forward=3.75, page='CI-20', lap=7.5),
    'A_long': dict(label='A — Long lap 2 ft 3 1/2 in', back=13.75, forward=13.75, page='CI-20', lap=27.5),
    'A_offset3': dict(
        label='A — Three-foot offset lap 3 ft 3 1/2 in', back=13.75, forward=25.75, page='CI-20', lap=39.5
    ),
    'A_max': dict(label='A — Max lap 4 ft 3 1/2 in', back=25.75, forward=25.75, page='CI-20', lap=51.5),
    'B_offset5': dict(
        label='B — Five-foot offset lap 5 ft 3 1/2 in', back=25.75, forward=37.75, page='CI-21', lap=63.5
    ),
    'B_super': dict(label='B — Super lap 6 ft 3 1/2 in', back=37.75, forward=37.75, page='CI-21', lap=75.5),
}
SIMPLE_PATTERNS = ('A_butt', 'A_simple')


BYPASS_STATUS = 'BYPASS: purlin BEARS ON the rafter top flange; the end piece runs to the END RAFTER FLANGE OUTER EDGE (end of the frame - the RAKE ANGLE is welded over the purlin ends, 4 in leg down) and the interior pieces butt at the rafter CENTERLINE with no gap'


def evidence():
    data = dict(
        source=SOURCE,
        patterns=PATTERNS,
        simple_cutback_basis='2 in support CL to nearest bolt line minus 1 3/4 in end-to-hole = 1/4 in. Terminal clearances are explicit project inputs.',
    )
    data['sha256'] = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
    return data


def _sss_zee_default_lap(p, clean):
    """SSS Zee bypass standard: 12 in total lap centred on each rafter (owner round 16).

    SSS Zee stock is one foot longer than the bay (21 ft for 20 ft), which is exactly an
    interior piece at bay + 12 in.  An explicit ``0`` lap in the saved layout is a chosen
    butt and is not overridden; a designed MBCI lap pattern is also left alone.
    """
    if clean.get("purlin_mode") != "bypass" or clean.get("purlin_pattern") not in SIMPLE_PATTERNS:
        return False
    ident = ((getattr(p, "secondary", None) or {}).get("purlin") or {}).get("profile_id") or ""
    if not str(ident).startswith("SSS-"):
        return False
    try:
        return get(ident)["family"] == "Z"
    except ValueError:
        return False


def apply(p):
    raw = p.bay_layout
    if not isinstance(raw, dict):
        raise ValueError('Bay layout must be an object')
    if not isinstance(raw.get('enabled', False), bool):
        raise ValueError('Bay layout enabled must be true or false')
    if not raw.get('enabled'):
        p.bay_layout = {}
        return
    if not p.auto_connections:
        raise ValueError('Run layout requires managed whole-frame geometry')
    # A bay layout saved under an older rule set is re-applied with the current rules and re-stamped
    # (v0.8.41).  The old hard stop ("Saved MBCI lap rules differ; review and reselect patterns") locked
    # every job out after any wording change in the rules - an unknown pattern or direction is still
    # rejected below by name.
    try:
        count = int(raw.get('bays', 0))
        if count != float(raw.get('bays', 0)) or not 1 <= count <= 100:
            raise ValueError()
    except (ValueError, TypeError, OverflowError):
        raise ValueError('Equal bay count must be a whole number from 1 to 100')
    spacing = D(raw.get('spacing', '0'))
    if not 0 < spacing.inches <= 1200:
        raise ValueError('Bay spacing must be positive and at most 100 ft; no span capacity is implied')
    clean = dict(enabled=True, bays=count, spacing=spacing.fmt(), rule_sha256=evidence()['sha256'])
    # The zero-gap welded rule (end rafter outside edge / interior centre butts) is a BYPASS fit; a flush
    # purlin sits beside each rafter and takes the flush rule whatever an older job saved (round 16).
    clean['welded_zero_gap'] = bool(
        p.connection_style != 'bolted'
        and p.welded_fit_rules.get('enabled', False)
        and getattr(p, 'purlin_mode', 'bypass') != 'flush'
    )
    for key in ('layout_mode', 'max_spacing', 'length_basis', 'bay_lengths'):
        if key in raw:
            clean[key] = raw[key]
    for key in ('front_clearance', 'rear_clearance'):
        val = D(raw.get(key, '1/4'))
        if not 0 <= val.inches < spacing.inches:
            raise ValueError('Terminal clearance must be nonnegative and less than bay spacing')
        clean[key] = val.fmt()
    for role in ('purlin', 'girt'):
        pattern = raw.get(role + '_pattern', 'A_simple')
        direction = raw.get(role + '_direction', 'forward')
        if pattern not in PATTERNS:
            raise ValueError('Unknown MBCI lap pattern')
        if direction not in ('forward', 'reverse'):
            raise ValueError('Offset direction must be forward or reverse')
        if PATTERNS[pattern]['lap'] >= float(spacing.inches):
            raise ValueError('Lap zones consume the bay; increase spacing or choose another pattern')
        clean[role + '_pattern'] = pattern
        clean[role + '_direction'] = direction
        clean[role + '_mode'] = getattr(p, role + '_mode')
        if role == 'girt':
            clean['girt_attachment'] = getattr(p, 'girt_attachment', 'web_weld') or 'web_weld'
        for which in ('starting', 'middle'):
            key = role + '_' + which + '_clearance'
            if key in raw or clean[role + '_mode'] == 'flush':
                val = D(raw.get(key, '1/8' if clean[role + '_mode'] == 'flush' else '1/2'))
                if not 0 <= val.inches < spacing.inches:
                    raise ValueError('Bay clearance must be nonnegative and below bay spacing')
                clean[key] = val.fmt()
    # Owner (round 16): purlin stock lengths land on the rafter CENTRES.  Standard lay = one stock length
    # spans as many whole bays as it can (15 + 15 -> one 30 ft stick, 10 + 20 -> one 30 ft stick) and a
    # purlin is never spliced between rafters; 'per_bay' keeps one piece to a bay.  A Zee laps OVER a
    # rafter: the entered lap is the TOTAL lap, centred on the rafter centreline (each piece overhangs
    # half of it); blank = butt at the centreline.  (0.8.45 laid a run in stock lengths with joints
    # between the rafters - retired; the two keys it saved are dropped and say so.)
    lay = raw.get('purlin_lay') or 'span'
    if lay not in ('span', 'per_bay'):
        raise ValueError('Purlin lay must be stock lengths spanning bays or one piece per bay')
    clean['purlin_lay'] = lay
    retired = raw.get('purlin_stock_in') not in (None, '')
    if retired:
        p.applied_rules = [x for x in getattr(p, 'applied_rules', []) if not x.startswith('PURLIN LAY:')] + [
            'PURLIN LAY: the 0.8.45 stock-length lay (joints between the rafters) is retired - purlin joints '
            'land only on rafter centres; one stock length now spans whole bays.'
        ]
    elif raw.get('purlin_lap_in') not in (None, '') or _sss_zee_default_lap(p, clean):
        if raw.get('purlin_lap_in') in (None, ''):
            from .standards import SSS_ZEE_LAP_IN

            raw_lap = D(SSS_ZEE_LAP_IN)
        else:
            raw_lap = D(raw['purlin_lap_in'])
        lap = raw_lap
        shortest = min(D(x).inches for x in (clean.get('bay_lengths') or [spacing.fmt()]))
        if not 0 <= lap.inches < shortest:
            raise ValueError('Purlin lap must be nonnegative and shorter than the shortest bay')
        if lap.inches and clean['purlin_pattern'] not in SIMPLE_PATTERNS:
            raise ValueError('Enter a Zee lap over the rafter OR choose a designed lap pattern, not both')
        if lap.inches:
            clean['purlin_lap_in'] = lap.fmt()
    for end in ('front_end', 'rear_end'):
        e = raw.get(end) or {}
        if not isinstance(e, dict):
            raise ValueError('End support reference must be an object')
        typ = e.get('type', 'bearing_endwall')
        if typ not in END_TYPES:
            raise ValueError('Choose bearing endwall, reduced rigid end frame or main rigid frame')
        rec = dict(
            type=typ,
            column_section=e.get('column_section', ''),
            rafter_section=e.get('rafter_section', ''),
            post_spacing=e.get('post_spacing', ''),
            roof_mode=e.get('roof_mode') or 'follow',
        )  # FOLLOW = the end line is a rigid frame (no separate end wall); the end-wall model syncs FLUSH here when an end wall is framed
        if typ == 'rigid_frame':
            # The end line is one more frame of the primary lot (roof-only / open
            # buildings): its sections ARE the main sections and the roof fit
            # follows the interior lines.  Nothing is pending at this end.
            rec.update(
                column_section=p.column_section, rafter_section=p.rafter_section, post_spacing='', roof_mode='follow'
            )
        if rec['roof_mode'] not in ('follow', 'flush', 'bypass'):
            raise ValueError('Invalid end roof fit mode')
        for name in ('column_section', 'rafter_section'):
            if rec[name]:
                rec[name] = sections.get_section(rec[name]).name
        if rec['post_spacing']:
            st = D(rec['post_spacing'])
            if st.inches <= 0:
                raise ValueError('Endwall post spacing must be positive')
            if typ != 'bearing_endwall':
                raise ValueError('Post spacing applies only to a post-supported bearing endwall')
            rec['post_spacing'] = st.fmt()
        clean[end] = rec
    for role in ('purlin', 'girt', 'eave'):
        if (p.secondary.get(role) or {}).get('quantity') or (p.secondary.get(role) or {}).get('piece_length'):
            raise ValueError(
                'Clear manual '
                + role
                + ' order quantity/length before enabling automatic runs; they will not be silently added or replaced'
            )
    if clean.get('welded_zero_gap'):
        clean['purlin_starting_clearance'] = '0'
        clean['purlin_middle_clearance'] = '0'
    # Owner (round 15, the shop bypass rule): a BYPASS purlin bears ON the rafter top flange.  Its
    # terminal piece ends at the end-wall rafter flange OUTER EDGE (the edge of the frame - the rake
    # angle is welded over the purlin ends) and the interior pieces butt at the rafter centerline with
    # no gap.  A lap pattern still sets the interior overlaps (a Zee overhangs the intermediate
    # rafter); the terminal rule is what this flag changes.
    clean['bypass_end_rule'] = bool(p.connection_style != 'bolted' and clean['purlin_mode'] == 'bypass')
    p.bay_layout = clean
    if clean.get('layout_mode') in ('standard', 'explicit'):
        # The bay list IS the grid: the primary frame lot follows it (bay zones set their own)
        from .bay_zones import active

        if not active(p):
            p.frames = interior_frame_count(p, count)


def end_roof_fits(cfg, role, spans):
    """Explicit end-only roof overrides; unknown receiving webs hold those cuts.
    End web face is referenced from the saved support CENTERPLANE. This is not
    an invented channel-wall thickness or an inside-depth fit approval.
    """
    if role != 'purlin':
        return spans
    N = cfg['bays']
    for end, i, web_index in [('front_end', 0, 0), ('rear_end', N - 1, -1)]:
        mode = cfg.get(end, {}).get('roof_mode') or 'follow'
        if mode == 'follow' or mode == cfg.get('purlin_mode', 'bypass'):
            continue
        row = spans[i]
        web = cfg.get('purlin_webs', [None] * (N + 1))[web_index]
        channel_end = bool(cfg.get('purlin_channels', [False] * (N + 1))[web_index])
        if mode == 'flush' and channel_end and row.get('start_in') is not None and row.get('end_in') is not None:
            # Shop rule: the purlin sits inside the open-face channel 1/4 in from the channel web,
            # welded to the flanges top and bottom (20 ft bay, bypass interior -> 20'-0 1/4 less).
            from .standards import CHANNEL_PURLIN_SETBACK_IN as SETBACK

            if i == 0 and end == 'front_end':
                row['start_in'] = float(support_stations(cfg)[0]) + SETBACK
            else:
                row['end_in'] = float(support_stations(cfg)[-1]) - SETBACK
            length = row['end_in'] - row['start_in']
            if length <= 0:
                raise ValueError('End roof fit consumes purlin length')
            length = math.floor((length + 1e-9) * 16) / 16
            if end == 'front_end':
                row['start_in'] = row['end_in'] - length
            else:
                row['end_in'] = row['start_in'] + length
            row.update(
                cut_length_in=length,
                cut_length=D(Fraction(str(length))).fmt(),
                fit_status='MIXED END IN CHANNEL: bypass interior centerline to 1/4 in from the end channel web; welded to the channel flanges top and bottom',
            )
            continue
        kinds = cfg.get('purlin_kinds', [None] * (N + 1))
        flanges = cfg.get('purlin_flanges', [None] * (N + 1))
        if mode == 'bypass' and row.get('start_in') is not None and row.get('end_in') is not None:
            # Owner (round 15): at a BYPASS end rafter the purlin BEARS ON its top flange - the end
            # piece runs to the rafter flange OUTER EDGE, which is the end of the frame (the rake
            # angle is welded over the purlin ends, 4 in leg down over them).
            stations = support_stations(cfg)
            if i == 0 and end == 'front_end':
                row['start_in'] = 0.0
            else:
                row['end_in'] = float(stations[-1])
            length = row['end_in'] - row['start_in']
            if length <= 0:
                raise ValueError('End roof fit consumes purlin length')
            length = math.floor((length + 1e-9) * 16) / 16
            if end == 'front_end':
                row['start_in'] = row['end_in'] - length
            else:
                row['end_in'] = row['start_in'] + length
            row.update(
                cut_length_in=length,
                cut_length=D(Fraction(str(length))).fmt(),
                fit_status=(
                    'MIXED END BYPASS: the piece bears ON the bypass END RAFTER top flange to its flange '
                    'OUTER EDGE (end of the frame); the RAKE ANGLE is welded over the purlin ends, 4 in leg down'
                ),
            )
            continue
        if mode == 'flush' and kinds[web_index] == 'W' and flanges[web_index] is not None:
            # Owner (round 15): flush mount at a W end rafter - clip welded to the rafter web, the
            # piece square cut 1/8 in total per bay clear of the rafter flange edge.
            stations = support_stations(cfg)
            half = float(flanges[web_index]) / 2 + 1 / 16
            if i == 0 and end == 'front_end':
                row['start_in'] = half
            else:
                row['end_in'] = float(stations[-1]) - half
            length = row['end_in'] - row['start_in']
            if length <= 0:
                raise ValueError('End roof fit consumes purlin length')
            length = math.floor((length + 1e-9) * 16) / 16
            if end == 'front_end':
                row['start_in'] = row['end_in'] - length
            else:
                row['end_in'] = row['start_in'] + length
            row.update(
                cut_length_in=length,
                cut_length=D(Fraction(str(length))).fmt(),
                fit_status=(
                    'MIXED END FLUSH: clip welded to the W end rafter web, purlin top flush with the rafter '
                    'top flange; square cut 1/8 in total per bay clear of the rafter flange edge'
                ),
            )
            continue
        if mode == 'flush' and web is None:
            row.update(
                start_in=None,
                end_in=None,
                cut_length='',
                cut_length_in=None,
                fit_status='PENDING MIXED END FLUSH: actual receiving web thickness / face datum required',
            )
            continue
        if row.get('start_in') is None or row.get('end_in') is None:
            continue
        clearance = float(D(cfg['front_clearance' if end == 'front_end' else 'rear_clearance']).inches)
        offset = (float(web) / 2 if mode == 'flush' else 0) + clearance
        if i == 0 and end == 'front_end':
            row['start_in'] = offset
        else:
            row['end_in'] = float(support_stations(cfg)[-1]) - offset
        length = row['end_in'] - row['start_in']
        if length <= 0:
            raise ValueError('End roof fit consumes purlin length')
        length = math.floor((length + 1e-9) * 16) / 16
        if end == 'front_end':
            row['start_in'] = row['end_in'] - length
        else:
            row['end_in'] = row['start_in'] + length
        row.update(
            cut_length_in=length,
            cut_length=D(Fraction(str(length))).fmt(),
            fit_status='MIXED END '
            + mode.upper()
            + ': end support centerplane to web face plus entered end clearance; verify actual installed face',
        )
    return spans


def support_stations(cfg):
    lengths = cfg.get('bay_lengths') or [cfg['spacing']] * cfg['bays']
    out = [Fraction(0)]
    for x in lengths:
        out.append(out[-1] + D(x).inches)
    return out


def _has_sidewalls(p):
    """False when both sidewalls are OPEN (roof only, or end walls only): zero girt runs are intended there."""
    c = getattr(p, 'cladding', None)
    if not isinstance(c, dict) or not c.get('enabled'):
        return True
    from .enclosure import states

    st = states(p)
    return st.get('left') == 'sheeted' or st.get('right') == 'sheeted'


def interior_frame_count(p, N):
    """Interior rigid-frame lines in the grid.

    Plain buildings: every interior support line.  Zoned buildings: interior
    lines that are not an enclosed-junction end wall (those are framed by the
    end-wall model and counted there).
    """
    from .bay_zones import active, framing_key, stations

    if not active(p):
        return N - 1 + rigid_end_count(p)
    ss = stations(p)
    return len([x for x in ss[1:-1] if framing_key(p, x) is None])


def rigid_end_count(p):
    """End lines framed by a main rigid frame of the primary lot."""
    cfg = p.bay_layout if isinstance(p.bay_layout, dict) else {}
    return len([e for e in ('front_end', 'rear_end') if (cfg.get(e) or {}).get('type') == 'rigid_frame'])


def lay_rows(cfg, role, rows):
    """Owner (round 16): purlin stock lengths land on the rafter centres - see ``purlin_lay``.

    Rows laid one piece to a bay become pieces laid to stock lengths: one stick spans every whole bay it can
    (15 + 15 -> one 30 ft stick) and the joint between two sticks is always at a rafter centre, never
    between rafters.  Left alone: a flush run (it sits beside each rafter), a designed MBCI lap pattern
    (laps are the structural designer's), a run set to one piece per bay, and any joint over a junction
    end wall.  ``cfg['lay_stocks_in']`` carries the stock lengths the product is bought in.
    """
    stocks = cfg.get('lay_stocks_in')
    if (
        not stocks
        or role not in ('purlin', 'eave', 'high_eave')
        or cfg.get('purlin_lay', 'span') == 'per_bay'
        or cfg.get(role + '_mode') == 'flush'
        or len(rows) < 2
    ):
        return rows
    from .purlin_lay import lay

    if not (
        cfg.get(role + '_pattern') in SIMPLE_PATTERNS
        or (role == 'purlin' and (cfg.get('purlin_lap_in') or cfg.get('welded_zero_gap')))
    ):
        return rows
    blocked = set(cfg.get('lay_blocked') or ())
    return lay(rows, stocks, [(j + 1) not in blocked for j in range(len(rows) - 1)])


def _lap_note(lap):
    return (
        'ZEE LAP over the rafter: each piece overhangs the rafter centerline by '
        + D(Fraction(lap) / 2).fmt()
        + ' ('
        + D(Fraction(lap)).fmt()
        + ' total lap centred on the rafter)'
    )


def extents(cfg, role):
    N = cfg['bays']
    pattern = PATTERNS[cfg[role + '_pattern']]
    ss = support_stations(cfg)
    lap = D(cfg['purlin_lap_in']).inches if role == 'purlin' and cfg.get('purlin_lap_in') else Fraction(0)
    if role == 'purlin' and cfg.get('welded_zero_gap') and cfg.get('purlin_mode') != 'flush':
        rows = []
        for i in range(N):
            lo = ss[i] - (lap / 2 if i else 0)
            hi = ss[i + 1] + (lap / 2 if i < N - 1 else 0)
            rows.append(
                dict(
                    bay=i + 1,
                    start_in=float(lo),
                    end_in=float(hi),
                    cut_length=D(hi - lo).fmt(),
                    cut_length_in=float(hi - lo),
                    fit_status='USER WELDED: end rafter OUTSIDE EDGE at0/L; interior CENTER BUTT; ZERO end gap. Depth fit separate.'
                    + ('; ' + _lap_note(lap) if lap else ''),
                )
            )
        # An end wall whose roof fit differs from the main purlin fit (an open-face channel end rafter takes the
        # purlin INSIDE its flanges, 1/4 in from the web) overrides the old zero-gap end piece (round 16: the
        # saved owner job kept 20'-0 at a channel end).  Eave members sit on the column, not in the channel.
        if not cfg.get('eave_lane'):
            rows = end_roof_fits(cfg, role, rows)
        return lay_rows(cfg, role, rows)
    if cfg.get(role + '_mode') == 'flush':
        from .standards import CHANNEL_PURLIN_SETBACK_IN as SETBACK
        from .standards import CLIP_GIRT_CLEARANCE_IN, girt_web_clip

        webs = cfg.get(role + '_webs', [None] * (N + 1))
        channels = cfg.get(role + '_channels', [False] * (N + 1))
        flanges = cfg.get(role + '_flanges', [None] * (N + 1))
        copes = cfg.get(role + '_copes', [None] * (N + 1))
        offsets = cfg.get(role + '_offsets', [0.0] * (N + 1))
        kinds = cfg.get(role + '_kinds', [None] * (N + 1))
        clip_option = role == 'girt' and cfg.get('girt_attachment') == 'web_clip'
        clip = girt_web_clip(cfg.get('girt_depth_in') or 0) if clip_option else None
        # Flush mount PURLIN on a wide-flange rafter (owner, round 15): a CLIP is welded to the rafter
        # web and the purlin is square cut (no cope) 1/8 in clear of the rafter FLANGE edge - "inside
        # to inside of the W flange less 1/8 in total per bay", the same for a C or a Z purlin.  A W
        # rafter is therefore a flange fit for a purlin, not a web fit (a flush GIRT still copes to
        # the column web).
        purlin_clip = role == 'purlin'
        out = []
        for i in range(N):
            clearance = D(
                cfg.get(role + ('_starting_clearance' if i in (0, N - 1) else '_middle_clearance'), '1/8')
            ).inches
            ends = (i, i + 1)
            # How the piece meets each support: inside an open-face channel (1/4 in from the web,
            # no clearance term), on a stock clip welded to a W web (inside to inside of the
            # flanges), or butted to the web (W, coped) / flat face (tube) - the owner's web rule.
            modes = []
            for k in ends:
                if channels[k]:
                    modes.append('channel')
                elif purlin_clip and kinds[k] == 'W' and flanges[k] is not None:
                    modes.append('purlin_clip')
                elif clip_option and kinds[k] == 'W' and flanges[k] is not None:
                    modes.append('clip')
                elif webs[k] is not None:
                    modes.append('face' if kinds[k] == 'HSS' else 'web')
                else:
                    modes.append(None)
            if None in modes:
                out.append(
                    dict(
                        bay=i + 1,
                        start_in=None,
                        end_in=None,
                        cut_length='',
                        cut_length_in=None,
                        fit_status='PENDING END SUPPORT FLANGE WIDTH'
                        if clip_option
                        else 'PENDING END SUPPORT WEB THICKNESS',
                    )
                )
                continue
            # Clearance only on a piece that is butted / clipped at BOTH ends: an end inside an open
            # face carries the leeway itself (1/4 in from the web) - owner: "10' minus column minus
            # 1/4 on the open side, 10' minus column minus 1/8 on the face side"
            butt = [m for m in modes if m != 'channel']
            total = Fraction(0)
            if len(butt) == 2:
                if 'purlin_clip' in modes:
                    total = Fraction(1, 8)  # 1/8 in TOTAL per bay, split between the two flange edges
                else:
                    total = Fraction(str(CLIP_GIRT_CLEARANCE_IN)) if 'clip' in butt else clearance
            share = total / 2 if total else Fraction(0)

            def deduction(k, mode):
                off = Fraction(str(offsets[k]))
                if mode == 'channel':
                    return Fraction(str(SETBACK))  # web inner face on the station
                if mode == 'purlin_clip':
                    # the rafter FLANGE occupies bf/2 each side of the frame line at purlin level
                    return off + Fraction(str(flanges[k])) / 2 + share
                if mode == 'clip':
                    return off + Fraction(str(flanges[k])) / 2 + share
                return off + Fraction(str(webs[k])) / 2 + share

            start = ss[i] + deduction(i, modes[0])
            end = ss[i + 1] - deduction(i + 1, modes[1])
            if end <= start:
                raise ValueError('Support contacts and clearance consume the flush bay')
            # Round shorter, never consuming the specified minimum clearance.
            length = Fraction((end - start) * 16 // 1, 16)
            extra = ((end - start) - length) / 2
            start += extra
            end -= extra
            n_channel = modes.count('channel')
            if 'purlin_clip' in modes:
                status = (
                    'FLUSH MOUNT: clip welded to the rafter web, purlin top flush with the rafter top flange; square cut (no cope) '
                    + (
                        '1/8 in total clear of the rafter flange edge across the bay (inside to inside of the W flange)'
                        if modes.count('purlin_clip') == 2
                        else '1/8 in clear of the rafter flange edge at the clipped end'
                    )
                    + (
                        '; IN CHANNEL at the other end (1/4 in from the web, welded to the flanges)'
                        if n_channel
                        else ''
                    )
                )
            elif n_channel == 2:
                status = (
                    'IN CHANNEL: 1/4 in from the channel web each end; welded to the channel flanges top and bottom'
                )
            elif 'clip' in modes:
                status = 'WEB CLIP: inside to inside of the column flanges less 1/4 in total; ' + (
                    f'{clip[0]} x {clip[1]} plate clip welded to the web each end ({clip[1]} in side welded, {clip[0]} in sticking out), girt welded to the clip'
                    if clip
                    else 'clip size for this girt depth is not in the shop table (6 in 3x5, 8 in 5x7, 10 in 7x9)'
                )
                if n_channel:
                    status = 'IN CHANNEL one end (1/4 in from the web) / ' + status.replace(
                        'less 1/4 in total', 'no clearance term (the open face carries the leeway)'
                    )
            else:
                faces = ' / '.join(
                    ('inside the open face' if m == 'channel' else 'tube flat face' if m == 'face' else 'column web')
                    for m in modes
                )
                status = (
                    ('IN CHANNEL one end (1/4 in from the web, welded to the flanges) / ' if n_channel else '')
                    + 'WEB WELD: welded directly to the support ('
                    + faces
                    + (
                        '); bay less half the contact each end less 1/8 in total'
                        if not n_channel
                        else '); bay less the contact, no clearance term (the open face carries the leeway)'
                    )
                    + (
                        '; coped around the column flange so the girt face matches the outside flange'
                        if role == 'girt' and any(copes[k] for k in ends)
                        else ''
                    )
                )
            if any(offsets[k] for k in ends):
                status += '; corner member outside face on the end wall line (half the flange width / tube added)'
            rec = dict(
                bay=i + 1,
                start_in=float(start),
                end_in=float(end),
                cut_length=D(end - start).fmt(),
                cut_length_in=float(end - start),
                fit_status=status,
                end_fits=[
                    dict(
                        end=which,
                        mode=modes[j],
                        offset_in=float(offsets[k]),
                        deduction_in=float(deduction(k, modes[j])),
                    )
                    for j, (which, k) in enumerate((('start', i), ('end', i + 1)))
                ],
            )
            if role == 'girt':
                cope_ends = [
                    dict(end=which, **copes[k])
                    for j, (which, k) in enumerate((('start', i), ('end', i + 1)))
                    if copes[k] and modes[j] == 'web'
                ]
                if cope_ends:
                    rec['copes'] = cope_ends
                clip_ends = [
                    dict(end=which, stick_out_in=clip[0], welded_in=clip[1]) if clip else dict(end=which)
                    for j, (which, k) in enumerate((('start', i), ('end', i + 1)))
                    if modes[j] == 'clip'
                ]
                if clip_ends:
                    rec['web_clips'] = clip_ends
            out.append(rec)
        return end_roof_fits(cfg, role, out)
    back = Fraction(str(pattern['back']))
    forward = Fraction(str(pattern['forward']))
    if cfg[role + '_direction'] == 'reverse':
        back, forward = forward, back
    if lap:
        back = forward = lap / 2
    out = []
    end_rule = role == 'purlin' and cfg.get('bypass_end_rule')
    for i in range(N):
        start = ss[i] - back if i else D(cfg['front_clearance']).inches
        end = ss[i + 1] + forward if i < N - 1 else ss[-1] - D(cfg['rear_clearance']).inches
        key = role + ('_starting_clearance' if i in (0, N - 1) else '_middle_clearance')
        if cfg[role + '_pattern'] in SIMPLE_PATTERNS and key in cfg and not lap:
            total = D(cfg[key]).inches
            start = ss[i] + total / 2
            end = ss[i + 1] - total / 2
        if end_rule and i == 0:
            start = 0.0  # the end rafter flange OUTER edge is the end wall line
        if end_rule and i == N - 1:
            end = float(ss[-1])
        if end <= start:
            raise ValueError('End clearances leave a nonpositive secondary piece length')
        row = dict(
            bay=i + 1,
            start_in=float(start),
            end_in=float(end),
            cut_length=D(end - start).fmt(),
            cut_length_in=float(end - start),
        )
        if lap:
            row['fit_status'] = ((BYPASS_STATUS + '; ' if end_rule else 'SIMPLE SPAN CUT; ') + _lap_note(lap)).replace(
                'interior pieces butt at the rafter CENTERLINE with no gap', 'interior pieces LAP over the rafter'
            )
        out.append(row)
    return lay_rows(cfg, role, end_roof_fits(cfg, role, out))


def finish(job, p):
    if not p.bay_layout:
        return
    cfg = p.bay_layout
    fid = p.column_mark
    l = job.settings['frame_layouts'][fid]
    owner = job.assemblies[fid]
    N = cfg['bays']
    cfg = copy.deepcopy(cfg)
    ss = support_stations(cfg)
    for role in ('purlin', 'girt'):

        def contact(ident, end=False):
            # contact envelope ALONG THE BUILDING LENGTH: W = web thickness (the piece is welded to
            # the web), tube = its width along the length (the piece butts the flat face)
            sec = sections.get_section(ident)
            return sec.bf if role == 'girt' and sec.kind == 'HSS' else sec.tw

        interior = contact(p.rafter_section if role == 'purlin' else p.column_section)

        def endweb(end):
            ident = cfg[end]['rafter_section' if role == 'purlin' else 'column_section']
            return contact(ident, True) if ident else None

        def end_offset(end):
            # Bearing end wall (posts + end rafter): the end members stand with their OUTSIDE face on
            # the end wall line - a W corner column like a frame column (flange width along the
            # length, web at half the flange width), a tube at half its width; an open-face channel
            # has its web inner face on the station.  Rigid end frames stay centred on the line.
            e = cfg[end]
            ident = e['rafter_section' if role == 'purlin' else 'column_section']
            if not ident or e.get('type', 'bearing_endwall') != 'bearing_endwall':
                return 0.0
            sec = sections.get_section(ident)
            return 0.0 if sec.kind == 'Channel' else float(sec.bf) / 2

        cfg[role + '_webs'] = [endweb('front_end')] + [interior] * (N - 1) + [endweb('rear_end')]
        cfg[role + '_offsets'] = [end_offset('front_end')] + [0.0] * (N - 1) + [end_offset('rear_end')]

        def support_section(i):
            ident = None
            if i in (0, N):
                end = cfg['front_end' if i == 0 else 'rear_end']
                ident = end['rafter_section' if role == 'purlin' else 'column_section'] or None
            else:
                ident = p.rafter_section if role == 'purlin' else p.column_section
            if getattr(p, 'bay_zones', {}).get('enabled'):
                from .bay_zones import framing_key

                key = framing_key(p, float(ss[i]))
                if key:
                    ident = p.endwalls[key]['resolved_rafter' if role == 'purlin' else 'resolved_column']
            return sections.get_section(ident) if ident else None

        supports = [support_section(i) for i in range(N + 1)]
        if getattr(p, 'bay_zones', {}).get('enabled'):
            from .bay_zones import framing_key

            for i, x in enumerate(ss):
                key = framing_key(p, float(x))
                if key:
                    cfg[role + '_webs'][i] = contact(
                        p.endwalls[key]['resolved_rafter' if role == 'purlin' else 'resolved_column'], True
                    )
        # Open-face channel supports (single or doubled): the purlin sits inside the open face
        # 1/4 in from the web - no web/clearance deduction (shop rule, v0.8.31).
        cfg[role + '_channels'] = [bool(sec is not None and sec.kind == 'Channel') for sec in supports]
        cfg[role + '_flanges'] = [None if sec is None else float(sec.bf) for sec in supports]
        cfg[role + '_kinds'] = [None if sec is None else sec.kind for sec in supports]
        if role == 'purlin':
            # Eave member at a side-welded corner column (carport standard): the column runs to the
            # roof line, so the eave member stops at the column's inside face along the length
            # (full width) instead of entering the end rafter channel.
            ends_cfg = p.endwalls if isinstance(getattr(p, 'endwalls', None), dict) else {}
            cfg['eave_end_faces'] = {}
            for i, end in ((0, 'front_end'), (N, 'rear_end')):
                head = (ends_cfg.get(end) or {}).get('post_head') if isinstance(ends_cfg.get(end), dict) else None
                ident = cfg[end].get('column_section')
                if head == 'side_welded' and ident and cfg[end].get('type', 'bearing_endwall') == 'bearing_endwall':
                    sec = sections.get_section(ident)
                    cfg['eave_end_faces'][i] = dict(width=float(sec.bf), kind=sec.kind, section=sec.name)
        if role == 'girt':
            from .standards import COPE_DEPTH_CLEARANCE_IN, COPE_LENGTH_CLEARANCE_IN

            cfg['girt_depth_in'] = f(p.girt_depth)
            # W column, girt welded to the web: cope the girt's outer flange for the column flange
            # (half flange width less half web, plus clearance; flange thickness plus clearance deep).
            cfg['girt_copes'] = [
                dict(
                    length_in=round((sec.bf - sec.tw) / 2 + COPE_LENGTH_CLEARANCE_IN, 4),
                    depth_in=round(sec.tf + COPE_DEPTH_CLEARANCE_IN, 4),
                    column=sec.name,
                )
                if sec is not None and sec.kind == 'W' and cfg.get('girt_attachment', 'web_weld') == 'web_weld'
                else None
                for sec in supports
            ]
    lanes = []

    def lane(role, side, position, clip_role, station=None):
        lanes.append(
            dict(
                run_id=f'{fid}-{role.upper()}-{len(lanes) + 1:03d}',
                role=role,
                side=side,
                frame_x_in=position[0],
                floor_y_in=position[1],
                clip_role=clip_role,
                station_from_cut_in=station,
            )
        )

    # Every modeled regular/peak station is one longitudinal row. Eave-start clips
    # are intentionally excluded; the eave strut rows below use those supports.
    for roof in l['rafters']:
        asm = job.assemblies[roof['mark']]
        records = []
        if l.get('welded'):
            records = [
                (r['station_top_in'], r['station_in'], r['role'])
                for r in l['clip_records']
                if r['role'] in ('regular', 'peak')
            ]
        else:
            for a in asm.attachments:
                if (
                    a.part == p.purlin_clip
                    and a.station is not None
                    and (a.note.startswith('purlin ') or a.note.startswith('peak '))
                ):
                    records.append((f(a.station), f(a.station), 'peak' if a.note.startswith('peak ') else 'regular'))
            peak = l.get('peak_clip')
            if peak and not any(r[2] == 'peak' for r in records):
                records.append((peak['station_in'], peak['station_in'], 'peak'))
        for st, cutst, role in records:
            s = roof['top_start']
            u = roof['direction']
            lane('purlin', roof['side'], [s[0] + u[0] * st, s[1] + u[1] * st], role, cutst)
    for col in l['columns']:
        asm = job.assemblies[col['mark']]
        seen = set()
        for a in asm.attachments:
            if a.part != p.girt_clip or a.station is None or not a.note.startswith('girt '):
                continue
            key = round(f(a.station), 6)
            if key in seen:
                continue
            seen.add(key)
            x = col['x0'] if col['side'] == 'left' else col['x1']
            lane('girt', col['side'], [x, col['y0'] + f(a.station)], 'girt', f(a.station))
    for start in l.get('starting_wall_runs', []):
        # Replace a coincident ordinary girt, not an unrelated elevated row.
        lanes[:] = [
            r
            for r in lanes
            if not (
                r['role'] == 'girt'
                and r['side'] == start['side']
                and abs(r['floor_y_in'] - start['elevation_in']) < 1e-6
            )
        ]
        lane(
            start['role'],
            start['side'],
            [start['x'], start['elevation_in']],
            'starting wall / slab' if p.slab else 'starting wall',
        )
    for i, col in enumerate(l['columns']):
        role = 'high_eave' if p.frame_type == 'monoslope' and i == 1 else 'eave'
        x = col['x0'] if col['side'] == 'left' else col['x1']
        # Eave location is a support-line reference, not a verified formed-section seat.
        lane(role, col['side'], [x, l['low_eave_in'] if i == 0 else l['high_eave_in']], 'starting eave support')
    if len(lanes) * N > 50000:
        raise ValueError('Run layout exceeds 50000 piece records; reduce bay/station count')
    used = {x['role'] for x in lanes}
    profiles = {}
    for role in used:
        chosen = p.base_angle if role == 'base_angle' else p.secondary.get('eave' if role == 'high_eave' else role)
        if not chosen or not chosen.get('profile_id'):
            raise ValueError(
                'Automatic runs require a selected supplier '
                + role
                + ' profile for the existing run locations (Building settings > step 4 - Secondaries > Purlin, girt & eave products'
                + (' / base angle' if role == 'base_angle' else '')
                + ')'
            )
        prof = get(chosen['profile_id'].replace('-low_', '-high_') if role == 'high_eave' else chosen['profile_id'])
        profiles[role] = (prof, chosen)
        if role in ('purlin', 'girt'):
            if prof.get('supplier') == 'sss' and cfg[role + '_pattern'] not in SIMPLE_PATTERNS:
                raise ValueError(
                    'SSS lap geometry is not supplied: select simple-span framing or supply reviewed SSS lap rules. MBCI laps are not transferred.'
                )
            pattern = cfg[role + '_pattern']
            d = prof['nominal_depth_in']
            fl = prof['flanges_in']
            if (d not in (6, 7, 8, 9, 10, 12) or (d == 12 and prof['family'] != 'Z')) and not (
                p.connection_style != 'bolted' and d == 4 and pattern in SIMPLE_PATTERNS
            ):
                raise ValueError(
                    role
                    + ': MBCI common-web pattern applicability is unconfirmed for this depth; select a verified 6–10 or 12 inch section'
                )
            if (
                not (role == 'purlin' and cfg.get('welded_zero_gap'))
                and cfg.get(role + '_mode') != 'flush'
                and N > 1
                and pattern not in SIMPLE_PATTERNS
                and (prof['family'] != 'Z' or not fl or abs(abs(fl[1] - fl[0]) - 0.25) > 1e-8)
            ):
                raise ValueError(
                    role
                    + ': automatic web-lapped layout requires a verified unequal-flange Zee; Cees/equal-flange Zees are simple-span only here'
                )
    pieces = []
    groups = {}
    stock_cache = {}

    def lay_stocks(ident):
        """Stock lengths (in) a product is bought in - what a spanning piece must fit (round 16)."""
        if ident not in stock_cache:
            from .ordering import stock_lengths_in

            try:
                stock_cache[ident] = stock_lengths_in(job, 'purlin', ident)
            except ValueError:
                stock_cache[ident] = []
        return stock_cache[ident]

    # a junction end wall (framed by the end-wall model) with a FLUSH roof fit is a break in the purlin lay;
    # one whose rafter is BYPASS lets the purlin run over it like any interior rafter
    blocked = []
    if getattr(p, 'bay_zones', {}).get('enabled'):
        from .bay_zones import framing_key

        for i in range(1, N):
            key = framing_key(p, float(ss[i]))
            if key and ((getattr(p, 'endwalls', None) or {}).get(key) or {}).get('roof_mode') == 'flush':
                blocked.append(i)
    # Eave members span like purlins, except where a column itself reaches eave height:
    # there the eave member is welded to the side of the column, so that frame line is a break.
    column_at_eave = any(
        abs(float(col.get('y1') or 0) - float(l.get('low_eave_in') or 0)) < 1 / 16 for col in l.get('columns', [])
    ) or any(
        abs(float(col.get('y1') or 0) - float(l.get('high_eave_in') or 0)) < 1 / 16 for col in l.get('columns', [])
    )
    eave_blocked = list(range(1, N)) if column_at_eave else blocked
    for row in lanes:
        role = row['role']
        prof, chosen = profiles[role]
        held = False
        eave_role = role in ('eave', 'high_eave')
        welded_roof = cfg.get('welded_zero_gap') and (role == 'purlin' or (eave_role and prof['family'] in ('C', 'Z')))
        if role == 'base_angle':
            basecfg = copy.deepcopy(cfg)
            basecfg.update(girt_mode='bypass', girt_pattern='A_simple')
            for key in ('girt_starting_clearance', 'girt_middle_clearance'):
                basecfg.pop(key, None)
            spans = []
            for seg in extents(basecfg, 'girt'):
                if seg['cut_length_in'] <= 240:
                    spans.append(seg)
                    continue
                # Stock rule: the base angle is a 20 ft stock angle anchored to the slab.  A bay longer
                # than 20 ft (25 ft optional bay, end wall without interior posts) is laid in full
                # sticks plus the remainder, butted on the slab - no fit consequence, nothing to ask.
                n = math.ceil(seg['cut_length_in'] / 240 - 1e-9)
                x = seg['start_in']
                for j in range(n):
                    L = 240.0 if j < n - 1 else seg['cut_length_in'] - 240.0 * (n - 1)
                    spans.append(
                        dict(
                            seg,
                            start_in=x,
                            end_in=x + L,
                            cut_length=D(Fraction(round(L * 16), 16)).fmt(),
                            cut_length_in=L,
                            fit_status='BASE ANGLE: 20 FT STOCK, STICK '
                            + str(j + 1)
                            + ' OF '
                            + str(n)
                            + ' IN THIS BAY (butted on the slab)',
                            stick=j + 1,
                            sticks=n,
                        )
                    )
                    x += L
        else:
            rowcfg = copy.deepcopy(cfg)
            rowcfg.update(
                lay_stocks_in=lay_stocks(prof['id']),
                lay_blocked=eave_blocked if eave_role else blocked,
                eave_lane=eave_role,
            )
            if role == 'girt' and row['side'] == 'right' and p.frame_type == 'monoslope':
                # high side of a mono-slope: the interior supports are the HIGH columns - same
                # contact rule as the low side (W = web thickness, tube = its face width)
                hs = sections.get_section(p.high_column_section or p.column_section)
                mid = N - 1

                def _mono(key, value):
                    rowcfg[key] = [cfg[key][0]] + [value] * mid + [cfg[key][-1]]

                _mono('girt_webs', hs.bf if hs.kind == 'HSS' else hs.tw)
                _mono('girt_kinds', hs.kind)
                _mono('girt_flanges', float(hs.bf))
                _mono('girt_channels', hs.kind == 'Channel')
            if eave_role and not welded_roof:
                # Eave struts are simple-span pieces between rafter/column
                # support lines: support centre line less the project end
                # clearance each side (same rule as a simple-span purlin),
                # terminal bays from the entered front/rear clearances.
                eavecfg = copy.deepcopy(cfg)
                eavecfg.update(
                    {role + '_pattern': 'A_simple', role + '_direction': 'forward', role + '_mode': 'bypass'},
                    lay_stocks_in=lay_stocks(prof['id']),
                    lay_blocked=eave_blocked,
                )
                for key in ('purlin_starting_clearance', 'purlin_middle_clearance'):
                    if key in cfg:
                        eavecfg[key.replace('purlin', role)] = cfg[key]
                if cfg.get('purlin_mode') == 'flush' and any(cfg.get('purlin_channels', [])):
                    # open-face channel rafters: the eave member sits inside the channel like the
                    # purlins - 1/4 in from the web at every channel support
                    for key in ('purlin_webs', 'purlin_channels', 'purlin_flanges', 'purlin_offsets', 'purlin_kinds'):
                        eavecfg[key.replace('purlin', role)] = copy.deepcopy(cfg[key])
                    eavecfg[role + '_mode'] = 'flush'
                    eavecfg[role + '_pattern'] = cfg['purlin_pattern']
                    for key in ('purlin_starting_clearance', 'purlin_middle_clearance'):
                        eavecfg[key.replace('purlin', role)] = cfg.get(key, '1/8')
                    for i, face in (cfg.get('eave_end_faces') or {}).items():
                        # side-welded corner column: butt its inside face along the length
                        eavecfg[role + '_channels'][i] = False
                        eavecfg[role + '_webs'][i] = face['width']
                        eavecfg[role + '_offsets'][i] = face['width'] / 2
                        eavecfg[role + '_kinds'][i] = 'HSS'  # flat face rule, whatever the section
                    spans = extents(eavecfg, role)
                    for seg in spans:
                        fits = {e['end']: e['mode'] for e in seg.get('end_fits', [])}
                        if 'face' in fits.values() and 'channel' in fits.values():
                            seg['fit_status'] = (
                                'EAVE MEMBER: butts the corner column inside face along the length (full width); '
                                'inside the interior channel 1/4 in from the web (no clearance term)'
                            )
                        elif 'CHANNEL' in seg.get('fit_status', ''):
                            seg['fit_status'] = 'EAVE MEMBER ' + seg['fit_status']
                        else:
                            seg['fit_status'] = 'EAVE MEMBER: ' + seg['fit_status']
                else:
                    spans = extents(eavecfg, role)
                    for seg in spans:
                        seg['fit_status'] = (
                            'EAVE STRUT ' + seg['fit_status']
                            if seg.get('span_bays', 1) > 1
                            else 'EAVE STRUT SIMPLE SPAN: support CL less end clearance each side'
                        )
            else:
                spans = extents(rowcfg, 'purlin' if welded_roof else role)
        pattern_name = (
            'WELDED ZERO GAP / OUTSIDE EDGE TO INTERIOR CL'
            if welded_roof
            else 'EAVE STRUT SIMPLE SPAN'
            if eave_role
            else 'BASE ANGLE / BUTT FIT REVIEW'
            if role == 'base_angle'
            else 'FLUSH BETWEEN WEBS'
            if cfg.get(role + '_mode') == 'flush'
            else cfg[role + '_pattern']
        )
        for seg in spans:
            from .bay_zones import framed

            if role in ('girt', 'base_angle') and not framed(p, seg['bay'] - 1, row['side']):
                continue
            rec = dict(
                frame_id=fid,
                piece_id=row['run_id']
                + '-B'
                + str(seg['bay']).zfill(3)
                + ('-' + str(seg['bay_last']).zfill(3) if seg.get('bay_last') else '')
                + ('-S' + str(seg['stick']) if seg.get('stick') else ''),
                run_id=row['run_id'],
                role=role,
                side=row['side'],
                frame_x_in=row['frame_x_in'],
                floor_y_in=row['floor_y_in'],
                profile_id=prof['id'],
                finish=chosen['finish'],
                pattern=pattern_name,
                direction=cfg.get(role + '_direction', '') if not held else '',
                support_start_in=float(ss[seg['bay'] - 1]),
                support_end_in=float(ss[seg.get('bay_last') or seg['bay']]),
                **seg,
                status=seg.get('fit_status')
                or (BYPASS_STATUS if role == 'purlin' and cfg.get('bypass_end_rule') else 'SIMPLE SPAN CUT'),
            )
            pieces.append(rec)
            key = (role, prof['id'], chosen['finish'], seg['cut_length'])
            if key not in groups:
                groups[key] = dict(
                    role=role,
                    profile_id=prof['id'],
                    designation=prof['designation'],
                    finish=chosen['finish'],
                    gauge=prof['gauge'],
                    cut_length=seg['cut_length'],
                    cut_length_in=seg['cut_length_in'],
                    quantity=0,
                    pattern=rec['pattern'],
                    weight_lb_ft=(
                        (
                            float(Decimal(str(prof['stock_weight_lb'][chosen['finish']])) / 20)
                            if prof['stock_weight_lb'].get(chosen['finish']) is not None
                            else None
                        )
                        if role == 'base_angle'
                        else prof['weight_lb_ft']
                    ),
                    source_page=''
                    if eave_role or role == 'base_angle' or cfg.get(role + '_mode') == 'flush' or welded_roof
                    else PATTERNS[cfg[role + '_pattern']]['page'],
                    source_revision=SOURCE['revision']
                    if not eave_role and role != 'base_angle' and cfg.get(role + '_mode') != 'flush'
                    else '',
                    source_url=SOURCE['url']
                    if not eave_role and role != 'base_angle' and cfg.get(role + '_mode') != 'flush'
                    else '',
                    length_basis='SIMPLE SPAN: SUPPORT CL LESS END CLEARANCE; WEIGHT FROM CATALOG LB/FT'
                    if eave_role
                    else 'PROJECT BUTT FIT; STOCK LIMIT 20 FT'
                    if role == 'base_angle'
                    else 'PROJECT WEB-TO-WEB FIT; TOTAL CLEARANCE; ROUND SHORTER 1/16'
                    if cfg.get(role + '_mode') == 'flush'
                    else 'MBCI LAP LENGTH / PROJECT TERMINAL ALLOWANCE',
                    status=rec['status'],
                )
            if seg.get('span_bays', 1) > 1:
                groups[key].update(
                    source_page='',
                    source_revision='',
                    source_url='',
                    length_basis='STOCK LENGTH SPANS WHOLE BAYS: LANDS ON THE RAFTER CENTRES; NO SPLICE BETWEEN RAFTERS',
                    pattern=rec['pattern'] + ' / SPANS BAYS ' + bays_text(seg) + ' (ONE STICK, NO SPLICE)',
                )
            elif welded_roof:
                groups[key].update(
                    source_page='',
                    source_revision='',
                    source_url='',
                    length_basis='OWNER WELDED STANDARD: END OUTSIDE EDGE / INTERIOR CL, ZERO END GAP',
                )
            elif (
                not eave_role
                and role != 'base_angle'
                and cfg.get(role + '_mode') != 'flush'
                and cfg[role + '_pattern'] == 'A_butt'
            ):
                groups[key].update(
                    source_page='',
                    source_revision='',
                    source_url='',
                    length_basis='SHOP STANDARD: BUTT AT THE INTERIOR SUPPORT CENTRELINE; END CLEARANCE / 1/4 IN INSIDE AN OPEN-FACE CHANNEL',
                )
            if any(x.get('copes') for x in pieces if x['piece_id'] == rec['piece_id']):
                groups[key]['copes'] = rec.get('copes')
            if rec.get('web_clips'):
                groups[key]['web_clips'] = rec.get('web_clips')
            groups[key]['quantity'] += 1
    cuts = list(groups.values())
    for i, c in enumerate(cuts, 1):
        c['cut_mark'] = f'SR-{fid}-{i:03d}'
        each = None
        if c['cut_length'] and c['weight_lb_ft'] is not None:
            frac = D(c['cut_length']).inches
            each = Decimal(str(c['weight_lb_ft'])) * Decimal(frac.numerator) / Decimal(frac.denominator) / 12
        c['estimated_weight_each_lb'] = str(each.quantize(Decimal('.01'))) if each is not None else ''
        c['estimated_lot_weight_lb'] = str((each * c['quantity']).quantize(Decimal('.01'))) if each is not None else ''
        for rec in pieces:
            if (rec['role'], rec['profile_id'], rec['finish'], rec['cut_length']) == (
                c['role'],
                c['profile_id'],
                c['finish'],
                c['cut_length'],
            ):
                rec['cut_mark'] = c['cut_mark']
    warnings = []
    if any(x['cut_length_in'] is None for x in pieces):
        warnings.append('Some secondary cuts are PENDING: enter end support section references for flush fits.')
    if p.slab:
        warnings.append(
            'Slab base angle: 2 in vertical / 4 in on slab. No anchor/clip design; estimated cut weight prorated from catalog 20-foot stock, waste excluded.'
        )
    expected_lot = interior_frame_count(p, N)
    if p.frames != expected_lot:
        warnings.append(
            f'PRIMARY QUANTITY MISMATCH: grid has {expected_lot} interior rigid-frame lines, but entered primary frame lot quantity is {p.frames}. Enter the lot quantity that matches the grid.'
        )
    if not any(x['role'] == 'girt' for x in lanes) and _has_sidewalls(p):
        warnings.append('No sidewall girt elevations defined: zero girt runs; sidewall takeoff is incomplete.')
    warnings.extend(getattr(p, 'applied_rules', None) or [])
    if max(float(b - a) for a, b in zip(ss, ss[1:])) > 40 * 12:
        warnings.append(
            'Bay spacing exceeds the catalog 40-foot eave maximum. Eave segmentation/support and final piece quantities also require review; one planned segment per bay is not a purchasable order.'
        )
    if not p.eave_start_clip:
        warnings.append('Eave runs shown but starting/eave clips are disabled; their attachment design is pending.')
    if cfg.get('welded_zero_gap'):
        warnings.insert(
            0,
            'WELDED PURLINS:0/L are END RAFTER OUTSIDE-EDGE planes, not terminal centerlines; interior stations are CENTER BUTTS. End gaps zero. Channel vertical fit remains a separate check. C/Z eave lengths use this rule; formed strut fits remain held.',
        )
    spanned = {
        (x['bay'], x['bay_last'], x['cut_length'], x.get('stock_length_in'))
        for x in pieces
        if x['role'] == 'purlin' and x.get('span_bays', 1) > 1
    }
    if spanned:

        def _spanned(a, b, cut, stock):
            held = D(Fraction(round(stock * 16), 16)).fmt() if stock else ''
            return f'bays {a}-{b} (' + (f'{cut} cut from {held} stock' if stock and held != cut else cut) + ')'

        warnings.insert(
            0,
            'PURLIN LAY: stock lengths land on the rafter centres and a purlin is never spliced between '
            'rafters - one stock length spans '
            + ', '.join(_spanned(*x) for x in sorted(spanned, key=lambda t: (t[0], t[1], t[2])))
            + ' with no joint at the rafter between.',
        )
    support_lines = [
        dict(
            line=i + 1,
            station_in=float(ss[i]),
            type=cfg['front_end']['type'] if i == 0 else cfg['rear_end']['type'] if i == N else 'interior_rigid',
            reference=copy.deepcopy(
                {'frame_mark': fid, **cfg['front_end']}
                if i == 0 and cfg['front_end']['type'] == 'rigid_frame'
                else {'frame_mark': fid, **cfg['rear_end']}
                if i == N and cfg['rear_end']['type'] == 'rigid_frame'
                else cfg['front_end']
                if i == 0
                else cfg['rear_end']
                if i == N
                else {'frame_mark': fid}
            ),
            design_status='END DESIGN / QUANTITIES PENDING'
            if i in (0, N) and (cfg['front_end'] if i == 0 else cfg['rear_end'])['type'] != 'rigid_frame'
            else 'INTERIOR FRAME REFERENCE',
        )
        for i in range(N + 1)
    ]
    layout = dict(
        config=copy.deepcopy(cfg),
        source=evidence(),
        support_length_in=float(ss[-1]),
        centerline_length=D(ss[-1]).fmt(),
        support_lines=support_lines,
        interior_frame_lines=expected_lot,
        primary_frame_lot_quantity=p.frames,
        lanes=lanes,
        pieces=pieces,
        cuts=cuts,
        warnings=warnings,
        coverage='roof purlins, sidewall girts, both eaves only; no endwall secondary framing',
        quantity_scope='ONE longitudinal building layout, never multiplied by the primary frame lot quantity',
    )
    owner.derivation['secondary_runs'] = layout
    l['secondary_runs'] = layout
    owner.derivation['secondary_warnings'].extend(warnings)
    # Replace only unquantified automatic roles. Manual accessory orders remain separate.
    if p.slab:
        from .secondary_catalog import catalog

        owner.derivation['secondary_catalog']['base_angle'] = dict(
            selection=copy.deepcopy(p.base_angle), profile=get(p.base_angle['profile_id']), source=catalog()['source']
        )
    material = [r for r in owner.derivation['secondary_material_rows'] if r['role'] == 'accessory']
    for c in cuts:
        prof = get(c['profile_id'])
        src = owner.derivation['secondary_catalog']['eave' if c['role'] == 'high_eave' else c['role']]['source']
        material.append(
            dict(
                frame_id=fid,
                role=c['role'],
                profile_id=c['profile_id'],
                designation=c['designation'],
                finish=c['finish'],
                gauge=c['gauge'],
                ordered_piece_length=c['cut_length'],
                total_lot_pieces=c['quantity'],
                weight_lb_ft=c['weight_lb_ft'],
                estimated_weight_each_lb=c['estimated_weight_each_lb'],
                estimated_lot_weight_lb=c['estimated_lot_weight_lb'],
                status=c['status'] + '; ' + c['cut_mark'],
                source_revision=src['revision'],
                source_page=prof['pdf_page'],
                source_url=src['url'],
            )
        )
    owner.derivation['secondary_material_rows'] = material
    l['secondary_material_rows'] = material
