"""Foundation option of a frame set.

* ``slab`` (default) - columns and posts bear on base plates at the top of the slab; the
  floor datum is the top of slab and column lengths run from the base plate up.
* ``post_footing`` - columns and posts are embedded in augered holes (standard 18 in
  diameter x 3 ft deep, both user inputs).  No base plate is detailed; the column cut
  and order length is the above-floor length PLUS the hole depth, and the shop stations
  (girt clips, floor line) are measured from the bottom of the post.

The floor datum (Y = 0) stays the finished floor / grade line in both cases, so every
elevation above the floor is unchanged by the option.
"""

from __future__ import annotations

from .model import D, Dim

SLAB = 'slab'
POST_FOOTING = 'post_footing'
TYPES = (SLAB, POST_FOOTING)
STANDARD_DEPTH = D("3'")  # 3 ft deep
STANDARD_DIAMETER = D(18)  # 18 in diameter
LABELS = {SLAB: 'Slab', POST_FOOTING: 'Post footing'}


def kind(p) -> str:
    return getattr(p, 'foundation', SLAB) or SLAB


def is_post_footing(p) -> bool:
    return kind(p) == POST_FOOTING


def depth(p) -> Dim:
    v = getattr(p, 'footing_depth', None)
    return STANDARD_DEPTH if v is None else v


def diameter(p) -> Dim:
    v = getattr(p, 'footing_diameter', None)
    return STANDARD_DIAMETER if v is None else v


def inches_text(dim: Dim) -> str:
    """Inches only (``18"``, ``18 1/2"``): hole diameters are quoted in inches, not feet."""
    v = abs(dim.inches)
    whole = int(v)
    frac = v - whole
    if whole and frac:
        return f'{whole} {frac.numerator}/{frac.denominator}"'
    if frac:
        return f'{frac.numerator}/{frac.denominator}"'
    return f'{whole}"'


def embed_in(p) -> float:
    """Length of column below the floor datum (inches); zero on a slab."""
    return float(depth(p).inches) if is_post_footing(p) else 0.0


def column_bottom_in(p, base_plate_thickness: float = 0.0) -> float:
    """Y of the bottom of a column / post relative to the floor datum.

    Slab: entered base elevation plus the base plate thickness (unchanged rule).
    Post footing: the bottom of the hole, ``-depth``; the base elevation does not apply.
    """
    if is_post_footing(p):
        return -embed_in(p)
    return float(p.base_elevation.inches) + float(base_plate_thickness or 0.0)


# ----------------------------------------------------------------------------- lean-tos
LEAN_CHOICES = ('main', SLAB, POST_FOOTING)


def lean_kind(p, z) -> str:
    """Foundation of a lean-to: lean posts stand in augered holes even on a slab building
    (owner round 13/17) - ``main`` and ``post_footing`` both mean post holes; only an
    explicit ``slab`` choice puts lean posts on the slab."""
    v = (z.get('foundation') or 'main') if isinstance(z, dict) else 'main'
    return SLAB if v == SLAB else POST_FOOTING


def lean_is_post_footing(p, z) -> bool:
    return lean_kind(p, z) == POST_FOOTING


def lean_depth(p, z) -> Dim:
    if (z.get('foundation') or 'main') == 'main':
        return depth(p)
    v = z.get('footing_depth')
    return STANDARD_DEPTH if v in (None, '') else D(v)


def lean_diameter(p, z) -> Dim:
    if (z.get('foundation') or 'main') == 'main':
        return diameter(p)
    v = z.get('footing_diameter')
    return STANDARD_DIAMETER if v in (None, '') else D(v)


def lean_column_bottom_in(p, z, base_plate_thickness: float = 0.0) -> float:
    """Bottom of a lean post relative to the floor datum (before any per-post grade)."""
    if lean_is_post_footing(p, z):
        return -float(lean_depth(p, z).inches)
    return float(p.base_elevation.inches) + float(base_plate_thickness or 0.0)


def lean_record(p, z) -> dict:
    post = lean_is_post_footing(p, z)
    k = lean_kind(p, z)
    return dict(
        type=k,
        label=LABELS[k] + ('' if (z.get('foundation') or 'main') != 'main' else ' (lean standard: post holes)'),
        choice=z.get('foundation') or 'main',
        hole_depth_in=float(lean_depth(p, z).inches) if post else 0.0,
        hole_depth=lean_depth(p, z).fmt() if post else '',
        hole_diameter_in=float(lean_diameter(p, z).inches) if post else 0.0,
        hole_diameter=inches_text(lean_diameter(p, z)) if post else '',
        embed_in=float(lean_depth(p, z).inches) if post else 0.0,
        column_datum='bottom of post = ground level at the post - hole depth; no base plate'
        if post
        else 'bottom of column = grade at the column + base elevation + base plate thickness',
    )


def validate_lean(z) -> list[str]:
    errors = []
    v = z.get('foundation') or 'main'
    if v not in LEAN_CHOICES:
        errors.append(z.get('id', 'lean') + ': lean foundation must be main, slab or post_footing')
        return errors
    if v == POST_FOOTING:
        for key, label in (('footing_depth', 'hole depth'), ('footing_diameter', 'hole diameter')):
            val = z.get(key)
            if val in (None, ''):
                continue
            try:
                if float(D(val).inches) <= 0:
                    errors.append(z.get('id', 'lean') + ': post footing ' + label + ' must be positive')
            except Exception:
                errors.append(z.get('id', 'lean') + ': post footing ' + label + ' is not a length')
    return errors


def validate(p) -> list[str]:
    errors = []
    if kind(p) not in TYPES:
        errors.append('Foundation must be slab or post_footing')
    if is_post_footing(p):
        if depth(p).inches <= 0:
            errors.append('Post footing hole depth must be positive (standard 3 ft)')
        if diameter(p).inches <= 0:
            errors.append('Post footing hole diameter must be positive (standard 18 in)')
    return errors


def record(p) -> dict:
    """Serialisable summary stored on frame layouts and assembly derivations."""
    post = is_post_footing(p)
    return dict(
        type=kind(p),
        label=LABELS[kind(p)],
        hole_depth_in=float(depth(p).inches) if post else 0.0,
        hole_depth=depth(p).fmt() if post else '',
        hole_diameter_in=float(diameter(p).inches) if post else 0.0,
        hole_diameter=inches_text(diameter(p)) if post else '',
        embed_in=embed_in(p),
        column_datum='bottom of post = floor datum - hole depth; no base plate'
        if post
        else 'bottom of column = base elevation + base plate thickness above the floor datum',
    )


def describe(p) -> str:
    """One line for cover sheets and schedules."""
    if is_post_footing(p):
        return (
            'FOUNDATION: POST FOOTINGS - holes '
            + inches_text(diameter(p))
            + ' DIA x '
            + depth(p).fmt()
            + ' DEEP; posts embedded full depth, column lengths include the embedment; no base plates'
        )
    return 'FOUNDATION: SLAB - columns on base plates at the top of slab (floor datum); anchor rods by others'
