"""Shop standards that every new job starts from (owner decision, 2026-10-15).

Triple-S Steel (SSS) is the primary supplier: new jobs, the blank first-launch job
and the sample jobs carry the SSS product policy and the SSS products below
already selected, so no per-job "supplier conversion" is needed.  The editor
offers these as defaults in the frame wizard (``GET /api/catalog`` →
``catalog.supplier_defaults``); every value stays editable per job.

Job numbers start at 356 and count up (``JOB_NO_START``).
"""

from __future__ import annotations

import copy

JOB_NO_START = "356"
LEGACY_SAMPLE_JOB_NO = "1277345"  # templates.sample_job (Clark Jordan reference): never advances the counter

SSS_STANDARD = {
    # job.settings — product policy (drives which catalogs the wizard shows) and purchasing labels
    "product_suppliers": {"primary": "sss", "secondaries": "sss", "sheets": "sss", "trim": "sss"},
    "sourcing": {"primary": "sss", "overrides": {}},
    # frame parameters
    "secondary": {
        "purlin": {"profile_id": "SSS-PN8ZEE-F2", "finish": "Red Oxide", "quantity": "", "piece_length": ""},
        "girt": {"profile_id": "SSS-PN8ZEE-F2", "finish": "Red Oxide", "quantity": "", "piece_length": ""},
        "eave": {"profile_id": "SSS-PN8SSES-low_single", "finish": "Red Oxide", "quantity": "", "piece_length": ""},
    },
    "base_angle": {"profile_id": "SSS-CAB1", "finish": "Red Oxide"},
    # SSS purlins/girts are simple span (no lap geometry is published)
    "bay_layout": {"purlin_pattern": "A_butt", "girt_pattern": "A_butt"},  # butt at the support centreline
    "cladding": {
        "supplier_products": True,  # products chosen per supplier policy; an empty trim role = not ordered
        "panel_profile_id": "SSS-PBR",
        "wall_finish": {"color": "SSS / Light Stone", "gauge": 26},
        "roof_finish": {"color": "SSS / Galvalume Plus", "gauge": 26},
        "trim_finish": {"color": "SSS / Burnished Slate", "gauge": 26},
        # Eave trim, base trim and gutters are UPGRADES (owner, 2026-10-15): not ordered unless the
        # customer asks.  SSS has no base or sill trim product either.  Empty = not ordered, still
        # visible on the trim list.
        "trim_stock": {
            "corner": "SSS-TRCRS",
            "rake": "SSS-TRRKTSTD",
            "eave": "",
            "high_eave": "SSS-TRETHS",
            "ridge": "SSS-TRRCF",
            "jamb": "SSS-TRDJMBT",
            "head": "SSS-TRDHT",
            "base": "",
            "sill": "",
            "transition": "",  # lowered lean roof: custom formed to the job pitch (no SSS SKU on file)
        },
    },
}


# Supplier rule by construction (owner, 17 Oct 2026): "as a general rule SSS steel is used for welded
# buildings and MBCI is used for bolt buildings".  A rule, not a lock: the supplier stays a per-job choice
# (Supplier PRODUCTS on Building settings step 5); the editor reads this table to say which one the shop
# rule points at.  Only the SSS product set is preselected today (``SSS_STANDARD``) - the MBCI standard
# product set for a bolted job is still to be confirmed with the owner (docs/design/SUPPLIERS-PRICING.md).
SUPPLIER_BY_CONSTRUCTION = {"fully_welded": "sss", "welded_box": "sss", "bolted": "mbci"}
# Centred on the rafter centreline, a 12 in lap covers the 4 in rafter flange (2 in each
# side of the centreline, owner round 16) with 4 in to spare; SSS Zee stock is bay + 1 ft.
SLAB_THICKNESS_IN = 6.0  # drawings show the slab 6 in thick, floor = top of slab (owner round 17)

SSS_ZEE_LAP_IN = 12.0  # owner round 16: SSS Zee stock is bay + 1 ft; lap centred on the rafter

MBCI_STANDARD = {
    "product_suppliers": {"primary": "mbci", "secondaries": "mbci", "sheets": "mbci", "trim": "mbci"},
    "sourcing": {"primary": "mbci", "overrides": {}},
    "secondary": {
        "purlin": {"profile_id": "MBCI-Z-8x2p5-G16", "finish": "Red Oxide", "quantity": "", "piece_length": ""},
        "girt": {"profile_id": "MBCI-Z-8x2p5-G16", "finish": "Red Oxide", "quantity": "", "piece_length": ""},
        "eave": {
            "profile_id": "MBCI-Eave-8x5x3p375-G14-low_single",
            "finish": "Red Oxide",
            "quantity": "",
            "piece_length": "",
        },
    },
    "base_angle": {"profile_id": "MBCI-Angle-2x4-G14", "finish": "Red Oxide"},
    "bay_layout": {"purlin_pattern": "A_butt", "girt_pattern": "A_butt"},
    "cladding": {
        "supplier_products": True,
        "panel_profile_id": "MBCI-PBR",
        "wall_finish": {"color": "Light Stone", "gauge": 26},
        "roof_finish": {"color": "Galvalume Plus", "gauge": 26},
        "trim_finish": {"color": "Burnished Slate", "gauge": 26},
        "trim_stock": {
            "corner": "FL-830",
            "rake": "FL-16",
            "eave": "",
            "high_eave": "FL-17",
            "ridge": "FL-38",
            "jamb": "FL-23",
            "head": "FL-25",
            "base": "",
            "sill": "",
            "transition": "",
        },
    },
}


def mbci_secondary_profile(max_bay_in: float = 240) -> str:
    """Owner round 16: MBCI 8 in Zee is 16 ga for a 20 ft bay, 14 ga for a 25 ft bay."""
    return "MBCI-Z-8x2p5-G14" if max_bay_in >= 300 - 1e-9 else "MBCI-Z-8x2p5-G16"


def supplier_standard(supplier: str, max_bay_in: float = 240) -> dict:
    """Preselected product set for a supplier; MBCI Zee gauge follows the longest bay."""
    if supplier == "mbci":
        out = copy.deepcopy(MBCI_STANDARD)
        profile = mbci_secondary_profile(max_bay_in)
        out["secondary"]["purlin"]["profile_id"] = profile
        out["secondary"]["girt"]["profile_id"] = profile
        return out
    return copy.deepcopy(SSS_STANDARD)


def supplier_for(connection_style: str) -> str:
    """Primary supplier the shop rule names for a construction (``sss`` for anything not bolted)."""
    return SUPPLIER_BY_CONSTRUCTION.get(connection_style, "sss")


def job_settings() -> dict:
    """Settings entries a new job starts with."""
    return {
        "product_suppliers": copy.deepcopy(SSS_STANDARD["product_suppliers"]),
        "sourcing": copy.deepcopy(SSS_STANDARD["sourcing"]),
    }


def frame_defaults() -> dict:
    """Frame-parameter entries (secondary products, base angle, cladding products) of the standard."""
    return copy.deepcopy({k: SSS_STANDARD[k] for k in ("secondary", "base_angle", "cladding")})


# ---------------------------------------------------------------------------
# Shop layout rules (owner decisions, 2026-10-15, v0.8.30)
# ---------------------------------------------------------------------------
#
# Wall girts
#   * slab:          base angle (CAB1) at the floor, then girts evenly spaced at
#                    5 ft maximum between the floor and the eave strut
#                    (12 ft eave -> 4 ft / 8 ft; 14 ft -> 4'-8 / 9'-4; 20 ft -> 5/10/15);
#   * post footing:  no base angle; first girt 12 in above the floor (dirt), then
#                    evenly spaced at 5 ft maximum up to the eave strut
#                    (12 ft eave -> 1'-0 / 4'-8 / 8'-4);
#   * walk door:     a header girt at 7'-3 (3070 door: 7'-0 clear + 2 1/2 in frame
#                    head + 1/2 in gap) replaces the regular line; the girts above
#                    it stay evenly spaced at 5 ft maximum.
#   * gable ends:    when the peak is more than 7 ft above the top sidewall girt,
#                    the end wall gets extra girt lines continuing the spacing.
# Roof purlins: evenly spaced at 5 ft maximum from the eave strut to the ridge
#   purlin (``auto_roof_spacing``), ridge purlin 11 in from the peak.
# End walls: W preset end rafters BYPASS (rake angle on top of the purlins, 4 in
#   leg down over the purlin ends); only open-face CHANNEL end rafters are flush -
#   the channel matches the purlin depth, the purlin sits inside the open face
#   1/4 in from the web, welded to the flanges top and bottom.  Posts centred by width:
#   30 ft -> 15/15, 40 ft -> 20/20, 50 ft -> 20/10/20; other widths equal bays at
#   20 ft maximum.  An end wall may stay OPEN (posts and rafter only).
# Frame bays along the length: 20 ft standard, 25 ft optional, any size possible but
#   not standard - never an equal subdivision; the odd bay sits in the middle and every
#   bay can be overridden (``standard_bays``).
# Upgrades (not standard): eave trim, base trim, gutters and downspouts.

from fractions import Fraction  # noqa: E402

GIRT_MAX_SPACING_IN = 60
PURLIN_MAX_SPACING_IN = 60
WALK_DOOR_HEADER_GIRT_IN = 87  # 7'-3"
POST_FRAME_FIRST_GIRT_IN = 12
GABLE_EXTRA_GIRT_RUN_IN = 84  # extra end-wall girt line when peak - top girt > 7'
WALK_DOOR = {"width": "3'", "height": "7'"}
OVERHEAD_DOOR = {"width": "10'", "height": "10'"}
# Open-face channel rafters match the PURLIN depth (owner correction, v0.8.31): the purlin sits
# inside the open face 1/4 in from the channel web and is welded to the flanges top and bottom
# (6 3/16 x 2 x 14 ga channel takes a 6 in purlin, 8 3/16 an 8 in purlin, 10 3/16 a 10 in purlin).
CHANNEL_BY_PURLIN_DEPTH = {
    "sss": {6: "SSS-SS6214", 8: "SSS-SS8214", 10: "SSS-SS10214"},
    "mbci": {6: "MBCI-Channel-6p125x2-G14", 8: "MBCI-Channel-8p125x2-G14", 10: "MBCI-Channel-10p125x2-G14"},
}
CHANNEL_PURLIN_SETBACK_IN = 0.25  # purlin end to the channel web, every channel support (single or doubled)
# Flush sidewall girts on W columns (owner rule): welded directly to the column web, girt = bay less
# half the web each end less 1/8 in total clearance, the girt's outer flange coped for the column
# flange so the girt face matches the outside flange.  Alternative: a plate clip welded to the web
# (long side welded, short side sticking out), girt welded to the clip, girt = inside to inside of
# the column flanges less 1/4 in.  Clip (stick-out x welded length) by girt depth:
GIRT_WEB_CLIP_BY_DEPTH_IN = {6: (3, 5), 8: (5, 7), 10: (7, 9)}
FLUSH_GIRT_CLEARANCE_IN = 0.125  # total per piece, web-weld option
COPE_LENGTH_CLEARANCE_IN = 0.125  # cope length = half flange width less half web, plus this
COPE_DEPTH_CLEARANCE_IN = 0.0625  # cope depth = column flange thickness plus this
CLIP_GIRT_CLEARANCE_IN = 0.25  # total per piece, web-clip option
# Standard carport (owner decision, v0.8.31; MONO-SLOPE since v0.8.34 - "most carports are
# monosloped"): 20 ft x 40 ft x 8 ft low eave, 2 bays at 20 ft, 1:12, roof only on post footings;
# 4x4x11 ga tube posts; interior rafter = two open-face channels welded back to back (I shape),
# single channel end rafters, 6 in purlins inside the channels.  The gable carport stays a frame-type
# choice (ridge = butt + face splice plates).
CARPORT_STANDARD = {
    "frame_type": "monoslope",
    "width": "20'",
    "length": "40'",
    "eave_height": "8'",
    "bays": 2,
    "spacing": "20'",
    "slope_rise": "1",
    "column_section": "HSS 4x4 x 11 ga",
    "rafter_section": "SSS-SS6214x2",
    "end_rafter_section": "SSS-SS6214",
    "purlin": "SSS-PN6ZEE-F2",
    "purlin_depth": '6"',
    # every rafter welded to the INSIDE face of its column (column to the rafter top line, pitch-cut
    # top, no cap on open-face rafters): interior doubled-channel I rafters and single channel end
    # rafters alike; gable ridge = butt + 3/16 x 5 x 7 splice plates welded to the channel faces, one
    # each side (a mono-slope carport has no ridge); the eave member butts the corner tube's inside
    # face along the length and sits inside the interior rafter channel 1/4 in from the web
    "welded_knee": "inside_flange",
    "end_post_head": "side_welded",
    "end_ridge_joint": "face_clip",
    "ridge_joint": "face_splice",
    "high_column_mark": "HCOL-1",
    "high_column_cut_mark": "HC-100",
}
ENDWALL_POST_STATIONS_FT = {20: [], 30: [15], 40: [20], 50: [20, 30]}
ENDWALL_MAX_POST_BAY_IN = 240


def _grid16(x: float) -> Fraction:
    return Fraction(round(x * 16), 16)


def _even(lo: float, hi: float, maximum: int = GIRT_MAX_SPACING_IN) -> list[Fraction]:
    """Interior lines dividing (lo, hi] evenly so that no space exceeds ``maximum``."""
    run = hi - lo
    if run <= 0:
        return []
    n = max(1, -(-int(round(run * 16)) // (maximum * 16)))  # ceil on the 1/16 grid
    return [_grid16(lo + run * i / n) for i in range(1, n)]


def girt_lines(eave_in: float, foundation: str = "slab", walk_door: bool = False) -> list[Fraction]:
    """Standard sidewall girt elevations (inches above the floor), eave strut excluded.

    ``foundation`` is ``slab`` (base angle at 0, first space from the floor) or
    ``post_footing`` (first girt at 12 in).  With ``walk_door`` the 7'-3 header
    girt is fixed and the lines above it are spaced evenly at 5 ft maximum.
    """
    H = float(eave_in)
    if H <= 0:
        raise ValueError("Eave height must be positive")
    slab = foundation != "post_footing"
    lines: list[Fraction] = []
    bottom = 0.0
    if not slab:
        bottom = float(POST_FRAME_FIRST_GIRT_IN)
        if bottom < H:
            lines.append(Fraction(POST_FRAME_FIRST_GIRT_IN))
    if walk_door and WALK_DOOR_HEADER_GIRT_IN < H:
        if WALK_DOOR_HEADER_GIRT_IN > bottom:
            lines.append(Fraction(WALK_DOOR_HEADER_GIRT_IN))
            bottom = float(WALK_DOOR_HEADER_GIRT_IN)
    lines.extend(_even(bottom, H))
    return sorted(set(lines))


def girt_lines_text(eave_in: float, foundation: str = "slab", walk_door: bool = False) -> str:
    from .model import D

    return ", ".join(D(x).fmt() for x in girt_lines(eave_in, foundation, walk_door))


def gable_extra_girt_lines(lines: list, top_in: float, peak_in: float) -> list[Fraction]:
    """Extra end-wall girt lines above the top sidewall line when the peak is more than
    7 ft above it; the sidewall spacing continues (5 ft when there is only one line)."""
    seq = sorted(float(x) for x in lines)
    if not seq:
        return []
    space = seq[-1] - seq[-2] if len(seq) >= 2 else min(GIRT_MAX_SPACING_IN, max(seq[-1], 1))
    space = min(space, GIRT_MAX_SPACING_IN) if space > 0 else GIRT_MAX_SPACING_IN
    out: list[Fraction] = []
    y = max(seq[-1], float(top_in))
    while peak_in - y > GABLE_EXTRA_GIRT_RUN_IN + 1e-6:
        y += space
        if y >= peak_in - 1e-6:
            break
        out.append(_grid16(y))
    return out


STANDARD_BAY_IN = 240  # frame bays along the length: 20 ft standard (25 ft optional, any size possible)
STANDARD_BAY_MIN_ODD_IN = 120  # a remainder shorter than this joins the middle bay instead of standing alone


def standard_bays(length_in) -> list[Fraction]:
    """Owner's frame-bay rule along the length: **20 ft bays**, never an equal subdivision.

    A length that is not a multiple of 20 ft keeps its 20 ft bays and puts the odd
    remainder in the **middle** bay - as its own bay when it is 10 ft or more
    (50 ft -> 20 / 10 / 20, 70 ft -> 20 / 20 / 10 / 20), otherwise added to the middle
    20 ft bay (45 ft -> 20 / 25, 65 ft -> 20 / 25 / 20).  Each bay stays editable.
    """
    L = Fraction(length_in)
    if L <= 0:
        raise ValueError("Building length must be positive")
    k, rem = divmod(L, STANDARD_BAY_IN)
    k = int(k)
    if rem == 0:
        return [Fraction(STANDARD_BAY_IN)] * k
    if k == 0:
        return [L]
    bays = [Fraction(STANDARD_BAY_IN)] * k
    if rem >= STANDARD_BAY_MIN_ODD_IN:
        bays.insert((k + 1) // 2, rem)
    else:
        bays[k // 2] += rem
    return bays


def endwall_post_stations(width_in: float) -> list[Fraction] | None:
    """Standard interior end-wall post stations from the outside wall line (inches), or
    ``None`` when the width is not in the table (caller falls back to equal bays)."""
    ft = float(width_in) / 12
    if abs(ft - round(ft)) > 1e-9 or int(round(ft)) not in ENDWALL_POST_STATIONS_FT:
        return None
    return [Fraction(x * 12) for x in ENDWALL_POST_STATIONS_FT[int(round(ft))]]


def channel_end_rafter(purlin_depth_in: float, supplier: str = "sss") -> str:
    """Open-face channel rafter matching the purlin depth (per secondaries supplier)."""
    table = CHANNEL_BY_PURLIN_DEPTH.get(supplier, CHANNEL_BY_PURLIN_DEPTH["sss"])
    depth = int(round(float(purlin_depth_in)))
    if abs(depth - float(purlin_depth_in)) > 1e-6 or depth not in table:
        raise ValueError(
            "Open-face channel rafters match the purlin depth: 6, 8 or 10 in purlins "
            f"(purlin depth {purlin_depth_in:g} in has no matching channel)"
        )
    return table[depth]


def girt_web_clip(girt_depth_in: float) -> tuple[int, int] | None:
    """(stick-out, welded length) of the web clip plate for a girt depth, or None."""
    return GIRT_WEB_CLIP_BY_DEPTH_IN.get(int(round(float(girt_depth_in))))


def layout_rules() -> dict:
    """Rule constants for the editor (``GET /api/catalog`` -> ``catalog.layout_rules``)."""
    return {
        "girt_max_spacing_in": GIRT_MAX_SPACING_IN,
        "purlin_max_spacing_in": PURLIN_MAX_SPACING_IN,
        "walk_door_header_girt_in": WALK_DOOR_HEADER_GIRT_IN,
        "post_frame_first_girt_in": POST_FRAME_FIRST_GIRT_IN,
        "gable_extra_girt_run_in": GABLE_EXTRA_GIRT_RUN_IN,
        "walk_door": dict(WALK_DOOR),
        "overhead_door": dict(OVERHEAD_DOOR),
        "endwall_post_stations_ft": {str(k): v for k, v in ENDWALL_POST_STATIONS_FT.items()},
        "channel_by_purlin_depth": {
            k: {str(d): ident for d, ident in v.items()} for k, v in CHANNEL_BY_PURLIN_DEPTH.items()
        },
        "channel_purlin_setback_in": CHANNEL_PURLIN_SETBACK_IN,
        "girt_web_clip_by_depth_in": {str(k): list(v) for k, v in GIRT_WEB_CLIP_BY_DEPTH_IN.items()},
        "flush_girt_clearance_in": FLUSH_GIRT_CLEARANCE_IN,
        "clip_girt_clearance_in": CLIP_GIRT_CLEARANCE_IN,
        "carport": dict(CARPORT_STANDARD),
        "standard_bay_in": STANDARD_BAY_IN,
        "standard_bay_min_odd_in": STANDARD_BAY_MIN_ODD_IN,
        "supplier_by_construction": dict(SUPPLIER_BY_CONSTRUCTION),
        "sss_zee_lap_in": SSS_ZEE_LAP_IN,
        "mbci_standard_secondary_by_bay": {"20 ft": "MBCI-Z-8x2p5-G16", "25 ft": "MBCI-Z-8x2p5-G14"},
    }
