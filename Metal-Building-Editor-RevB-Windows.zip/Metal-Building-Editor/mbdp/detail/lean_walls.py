"""Lean-to walls under the shop rules (v0.8.35).

Every wall of a lean-to is an explicit choice (owner, 2026-10-15):

* ``walls`` = ``{outer, start_end, finish_end: 'open' | 'sheeted', main_below: 'sheeted' | 'open'}``.
  A NEW lean-to is ROOF ONLY: the three lean walls open and the main wall under the lean
  kept sheeted.
* Lean posts follow the main framing lines (one at every main frame line inside the lean
  run); the lean can run the whole length or only a chosen range of main bays (``bays``).
* Lean END-WALL posts (between the main column and the lean post) are standard only when
  that end is SHEETED and the projection exceeds the 20 ft end-wall post bay: ``end_posts``
  ``auto`` (standard) / ``always`` / ``never``.  Standard stations follow the end-wall table
  (30 ft -> 15, 40 ft -> 20, 50 ft -> 20 / 30), otherwise equal bays of at most 20 ft.
* Lean girts have their own setting (``girt_mode`` flush by default, ``girt_attachment``
  web_weld / web_clip) and follow the main-wall shop rules: welded to a W web (coped for the
  flange), to a tube face, inside an open-face channel 1/4 in from the web, or butted to a
  flange face; 1/8 in total clearance only on a piece butted at BOTH ends.
* Girt lines: the sidewall rule for the lean low eave (slab: base angle at the floor then at
  most 5 ft; post footing: first girt 12 in then at most 5 ft); the sloped end-wall region
  above the top line gets extra lines while the high side is more than 7 ft above it.
* Lean columns and end posts may be W, HSS or an open-face channel (all column options).
"""

from __future__ import annotations

import math
from fractions import Fraction

from .cladding import EPS, fmt, inch
from .standards import (
    CHANNEL_PURLIN_SETBACK_IN,
    CLIP_GIRT_CLEARANCE_IN,
    COPE_DEPTH_CLEARANCE_IN,
    COPE_LENGTH_CLEARANCE_IN,
    ENDWALL_MAX_POST_BAY_IN,
    FLUSH_GIRT_CLEARANCE_IN,
    endwall_post_stations,
    gable_extra_girt_lines,
    girt_lines,
    girt_web_clip,
)

WALLS = ('outer', 'start_end', 'finish_end', 'main_below')
STATES = ('open', 'sheeted')
END_POST_MODES = ('auto', 'always', 'never')
WALL_LABELS = {
    'outer': 'lean outer wall',
    'start_end': 'lean start end wall',
    'finish_end': 'lean finish end wall',
    'main_below': 'main wall under the lean',
}


def default_walls():
    """Roof only: the three lean walls open, the main wall under the lean sheeted."""
    return dict(outer='open', start_end='open', finish_end='open', main_below='sheeted')


# ----------------------------------------------------------------------------- configuration


def normalize(p, r):
    """Validate the wall switches, the end-post option and the girt settings of one lean."""
    walls = r.get('walls')
    if walls is None:
        if any(k in r for k in ('sheeted_ends', 'sheeted_outer_wall', 'open_main_below')):
            # Legacy flags (pre-0.8.35 jobs) map onto the explicit per-wall choice.
            ends = 'sheeted' if r.get('sheeted_ends', True) else 'open'
            walls = dict(
                outer='sheeted' if r.get('sheeted_outer_wall', True) else 'open',
                start_end=ends,
                finish_end=ends,
                main_below='open' if r.get('open_main_below') else 'sheeted',
            )
        else:
            walls = default_walls()
    if not isinstance(walls, dict) or any(k not in WALLS for k in walls):
        raise ValueError(
            r.get('id', 'lean') + ': walls must be an object with outer, start_end, finish_end, main_below'
        )
    full = default_walls()
    for k, v in walls.items():
        if v not in STATES:
            raise ValueError(r.get('id', 'lean') + ': ' + WALL_LABELS[k] + ' must be open or sheeted')
        full[k] = v
    r['walls'] = full
    # The saved lean record carries the explicit choice only; the pre-0.8.35 flags are
    # dropped from the input and re-derived on the generated model (``mirror_legacy``).
    for k in ('sheeted_ends', 'sheeted_outer_wall', 'open_main_below'):
        r.pop(k, None)
    r['end_posts'] = r.get('end_posts') or 'auto'
    if r['end_posts'] not in END_POST_MODES:
        raise ValueError('Lean end posts must be auto (only when that end is sheeted), always or never')
    raw_girts = r.get('girt_elevations')
    if raw_girts in (None, ''):
        r['girt_elevations_in'] = []
    else:
        from .cladding import inch as _inch

        vals = [_inch(v) for v in str(raw_girts).replace(';', ',').split(',') if str(v).strip()]
        if any(not 0 < v < _inch(r.get('low_eave') or '120') for v in vals):
            raise ValueError(
                r.get('id', 'lean') + ': lean girt elevations must be above the floor and below the low eave'
            )
        r['girt_elevations_in'] = sorted(set(vals))
    r['girt_attachment'] = r.get('girt_attachment') or getattr(p, 'girt_attachment', 'web_weld') or 'web_weld'
    if r['girt_attachment'] not in ('web_weld', 'web_clip'):
        raise ValueError('Lean girt attachment must be web_weld or web_clip')
    r['end_post'] = str(r.get('end_post') or '').strip()


def resolve_bays(p, r):
    """``bays = {from, to}`` (1-based main bays, inclusive) -> start / length on the face."""
    bays = r.get('bays')
    if not bays:
        return
    if r.get('face') not in ('left', 'right'):
        raise ValueError(r.get('id', 'lean') + ': a bay range applies to sidewall lean-tos only')
    cfg = p.bay_layout if isinstance(p.bay_layout, dict) else {}
    if not cfg.get('enabled') or not cfg.get('bays'):
        raise ValueError(r.get('id', 'lean') + ': a bay range needs the main bay layout (Building settings > step 1)')
    from .secondary_runs import support_stations

    ss = [float(x) for x in support_stations(cfg)]
    n = len(ss) - 1
    try:
        a = int(bays.get('from', 1))
        b = int(bays.get('to', n))
    except (TypeError, ValueError):
        raise ValueError(r.get('id', 'lean') + ': bay range from / to must be whole bay numbers')
    if not 1 <= a <= b <= n:
        raise ValueError(r.get('id', 'lean') + ': bay range must lie within bays 1-%d' % n)
    r['bays'] = dict(**{'from': a, 'to': b})
    lo, hi = ss[a - 1], ss[b]
    L = ss[-1]
    # Lean coordinates are the OUTSIDE view of the face: the back sidewall is mirrored.
    if r['face'] == 'left':
        lo, hi = L - hi, L - lo
    r['start'] = str(lo)
    r['length'] = str(hi - lo)
    r['full_length'] = a == 1 and b == n


# ----------------------------------------------------------------------------- framing


def _support(kind, profile, mark, station, **more):
    rec = dict(kind=kind, profile=profile, mark=mark, station_in=station)
    rec.update(more)
    return rec


def _contact(sup, which, clip_option):
    """(deduction from the support station, mode, note) for a girt end at ``sup``.

    ``which`` is 'start' (the girt leaves the support toward +X) or 'end'.  Modes: web (W, coped),
    face (tube), channel (inside an open face, 1/4 in from the web), clip (web clip option),
    flange (butted to a flange / outside face at the station).
    """
    pr = sup['profile']
    fam = pr.get('family')
    if sup['kind'] == 'flange':
        return sup.get('contact_in', 0.0), 'flange', sup.get('note') or ('face of ' + sup['mark'])
    if fam == 'HSS':
        return pr['width'] / 2, 'face', 'flat face of tube ' + sup['mark']
    if fam in ('C', 'Channel'):
        if not pr.get('open_face'):
            return pr['depth'], 'flange', 'lips of Cee ' + sup['mark']
        # Open-face channel upright: web on the station, body toward +X; the girt leaving the
        # post (start) sits inside the open face, the girt arriving (end) butts the flat side.
        if which == 'start':
            return CHANNEL_PURLIN_SETBACK_IN, 'channel', 'open face of ' + sup['mark'] + ' (1/4 in from the web)'
        return 0.0, 'flange', 'flat (web) side of ' + sup['mark']
    if fam == 'W':
        if clip_option and pr.get('flange') is not None:
            return pr['width'] / 2, 'clip', 'web clip on ' + sup['mark']
        return (pr.get('web') or 0.0) / 2, 'web', 'web of ' + sup['mark']
    return None, None, ''


def _piece(a, b, y, cfg):
    """One girt piece between supports a (start) and b (end) at elevation y."""
    clip_option = cfg['attachment'] == 'web_clip'
    da, ma, na = _contact(a, 'start', clip_option)
    db, mb, nb = _contact(b, 'end', clip_option)
    span = b['station_in'] - a['station_in']
    if da is None or db is None:
        return dict(cut_length_in=None, status='FLUSH FIT PENDING: ATTACHMENT FACE NOT CONFIRMED')
    butt = [m for m in (ma, mb) if m != 'channel']
    gap = 0.0
    if len(butt) == 2:
        gap = CLIP_GIRT_CLEARANCE_IN if 'clip' in butt else FLUSH_GIRT_CLEARANCE_IN
    length = math.floor((span - da - db - gap) * 16 + 1e-9) / 16
    if length <= 0:
        raise ValueError('Lean girt deductions consume the bay')
    extra = (span - da - db - gap - length) / 2
    start = a['station_in'] + da + gap / 2 + extra
    rec = dict(
        start_in=start,
        end_in=start + length,
        cut_length_in=length,
        cut_length=fmt(length),
        y_in=y,
        end_fits=[
            dict(end='start', mode=ma, support=a['mark'], deduction_in=da),
            dict(end='end', mode=mb, support=b['mark'], deduction_in=db),
        ],
    )
    kinds = {
        'web': 'column web',
        'face': 'tube face',
        'channel': 'open face',
        'clip': 'web clip',
        'flange': 'flange face',
    }
    if 'clip' in (ma, mb):
        clip = girt_web_clip(cfg['girt_depth_in'])
        rec['status'] = (
            'WEB CLIP: welded to the '
            + na
            + ' and the '
            + nb
            + (
                '; %d x %d plate clip (%d in side welded, %d in sticking out), 1/4 in total clearance'
                % (clip[0], clip[1], clip[1], clip[0])
                if clip
                else '; clip size for this girt depth is not in the shop table (6 in 3x5, 8 in 5x7, 10 in 7x9)'
            )
        )
    else:
        rec['status'] = (
            'FLUSH LEAN GIRT: welded to the '
            + na
            + ' and the '
            + nb
            + ' ('
            + kinds.get(ma, ma)
            + ' / '
            + kinds.get(mb, mb)
            + ')'
            + ('; 1/8 in total clearance' if gap else '; no clearance term (an end inside an open face)')
        )
    copes = []
    for which, sup, mode in (('start', a, ma), ('end', b, mb)):
        pr = sup['profile']
        if mode == 'web' and pr.get('family') == 'W' and pr.get('flange') is not None:
            copes.append(
                dict(
                    end=which,
                    length_in=(pr['width'] - (pr.get('web') or 0)) / 2 + COPE_LENGTH_CLEARANCE_IN,
                    depth_in=pr['flange'] + COPE_DEPTH_CLEARANCE_IN,
                )
            )
    if copes:
        rec['copes'] = copes
        rec['status'] += '; coped around the column flange so the girt face matches the outside flange'
    return rec


def _end_post_stations(P, mode, sheeted):
    """Intermediate end-wall post stations (from the main wall face) for one lean end."""
    if mode == 'never' or (mode == 'auto' and not sheeted):
        return []
    if P <= ENDWALL_MAX_POST_BAY_IN + 1e-9:
        return []
    table = endwall_post_stations(P)
    if table is not None:
        return [float(x) for x in table]
    n = int(math.ceil(P / ENDWALL_MAX_POST_BAY_IN - 1e-9))
    return [P * i / n for i in range(1, n)]


def mirror_legacy(z):
    """Derived booleans on the generated lean model for older readers of the saved job."""
    full = z['walls']
    z['sheeted_ends'] = full['start_end'] == 'sheeted' or full['finish_end'] == 'sheeted'
    z['sheeted_outer_wall'] = full['outer'] == 'sheeted'
    z['open_main_below'] = full['main_below'] == 'open'


def finish(job, p, z, rf, col, posts):
    """Lean end posts, girt lines and girt pieces for the sheeted (or framed) lean walls."""
    from .secondary_catalog import get

    walls = z['walls']
    mirror_legacy(z)
    z['wall_framing'] = None
    z['wall_girts'] = []
    z['end_posts_resolved'] = {}
    if not rf or not col or len(posts) < 2:
        return  # wall framing is face-local (along the wall / out), any attachment face
    cut = z.get('rafter_cut_detail') or {}
    low = z.get('low_connection_detail') or {}
    if 'high_top_in' not in cut or 'column_bottom_in' not in low:
        return
    P = z['projection_in']
    H = z['low_eave_in']
    m = z['pitch'] / 12
    co = 1 / math.hypot(1, m)
    spec = p.secondary.get('girt') or {}
    girt = get(spec['profile_id']) if spec.get('profile_id') else None
    base_in = float(low['column_bottom_in'])
    low_lines = low.get('lines') or []
    attachment = z.get('girt_attachment') or 'web_weld'
    cfg = dict(attachment=attachment, girt_depth_in=float(girt['nominal_depth_in']) if girt else 0.0)
    tag = p.column_mark + '-' + z['id']
    from . import foundation as FND

    # the lean's OWN girt heights: an explicit list when entered, else the shop rule
    # run from the lean's low eave on the lean's own foundation (v0.8.43)
    lines = [float(x) for x in (z.get('girt_elevations_in') or girt_lines(H, FND.lean_kind(p, z)))]
    any_framed = False
    framing = dict(
        girt_lines_in=lines,
        girt_profile_id=girt['id'] if girt else '',
        girt_finish=spec.get('finish', ''),
        girt_mode=z.get('girt_mode', 'flush'),
        girt_attachment=attachment,
        outer=dict(sheeted=walls['outer'] == 'sheeted', pieces=[]),
        start_end=dict(sheeted=walls['start_end'] == 'sheeted', posts=[], pieces=[], extra_lines_in=[]),
        finish_end=dict(sheeted=walls['finish_end'] == 'sheeted', posts=[], pieces=[], extra_lines_in=[]),
        notes=[],
    )
    z['wall_framing'] = framing
    if z.get('girt_mode', 'flush') != 'flush':
        framing['notes'].append(
            'Lean girt mode BYPASS: pieces follow the main bypass pattern; no flush fit shown here.'
        )

    def post_profile(section, mark):
        return _support('post', section, mark, 0.0)

    lean_post = dict(col)
    lean_post.setdefault('web', col.get('web'))

    # ----- outer wall: girts between the lean posts on the main framing lines
    if walls['outer'] == 'sheeted':
        if not girt:
            z['issues'].append('Lean outer wall is sheeted: select the girt product (Building settings > step 4)')
        else:
            any_framed = True
            sups = [post_profile(lean_post, tag + '-' + str(i + 1) + '-COL') for i in range(len(posts))]
            for sup, u in zip(sups, posts):
                sup['station_in'] = u['x']
            for k, y in enumerate(lines):
                for i, (a, b) in enumerate(zip(sups, sups[1:])):
                    if z.get('girt_mode', 'flush') != 'flush':
                        length = b['station_in'] - a['station_in']
                        rec = dict(
                            start_in=a['station_in'],
                            end_in=b['station_in'],
                            cut_length_in=length,
                            cut_length=fmt(length),
                            y_in=y,
                            status='BYPASS LEAN GIRT: centre to centre of the lean posts (lap / clip pattern per the main walls)',
                        )
                    else:
                        rec = _piece(a, b, y, cfg)
                    rec.update(
                        mark=tag + '-OG' + str(k + 1) + '-' + str(i + 1),
                        wall='outer',
                        bay=i + 1,
                        profile_id=girt['id'],
                        finish=spec.get('finish', ''),
                        quantity=1,
                        role='lean girt',
                    )
                    framing['outer']['pieces'].append(rec)
                    z['wall_girts'].append(rec)

    # ----- end walls: main column -> (end posts) -> lean post, across the projection
    high_top = float(cut['high_top_in'])
    plumb = float(cut.get('plumb_depth_in') or rf['depth'] / co)
    # the end rafter can be a different section than the standard line (v0.8.42 per-line choice)
    by_line = {q['station']: q for q in (cut.get('lines') or [])}
    end_section = None
    if z.get('end_post'):
        from .framing_additions import profile

        end_section = profile(z['end_post'])
        if end_section and end_section['family'] not in ('W', 'HSS') and not end_section.get('open_face'):
            raise ValueError(z['id'] + ': lean end posts must be W, HSS or an open-face channel')
    end_section = end_section or lean_post
    for key, u in (('start_end', posts[0]), ('finish_end', posts[-1])):
        sheeted = walls[key] == 'sheeted'
        stations = _end_post_stations(P, z.get('end_posts', 'auto'), sheeted)
        z['end_posts_resolved'][key] = stations
        end = framing[key]
        end['post_stations_in'] = stations
        end['rule'] = (
            'no intermediate posts: projection within the 20 ft end-wall post bay'
            if P <= ENDWALL_MAX_POST_BAY_IN + 1e-9
            else 'end posts on the standard end-wall stations'
            if stations
            else 'NO end posts (open end / end posts never)'
        )
        letter = 'S' if key == 'start_end' else 'F'
        end_line = by_line.get(1 if key == 'start_end' else len(posts), {})
        end_top = float(end_line.get('high_top_in', high_top))
        end_plumb = float(end_line.get('plumb_depth_in', plumb))
        # base as the lean post of that end line (its grade included, v0.8.43)
        end_low = low_lines[0 if key == 'start_end' else -1] if low_lines else {}
        end_base = float(end_low.get('column_bottom_in', base_in))
        for i, d in enumerate(stations):
            top = end_top - d * m - end_plumb  # under the lean end rafter at the post centre
            length = top - end_base
            if length <= 0:
                raise ValueError(z['id'] + ': lean end post height consumed by the rafter')
            width = end_section.get('width') or end_section.get('depth')
            long_blank = length + (width or 0) * m / 2
            row = dict(
                mark=tag + '-' + letter + 'EP' + str(i + 1),
                profile=end_section['id'],
                family=end_section['family'],
                quantity=1,
                role='lean end post',
                wall=key,
                station_from_main_wall_in=d,
                reference_length_in=length,
                cut_length_in=length,
                blank_length_in=math.ceil(long_blank * 16 - 1e-9) / 16,
                top_in=top,
                bottom_in=end_base,
                grade_in=float(end_low.get('grade_in') or 0.0),
                status='LEAN END POST: pitch-cut head welded under the lean end rafter (short side %s toward the lean post); base as the lean post'
                % fmt(length),
            )
            end['posts'].append(row)
            z['members'].append(row)
        if not sheeted:
            continue
        if not girt:
            z['issues'].append(
                'Lean ' + WALL_LABELS[key] + ' is sheeted: select the girt product (Building settings > step 4)'
            )
            continue
        any_framed = True
        # Supports along the projection, X from the main wall face outward.
        main = _support(
            'flange',
            dict(family='W', width=u['face_width']),
            u['mark'],
            0.0,
            contact_in=0.0,
            note='outside flange of main column ' + u['mark'],
        )
        sups = [main]
        for i, d in enumerate(stations):
            sups.append(post_profile(end_section, tag + '-' + letter + 'EP' + str(i + 1)))
            sups[-1]['station_in'] = d
        sups.append(
            _support(
                'flange',
                lean_post,
                tag + '-' + ('1' if key == 'start_end' else str(len(posts))) + '-COL',
                P - lean_post['depth'] / 2,
                contact_in=lean_post['depth'] / 2,
                note='inside face of lean post '
                + tag
                + '-'
                + ('1' if key == 'start_end' else str(len(posts)))
                + '-COL',
            )
        )
        high = z['high_eave_in']
        extra = [float(x) for x in gable_extra_girt_lines(lines, max(lines) if lines else H, high)] if lines else []
        end['extra_lines_in'] = extra
        if extra:
            framing['notes'].append(
                WALL_LABELS[key].upper()
                + ': extra girt line(s) at '
                + ', '.join(fmt(x) for x in extra)
                + ' in the sloped region (high side more than 7 ft above the top line).'
            )
        for k, y in enumerate(lines + extra):
            for i, (a, b) in enumerate(zip(sups, sups[1:])):
                # The roof underside at the far support must clear the girt.
                roof_b = high_top - b['station_in'] * m - plumb
                if y > roof_b - 1e-6:
                    if y in extra and i == 0 and len(sups) == 2:
                        z['issues'].append(
                            z['id']
                            + ': '
                            + WALL_LABELS[key]
                            + ' extra girt line at '
                            + fmt(y)
                            + ' exceeds the lean post height; it needs an end post (set lean end posts = always)'
                        )
                    continue
                if (
                    P - 1e-9 > ENDWALL_MAX_POST_BAY_IN
                    and b['station_in'] - a['station_in'] > ENDWALL_MAX_POST_BAY_IN + 1e-9
                ):
                    z['issues'].append(
                        z['id']
                        + ': '
                        + WALL_LABELS[key]
                        + ' girt span '
                        + fmt(b['station_in'] - a['station_in'])
                        + ' exceeds the 20 ft end-wall post bay; set lean end posts = auto or always'
                    )
                rec = _piece(a, b, y, cfg)
                rec.update(
                    mark=tag + '-' + letter + 'G' + str(k + 1) + '-' + str(i + 1),
                    wall=key,
                    bay=i + 1,
                    profile_id=girt['id'],
                    finish=spec.get('finish', ''),
                    quantity=1,
                    role='lean girt',
                )
                end['pieces'].append(rec)
                z['wall_girts'].append(rec)
    framing['framed'] = any_framed
    framing['status'] = (
        'LEAN WALL GIRTS: %d pieces on %d line(s); %s'
        % (
            len(z['wall_girts']),
            len(lines),
            'web weld (flush, coped at W flanges)' if attachment == 'web_weld' else 'web clips',
        )
        if any_framed
        else 'ROOF ONLY: all lean walls open - no wall girts'
    )
    posts_n = sum(len(framing[k]['posts']) for k in ('start_end', 'finish_end'))
    if posts_n:
        framing['status'] += '; %d lean end post(s)' % posts_n
    z['issues'] = [
        t
        for t in z['issues']
        if not (t.startswith('Wall-to-roof transition profile') and z.get('roof_continuity') == 'main_plane')
    ]


# ----------------------------------------------------------------------------- sheet surfaces


def surfaces(z, top_allowance, bottom_in):
    """Wall sheet surfaces of one lean (outside views) for the cladding takeoff.

    Outer wall: X along the wall as the main face view.  Start end: viewed from that end, the
    main wall is on the LEFT (high side); finish end: main wall on the RIGHT.
    """
    out = []
    walls = z['walls']
    P = z['projection_in']
    H = z['low_eave_in']
    high = z['high_eave_in']
    if walls['outer'] == 'sheeted':
        out.append(
            dict(
                id='lean_' + z['id'] + '_outer',
                lean_id=z['id'],
                lean_wall='outer',
                kind='wall',
                width_in=z['length_in'],
                top_profile=[(0.0, H + top_allowance), (z['length_in'], H + top_allowance)],
                bottom_in=bottom_in,
                datum='Lean-to %s OUTER WALL, outside view: X along the main face from the lean start; Y above the floor'
                % z['id'],
            )
        )
    for key, poly in (
        ('start_end', [(0.0, high + top_allowance), (P, H + top_allowance)]),
        ('finish_end', [(0.0, H + top_allowance), (P, high + top_allowance)]),
    ):
        if walls[key] != 'sheeted':
            continue
        out.append(
            dict(
                id='lean_' + z['id'] + '_' + key,
                lean_id=z['id'],
                lean_wall=key,
                kind='wall',
                width_in=P,
                top_profile=poly,
                bottom_in=bottom_in,
                datum=(
                    'Lean-to %s %s END WALL, outside view: X from the main wall face (left, high side) to the lean post; Y above the floor'
                    if key == 'start_end'
                    else 'Lean-to %s %s END WALL, outside view: X from the lean post (left, low side) to the main wall face; Y above the floor'
                )
                % (z['id'], 'START' if key == 'start_end' else 'FINISH'),
            )
        )
    return out


def roof_surface(z, rake_front_in, rake_rear_in):
    """Separate-plane lean roof surface (one slope from the main wall to the low eave)."""
    if z.get('roof_continuity') == 'main_plane':
        return None
    face_length = z['roof_slope_length_in'] + z['roof_overhang_in']
    return dict(
        id='lean_' + z['id'] + '_roof',
        lean_id=z['id'],
        lean_wall='roof',
        kind='roof',
        width_in=z['length_in'] + rake_front_in + rake_rear_in,
        face_length_in=face_length,
        rake_length_in=face_length,
        datum='Lean-to %s ROOF: one slope, panels from the low eave (with the %s overhang along the slope) up to the main wall'
        % (z['id'], fmt(z['roof_overhang_in'])),
    )


def wall_name(sid):
    """Readable name for a lean surface id (``lean_<id>_<wall>``)."""
    if not str(sid).startswith('lean_'):
        return None
    body = sid[5:]
    for key in ('start_end', 'finish_end', 'outer', 'roof'):
        if body.endswith('_' + key):
            lid = body[: -(len(key) + 1)]
            names = {
                'start_end': 'start end wall',
                'finish_end': 'finish end wall',
                'outer': 'outer wall',
                'roof': 'roof',
            }
            return 'Lean-to ' + lid + ' ' + names[key]
    return 'Lean-to ' + body


def wall_code(sid):
    name = wall_name(sid)
    return None if name is None else name.lower().replace(' ', '_').replace('-', '_')


__all__ = [
    'CHANNEL_PURLIN_SETBACK_IN',
    'Fraction',
    'inch',
    'EPS',
    'normalize',
    'resolve_bays',
    'finish',
    'surfaces',
    'roof_surface',
    'wall_name',
    'wall_code',
]
