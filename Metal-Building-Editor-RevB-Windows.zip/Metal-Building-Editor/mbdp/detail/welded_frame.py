"""User-defined welded frame alternatives; nominal vertical-depth datum is explicit."""

import copy
import math
from decimal import Decimal

from . import sections
from .clip_clearance import check_edges
from .connections import f, precision
from .model import Assembly, Attachment, D, EndCut, MainMember, Part


def clear_owned(job, frame_id):
    job.settings.setdefault('connections', {})  # a cut-and-fold frame owns no connection records
    owners = [k for k, c in job.settings.get('connections', {}).items() if c.get('frame_id') == frame_id]
    for mark in owners:
        job.settings['connections'].pop(mark, None)
    for mark, assembly in list(job.assemblies.items()):
        physical = assembly.derivation.get('physical_frame_connection') or {}
        if physical.get('frame_id') == frame_id:
            del job.assemblies[mark]
    for mark, p in list(job.parts.items()):
        if mark in owners or p.symbol.get('owner') in owners or p.symbol.get('welded_frame_id') == frame_id:
            del job.parts[mark]


def generate(job, p):
    from . import foundation as FND
    from .base_options import mark as base_mark
    from .base_options import resolve as resolve_base
    from .base_options import thickness as base_thickness
    from .frame import dependency_key, grid16
    from .plate_rules import migrate_plate_defaults

    inside = p.welded_knee == 'inside_flange'
    knee_records = []
    # Owner rules (round 15, correcting round 14).  DATUM: the ROOF LINE is the TOP OF THE PURLIN
    # (the sheets lay on the purlins) and EAVE HEIGHT is the TOP OF THE EAVE PURLIN; the building has
    # an eave height AND a peak height, and a lean-to has its own eave height even when it is tied
    # into the same roof line.
    #   BYPASS (the standard fit): the purlin BEARS ON the rafter top flange - the rafter top is one
    #   purlin depth below the roof line, and the eave purlin bears on the column seat.
    #   FLUSH (option): the purlin TOP is flush with the rafter top - a W rafter takes a clip welded
    #   to its web with the purlin cut 1/8 in clear of the rafter flange (square cut, no cope), an
    #   open-face channel rafter holds the purlin inside the flanges 1/4 in from the web - so the
    #   Rafter top IS the roof line and the column runs to EAVE HEIGHT.
    # SEAT: welded to the column flange (inside flange, standard - the rafter top is level with the
    # column top) or the rafter ON TOP of the column seat (outside seat, option).  The pitched cap
    # plate stays on W rafters; open-face channel (single / doubled) rafters get no cap - carports.
    mono = p.frame_type == 'monoslope'
    fid = p.column_mark
    for location in p.welded_knee_overrides:
        ordinal = int(location.split(':', 1)[0])
        if ordinal > p.frames:
            raise ValueError(
                'Primary connection override refers to frame %d, but only %d rigid-frame lines are generated'
                % (ordinal, p.frames)
            )
    if p.welded_knee_overrides and p.connection_style == 'bolted':
        raise ValueError('Per-column seat overrides are only supported on welded primary frames')
    m = float(p.slope_rise) / 12
    co = 1 / math.sqrt(1 + m * m)
    sn = m * co
    ang = math.degrees(math.atan(m))
    if p.connection_style == 'welded_box' and mono:
        raise ValueError('Welded apex box is a gable option; choose fully_welded for mono-slope')
    if not p.auto_connections:
        raise ValueError('Welded frames require linked geometry')
    if p.height_mode != 'top_eave_strut':
        raise ValueError('Welded frames use top-of-purlin roof-line datum')
    if any(f(x) != 0 for x in (p.column_top_gap, p.knee_setback, p.ridge_half_gap, p.top_extension)):
        raise ValueError(
            'Welded seated frames require zero gaps/setbacks/top extension; the rafter end is flush with the outside column face'
        )
    if f(p.purlin_depth) <= 0 or f(p.eave_plate_extension) < 0:
        raise ValueError('Purlin depth must be positive; plate extension cannot be negative')
    if p.inset_for_bypass and (p.girt_mode != 'bypass' or f(p.girt_depth) <= 0):
        raise ValueError('Column inset requires bypass girts and a positive girt depth')
    inset = f(p.girt_depth) if p.inset_for_bypass else 0
    cs = sections.get_section(p.column_section)
    rs = sections.get_section(p.rafter_section)
    hs = sections.get_section(p.high_column_section or p.column_section)
    W = f(p.width)
    roof0 = f(p.eave_height)
    # P = the purlin depth the RAFTER TOP sits below the roof line: the purlin depth on the BYPASS
    # fit (purlin bearing on the rafter) and ZERO on the flush fit (purlin top flush with the rafter
    # top, the clip raised so a shallow purlin still reaches the roof line).
    P = 0.0 if p.purlin_mode == 'flush' else f(p.purlin_depth)
    channel_rafter = rs.kind == 'Channel'
    cap = inside and not channel_rafter
    d = rs.d
    bf = rs.bf
    if W <= 2 * inset + cs.d + hs.d:
        raise ValueError('Column inset consumes the building width')
    marks = [p.column_mark, p.rafter_mark] + ([p.high_column_mark] if mono else [])
    cuts = [p.column_cut_mark, p.rafter_cut_mark] + ([p.high_column_cut_mark] if mono else [])
    for mark, cut in zip(marks, cuts):
        if mark in job.parts:
            raise ValueError('Assembly mark belongs to a part: ' + mark)
        if mark in job.assemblies and job.assemblies[mark].derivation.get('frame_id') != fid:
            raise ValueError('Assembly mark already used: ' + mark)
        if any(a.main.mark == cut and a.derivation.get('frame_id') != fid for a in job.assemblies.values()):
            raise ValueError('Cut mark already used: ' + cut)
    clear_owned(job, fid)
    migrate_plate_defaults(job)
    params = p.to_json()
    members = []
    cols = []

    def plate(mark, t, w, h, role, owner=None, points=None):
        if mark in job.parts:
            raise ValueError('Part mark collision: ' + mark)
        points = points or [(0, 0), (h, 0), (h, w), (0, w)]
        x0 = min(x for x, y in points)
        y0 = min(y for x, y in points)
        pts = [(x - x0, y - y0) for x, y in points]
        L = max(x for x, y in pts)
        B = max(y for x, y in pts)
        q = Part(
            mark,
            'plate',
            precision(t),
            precision(B),
            precision(L),
            holes=[],
            symbol=dict(
                welded_frame_id=fid,
                owner=owner,
                role=role,
                draft_connection=True,
                cut_contour=[(precision(x).to_json(), precision(y).to_json()) for x, y in pts],
                weld_size=p.weld_size,
            ),
            source='User welded-frame geometry',
            notes='Welded; no bolt holes. Review fit/material/weld design before fabrication.',
        )
        job.parts[mark] = q
        return q

    def asm(mark, kind, qty, cut, section, length):
        a = Assembly(mark, kind, qty, MainMember(cut, section, D(grid16(length))))
        a.derivation = dict(wizard='rigid-frame', frame_id=fid, params=params, connection_style=p.connection_style)
        job.assemblies[mark] = a
        members.append(a)
        return a

    base = f(p.base_elevation)
    for side, mark, cut, sec in [('left', p.column_mark, p.column_cut_mark, cs)] + (
        [('right', p.high_column_mark, p.high_column_cut_mark, hs)] if mono else []
    ):
        x0 = inset if side == 'left' else W - inset - sec.d
        x1 = x0 + sec.d
        # Low side of each pitch-cut column, not its center or long point.
        xlow = x0
        toproof = roof0 + m * xlow
        ylow = toproof - P - (0 if inside else d / co)
        ylong = ylow + sec.d * m
        bp = resolve_base(job, p, sec.name)
        y0 = FND.column_bottom_in(p, base_thickness(bp))
        length = ylong - y0
        if ylow <= y0:
            raise ValueError('Roof deductions leave a nonpositive column height')
        a = asm(mark, 'COLUMN', p.frames if mono else 2 * p.frames, cut, sec.name, length)
        a.main.right_cut = EndCut('bevel', -ang if side == 'left' else ang)
        a.main.derivation = (
            'SHOP STANDARD inside-flange knee: rafter welded to the inside flange, column LONG point to the underside of the top plate, run to the rafter top line; '
            + (
                'FLUSH purlins: column cut to EAVE HEIGHT (roof line = top of rafter = top of purlin) and the eave purlin welded flush to the outside of the column flange'
                if P == 0
                else 'BYPASS purlins: eave purlin bears on the COLUMN SEAT, so the column is cut to EAVE HEIGHT less the purlin depth'
            )
            if cap
            else 'Side-welded open-face rafter: column LONG point at the rafter top line (pitch cut), rafter welded to the inside face, NO CAP; '
            + (
                'FLUSH purlins: column at EAVE HEIGHT, eave purlin welded flush to the outside of the column flange'
                if P == 0
                else 'BYPASS purlins: eave purlin bears on the COLUMN SEAT, column cut to EAVE HEIGHT less the purlin depth'
            )
            if inside
            else 'OPTION outside seat (rafter on top of the column seat): pitch-cut column LONG point; low side = roof line - actual plumb rafter depth - base elevation - base plate'
            + ('' if P == 0 else ' - purlin depth (the eave purlin bears on the rafter top flange)')
        ) + (
            f'; post footing: + {FND.depth(p).fmt()} embedment below the floor, no base plate'
            if FND.is_post_footing(p)
            else ''
        )
        a.attachments = [Attachment(bp.mark, 'left_end', show_first_hole_ref=True)] if bp else []
        a.derivation.update(
            resolved_base_plate=base_mark(bp),
            foundation=FND.record(p),
            embed_in=FND.embed_in(p),
            column_cut_unrounded_in=length,
            column_low_side_floor_in=ylow,
            column_long_side_floor_in=ylong,
            roof_line_at_low_side_in=toproof,
            rafter_top_at_low_side_in=toproof - P,
            welded_knee=p.welded_knee,
            nominal_depth_correction_in=0 if inside else d / co - d,
            nominal_depth_fit_difference_in=0.0,
            formula=a.main.derivation,
        )
        if cap:
            from .welded_knee import geometry as knee_geometry
            from .welded_knee import part as knee_part

            kg = knee_geometry(sec.d, bf, -p.slope_rise if side == 'right' else p.slope_rise)
            kp = knee_part(
                'WK-' + mark,
                kg,
                fid,
                (p.eave_clip or p.purlin_clip) if p.eave_start_clip and p.purlin_mode == 'bypass' else None,
            )
            job.parts[kp.mark] = kp
            a.attachments.append(Attachment(kp.mark, 'right_end', note='PITCHED TOP BEARING PLATE /3in rafter overlap'))
            knee_records.append(
                dict(
                    column=mark,
                    side=side,
                    part=kp.mark,
                    x=x0 if side == 'left' else x1,
                    y=ylow if side == 'left' else ylong,
                    mirror=1 if side == 'left' else -1,
                    geometry=kg,
                )
            )
        elevs = p.girt_elevations if side == 'left' or p.high_girt_elevations is None else p.high_girt_elevations
        for e in elevs:
            st = f(e) - y0
            if not 0 <= st <= ylow - y0:
                raise ValueError('Girt lies outside column low-side height')
            a.attachments.append(
                Attachment(
                    p.girt_clip,
                    'top' if p.girt_mode == 'bypass' else 'web',
                    precision(st),
                    side=p.girt_side if p.girt_mode == 'flush' else 'NS',
                    y_from_top=p.girt_web_y if p.girt_mode == 'flush' else None,
                    note='girt ' + p.girt_mode,
                )
            )
        cols.append(
            dict(
                mark=mark,
                side=side,
                x0=x0,
                x1=x1,
                y0=y0,
                y1=ylow,
                top_y0=ylow,
                top_y1=ylong,
                design_length=length,
                shop_cut=a.main.cut_length.fmt(),
                base_thickness=base_thickness(bp),
                rounding_residual_in=f(a.main.cut_length) - length,
            )
        )
    if cap and not mono:
        knee_records.append({**knee_records[0], 'side': 'right', 'x': W - inset, 'mirror': -1})
    if not mono:
        cols.append(
            {
                **cols[0],
                'side': 'right',
                'x0': W - inset - cs.d,
                'x1': W - inset,
                'top_y0': cols[0]['top_y1'],
                'top_y1': cols[0]['top_y0'],
            }
        )
    root = None
    connections = []
    ridge_x = W / 2
    ridge_y = roof0 - P + m * W / 2
    from .frame import ridge_fabrication_resolved

    fold = (
        not mono
        and p.connection_style == 'fully_welded'
        and not channel_rafter
        and ridge_fabrication_resolved(p) == 'cut_and_fold'
    )
    ridge_joint = None
    ep = None
    reach = 0.0
    inner = 0.0
    if fold:
        # Owner (shop standard option): ONE-PIECE W rafter.  A wedge 2 x depth x tan(pitch) wide at the
        # bottom flange, apex at the underside of the top flange, is cut out of the bottom flange and the
        # web at the ridge; the rafter is folded to the pitch on the continuous top flange and the seam is
        # welded back up.  No ridge plate, no ridge connection: the two legs are one shop piece.
        ridge_joint = 'cut_and_fold'
    if not mono and not fold:
        rm = 'AP-' + fid
        if rm in job.parts:
            raise ValueError('Connection mark already used: ' + rm)
        cfg = dict(
            welded=True,
            kind='apex',
            installed=True,
            frame_role='ridge',
            frame_id=fid,
            qty=p.frames,
            column=fid,
            rafter=p.rafter_mark,
            rise=str(p.slope_rise),
        )
        children = []
        profiles = []

        def add_piece(suffix, t, w, h, role, polys, points=None, count=1):
            pp = plate(rm + '-' + suffix, t, w, h, role, rm, points)
            children.extend(Attachment(pp.mark, 'top') for _ in range(count))
            profiles.extend(dict(role=role, points=poly) for poly in polys)
            return pp

        ridge_joint = 'shared_plate' if p.connection_style == 'fully_welded' else 'box'
        if p.connection_style == 'fully_welded' and channel_rafter:
            # Owner (gable carports): open-face channel rafters BUTT at the ridge; 3/16 x 5 x 7 splice
            # plates welded to the channel faces, one each side - the end-wall ridge detail
            ridge_joint = 'face_splice'
            cut_depth = d / co
            H = 5.0
            reach = 0.0
            inner = 0.0
            pad = (cut_depth - H) / 2  # plate centred on the plumb rafter depth
            ep = add_piece(
                'FACE',
                3 / 16,
                5,
                7,
                'ridge face splice plate, one each side; welded to the channel faces; NO BOLTS',
                [[(-3.5, 0), (3.5, 0), (3.5, H), (-3.5, H)]],
                count=2,
            )
            ep.symbol.update(face_splice=True, actual_pitch_cut_in=cut_depth)
            ep.description = 'PL .188 x 5.000 x 7.000 IN'
            endpoints = [(0.0, H + pad), (0.0, H + pad)]
            root_y = ridge_y - H - pad
        elif p.connection_style == 'fully_welded':
            cut_depth = d / co
            H = cut_depth + 1
            reach = 0.25
            inner = 0.0
            root_y = ridge_y - H + 0.5 - reach * m
            ep = add_piece(
                'RIDGE',
                0.5,
                bf,
                H,
                'single shared ridge plate: actual pitch cut +1in',
                [[(-0.25, 0), (0.25, 0), (0.25, H), (-0.25, H)]],
            )
            ep.symbol.update(actual_pitch_cut_in=cut_depth, top_extension_in=0.5, bottom_extension_in=0.5)
            ep.description = f'PL .500 x {bf:.3f} x {H:.3f} IN'
            endpoints = [(0.25, H - 0.5), (-0.25, H - 0.5)]
        else:
            F = f(p.apex_bottom_half or D(6))
            t = f(p.flange_thk)
            tw = f(p.web_thk)
            if F <= t or t <= 0 or tw <= 0 or 2 * t >= d or tw >= bf:
                raise ValueError('Invalid welded apex plate/body dimensions')
            E = (F + d * sn, d * co)
            H = d / co + F * m
            top = [(0, H), E, (E[0] - t * sn, E[1] - t * co), (0, H - t / co)]
            end = [(F, 0), E, (E[0] + 0.5 * co, E[1] - 0.5 * sn), (F + 0.5 * co, -0.5 * sn)]
            add_piece('TOP', t, bf, E[0] / co, 'apex top flange', [top, [(-x, y) for x, y in top]], count=2)
            add_piece('BOT', t, bf, 2 * F, 'horizontal bottom', [[(-F, 0), (F, 0), (F, t), (-F, t)]])
            xb = F + t * m
            xt = E[0] - t * sn
            yt = E[1] - t * co
            web = [(-xb, t), (xb, t), (xt, yt), (0, H - t / co), (-xt, yt)]
            add_piece('WEB', tw, 0, 0, 'single continuous apex web', [web], web)
            ep = add_piece('END', 0.5, bf, d, 'welded end plate; NO BOLTS', [end, [(-x, y) for x, y in end]], count=2)
            inner = E[0] / co
            reach = E[0] + 0.5 * co
            endpoints = [(reach, E[1] - 0.5 * sn), (-reach, E[1] - 0.5 * sn)]
            root_y = ridge_y - H
        root = Part(
            rm,
            'bracket',
            attachments=children,
            source='User welded frame',
            symbol=dict(
                connection=True,
                welded=True,
                config=cfg,
                welded_frame_id=fid,
                ridge_type=p.connection_style,
                ridge_joint=ridge_joint,
                welded_profiles=profiles,
                h=H,
                w=2 * reach,
                rafter_depth=d,
                pitch_deg=ang,
                bottom_length_in=f(p.apex_bottom_half or D(6))
                if p.connection_style == 'welded_box'
                else 0.25
                if ridge_joint == 'shared_plate'
                else 0,
                top_extension_in=0.5 if ridge_joint == 'shared_plate' else 0,
                bottom_extension_in=0.5 if ridge_joint == 'shared_plate' else 0,
                mate=ep.mark,
                interfaces=0,
                roof_clips=[],
                beam_starts=endpoints,
                pending=[
                    'WELDED — no connection bolt holes or loose bolted mates. Verify weld lengths, access and capacity.',
                    f'Column cut includes plumb-depth correction {d / co - d:.6f} in; nominal subtraction does not leave an overlap.',
                    'Square cuts through plate thickness; no bevel preparation inferred.',
                ],
            ),
        )
        root.unit_weight = sum((job.part(a.part).weight(job.weights) for a in children), Decimal(0))
        job.parts[rm] = root
        job.settings.setdefault('connections', {})[rm] = cfg
        connections.append(
            dict(
                mark=rm,
                x=ridge_x,
                y=root_y,
                mirror=1,
            )
        )
    start_x = inset + (cs.d if inside else 0)
    start = [start_x, roof0 - P + start_x * m]
    end_x = W - inset - (hs.d if inside else 0)
    end = [end_x, roof0 - P + end_x * m] if mono else [ridge_x - reach, ridge_y - reach * m]
    top_length = (end[0] - start[0]) / co
    offset = d * m
    length = top_length + offset
    if top_length <= 6:
        raise ValueError('Connections consume the rafter span')
    fold_record = None
    if fold:
        # straight blank, bottom (long) corner of the left knee cut to the bottom corner of the right knee cut
        overall = 2 * top_length + 2 * offset
        fold_record = dict(
            overall_in=overall,
            leg_top_in=top_length,
            leg_bottom_in=top_length,
            wedge_bottom_in=2 * offset,
            wedge_half_in=offset,
            wedge_depth_in=d - f(rs.tf or 0),
            knee_long_point_in=offset,
            centre_in=overall / 2,
            pitch_deg=ang,
            rafter_depth_in=d,
            rule='Bottom of knee cut to bottom of ridge wedge = top-line span / cos(pitch) each leg; wedge at the bottom flange = 2 x depth x tan(pitch) with its apex at the underside of the top flange; overall blank = both legs + the wedge (the wedge is the cut loss and is included in the stock length).',
        )
        raf = asm(p.rafter_mark, 'RAFTER', p.frames, p.rafter_cut_mark, rs.name, overall)
        raf.main.left_cut = EndCut('bevel', ang)
        raf.main.right_cut = EndCut('bevel', -ang)
        raf.main.derivation = 'ONE-PIECE CUT-AND-FOLD RAFTER: blank = 2 x (top-line span/cos(pitch) + depth*tan(pitch)); knee cuts plumb both ends (long point at the bottom flange); ridge wedge 2 x depth*tan(pitch) cut from the bottom flange and web, folded on the top flange and welded. No ridge plate.'
    else:
        raf = asm(p.rafter_mark, 'RAFTER', p.frames if mono else 2 * p.frames, p.rafter_cut_mark, rs.name, length)
        raf.main.left_cut = EndCut('bevel', ang)
        raf.main.right_cut = EndCut('bevel', ang) if mono or p.connection_style == 'fully_welded' else EndCut()
        raf.main.derivation = 'LONG-point blank = top-line span/cos(pitch) + rafter depth*tan(pitch); column end plumb. No weld-preparation bevel specified.'
    eplate = None
    if not inside:
        eplate = plate(
            'WE-' + fid,
            3 / 16,
            bf,
            d / co + f(p.eave_plate_extension),
            'column-end cover plate; top flush with rafter; actual overlap ' + p.eave_plate_extension.fmt(),
        )
        eplate.symbol.update(top_flush=True, extension_in=f(p.eave_plate_extension), plumb_rafter_depth_in=d / co)
        eplate.description = f'PL .188 x {bf:.3f} x {d / co + f(p.eave_plate_extension):.3f} IN'
        raf.attachments = [Attachment(eplate.mark, 'left_end', note='WELDED: TOP FLUSH; extends onto column')]
        if mono:
            raf.attachments.append(
                Attachment(eplate.mark, 'right_end', note='WELDED: TOP FLUSH; extends onto high column')
            )
    else:
        raf.attachments = []
    regular_cp = job.part(p.purlin_clip)
    starting_cp = job.part(p.eave_clip or p.purlin_clip)
    cp = regular_cp
    ct = f(cp.thk)
    if min(ct, f(cp.length), f(cp.width)) <= 0:
        raise ValueError('Selected roof clip needs positive plate dimensions')
    first = f(p.first_purlin) + (cs.d / co if p.first_purlin_datum == 'column_face' else 0)
    if inside and p.first_purlin_datum == 'column_face':
        first = f(p.first_purlin)
    if inside and p.first_purlin_datum == 'outside_column':
        first = f(p.first_purlin) - cs.d / co
    if p.first_purlin_datum == 'rafter_cut':
        first -= offset
    if not p.auto_roof_spacing and (first < 0 or first >= top_length - 6):
        raise ValueError('First regular purlin falls outside usable rafter range')
    peak = None
    limit = top_length - 6
    if not mono and p.peak_clip_edge is not None:
        raw = (ridge_x - start[0]) / co - f(p.peak_clip_edge) - ct / 2
        st = math.floor((raw + offset) * 16) / 16 - offset
        edge = (ridge_x - start[0]) / co - st - ct / 2
        if not p.auto_roof_spacing and st <= first + ct:
            raise ValueError('First and peak clips overlap/reverse; check distances')
        support = (
            'apex'
            if p.connection_style == 'welded_box' and edge + ct <= inner
            else 'rafter'
            if st + ct / 2 <= top_length
            else 'interface conflict'
        )
        peak = dict(
            input_edge_in=f(p.peak_clip_edge),
            actual_edge_in=edge,
            station_in=st + offset,
            station_from_cut=precision(st + offset).fmt(),
            thickness_in=ct,
            height_in=f(cp.length),
            part=cp.mark,
            mode=p.purlin_mode,
            web_center_in=f(p.purlin_web_y),
            web_height_in=f(cp.width),
            datum='ridge centerline to nearest clip edge along slope',
            support=support,
            rounding_away_from_ridge_in=edge - f(p.peak_clip_edge),
            warnings=[],
        )
        limit = min(limit, st - ct)
    stations = []
    s = first
    while s < limit:
        if len(stations) > 10000:
            raise ValueError('Too many purlin stations')
        stations.append((s, 'regular'))
        s += f(p.purlin_spacing)
    if p.auto_roof_spacing:
        from .layout_options import equal_stations

        endpoint = st if peak else limit
        stations = [(x, 'regular') for x in equal_stations(endpoint)]
        if not peak:
            stations.append((endpoint, 'regular'))
    if p.eave_start_clip and (not inside or p.purlin_mode == 'flush'):
        stations.insert(0, (ct / 2, 'starting'))
    if mono and p.eave_start_clip and (not inside or p.purlin_mode == 'flush'):
        stations.append((top_length - ct / 2, 'starting high'))
    if peak:
        stations.append((st, 'peak'))
    clip_records = []
    checks = []
    # Open-face channel rafter with flush purlins (shop rule): the purlin sits inside the open
    # face 1/4 in from the web and is welded to the channel flanges top and bottom - no clips.
    in_channel = rs.kind == 'Channel' and p.purlin_mode == 'flush'
    for s, role in stations:
        cp = starting_cp if role.startswith('starting') else regular_cp
        ct = f(cp.thk)
        station = D(grid16(s + offset)) if role == 'regular' else precision(s + offset)
        # Keep actual setout synchronized with displayed station rounding.
        s = f(station) - offset
        own = role == 'peak' and peak['support'] == 'apex'
        if in_channel:
            # no clip part is attached, weighed or ordered; the record keeps the station for the
            # purlin rows and the frame sheet (drawn as the purlin end inside the channel)
            clip_records.append(
                dict(
                    part=cp.mark,
                    role=role,
                    station_top_in=s,
                    station_in=f(station),
                    owner=raf.mark,
                    orientation='IN CHANNEL',
                    in_channel=True,
                )
            )
            continue
        if own:
            for sign in [-1, 1]:
                z0 = 0 if p.purlin_mode == 'bypass' else -f(p.purlin_web_y) - f(cp.width) / 2
                z1 = f(cp.length) if p.purlin_mode == 'bypass' else z0 + f(cp.width)
                corners = [
                    (sign * (dd * co + z * sn), H - dd * sn + z * co)
                    for dd, z in [(edge, z0), (edge + ct, z0), (edge + ct, z1), (edge, z1)]
                ]
                root.symbol['roof_clips'].append(
                    dict(
                        role='peak',
                        part=cp.mark,
                        corners=corners,
                        quantity=2 if p.purlin_mode == 'flush' and p.purlin_side == 'both' else 1,
                        mirror=sign,
                        near_edge_in=edge,
                        station_in=edge + ct / 2,
                        datum=peak['datum'],
                    )
                )
                root.attachments.append(
                    Attachment(
                        cp.mark,
                        'top' if p.purlin_mode == 'bypass' else 'web',
                        precision(edge + ct / 2),
                        side=p.purlin_side if p.purlin_mode == 'flush' else 'NS',
                        note='peak apex clip',
                    )
                )
                root.unit_weight += cp.weight(job.weights) * (
                    2 if p.purlin_mode == 'flush' and p.purlin_side == 'both' else 1
                )
        else:
            raf.attachments.append(
                Attachment(
                    cp.mark,
                    'top' if p.purlin_mode == 'bypass' else 'web',
                    station,
                    side=p.purlin_side if p.purlin_mode == 'flush' else 'NS',
                    y_from_top=p.purlin_web_y if p.purlin_mode == 'flush' else None,
                    note=role + ' purlin ' + p.purlin_mode,
                    tilt=-ang if role.startswith('starting') else 0,
                    label=role.upper() + ' ' + cp.mark,
                )
            )
            if fold_record:
                # one-piece rafter: the right leg carries the mirror image of every clip,
                # stationed from the same left long point
                raf.attachments.append(
                    Attachment(
                        cp.mark,
                        'top' if p.purlin_mode == 'bypass' else 'web',
                        precision(f(raf.main.cut_length) - f(station)),
                        side=p.purlin_side if p.purlin_mode == 'flush' else 'NS',
                        y_from_top=p.purlin_web_y if p.purlin_mode == 'flush' else None,
                        note='right leg ' + role + ' purlin ' + p.purlin_mode,
                        tilt=ang if role.startswith('starting') else 0,
                        label=role.upper() + ' ' + cp.mark,
                    )
                )
        clip_records.append(
            dict(
                part=cp.mark,
                role=role,
                station_top_in=s,
                station_in=f(station),
                owner=root.mark if own else raf.mark,
                orientation='PLUMB' if role.startswith('starting') else 'ROOF NORMAL',
            )
        )
        # Starting clip deliberately aligns with its welded eave cover plate; no bolt-access gap is required there.
        if root:
            far = top_length
            thick = 0.5 / co if p.connection_style == 'fully_welded' else 0.5
            c = check_edges(
                s - ct / 2,
                s + ct / 2,
                [(ep.mark, far, far + thick)],
                root.mark if own else raf.mark,
                role,
                cp.mark,
                f(station),
            )
            c['datum'] = 'rafter top-cut along slope'
            checks.append(c)
            if role == 'peak':
                peak['warnings'] = c['warnings']
                peak['clearance_checks'] = c['checks']
                peak['clip_clearance_in'] = c['checks'][0]['clearance_in']
    regular = [r for r in clip_records if r['role'] == 'regular']
    for i in p.flange_brace_at:
        if 0 <= i < len(regular):
            if fold_record:
                raf.attachments.append(
                    Attachment(
                        p.flange_brace_clip,
                        'web',
                        precision(f(raf.main.cut_length) - regular[i]['station_in']),
                        side='both',
                        y_from_top=p.flange_brace_y,
                    )
                )
            raf.attachments.append(
                Attachment(
                    p.flange_brace_clip,
                    'web',
                    precision(regular[i]['station_in']),
                    side='both',
                    y_from_top=p.flange_brace_y,
                )
            )
    for a, part, mode, y in [
        (members[0], p.girt_clip, p.girt_mode, p.girt_web_y),
        (raf, p.purlin_clip, p.purlin_mode, p.purlin_web_y),
    ] + ([(members[1], p.girt_clip, p.girt_mode, p.girt_web_y)] if mono else []):
        if mode == 'flush':
            if job.part(part).kind == 'mark':
                continue  # girt welded directly to the web: no clip to fit
            if a.main.sec.kind == 'HSS':
                a.derivation.setdefault('section_fit_holds', []).append(
                    'Closed HSS: external side-face clips only, no internal web; weld access, wall thickness, fit and connection capacity unverified'
                )
                continue
            if a.main.sec.tf is None:
                a.derivation.setdefault('section_fit_holds', []).append(
                    'Channel flange/web thickness unknown; flush clip and secondary fit are not verified from gauge alone'
                )
                if f(y) - f(job.part(part).width) / 2 < 0 or f(y) + f(job.part(part).width) / 2 > a.main.sec.d:
                    raise ValueError('Flush clip exceeds even the outside channel depth')
            elif (
                f(y) - f(job.part(part).width) / 2 < a.main.sec.tf
                or f(y) + f(job.part(part).width) / 2 > a.main.sec.d - a.main.sec.tf
            ):
                raise ValueError('Flush clip does not fit selected member web')
    raf.derivation.update(
        rafter_cut_unrounded_in=fold_record['overall_in'] if fold_record else length,
        leg_blank_in=length,
        ridge_fold=fold_record,
        top_line_length_in=top_length,
        top_cut_station_in=offset,
        peak_clip=peak,
        first_purlin_datum=p.first_purlin_datum,
        first_purlin_input=p.first_purlin.fmt(),
        bracket_occupied_slope_in=0,
        first_purlin_formula='No eave bracket; first regular station follows selected datum. Add depth*tan(pitch) for long-point cut origin.',
        purlin_stations=[precision(r['station_in']).fmt() for r in clip_records],
        clip_clearances=checks,
        clip_warnings=[w for c in checks for w in c['warnings']],
        formula=raf.main.derivation,
    )
    roofs = [
        dict(
            mark=raf.mark,
            side='left',
            top_start=start,
            top_end=end,
            direction=[co, sn],
            normal=[-sn, co],
            design_length=length,
            shop_cut=raf.main.cut_length.fmt(),
            rounding_residual_in=f(raf.main.cut_length) - length,
            top_cut_station_in=offset,
            far_plumb=mono or p.connection_style == 'fully_welded',
            one_piece=bool(fold_record),
        )
    ]
    if not mono:
        roofs.append(
            {
                **roofs[0],
                'side': 'right',
                'top_start': [W - start[0], start[1]],
                'top_end': [W - end[0], end[1]],
                'direction': [-co, sn],
                'normal': [sn, co],
            }
        )
    schedule = [
        dict(
            mark=a.mark,
            role=a.kind.lower(),
            per_frame=a.qty // p.frames,
            total=a.qty,
            section=a.main.section,
            cut=a.main.cut_length.fmt(),
        )
        for a in members
    ]
    if root:
        schedule.append(
            dict(
                mark=root.mark,
                role=p.connection_style,
                per_frame=1,
                total=p.frames,
                section='welded ridge',
                cut='see detail',
            )
        )
    warns = [w for c in checks for w in c['warnings']]
    knee_notes = (
        knee_records[0]['geometry']['fit_notes']
        if cap
        else [
            'Column run to the rafter top line and cut to the pitch; open-face rafter welded to the inside face; no cap plate.'
        ]
        if inside
        else []
    )
    job.settings.setdefault('frame_layouts', {})[fid] = dict(
        welded=True,
        connection_style=p.connection_style,
        frame_id=fid,
        frame_type=p.frame_type,
        frames=p.frames,
        width_in=W,
        inset_in=inset,
        # Round 15 datums: low_eave_in / high_eave_in = the TOP OF THE EAVE PURLIN (eave height, the
        # roof line at the wall), peak_height_in = the TOP OF THE PEAK PURLIN (the actual highest
        # point of the roof line - not the height of the last purlin row's top edge); a lean-to
        # reports its own eave height even when it is tied into the same roof line.
        low_eave_in=roof0,
        high_eave_in=roof0 + W * m if mono else roof0,
        peak_height_in=roof0 + W * m if mono else roof0 + W * m / 2,
        ridge_top_in=None if mono else ridge_y,
        roof_left_in=roof0 - P,
        strut_depth_in=P,
        nominal_roof_purlin_depth_in=f(p.purlin_depth),
        slope_rise=str(p.slope_rise),
        base_elevation_in=base,
        foundation=FND.record(p),
        columns=cols,
        rafters=roofs,
        connections=connections,
        schedule=schedule,
        peak_clip=peak,
        clip_records=clip_records,
        clip_clearances=checks,
        clip_warnings=warns,
        knee_notes=knee_notes,
        eave_plate=eplate.mark if eplate else None,
        welded_knee=p.welded_knee,
        welded_knee_cap=cap,
        rafter_seat='inside_face' if inside else 'on_top',
        ridge_joint=None if mono else ridge_joint,
        ridge_fold=fold_record,
        knee_records=knee_records,
        nominal_depth_correction_in=0 if inside else d / co - d,
        nominal_depth_fit_difference_in=0.0,
        datum=(
            'Fixed outside wall lines; ROOF LINE = TOP OF PURLIN; eave height = top of the eave purlin,'
            ' peak height = top of the peak purlin; '
            + (
                'FLUSH fit: rafter top = roof line, column to eave height'
                if P == 0
                else 'BYPASS fit: purlin bears on the rafter top flange, rafter top = roof line less the purlin depth'
            )
            + (
                ', inside-flange knee (rafter welded to the column flange)'
                if inside
                else ', outside seat (rafter on the column seat)'
            )
        ),
        allowances={},
        version=8,
    )
    params['dependency_key'] = dependency_key(job, p)
    job.settings.setdefault('frames', {})[fid] = params
    return [job.assemblies[k] for k in marks]


def split_physical_frame_connections(job, p):
    """Split welded primary members to one physical frame/column per assembly when local seat
    overrides are requested.  This runs after the shared building geometry has been resolved, so
    longitudinal secondary layouts remain anchored to the parent frame family.
    """
    overrides = p.welded_knee_overrides or {}
    if not overrides:
        return []
    if p.connection_style == 'bolted':
        raise ValueError('Per-column seat overrides are only supported on welded primary frames')
    from .frame import grid16

    fid = p.column_mark
    layout = job.settings['frame_layouts'][fid]
    column_templates = {
        'left': copy.deepcopy(job.assemblies[p.column_mark]),
        'right': copy.deepcopy(job.assemblies[p.high_column_mark])
        if p.frame_type == 'monoslope'
        else copy.deepcopy(job.assemblies[p.column_mark]),
    }
    rafter_template = copy.deepcopy(job.assemblies[p.rafter_mark])
    mono = p.frame_type == 'monoslope'
    folded = bool(layout.get('ridge_fold'))
    m = float(p.slope_rise) / 12
    co = 1 / math.hypot(1, m)
    d = float(rafter_template.main.sec.d)
    offset = d * m
    W = float(p.width.inches)
    inset = float(p.girt_depth.inches) if p.inset_for_bypass else 0.0
    channel = rafter_template.main.sec.kind == 'Channel'
    physical_columns = []
    physical_rafters = []
    made = []

    def mode_for(ordinal, side):
        return overrides.get(f'{ordinal}:{side}', p.welded_knee)

    def seat_tail(mode):
        return 0.0 if mode == 'inside_flange' else d / co

    def first_purlin(mode, column_depth):
        value = float(p.first_purlin.inches)
        if p.first_purlin_datum == 'column_face':
            value += column_depth / co
            if mode == 'inside_flange':
                value = float(p.first_purlin.inches)
        if mode == 'inside_flange' and p.first_purlin_datum == 'outside_column':
            value -= column_depth / co
        if p.first_purlin_datum == 'rafter_cut':
            value -= offset
        return value

    def leg_length(mode, column_depth):
        start_x = inset + (column_depth if mode == 'inside_flange' else 0.0)
        return (W / 2 - start_x) / co + offset

    def rafter_length(left_mode, right_mode):
        if mono:
            cs = column_templates['left'].main.sec
            hs = column_templates['right'].main.sec
            start_x = inset + (float(cs.d) if left_mode == 'inside_flange' else 0.0)
            end_x = W - inset - (float(hs.d) if right_mode == 'inside_flange' else 0.0)
            return (end_x - start_x) / co + offset
        if folded:
            cs = float(column_templates['left'].main.sec.d)
            return leg_length(left_mode, cs) + leg_length(right_mode, cs)
        return leg_length(left_mode, float(column_templates['left'].main.sec.d))

    def ensure_cover():
        mark = 'WE-' + fid
        if mark not in job.parts:
            sec = rafter_template.main.sec
            length = float(sec.d) / co + float(p.eave_plate_extension.inches)
            plate = Part(
                mark,
                'plate',
                D('3/16'),
                D(sec.bf),
                D(length),
                source='User welded frame',
                notes='Column-end cover plate; top flush with rafter; actual plumb overlap plus entered extension.',
                symbol=dict(
                    welded_frame_id=fid,
                    role='column-end cover plate',
                    top_flush=True,
                    extension_in=float(p.eave_plate_extension.inches),
                    plumb_rafter_depth_in=float(sec.d) / co,
                ),
            )
            plate.description = f'PL .188 x {float(sec.bf):.3f} x {length:.3f} IN'
            job.parts[mark] = plate
        return mark

    def ensure_knee(side):
        base_mark = p.high_column_mark if mono and side == 'right' else p.column_mark
        mark = 'WK-' + base_mark
        if mark not in job.parts:
            from .welded_knee import geometry as knee_geometry
            from .welded_knee import part as knee_part

            sec = column_templates[side].main.sec
            pitch = -p.slope_rise if mono and side == 'right' else p.slope_rise
            geo = knee_geometry(float(sec.d), float(rafter_template.main.sec.bf), pitch)
            start_clip = (p.eave_clip or p.purlin_clip) if p.eave_start_clip and p.purlin_mode == 'bypass' else None
            job.parts[mark] = knee_part(mark, geo, fid, start_clip)
        return mark

    def locate_assembly(template, mark, cut_mark, kind, ordinal, side, mode, length):
        if mark == template.mark:
            a = job.assemblies[mark]
        else:
            if mark in job.assemblies or cut_mark in {x.main.mark for x in job.assemblies.values()}:
                raise ValueError('Physical frame member mark already in use: ' + mark)
            a = copy.deepcopy(template)
            a.mark = mark
            a.main.mark = cut_mark
            for owner_key in (
                'framing_additions',
                'cladding',
                'endwalls',
                'column_grades',
                'secondary_runs',
                'secondary_warnings',
                'secondary_material_rows',
                'secondary_catalog',
                'wall_girt_connections',
                'end_girt_clip_quantity',
                'end_girt_clip_counts',
                'bay_zones',
            ):
                a.derivation.pop(owner_key, None)
            job.assemblies[mark] = a
            made.append(a)
        a.qty = 1
        a.main.cut_length = D(grid16(length))
        a.derivation['physical_frame_connection'] = dict(frame_id=fid, frame_ordinal=ordinal, side=side, mode=mode)
        a.derivation['frame_id'] = fid
        params = a.derivation.get('params')
        if isinstance(params, dict):
            params['welded_knee'] = mode
        a.main.derivation = (
            a.main.derivation or ''
        ) + f'; PHYSICAL FRAME {ordinal} {side.upper()} / {mode}; cut length {a.main.cut_length.fmt()}'
        return a

    # Column stock is now individual by frame and side. Resolve that frame line's grade before
    # changing the seat deduction so the per-location cut remains correct on stepped slabs.
    from . import frame_lines as FL
    from . import grades as GR

    physical_line_indices = [x['index'] for x in FL.lines(job, fid) if x['kind'] == 'interior']
    column_bases = {}
    for side, mark in [('left', p.column_mark), ('right', p.high_column_mark if mono else p.column_mark)]:
        template = column_templates[side]
        meta = next((x for x in layout.get('columns', []) if x.get('side') == side), {})
        for ordinal in range(1, p.frames + 1):
            line_index = physical_line_indices[ordinal - 1] if ordinal <= len(physical_line_indices) else ordinal
            grade_row = GR.line_columns(layout, line_index).get(side) or {}
            default_length = float(
                grade_row.get('cut_in') or meta.get('design_length', template.main.cut_length.inches)
            )
            mode = mode_for(ordinal, side)
            new_length = default_length - seat_tail(mode) + seat_tail(p.welded_knee)
            is_base_location = ordinal == 1 and (side == 'left' or mono)
            mark_out = mark if is_base_location else f'{mark}-F{ordinal:03d}-{side[0].upper()}'
            cut = template.main.mark if is_base_location else template.main.mark + f'-F{ordinal:03d}-{side[0].upper()}'
            a = locate_assembly(template, mark_out, cut, 'COLUMN', ordinal, side, mode, new_length)
            # Correct the head attachment/plate schedule for this actual connection mode.
            a.attachments = [att for att in a.attachments if 'PITCHED TOP BEARING PLATE' not in (att.note or '')]
            if mode == 'inside_flange' and not channel:
                knee = ensure_knee(side)
                a.attachments.append(
                    Attachment(knee, 'right_end', note='PITCHED TOP BEARING PLATE /3in rafter overlap')
                )
            physical_columns.append(
                dict(
                    frame_ordinal=ordinal,
                    side=side,
                    mode=mode,
                    source='override' if f'{ordinal}:{side}' in overrides else 'inherited',
                    mark=a.mark,
                    cut_mark=a.main.mark,
                    section=a.main.section,
                    cut_length_in=float(a.main.cut_length.inches),
                )
            )
            column_bases[(ordinal, side)] = a

    # Split rafter cut takeoffs to one physical frame (cut-and-fold), one physical mono rafter,
    # or one eave-to-ridge leg (two-piece gable) per mark. Purlin clip stations are translated
    # with the eave seat so their location remains measured from the actual steel cut.
    old_rafter_length = float(rafter_template.main.cut_length.inches)

    def raf_suffix(ordinal, side=None):
        return f'-F{ordinal:03d}' + (f'-{side[0].upper()}' if side else '')

    def make_rafter(ordinal, side=None):
        left_mode = mode_for(ordinal, 'left')
        right_mode = mode_for(ordinal, 'right')
        if mono or folded:
            new_length = rafter_length(left_mode, right_mode)
            physical_side = 'both'
            mark_out = p.rafter_mark if ordinal == 1 else p.rafter_mark + raf_suffix(ordinal)
            cut_mark = rafter_template.main.mark if ordinal == 1 else rafter_template.main.mark + raf_suffix(ordinal)
        else:
            physical_side = side
            seat_mode = left_mode if side == 'left' else right_mode
            new_length = leg_length(seat_mode, float(column_templates[side].main.sec.d))
            mark_out = p.rafter_mark if ordinal == 1 and side == 'left' else p.rafter_mark + raf_suffix(ordinal, side)
            cut_mark = (
                rafter_template.main.mark
                if ordinal == 1 and side == 'left'
                else rafter_template.main.mark + raf_suffix(ordinal, side)
            )
        a = locate_assembly(
            rafter_template,
            mark_out,
            cut_mark,
            'RAFTER',
            ordinal,
            physical_side,
            left_mode if physical_side != 'right' else right_mode,
            new_length,
        )
        # Keep eave covers on exactly the outside-seat ends; the plate is shared by identical parts.
        a.attachments = [
            att for att in a.attachments if not (att.part == 'WE-' + fid and 'WELDED: TOP FLUSH' in (att.note or ''))
        ]
        cover = (
            ensure_cover()
            if (
                (physical_side == 'left' and left_mode == 'outside_seat')
                or (physical_side == 'right' and right_mode == 'outside_seat')
                or (physical_side == 'both' and (left_mode == 'outside_seat' or right_mode == 'outside_seat'))
            )
            else None
        )
        if cover:
            if physical_side == 'right':
                a.attachments.append(Attachment(cover, 'left_end', note='WELDED: TOP FLUSH; extends onto column'))
            elif physical_side == 'both':
                if left_mode == 'outside_seat':
                    a.attachments.append(Attachment(cover, 'left_end', note='WELDED: TOP FLUSH; extends onto column'))
                if right_mode == 'outside_seat':
                    a.attachments.append(Attachment(cover, 'right_end', note='WELDED: TOP FLUSH; extends onto column'))
            else:
                a.attachments.append(Attachment(cover, 'left_end', note='WELDED: TOP FLUSH; extends onto column'))
        # Translate connection-driven purlin clip stations for this physical steel blank.
        if not (mono or folded):
            seat_mode = left_mode if side == 'left' else right_mode
            col_depth = float(column_templates[side].main.sec.d)
            first_delta = first_purlin(seat_mode, col_depth) - first_purlin(p.welded_knee, col_depth)
            length_delta = new_length - old_rafter_length
            for att in a.attachments:
                if att.station is None:
                    continue
                note = (att.note or '').lower()
                if 'regular purlin' in note:
                    att.station = D(float(att.station.inches) + first_delta)
                elif 'peak purlin' in note:
                    att.station = D(float(att.station.inches) + length_delta)
        else:
            # On the one-piece gable / mono rafter, the existing clip set has a mirrored right
            # leg. Move each half independently while retaining the mirror datum about the apex.
            length_delta = new_length - old_rafter_length
            left_depth = float(column_templates['left'].main.sec.d)
            right_depth = float(column_templates['right'].main.sec.d)
            left_first = first_purlin(left_mode, left_depth) - first_purlin(p.welded_knee, left_depth)
            right_first = first_purlin(right_mode, right_depth) - first_purlin(p.welded_knee, right_depth)
            for att in a.attachments:
                if att.station is None:
                    continue
                note = (att.note or '').lower()
                old_station = float(att.station.inches)
                on_right = old_station > old_rafter_length / 2 if folded else False
                local_shift = 0.0
                if 'regular purlin' in note:
                    local_shift = right_first if on_right else left_first
                elif 'peak purlin' in note:
                    local_shift = (new_length - old_rafter_length) / 2 if folded else 0.0
                if folded and on_right:
                    shift = length_delta - local_shift
                else:
                    shift = local_shift
                att.station = D(old_station + shift)
        purlin_stations = sorted(
            float(att.station.inches)
            for att in a.attachments
            if att.station is not None and 'purlin' in (att.note or '').lower()
        )
        purlin_left = list(purlin_stations)
        purlin_right = list(purlin_stations)
        if folded:
            left_length = leg_length(left_mode, float(column_templates['left'].main.sec.d))
            purlin_left = [x for x in purlin_stations if x <= left_length + 1e-6]
            purlin_right = [float(a.main.cut_length.inches) - x for x in purlin_stations if x > left_length + 1e-6]
        physical_rafters.append(
            dict(
                frame_ordinal=ordinal,
                side=physical_side,
                left_mode=left_mode,
                right_mode=right_mode,
                mark=a.mark,
                cut_mark=a.main.mark,
                section=a.main.section,
                cut_length_in=float(a.main.cut_length.inches),
                purlin_stations_in=purlin_stations,
                purlin_stations_left_in=sorted(purlin_left),
                purlin_stations_right_in=sorted(purlin_right),
            )
        )
        return a

    if folded or mono:
        for ordinal in range(1, p.frames + 1):
            make_rafter(ordinal)
    else:
        for ordinal in range(1, p.frames + 1):
            make_rafter(ordinal, 'left')
            make_rafter(ordinal, 'right')

    schedule = []
    for col in physical_columns:
        raf = next(
            (
                x
                for x in physical_rafters
                if x['frame_ordinal'] == col['frame_ordinal'] and (x['side'] == 'both' or x['side'] == col['side'])
            ),
            None,
        )
        schedule.append(
            {
                **col,
                'rafter_mark': raf['mark'] if raf else '',
                'rafter_cut_length_in': raf['cut_length_in'] if raf else None,
                'rafter_purlin_stations_in': (
                    list(
                        raf.get('purlin_stations_left_in' if col['side'] == 'left' else 'purlin_stations_right_in')
                        or []
                    )
                    if raf and folded
                    else list(raf.get('purlin_stations_in') or [])
                    if raf
                    else []
                ),
            }
        )
    layout['physical_connection_schedule'] = schedule
    layout['physical_rafters'] = physical_rafters
    layout['connection_override_default'] = p.welded_knee
    layout['connection_overrides_applied'] = True
    return made
