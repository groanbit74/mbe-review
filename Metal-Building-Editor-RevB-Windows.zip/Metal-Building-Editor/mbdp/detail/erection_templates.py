"""1277345 erection details as scoped templates, never silently rescaled shop parts."""

import copy
import math

from .cladding import fmt, inch
from .secondary_catalog import get

SOURCE = '1277345 / Erection Dwgs.pdf / rev C 2023-08-17 / REVIEW watermark'
OPENING = '1277345-SD85C-SD95'
TRANSITIONS = {
    '1277345-D9-T1': dict(page=29, position='lower left', angles=['SA1', 'SA-2'], penetration=False),
    '1277345-D10-T2': dict(page=30, position='upper left', angles=['SA1'], penetration=True),
    '1277345-D10-T3': dict(page=30, position='upper middle', angles=['SA1'], penetration=True),
    '1277345-D10-T4-BOLTED': dict(page=30, position='lower left', angles=['SA3'], penetration=True),
    '1277345-D10-T4-EAVE': dict(page=30, position='upper right', angles=[], penetration=False),
}


def validate(p):
    for rec in p.additions.get('opening_members', {}).values():
        if rec.get('connection_template', '') not in ('', OPENING):
            raise ValueError('Unknown opening connection template')
        v = rec.get('girt_end_clearance')
        if v not in ('', None) and not 0 <= inch(v) <= 6:
            raise ValueError('Girt end clearance must be0–6in; SD87 says Varies, do not infer it')
    for r in p.additions.get('lean_tos', []):
        if r.get('transition_template', '') not in ('', *TRANSITIONS):
            raise ValueError('Unknown transition detail; distinguish BOTH source T4 details')
        if r.get('transition_template') == '1277345-D10-T4-EAVE':
            raise ValueError('D10 upper-right T4 is a FREE HIGH EAVE, not a main-wall transition; choose wall detail')


def default_detail(p, o):
    """Project default opening framing when no source kit is selected.

    Jambs run from the base to the top of the header; the header (and sill)
    fit between the jambs less the entered girt end clearance (general 1/8 in)
    at each end; intercepted girts are cut at the jamb faces with the same
    clearance.  Welded frames weld the girt ends to the jamb; bolted frames use
    one shop-standard girt clip per cut end.
    """
    cfg = p.additions['opening_members'].get(o['id'], {})
    gap = 0.125 if cfg.get('girt_end_clearance') in ('', None) else inch(cfg['girt_end_clearance'])
    welded = p.connection_style == 'fully_welded'
    o['termination'] = dict(
        rule='PROJECT DEFAULT',
        girt_end_clearance_in=gap,
        clearance_basis='GENERAL 1/8 in' if cfg.get('girt_end_clearance') in ('', None) else 'ENTERED',
        girt_end='welded to jamb' if welded else 'shop-standard clip at each cut end',
        applicable=not o.get('bearing_jambs'),
        issues=[],
        components=[],
        girt_segments=[],
    )
    if o.get('bearing_jambs'):
        return
    for m in o['members']:
        if m['role'] in ('JL', 'JR'):
            L = m['y1_in'] - m['y0_in']
            basis = (
                'base to header girt @ ' + fmt(o['header_girt_in']) + '; square ends'
                if o.get('header_girt_in') is not None and o.get('jamb_top_in') == o.get('header_girt_in')
                else 'base to '
                + ('end rafter' if o['face'] in ('front', 'rear') else 'eave strut')
                + ' underside; square ends'
                if o.get('jamb_top_in') is not None
                else 'base to header top; square ends'
            )
        else:
            m['x0_in'] += gap
            m['x1_in'] -= gap
            L = m['x1_in'] - m['x0_in']
            basis = 'clear between jambs less ' + fmt(gap) + ' each end'
        if L <= 0:
            raise ValueError(o['id'] + ': member deductions consume the ' + m['role'] + ' length')
        m.update(
            cut_length_in=L,
            reference_length_in=L,
            cut_length=fmt(L),
            end_cuts='SQUARE / SQUARE',
            status='CUT: ' + basis,
        )


def termination(p, o):
    """Girt termination rule at an opening (source kit when selected, else project default)."""
    d = o.get('connection_detail')
    if d:
        return d if d['applicable'] else None
    t = o.get('termination')
    return t if t and t['applicable'] else None


def opening_template(p, o):
    cfg = p.additions['opening_members'].get(o['id'], {})
    o['connection_detail'] = None
    if cfg.get('connection_template') != OPENING:
        default_detail(p, o)
        return
    errors = [s for s in o['issues'] if not s.startswith('GIRT at ')]
    from .framing_additions import profile

    members = {m['role']: m for m in o['members']}
    if not all(k in members for k in ('JL', 'JR', 'HD')):
        errors.append('Template requires both jambs and header')
    for k, m in members.items():
        pr = profile(m['profile'])
        if pr.get('open_face') or pr['family'] != 'C' or pr['depth'] != 8:
            errors.append(k + ': SD85C/SD95 scoped to8in cold-formed Cee; no W/HSS conversion')
    if o['sill_face']:
        errors.append('Window sill support is not established by this door-header template')
    detail = dict(
        template=OPENING,
        source=SOURCE,
        pages=[23, 24],
        base_detail='D3/SD85C',
        header_detail='D4/SD95',
        girt_detail='D3/SD87',
        base_gap_in=0.25,
        header_end_gap_in=0.25,
        anchor_diameter_in=0.625,
        anchor_spacing_in=3,
        anchor_edge_reference_in=1.75,
        jamb8_offset_in=2.5,
        bolt_note='SD95/87: A3071/2x1-1/4 machine bolts U.N.; labeled fin-necks1/2x1. SD85C BASE fin-necks1/2x1-1/4. Different types/lengths retained.',
        girt_end_clearance_in=0.125 if cfg.get('girt_end_clearance') in ('', None) else inch(cfg['girt_end_clearance']),
        clearance_basis='USER GENERAL1/8in'
        if cfg.get('girt_end_clearance') in ('', None)
        else 'EXPLICIT MANUFACTURER / USER OVERRIDE',
        applicable=not errors,
        issues=errors,
        components=[],
        girt_segments=[],
    )
    o['connection_detail'] = detail
    if errors:
        return
    # SD85C: jamb bottom1/4 above floor. SD95: header end1/4 clear at each jamb.
    for m in o['members']:
        if m['role'] in ('JL', 'JR'):
            m['y0_in'] = 0.25
            L = m['y1_in'] - 0.25
        else:
            m['x0_in'] += 0.25
            m['x1_in'] -= 0.25
            L = m['x1_in'] - m['x0_in']
        if L <= 0:
            raise ValueError('Opening template deductions consume member')
        m.update(
            cut_length_in=L,
            reference_length_in=L,
            cut_length=fmt(L),
            end_cuts='SQUARE / SQUARE',
            status='SOURCE-TEMPLATE CUT; holes/clip fit, jamb top restraint and capacity review remain',
        )
    detail['components'] = [
        dict(part='SD85C base clip', quantity=2, basis='one per jamb; supplier clip identity/size required'),
        dict(
            part='5/8in anchor rod',
            quantity=4,
            basis='two per jamb shown in SD85C; embedment, length, grade and foundation NOT inferred',
        ),
        dict(part='JH-8', quantity=2, basis='one per header end, SD95; vendor part dimensions/punching must match'),
    ]
    detail['components'] += [
        dict(part='Fin-neck bolt1/2x1-1/4 / SD85C base', quantity=4, basis='two per jamb base'),
        dict(part='Fin-neck bolt1/2x1 / SD95 header', quantity=4, basis='two per header end'),
        dict(
            part='A307 machine bolt1/2x1-1/4 / SD95 header',
            quantity=4,
            basis='two per header end; nut/washer specification separate',
        ),
    ]
    detail['issues'] += [
        'Jamb top restraint, vendor clip geometry/punching and foundation anchor specification must match actual job.'
    ]
    o['issues'] = [s for s in o['issues'] if not s.startswith('GIRT at ')]
    o['status'] = 'SOURCE TEMPLATE / CONNECTION REVIEW'


def trim_detail(z):
    key = z.get('transition_template', '')
    z['transition_detail'] = None
    if not key:
        return
    source = TRANSITIONS[key]
    n = len(z['stations'])
    L = z['length_in']
    penetration = source['penetration']
    out = dict(
        template=key,
        source=SOURCE,
        page=source['page'],
        position=source['position'],
        components=[],
        closure_envelopes=[],
        issues=[],
    )
    out.update(
        material_gauge=26,
        fabrication='FIELD FABRICATED',
        developed_blank_status='FIELD FIT; bend allowance not inferred',
    )
    z['transition_detail'] = out

    def run(part, multiple=1):
        out['components'].append(
            dict(
                part=part,
                quantity=L / 12 * multiple,
                unit='ft net',
                basis='Net run only; joints, corner returns, cuts and waste additional',
            )
        )

    run('Parapet high-eave flashing')
    run('Inside closure')
    run('Outside closure')
    run('Tape sealant', 2)
    out['components'].append(
        dict(
            part='Stitch screw line',
            quantity=math.ceil(L / 12) + 1,
            unit='ea layout',
            basis='12in maximum centers, both run ends included; screw specification/edge offsets and lap extras pending',
        )
    )
    out['support_angle_marks'] = source['angles']
    out['issues'].append(
        'SA marks are source accessories, not substituted sections. Flashing formed profile, gauge/finish, member screw lines and lap extras require confirmation.'
    )
    if penetration:
        from .framing_additions import profile

        rf = profile(z['rafter'])
        out['components'] += [
            dict(part='TD250 left-hand closure', quantity=n, unit='ea', basis='one per physical penetration'),
            dict(part='TD250 right-hand closure', quantity=n, unit='ea', basis='one per physical penetration'),
            dict(
                part='TD250 lap rivet',
                quantity=2 * n,
                unit='ea',
                basis='2 per trim lap per detail; rivet specification pending',
            ),
        ]
        for st in z['stations']:
            out['closure_envelopes'].append(
                dict(
                    main_mark=st['main_mark'],
                    station_in=st['x_in'],
                    rafter_profile=z['rafter'],
                    rafter_depth_plus_half_in=rf['depth'] + 0.5 if rf else None,
                    half_flange_plus_quarter_in=rf['width'] / 2 + 0.25 if rf and rf['family'] == 'W' else None,
                    lap_in=3,
                    minimum_tab_in=3,
                    return_in=1,
                    other_leg_in=1.5,
                    status='TD250 dimensional references, NOT developed flat pattern;12in MAX callout/field removal must be checked on source detail',
                )
            )
        out['issues'].append(
            'TD250 field removal,12in MAX callout, bend radii/allowance and developed blank are not resolved by a schematic. Cee flange halves are NOT treated as symmetric W flanges.'
        )
    z['transition_trim']['profile'] = 'PARAPET HIGH-EAVE FLASHING / ' + key
    z['transition_trim']['status'] = (
        'Source assembly selected; net closure/sealant/fastener schedule attached; formed flashing profile and bends pending'
    )


def finish(job, p, model):
    for o in model['openings']:
        opening_template(p, o)
    for z in model['lean_tos']:
        trim_detail(z)
    interrupt_girts(job, p, model)
    interrupt_endwall_girts(job, p, model)


def interrupt_girts(job, p, model):
    """Coordinate proposed girt terminations, including direction reversal on BACK.
    Actual cuts only when SD87's variable gap is explicitly entered. No upright edit.
    """
    model['girt_interruptions'] = []
    runs = job.assemblies[p.column_mark].derivation.get('secondary_runs', {})
    if not runs:
        return
    L = runs['support_length_in']
    old = copy.deepcopy(runs['pieces'])
    new = []
    changed = False
    for r in old:
        if r['role'] != 'girt' or r.get('start_in') is None:
            new.append(r)
            continue
        face = r['side']
        reverse = face == 'left'
        start, end = (L - r['end_in'], L - r['start_in']) if reverse else (r['start_in'], r['end_in'])
        spans = [(start, end, False, False)]
        affected = []
        for o in model['openings']:
            d = termination(p, o)
            if not d or o['face'] != face or not o['y_in'] < r['floor_y_in'] < o['y_in'] + o['height_in']:
                continue
            pr = get(r['profile_id'])
            kit = d.get('template') is not None
            if kit and (p.girt_mode != 'bypass' or pr['nominal_depth_in'] != 8):
                d['issues'].append(
                    'SD87 girt interruption requires8in BYPASS girt; no flush/W/HSS connection substitution'
                )
                continue
            gap = d['girt_end_clearance_in']
            left = o['x_in'] - o['jamb_face'] - (gap or 0)
            right = o['x_in'] + o['width_in'] + o['jamb_face'] + (gap or 0)
            updated = []
            hits = 0
            for a, b, lc, rc in spans:
                if b <= left or a >= right:
                    updated.append((a, b, lc, rc))
                    continue
                if a < left:
                    updated.append((a, left, lc, True))
                    hits += 1
                if b > right:
                    updated.append((right, b, True, rc))
                    hits += 1
            if updated != spans:
                affected.append(o)
                if kit:
                    d['components'].append(
                        dict(part='GC-8', quantity=hits, basis=r['piece_id'] + ' / SD87 / one at each terminated end')
                    )
                    d['components'] += [
                        dict(
                            part='Fin-neck bolt1/2x1 / SD87 girt',
                            quantity=2 * hits,
                            basis='two per terminated girt end',
                        ),
                        dict(
                            part='A307 machine bolt1/2x1-1/4 / SD87 girt',
                            quantity=2 * hits,
                            basis='two per terminated girt end; nuts/washers separate',
                        ),
                    ]
                elif p.connection_style != 'fully_welded':
                    d['components'].append(
                        dict(
                            part='Girt-to-jamb clip (shop standard)',
                            quantity=hits,
                            basis=r['piece_id'] + ' / one at each terminated girt end',
                        )
                    )
                if gap is None:
                    d['issues'].append(
                        'SD87 girt end distance says VARIES; enter actual gap before girt cut lengths can be issued'
                    )
            spans = updated
        if not affected:
            new.append(r)
            continue
        changed = True
        resolved = all(termination(p, o)['girt_end_clearance_in'] is not None for o in affected)
        kit = any(termination(p, o).get('template') for o in affected)
        for i, (a, b, lc, rc) in enumerate(spans, 1):
            if b - a <= 1e-8:
                continue
            item = copy.deepcopy(r)
            length = b - a
            mark = r['piece_id'] + '-OP' + str(i)
            item.update(
                piece_id=mark,
                start_in=L - b if reverse else a,
                end_in=L - a if reverse else b,
                cut_length_in=length if resolved else None,
                cut_length=fmt(length) if resolved else '',
                reference_length_in=length,
                pattern='SD87 OPENING TERMINATION' if kit else 'OPENING TERMINATION / ' + fmt(gap) + ' CLEAR OF JAMB',
                status=(
                    ('OPENING CUT / SD87 gap ' if kit else 'OPENING CUT / ' + fmt(gap) + ' clear of jamb face; ')
                    + ', '.join(o['id'] for o in affected)
                    if resolved
                    else 'GIRT CUT HOLD: SD87 variable end gap not entered'
                ),
                parent_piece=r['piece_id'],
                opening_ids=[o['id'] for o in affected],
            )
            new.append(item)
            rec = dict(
                mark=mark,
                parent_piece=r['piece_id'],
                face=face,
                y_in=r['floor_y_in'],
                x0_in=a,
                x1_in=b,
                cut_length_in=item['cut_length_in'],
                reference_length_in=length,
                opening_ids=[o['id'] for o in affected],
                left_jamb_end=lc,
                right_jamb_end=rc,
                status=item['status'],
            )
            model['girt_interruptions'].append(rec)
            for o in affected:
                termination(p, o)['girt_segments'].append(rec)
    if changed:
        runs['uninterrupted_pieces'] = old
        runs['pieces'] = new
        regroup(job, p, runs)


def regroup(job, p, runs):
    """Replace ALL cut summaries consistently; no old full-length duplicate order."""

    groups = {}
    old = {r['cut_mark']: r for r in runs['cuts']}
    for r in runs['pieces']:
        key = (r['role'], r['profile_id'], r['finish'], r['cut_length'], r['status'])
        if key not in groups:
            c = copy.deepcopy(old[r['cut_mark']])
            c.update(
                cut_mark=p.column_mark + '-ORUN-' + str(len(groups) + 1),
                quantity=0,
                cut_length=r['cut_length'],
                cut_length_in=r['cut_length_in'],
                status=r['status'],
                pattern=r['pattern'],
            )
            if r.get('parent_piece'):
                c.update(
                    source_page='D3/SD87' if 'SD87' in r['pattern'] else '',
                    source_revision='C 8/17/23' if 'SD87' in r['pattern'] else '',
                    source_url='',
                    length_basis='SOURCE SD87 + EXPLICIT VARIABLE END GAP; outside-view clipping'
                    if 'SD87' in r['pattern']
                    else 'RUN PIECE CUT AT OPENING JAMB FACES LESS END CLEARANCE',
                )
            groups[key] = c
        c = groups[key]
        c['quantity'] += 1
        r['cut_mark'] = c['cut_mark']
    for c in groups.values():
        wt = (
            None
            if c['cut_length_in'] is None or c.get('weight_lb_ft') is None
            else c['cut_length_in'] / 12 * c['weight_lb_ft']
        )
        c['estimated_weight_each_lb'] = '' if wt is None else str(round(wt, 2))
        c['estimated_lot_weight_lb'] = '' if wt is None else str(round(wt * c['quantity'], 2))
    runs['cuts'] = list(groups.values())
    owner = job.assemblies[p.column_mark]
    rows = [r for r in owner.derivation['secondary_material_rows'] if r['role'] == 'accessory']
    for c in runs['cuts']:
        rows.append(
            dict(
                frame_id=p.column_mark,
                role=c['role'],
                profile_id=c['profile_id'],
                designation=c['designation'],
                finish=c['finish'],
                gauge=c['gauge'],
                ordered_piece_length=c['cut_length'],
                total_lot_pieces=c['quantity'],
                weight_lb_ft=c['weight_lb_ft'],
                estimated_weight_each_lb=c['estimated_weight_each_lb'],
                estimated_lot_weight_lb=c['estimated_lot_weight_lb'],
                status=c['status'] + '; ' + c['cut_mark'],
                source_revision=c['source_revision'],
                source_page=c['source_page'],
                source_url=c['source_url'],
            )
        )
    owner.derivation['secondary_material_rows'] = rows
    job.settings['frame_layouts'][p.column_mark]['secondary_material_rows'] = rows


def interrupt_endwall_girts(job, p, model):
    for end, wall in job.assemblies[p.column_mark].derivation.get('endwalls', {}).items():
        face = 'front' if end == 'front_end' else 'rear'
        reverse = face == 'rear'
        W = wall['width_in']
        new = []
        changed = False
        for r in wall['members']:
            if r['role'] != 'endwall girt' or r['reference_cut_in'] is None:
                new.append(r)
                continue
            # Existing BYPASS endwall rule is B-.5: explicit1/4 at each support CL.
            a, b = r['x0_in'] + 0.25, r['x1_in'] - 0.25
            start, endx = (W - b, W - a) if reverse else (a, b)
            spans = [(start, endx, False, False)]
            affected = []
            for o in model['openings']:
                d = termination(p, o)
                if not d or o['face'] != face or not o['y_in'] < r['y0_in'] < o['y_in'] + o['height_in']:
                    continue
                kit = d.get('template') is not None
                if kit and (p.girt_mode != 'bypass' or get(r['profile_id'])['nominal_depth_in'] != 8):
                    d['issues'].append(
                        'Endwall SD87 interruption requires8in bypass girts; flush connection is not substituted'
                    )
                    continue
                gap = d['girt_end_clearance_in']
                left = o['x_in'] - o['jamb_face'] - (gap or 0)
                right = o['x_in'] + o['width_in'] + o['jamb_face'] + (gap or 0)
                updated = []
                hits = 0
                for a, b, lc, rc in spans:
                    if b <= left or a >= right:
                        updated.append((a, b, lc, rc))
                        continue
                    if a < left:
                        updated.append((a, left, lc, True))
                        hits += 1
                    if b > right:
                        updated.append((right, b, True, rc))
                        hits += 1
                if updated != spans:
                    affected.append(o)
                    if kit:
                        d['components'] += [
                            dict(part='GC-8', quantity=hits, basis=r['mark'] + ' / SD87'),
                            dict(part='Fin-neck bolt1/2x1 / SD87 girt', quantity=2 * hits, basis='two per girt end'),
                            dict(
                                part='A307 machine bolt1/2x1-1/4 / SD87 girt',
                                quantity=2 * hits,
                                basis='two per girt end',
                            ),
                        ]
                    elif p.connection_style != 'fully_welded':
                        d['components'].append(
                            dict(
                                part='Girt-to-jamb clip (shop standard)',
                                quantity=hits,
                                basis=r['mark'] + ' / one at each terminated girt end',
                            )
                        )
                    if gap is None:
                        d['issues'].append('SD87 endwall variable end gap is missing; interrupted girt cuts held')
                spans = updated
            if not affected:
                new.append(r)
                continue
            changed = True
            resolved = all(termination(p, o)['girt_end_clearance_in'] is not None for o in affected)
            kit = any(termination(p, o).get('template') for o in affected)
            for i, (a, b, lc, rc) in enumerate(spans, 1):
                rr = copy.deepcopy(r)
                length = b - a
                cut = length if resolved else None
                mark = r['mark'] + '-OP' + str(i)
                rr.update(
                    mark=mark,
                    x0_in=W - b if reverse else a,
                    x1_in=W - a if reverse else b,
                    reference_cut_in=cut,
                    blank_length_in=cut,
                    reference_cut=fmt(cut) if cut is not None else '',
                    blank_length=fmt(cut) if cut is not None else '',
                    estimated_weight_lb=round(cut / 12 * rr['weight_lb_ft'], 2)
                    if cut is not None and rr.get('weight_lb_ft') is not None
                    else None,
                    status=(
                        ('SD87 OPENING CUT / ' if kit else 'OPENING CUT / ' + fmt(gap) + ' clear of jamb face; ')
                        + ', '.join(o['id'] for o in affected)
                        if resolved
                        else 'SD87 VARIABLE END GAP HOLD'
                    ),
                    parent_piece=r['mark'],
                    opening_ids=[o['id'] for o in affected],
                )
                new.append(rr)
                rec = dict(
                    mark=mark,
                    parent_piece=r['mark'],
                    face=face,
                    y_in=r['y0_in'],
                    x0_in=a,
                    x1_in=b,
                    cut_length_in=cut,
                    reference_length_in=length,
                    opening_ids=[o['id'] for o in affected],
                    left_jamb_end=lc,
                    right_jamb_end=rc,
                    status=rr['status'],
                )
                model['girt_interruptions'].append(rec)
                for o in affected:
                    termination(p, o)['girt_segments'].append(rec)
        if changed:
            wall['uninterrupted_members'] = copy.deepcopy(wall['members'])
            wall['members'] = new
            tag = wall['cuts'][0]['cut_group'].rsplit('-C', 1)[0] if wall.get('cuts') else 'EW-OP-' + end
            groups = {}
            for r in new:
                key = (
                    r['role'],
                    r['profile_id'],
                    r['finish'],
                    r['reference_cut_in'],
                    r['blank_length_in'],
                    r['status'],
                )
                if key not in groups:
                    groups[key] = {
                        k: r[k]
                        for k in (
                            'role',
                            'profile_id',
                            'finish',
                            'reference_cut',
                            'reference_cut_in',
                            'blank_length',
                            'blank_length_in',
                            'status',
                        )
                    }
                    groups[key].update(cut_group=tag + '-C' + str(len(groups)).zfill(2), quantity=0)
                groups[key]['quantity'] += 1
                r['cut_group'] = groups[key]['cut_group']
            wall['cuts'] = list(groups.values())
