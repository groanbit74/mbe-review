"""Read-only issue locations, evidence and suggested actions. Never auto-correct geometry.
Adapters add context to legacy messages; unmatched messages retain explicit unmapped status.
"""

import hashlib
import re

from . import model as M


def field(attr, value):
    return dict(attribute=attr, value=value)


def target(editor, owner, fields=()):
    return dict(editor=editor, owner=owner, fields=list(fields))


def enrich(job, issues=None):
    out = []
    frames = job.settings.get('frames', {})
    for issue in issues if issues is not None else M.validate(job):
        r = issue.to_json() if hasattr(issue, 'to_json') else dict(issue)
        text = r['text']
        scope = r['assembly']
        low = text.lower()
        owner = scope.split(' ')[0]
        asm = job.assemblies.get(owner)
        fid = (asm.derivation.get('frame_id') if asm else None) or (owner if owner in frames else None)
        if owner in job.parts:
            fid = job.parts[owner].symbol.get('frame_id') or job.settings.get('connections', {}).get(owner, {}).get(
                'frame_id'
            )
        r.update(
            category='unmapped',
            suggestion='Review the original message and related source model. An exact editable field has not been identified; no automatic correction is proposed.',
            impact='Saved model check; existing release rules remain in force.',
            frame_id=fid,
            edit=None,
            drawing=None,
            marks=[owner],
            evidence=[],
            mapping='Related scope only; exact input/geometry location unavailable.',
        )
        if asm:
            r['drawing'] = dict(kind='assembly', name=owner)
        if fid:
            r['edit'] = target('wizard', fid)
            r['drawing'] = dict(kind='frame', name=fid)
        if owner in job.parts:
            r['edit'] = target('part', owner)
            r['drawing'] = dict(kind='connection' if job.parts[owner].symbol.get('connection') else 'plate', name=owner)
        if any(
            v in low
            for v in ('review:', 'draft', 'review hold', 'not released', 'unverified', 'verify', 'pending', 'held')
        ):
            r.update(
                category='review',
                suggestion='Review the specified fit, material or connection evidence. This is not necessarily an input mistake. Obtain the required shop/supplier/engineering confirmation; do not change geometry merely to remove the warning.',
                impact='Review/fabrication restriction. Editing and design review may continue; no approval is inferred.',
            )
        additions = job.assemblies[fid].derivation.get('framing_additions', {}) if fid in job.assemblies else {}
        for i, z in enumerate(additions.get('lean_tos', [])):
            if scope != fid + ' ' + z['id']:
                continue
            r['edit'] = target('additions', fid, [field('data-addition-field', f'lean_{i}_high_connection')])
            r['drawing'] = dict(kind='additions', name=f'{fid}~lean~{i}~1')
            r['marks'] = [z['id']] + [m['mark'] for m in z['members']]
            r['mapping'] = 'Related lean connection controls; changes require coordinated review.'
            if 'low-eave' in low:
                r['edit']['fields'] = [field('data-addition-field', f'lean_{i}_low_connection')]
                r['drawing']['name'] = f'{fid}~low_detail~{i}~1'
            if 'high attachment center outside' in low:
                match = re.search(re.escape(fid + '-' + z['id']) + r'-(\d+):', text)
                idx = int(match.group(1)) - 1 if match else -1
                clips = z.get('flush_clips', [])
                if 0 <= idx < len(clips):
                    clip = clips[idx]
                    main = next(
                        (
                            m
                            for w in job.assemblies[fid].derivation.get('endwalls', {}).values()
                            for m in w['members']
                            if m['mark'] == clip['main_mark']
                        ),
                        None,
                    )
                    r.update(
                        category='conflict',
                        suggestion='The modeled high clip does not fit the existing upright height. Compare its weld-edge elevations with the end-column head. Confirm the intended attachment/load path with the connection designer (column versus rafter/approved adapter). Do NOT lower the clip or lengthen the column automatically: roof and lean rafter geometry must remain coordinated.',
                        impact='Actual modeled fit conflict; connection fabrication remains held. Design edits may continue.',
                        marks=[clip['mark'], clip['main_mark']],
                        drawing=dict(kind='additions', name=f'{fid}~flush_clip~{i}~1'),
                    )
                    if main:
                        heads = [pt[1] for pt in main.get('top_cut_points', [])] or [main['y1_in']]
                        top = max(heads)
                        bottom = main['y0_in']
                        r['evidence'] = [
                            dict(label='Existing upright bottom', value_in=bottom, mark=main['mark']),
                            dict(label='Upright head LOW', value_in=min(heads), mark=main['mark']),
                            dict(label='Upright head HIGH (conservative envelope)', value_in=top, mark=main['mark']),
                            dict(label='Clip column-edge bottom', value_in=clip['root_bottom_in'], mark=clip['mark']),
                            dict(label='Clip column-edge top', value_in=clip['root_top_in'], mark=clip['mark']),
                            dict(
                                label='Gap above even the highest column point',
                                value_in=max(0, clip['root_bottom_in'] - top),
                                mark=clip['mark'],
                            ),
                        ]
                        r['comparison'] = dict(
                            column_mark=main['mark'],
                            column_bottom=bottom,
                            column_top=top,
                            column_low_top=min(heads),
                            clip_mark=clip['mark'],
                            clip_bottom=clip['root_bottom_in'],
                            clip_top=clip['root_top_in'],
                        )
        for i, o in enumerate(additions.get('openings', [])):
            if scope != fid + ' ' + o['id']:
                continue
            oid = o['id']
            walk = o.get('walk_slip_fit')
            r['edit'] = target(
                'wizard',
                fid,
                [
                    field('data-addition-field', oid + '_walk_head_face')
                    if walk
                    else field('data-cladding-field', f'opening_{i}_x')
                ],
            )
            r['drawing'] = dict(kind='additions', name=f'{fid}~' + ('walk_fit' if walk else 'opening') + f'~{i}~1')
            r['marks'] = [oid]
            r['mapping'] = (
                'Opening-specific controls and drawing; highlight is a field/label locator, not an automatically located collision.'
            )
            if any(x in text for x in ('CLASH', 'NO VALID', 'UPRIGHT')):
                r.update(
                    category='conflict',
                    suggestion='Compare the clear opening and jamb envelope with existing upright positions. Revise the explicitly entered opening location/size or the reviewed post layout. Do not silently move or remove supporting posts.',
                )
            if walk:
                r['evidence'] = [
                    dict(label=k.replace('_', ' '), value_in=walk[k], mark=walk.get('girt_member_ref', oid))
                    for k in ('girt_web_underside_in', 'door_frame_outside_top_in', 'inside_gap_in')
                ]
                r['marks'].append(walk['girt_member_ref'])
        if fid and scope in (fid + ' front_end', fid + ' rear_end'):
            end = scope.split(' ')[-1]
            r.update(
                category='conflict',
                edit=target(
                    'wizard',
                    fid,
                    [
                        field('data-end-field', end + '_roof_depth_clearance'),
                        field('data-end-field', end + '_rafter'),
                        field('data-end-field', end + '_roof_mode'),
                    ],
                ),
                drawing=dict(kind='endwall', name=fid + '~' + end),
                suggestion='Compare actual secondary depth plus the entered total clearance with available end-rafter depth. Correct an erroneous selection/clearance or review a different connection arrangement; do not force a fit by shortening unrelated members.',
            )
        if fid:
            for role in ('purlin', 'girt', 'eave'):
                if text.startswith(role.upper() + ':'):
                    r['edit'] = target('wizard', fid, [field('data-secondary-role', role)])
                    r['drawing'] = dict(kind='secondaries', name=fid)
                    r['mapping'] = 'Selected source profile; unknown thickness/fit is not a numeric input error.'
        if asm:
            paths = []
            suggest = None
            for trigger, key, hint in [
                (
                    'cut length must be positive',
                    'cut_length',
                    'Enter a positive member length. Managed frame cuts must be corrected through their generating frame parameters.',
                ),
                (
                    'not on the 1/16',
                    'cut_length',
                    'Check the required cut precision; do not round or shorten automatically.',
                ),
                (
                    'cut mark ',
                    'mark',
                    'Use a distinct cut mark for unequal section/length requirements; preserve marks that still describe identical cuts.',
                ),
                (
                    'main member section',
                    'section',
                    'Choose the actual required supported section; do not substitute merely to remove an error.',
                ),
            ]:
                if (
                    trigger in text
                    and not text.startswith(('web holes',))
                    and (trigger != 'not on the 1/16' or text.startswith('cut length'))
                ):
                    paths = [field('data-issue-path', f'/assemblies/{owner}/main/{key}')]
                    suggest = hint
                    break
            if text == 'quantity must be >= 1':
                paths = [field('data-issue-path', f'/assemblies/{owner}/qty')]
                suggest = 'Enter the actual positive integer lot quantity, not zero or a negative value.'
            for k, att in enumerate(asm.attachments):
                if not text.startswith(att.part + ':') and not text.startswith(att.part + ' on '):
                    continue
                key = (
                    'station'
                    if 'station' in low
                    else 'y_from_top'
                    if 'y_from_top' in low
                    else 'part'
                    if 'undefined part' in low
                    else None
                )
                if key:
                    paths.append(field('data-issue-path', f'/assemblies/{owner}/attachments/{k}/{key}'))
                    suggest = 'Check this attachment against the member length and drawing datum. Correct its position only after verifying the intended connection. Repeated marks may identify multiple candidate attachment rows.'
            if paths:
                r.update(
                    category='input',
                    edit=target('assembly', owner, paths),
                    drawing=dict(kind='assembly', name=owner),
                    suggestion=suggest,
                    mapping='Specific property control(s); generated/read-only values may require upstream frame settings.',
                )
        r['id'] = 'ISS-' + hashlib.sha256((scope + '|' + text).encode()).hexdigest()[:10]
        out.append(r)
    return out


def rejected(message, route, body=None):
    """Known error-field vocabulary only; no arbitrary fuzzy match pretending certainty."""
    body = body if isinstance(body, dict) else {}
    low = str(message).lower()
    fields = []
    attr = 'data-geometry-field' if route == '/api/building-geometry' else 'data-frame-field'
    vocab = {
        'width': ['width'],
        'length': ['length'],
        'eave_height': ['eave height'],
        'slope_rise': ['pitch', 'slope_rise'],
        'apex_bottom_half': ['apex bottom half', 'half-length'],
        'peak_clip_edge': ['peak clip edge'],
        'weld_size': ['weld size'],
        'purlin_spacing': ['purlin spacing'],
    }
    if route in ('/api/building-geometry', '/api/frame'):
        payload = body.get('geometry', body)
        # Identify invalid entered dimensions individually, not whichever generic conversion failed first.
        for key in ('width', 'length', 'eave_height', 'slope_rise'):
            if key not in payload:
                continue
            try:
                n = float(M.D(payload[key]).inches)
                if n <= 0:
                    raise ValueError()
            except Exception:
                fields.append(field(attr, key))
        if not fields:
            for key, terms in vocab.items():
                if any(t in low for t in terms):
                    fields.append(field(attr, key))
    elif route in ('/api/order-options', '/api/order-preview'):
        for key in (
            'kerf_in',
            'end_allowance_in',
            'heavy_shear_loss_in',
            'thin_shear_loss_in',
            'beam_stock_ft',
            'purlin_stock_ft',
            'hss_stock_ft',
            'channel_stock_ft',
        ):
            if key in low:
                fields.append(field('data-order-field', key))
    # Zoned dimensions and opening records live in separate tabs now.
    specific = None
    if route == '/api/frame':
        zones = body.get('bay_zones', {})
        if zones.get('enabled') and any(
            t in low
            for t in (
                'bay length',
                'each bay',
                'bay enclosure',
                'left extension',
                'install-now',
                'junction',
                'outer end',
            )
        ):
            fields = []
            for i, b in enumerate(zones.get('bays', [])):
                bad = False
                try:
                    bad = float(M.D(b['length']).inches) <= 0 or float(M.D(b['length']).inches) > 1200
                except Exception:
                    bad = True
                if bad or 'bay lengths' in low:
                    fields.append(field('data-zone-field', f'bay_{i}_length'))
            if not fields:
                if 'gable' in low:
                    fields = [field('data-frame-field', 'frame_type'), field('data-zone-field', 'enabled')]
                elif 'endwall framing' in low:
                    fields = [field('data-end-field', 'enabled'), field('data-zone-field', 'enabled')]
                    specific = 'Bay enclosure needs separate endwall framing. The editor switches it on together with bay enclosure; if this job was sent another way, set endwalls.enabled=true (Building settings > step 3 - Endwalls & openings). No framing is generated until you save.'
                elif 'takeoff' in low or 'cladding' in low:
                    fields = [field('data-cladding-field', k) for k in ('enabled', 'walls', 'roof')] + [
                        field('data-zone-field', 'enabled')
                    ]
                    specific = 'Bay enclosure needs the roof and wall sheet takeoff switched on (Building settings > step 5 - Sheets & trim); which walls are actually sheeted is decided by the bay states, not by these boxes.'
                elif 'roof-only' in low:
                    line = int(zones.get('enclosed_start_line') or 0)
                    fields = [
                        field('data-zone-field', f'bay_{i}_{side}')
                        for i, b in enumerate(zones.get('bays', [])[:line])
                        for side in ('left', 'right')
                        if isinstance(b, dict) and b.get(side) == 'sheeted'
                    ] or [field('data-zone-field', 'enclosed_start_line')]
                    specific = f'Bays left of the junction wall (Frame line {line + 1}) are a roof-only extension in this version: set their sidewalls to Open or Future, or move the junction to Frame line 1 so every bay is inside the enclosure. A future bay at the RIGHT end is entered mirrored (future bay first).'
                elif 'outer' in low:
                    fields = [
                        field('data-zone-field', 'outer_front_state'),
                        field('data-zone-field', 'outer_girts_now'),
                    ]
                else:
                    fields = [field('data-zone-field', 'enclosed_start_line')]
            specific = (
                specific
                or 'Check the highlighted bay lengths and wall states. Each bay must be positive and at most100ft. The roof length is their sum; change the bay lengths, not a competing total. Future framing is allowed only on a future wall. No frame or opening will be moved automatically.'
            )
        if any(t in low for t in ('channel post', 'post family', 'post profile', 'family must match')):
            from .secondary_catalog import get

            candidates = []
            for end, e in body.get('endwalls', {}).items():
                if not isinstance(e, dict) or e.get('post_family') not in ('C', 'Channel'):
                    continue
                try:
                    valid = get(e.get('post_profile_id', ''))['family'] == e['post_family']
                except ValueError:
                    valid = False
                if not valid:
                    candidates.extend([field('data-end-field', end + '_family'), field('data-end-field', end + '_cee')])
            if candidates:
                fields = candidates
                specific = 'The selected intermediate-post product must match its family. Choose an actual unlipped channel for Channel, or a lipped Cee for C. Do not substitute a similar nominal depth without checking the actual supplier shape.'
        if ('sheet color' in low or 'mbci color' in low) and not fields:
            clad = body.get('cladding', {}) if isinstance(body.get('cladding'), dict) else {}
            fields = [
                field('data-cladding-field', role + '_color')
                for role in ('wall', 'roof', 'trim')
                if not (clad.get(role + '_finish') or {}).get('color')
            ]
            fields += [
                field('data-cladding-field', k + '_color')
                for k, v in (clad.get('surface_finishes') or {}).items()
                if isinstance(v, dict) and not v.get('color')
            ]
            if not fields:
                fields = [field('data-cladding-field', role + '_color') for role in ('wall', 'roof', 'trim')]
            specific = 'Pick the wall, roof and trim colors from the selected supplier (Building settings > step 5 - Sheets & trim). The takeoff cannot price or label sheets without the actual color; nothing is substituted.'
        if 'automatic bolted clips' in low and not fields:
            fields = [
                field('data-secondary-role', 'girt'),
                field('data-secondary-role', 'purlin'),
                field('data-frame-field', 'girt_depth'),
                field('data-frame-field', 'purlin_depth'),
            ]
            specific = 'Bolted girt/purlin clips are modelled for 6 in and 8 in members only. Pick a 6 in or 8 in girt and purlin product (Building settings > step 4 - Secondaries), or change the clip policy; the depth is never changed for you.'
        m = re.search(r'selected (?:MBCI|supplier) (\w+) profile', str(message))
        if m and not fields:
            role = m.group(1)
            fields = (
                [field('data-base-angle', 'profile_id')]
                if role == 'base_angle'
                else [field('data-secondary-role', 'eave' if role == 'high_eave' else role)]
            )
            specific = f'Choose the actual supplier {role.replace("_", " ")} product (Building settings > step 4 - Secondaries). Automatic run layout needs the real section for cut lengths and weights; no default product is substituted.'
        for i, o in enumerate(body.get('cladding', {}).get('openings', [])):
            if str(message).startswith(str(o.get('id')) + ':'):
                fields = [field('data-cladding-field', f'opening_{i}_{k}') for k in ('x', 'width', 'height')]
                specific = f"Opening {o.get('id')}: entered X={o.get('x')}, width={o.get('width')}, height={o.get('height')}. Compare its outside edges and selected jamb/header with the wall, roof and adjacent uprights. Reposition or resize only with owner approval; no automatic relocation is proposed."
    stale = 'changed' in low or 'stale' in low
    return dict(
        id='INPUT-REJECTED',
        severity='error',
        category='input',
        assembly='',
        text=str(message),
        fields=fields,
        mapping='Candidate input(s) identified from invalid values/known validator terminology.'
        if fields
        else 'Exact field not identified; the active form is highlighted instead.',
        suggestion=specific
        or (
            'Keep a copy of your unsaved entries. Reopen the current job/settings and reapply the intended changes; do not overwrite a newer revision.'
            if stale
            else 'Correct the highlighted value using the stated range/format. Dimensions accept inches, fractions, or feet/inches. For a conflict, compare both related settings before changing either.'
        ),
        impact='Request rejected; attempted edits were NOT saved. The drawing still represents the saved revision, not the rejected values.',
    )


def report_sheets(job):
    from .drawing.canvas import Canvas, Sheet, Style, View
    from .drawing.print_packets import tables

    rows = enrich(job)
    out = tables(
        job,
        'ISSUE NAVIGATOR - MODEL REVIEW',
        ['ID / SCOPE', 'TYPE', 'MESSAGE', 'SUGGESTED ACTION / EFFECT', 'RELATED DRAWING'],
        [160, 85, 285, 310, 160],
        [
            [
                r['id'] + ' / ' + r['assembly'],
                r['category'],
                r['text'],
                r['suggestion'] + ' ' + r['impact'],
                ((r['drawing']['kind'] + ' / ' + r['drawing']['name']) if r['drawing'] else 'No exact drawing mapped'),
            ]
            for r in rows
        ],
        [
            'Read-only comparison; no corrections, waivers or engineering approvals generated.',
            'Input mistakes, modeled fit conflicts and review holds are distinct. Unmapped findings are explicitly labeled.',
        ],
    )
    for r in rows:
        if 'comparison' not in r:
            continue
        b = r['comparison']
        sh = Sheet(r['id'], 'diagnostic')
        c = Canvas(sh)
        c.ptext(70, 58, 'MODELED HEIGHT CONFLICT / ' + r['assembly'], 19, bold=True)
        c.ptext(70, 87, r['id'] + ' / ' + job.revision(), 10)
        c.ptext(
            70, 114, 'Actual derived height intervals. Comparison diagram, NOT a replacement connection detail.', 10
        )
        lo = min(b['column_low_top'], b['clip_bottom']) - 3
        v = View(0, 470 + lo * 25, 1, 25)
        a = Canvas(sh, v)
        a.rect(180, lo, 350, b['column_top'], Style(fill=(0.7, 0.8, 0.9)))
        a.rect(520, b['clip_bottom'], 650, b['clip_top'], Style(fill=(1, 0.75, 0.7), color=(0.7, 0, 0)))
        a.line(160, b['column_top'], 680, b['column_top'], Style(color=(0.2, 0.3, 0.5), dash=(4, 3)))
        c.ptext(180, 515, 'Upright cropped near head; bottom is not zero.', 8)
        c.ptext(180, 497, b['column_mark'], 11, bold=True)
        c.ptext(520, 497, b['clip_mark'], 11, bold=True)
        for i, e in enumerate(r['evidence']):
            c.ptext(715, 183 + i * 37, e['label'], 9)
            c.ptext(
                715,
                197 + i * 37,
                f"{e['value_in']:.6f} in above floor"
                if 'Gap' not in e['label']
                else f"{e['value_in']:.6f} in clear separation",
                10,
                bold=True,
            )
        c.ptext(
            70,
            536,
            (
                'The entire clip edge is above the HIGH column-head envelope.'
                if b['clip_bottom'] > b['column_top']
                else 'Compare the clip edge interval with the upright height envelope; overlap alone is NOT weld approval.'
            ),
            11,
            bold=True,
        )
        for i, line in enumerate(
            [
                'Review attachment to the intended upright/rafter and the designed load path.',
                'Do not simply lower the clip: the lean rafter engagement must remain coordinated.',
                'An adapter or changed supporting member requires connection design; no automatic fix is safe.',
                'Source drawing: ' + r['drawing']['name'],
                'Editing/review can continue. Connection fabrication remains held.',
            ]
        ):
            c.ptext(70, 567 + i * 27, line, 11)
        c.ptext(
            70,
            750,
            'Vertical values from current model; compare exact sloping head/fillets and weld extent on the detailed drawings.',
            9,
        )
        out.append(sh)
    # Append the actual saved-model detail sheets, not an invented overlay.
    from .editor.server import sheet_for, sheet_list

    available = {(s['kind'], s['name']) for s in sheet_list(job)}
    seen = set()
    for r in rows:
        targets = []
        if 'comparison' in r:
            targets.append(r['drawing'])
            mark = r['comparison']['column_mark']
            end = 'front_end' if '-F-' in mark else 'rear_end' if '-R-' in mark else None
            if end:
                targets.append(dict(kind='endwall', name=r['frame_id'] + '~' + end))
        elif r['drawing'] and '~walk_fit~' in r['drawing']['name']:
            targets.append(r['drawing'])
        for t in targets:
            key = (t['kind'], t['name'])
            if key in available and key not in seen:
                out.append(sheet_for(job, key[0], key[1], M.validate(job)))
                seen.add(key)
    return out
