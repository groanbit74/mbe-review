"""Parametric single-web connections; derived proposals, never implicit design approval.

Source: Shop Dwgs Copy pp1-4. Low/high eave retain the single-web plate
arrangement. Apex mirrors the high-eave profile into ONE continuous web.
K-plate bottom seats on the TOP of the bottom plate; bracket/rafter tops align.
The existing centered plate-to-rafter placement remains a review assumption.
Body depth is normal to roof slope. Bottom length is a horizontal body datum;
end plates are outside that datum. Finished cut coordinates are derived at 0.000001 inch; stock blanks round UP to 1/16.
Standalone lots are separately quantified; frame-managed connections use frame quantities.
"""

from __future__ import annotations

import copy
import math
import re
from decimal import Decimal
from fractions import Fraction

from . import model as M
from . import sections

SOURCE = 'Shop Dwgs Copy pp1-4; resized geometry is derived'
DEFAULTS = dict(
    kind='low',
    column='COL-1',
    rafter='RF1-2',
    rise='1',
    bottom='10 1/2',
    bottom_mode='column_depth',
    top_extension='0',
    flange_thk='1/4',
    web_thk='3/16',
    end_plate='K-14',
    qty=1,
    weld_size='1/4"',
    plate_mode='library',
    pitch_source='manual',
    fit='tight',
    bevel='none',
)


def q(x):
    return M.D(Fraction(round(float(x) * 16), 16))


def f(v):
    return float(M.D(v).inches)


def precision(x):
    # Derived coordinates quantized to one millionth inch, serialized rationally.
    return M.D(Fraction(round(float(x) * 1000000), 1000000))


def contour(p):
    if p.symbol.get('cut_contour'):
        return [(f(x), f(y)) for x, y in p.symbol['cut_contour']]
    if p.symbol.get('contour'):
        return [(f(x), f(y)) for x, y in p.symbol['contour']]
    L, W = f(p.length), f(p.width)
    return [(0, 0), (L, 0), (L, W), (0, W)]


def connection_bom(job, mark):
    p = job.part(mark)
    counts = {}
    for a in p.attachments:
        counts[a.part] = counts.get(a.part, 0) + (2 if a.face == 'web' and a.side == 'both' else 1)
    return [
        M.BOMLine(k, n, job.part(k).bom_description(), job.part(k).weight(job.weights), job.part(k).kind)
        for k, n in counts.items()
    ]


def normalize_columns(job):
    """Explicit one-time migration; preserve source identity in derivation."""
    mapping = {}
    original_order = list(job.assemblies)
    for old, a in list(job.assemblies.items()):
        if a.kind != 'COLUMN' or re.fullmatch(r'COL-\d+', old):
            continue
        n = 1
        while f'COL-{n}' in job.assemblies:
            n += 1
        new = f'COL-{n}'
        mapping[old] = new
        a.derivation['previous_mark'] = old
        del job.assemblies[old]
        a.mark = new
        job.assemblies[new] = a
    job.assemblies = {mapping.get(k, k): job.assemblies[mapping.get(k, k)] for k in original_order}
    for cfg in job.settings.get('connections', {}).values():
        cfg['column'] = mapping.get(cfg.get('column'), cfg.get('column'))
    return mapping


def build(job, mark, supplied):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,22}', mark):
        raise ValueError('Connection mark: 1-23 letters, numbers, hyphens or underscores.')
    cfg = {**DEFAULTS, **supplied}
    from .plate_rules import connecting_holes, migrate_plate_defaults

    migrate_plate_defaults(job)
    if 'bottom_mode' not in supplied and 'bottom' in supplied and M.D(supplied['bottom']) != M.D('10 1/2'):
        cfg['bottom_mode'] = 'manual'
    kind = cfg['kind']
    if kind not in ('low', 'high', 'apex'):
        raise ValueError('Choose low, high or apex.')
    col = job.assemblies[cfg['column']]
    raf = job.assemblies[cfg['rafter']]
    if col.kind != 'COLUMN' or raf.kind != 'RAFTER':
        raise ValueError('Select a COLUMN and a RAFTER.')
    cs = sections.get_section(col.main.section)
    rs = sections.get_section(raf.main.section)
    B = f(cfg['bottom'])
    t = f(cfg['flange_thk'])
    tw = f(cfg['web_thk'])
    ext = f(cfg['top_extension'])
    if cfg.get('pitch_source') == 'frame':
        params = raf.derivation.get('params', {})
        if 'slope_rise' not in params:
            raise ValueError('Selected rafter has no frame pitch; choose manual pitch.')
        cfg['rise'] = str(params['slope_rise'])
    rise = float(Fraction(str(cfg['rise'])))
    theta = math.atan(rise / 12)
    weld = (cfg.get('weld_size') or '1/4"').strip()
    cfg['weld_size'] = weld
    if weld and f(weld) <= 0:
        raise ValueError('Weld size must be positive or blank (unspecified).')
    cfg['fit'] = 'tight'
    cfg['bevel'] = 'none'
    if (
        not all(math.isfinite(x) for x in (B, t, tw, ext, rise))
        or B <= 0
        or t <= 0
        or tw <= 0
        or ext < 0
        or not 0 <= rise <= 12
    ):
        raise ValueError('Positive lengths/thicknesses, nonnegative top extension, and slope from 0 to 12:12 required.')
    qty = int(cfg['qty'])
    if qty < 1 or qty != float(cfg['qty']):
        raise ValueError('Quantity must be a positive integer.')
    width = float(cs.bf)
    d = float(rs.d)
    sn, co = math.sin(theta), math.cos(theta)
    if tw >= width or t * 2 >= d or t >= B:
        raise ValueError('Plate thickness exceeds the body dimensions.')
    if cfg.get('plate_mode') not in ('library', 'member'):
        raise ValueError('Plate mode must be library or member')
    if cfg['plate_mode'] == 'member':
        from .plate_rules import make

        ep = make(job, 'R' if kind == 'apex' else 'K', rs.name, cs.name, weld)
        cfg['end_plate'] = ep.mark
    else:
        ep = job.part(cfg['end_plate'])
    if ep.kind != 'plate' or ep.symbol.get('owner') or None in (ep.thk, ep.width, ep.length):
        raise ValueError('Mating plate must be a defined plate.')
    if cfg['bottom_mode'] not in ('column_depth', 'manual'):
        raise ValueError('Bottom length mode must be column_depth or manual')
    if cfg['bottom_mode'] == 'column_depth':
        B = float(cs.d) + f(ep.thk)
    if kind == 'apex' and cfg.get('apex_bottom_half') not in (None, ''):
        finished = f(cfg['apex_bottom_half'])
        if finished <= 0:
            raise ValueError('Apex finished bottom half-length must be positive')
        # finished half = reference half - END thickness*cos + (plate L - rafter d)/2*sin
        B = finished + f(ep.thk) * co - (f(ep.length) - d) * sn / 2
        if B <= t:
            raise ValueError('Apex finished half produces an invalid reference geometry with this plate/section')
        cfg['bottom_mode'] = 'manual'
    cfg['bottom'] = precision(B).fmt()
    # Library source plates stay immutable: only assembly-owned END/MATE adopt
    # the user hole-center standard. Keep the selected plate's hole diameter.
    dias = {h.dia.inches for h in ep.holes}
    if len(dias) > 1:
        raise ValueError('Mating plate has mixed hole diameters; choose a uniform diameter')
    holes = connecting_holes(job, ep.length, ep.width, M.D(next(iter(dias))) if dias else None)

    # All parts owned by this connection are deterministic. No overwriting library parts.
    old = job.parts.get(mark)
    if old and not old.symbol.get('connection'):
        raise ValueError('Mark already belongs to a non-parametric part.')
    cfg['qty'] = qty
    owned = {}
    children = []

    def plate(suffix, thick, W, L, role, points=None, holes=None, count=1):
        name = f'{mark}-{suffix}'
        if name in job.parts and job.parts[name].symbol.get('owner') != mark:
            raise ValueError(f'Piece mark collision: {name}')
        if points:
            x0 = min(x for x, y in points)
            y0 = min(y for x, y in points)
            cut = [(precision(x - x0).to_json(), precision(y - y0).to_json()) for x, y in points]
            L = max(f(x) for x, y in cut)
            W = max(f(y) for x, y in cut)
        else:
            cut = [(precision(x).to_json(), precision(y).to_json()) for x, y in [(0, 0), (L, 0), (L, W), (0, W)]]
        pts = [(q(f(x)).fmt(), q(f(y)).fmt()) for x, y in cut]
        p = M.Part(
            name,
            'plate',
            M.D(thick),
            M.D(Fraction(math.ceil(W * 16 - 1e-8), 16)),
            M.D(Fraction(math.ceil(L * 16 - 1e-8), 16)),
            holes=copy.deepcopy(holes or []),
            symbol={
                'owner': mark,
                'role': role,
                'contour': pts,
                'cut_contour': cut,
                'draft_connection': True,
                'fit': 'tight',
                'bevel': 'none',
                'weld_size': weld,
                'finished_length_in': L,
                'finished_width_in': W,
            },
            source=SOURCE,
            notes='Tight fit; no bevel. Decimal contour governs; stock blank rounded UP to 1/16.',
        )
        if min(f(p.length), f(p.width)) <= 0:
            raise ValueError('Derived plate has zero or negative dimension.')
        owned[name] = p
        children.extend([M.Attachment(name, 'top') for _ in range(count)])
        return p

    # Bracket spans the column top. Square-cut END plate is inset: its
    # OUTER lower corner X equals the bottom-plate end, and its lowest corner
    # seats at y=t. At nonzero pitch the other lower corner is slightly higher.
    sign = 1 if kind == 'low' else -1
    plate_length = f(ep.length)
    et = f(ep.thk)
    if plate_length < d:
        raise ValueError('Mating plate is shorter than the rafter depth')
    px = B - et * co
    py = t + max(0, -sign * et * sn)
    A = px + sign * py * math.tan(theta)  # inner END plane x + sign*y*tan = A
    face_height = (plate_length + d) / 2
    e = (px - sign * face_height * sn, py + face_height * co)
    h = e[1] - sign * e[0] * math.tan(theta)
    body_depth = h * co + sign * A * sn
    if h < 2 * t:
        raise ValueError('Bottom length/pitch makes the column-side body depth too small')
    top_inner = h - t / co
    yt = (top_inner + sign * A * math.tan(theta)) * co * co
    xt = A - sign * yt * math.tan(theta)
    xb = px
    right = [(px, t)] + ([(px, py)] if py > t + 1e-9 else []) + [(xt, yt)]
    back_height = h - t / co - t + min(0, sign * t * math.tan(theta))
    reference_B = B
    bottom_y = 0.0
    if kind != 'apex':
        web = [(t, t)] + right + [(t, top_inner + sign * t * math.tan(theta))]
        outer = [(0, 0), (B, 0), (B, t), (px, py), e, (0, h)]
        plate(
            'TOP',
            cfg['flange_thk'],
            width,
            math.hypot(e[0], e[1] - h) + (ext if kind == 'low' else 0),
            'top flange; square cuts; no bevel',
        )
        plate('BOT', cfg['flange_thk'], width, B, 'horizontal bottom plate spans column top')
        plate(
            'BACK',
            cfg['flange_thk'],
            width,
            back_height,
            'back plate BOTTOM sits on TOP of bottom plate; square top fit review',
            holes=M.rect_holes('9/16', [M.D('2')], [precision(width / 2 - 1.125), precision(width / 2 + 1.125)]),
        )
        plate('WEB', cfg['web_thk'], 0, 0, 'single centered web', web)
        end_count = 1
    else:
        # Apex exception: keep the bolted interfaces and rafter TOP line fixed,
        # raise the horizontal BOT underside to the rafter BOTTOM at each
        # inner END connection plane. The K/R plate tails now extend below BOT.
        bottom_y = e[1] - d * co
        B = e[0] - d * sn  # sign=-1, rafter-bottom point on inner END plane
        xb = A + (bottom_y + t) * math.tan(theta)
        web = [(-xb, bottom_y + t), (xb, bottom_y + t), (xt, yt), (0, top_inner), (-xt, yt)]
        outer = [(-B, bottom_y), (B, bottom_y), (B, bottom_y + t), e, (0, h), (-e[0], e[1]), (-B, bottom_y + t)]
        plate(
            'TOP',
            cfg['flange_thk'],
            width,
            math.hypot(e[0], e[1] - h),
            'top flange one each side; square ridge fit review',
            count=2,
        )
        plate(
            'BOT',
            cfg['flange_thk'],
            width,
            2 * B,
            'continuous horizontal bottom; UNDERSIDE aligns with rafter bottom at inner END planes',
        )
        plate('WEB', cfg['web_thk'], 0, 0, 'ONE continuous ridge web; raised bottom', web)
        end_count = 2
    if any(y < 0 for x, y in web) or xt <= t or xb <= t or yt <= t:
        raise ValueError('Derived web is inverted or too small for the chosen thickness, pitch and bottom length.')
    end = plate(
        'END',
        ep.thk,
        f(ep.width),
        f(ep.length),
        'user hole-center rule; envelope / diameter from ' + ep.mark,
        holes=holes,
        count=end_count,
    )
    # Matching loose plates supplied for the rafter sides; separate from weldment BOM.
    mate = plate(
        'MATE',
        ep.thk,
        f(ep.width),
        f(ep.length),
        'loose rafter mating plate, not included in weldment weight',
        holes=holes,
        count=0,
    )
    placement = dict(
        plate_bottom_y_in=t,
        inner_lower_corner_y_in=py,
        outer_lower_corner_x_in=reference_B,
        back_plate_bottom_y_in=t,
        bottom_underside_y_in=bottom_y,
        apex_bottom_alignment='rafter underside at inner END planes' if kind == 'apex' else '',
        inset_normal_in=et,
        bottom_length_in=B,
        bottom_mode=cfg['bottom_mode'],
        plate_to_rafter_top_in=(plate_length - d) / 2,
        rafter_bottom_from_plate_bottom_in=(plate_length - d) / 2,
        alignment='inset END outer lower corner flush with bottom end; square-cut lower edge seated; common top line',
        centering_status='REVIEW ASSUMPTION: centered K/R plate on rafter depth',
    )
    for part in (end, mate):
        part.symbol['interface_placement'] = placement.copy()
    if ep.symbol.get('plate_rule_generated'):
        for p in (end, mate):
            p.symbol['interface_key'] = ep.symbol['geometry_key']
            p.symbol['plate_rule_ref'] = ep.mark
            p.symbol['review_hold'] = ep.symbol['review_hold']
            p.source = ep.source
    pending = [
        'K/R plate centered on rafter depth remains a review assumption; verify the above/below-rafter offsets.',
        'Confirm plate thicknesses, material and weld sizes/lengths; tight fit and no bevel specified by user.',
        'User hole-center standard; confirm diameter/bolt specification and rafter fit; envelope from '
        + ep.mark
        + ' ('
        + ep.source
        + ').',
        'Derived geometry: verify joint fit. Contour coordinates at 0.000001 in; no kerf/clearance applied.',
    ]
    if ep.symbol.get('plate_rule_generated'):
        pending.append(ep.symbol['review_hold'])
    if weld:
        pending.append('User-entered fillet weld leg ' + weld + '; size is not structurally approved by this software.')
    else:
        pending.append('Weld size unspecified: enter the approved shop weld size; no automatic capacity inference.')
    if kind == 'apex':
        pending.append(
            'Apex BOT underside aligned with rafter underside at INNER END planes; plate tails extend below BOT.'
        )
        pending.append(
            f'Square apex BOT/end-plane corner mismatch {t * math.tan(theta):.6f} in: web reaches inner END plane at BOT top; verify corner support/weld fit. No hidden bevel.'
        )
    if f(ep.length) < d:
        pending.append('ERROR: mating plate is shorter than the rafter depth.')
    if f(ep.width) < rs.bf:
        pending.append('ERROR: mating plate is narrower than the rafter flange.')
    notes = 'DRAFT - NOT FOR FABRICATION; welded details and connection design unverified.'
    root = M.Part(
        mark,
        'bracket',
        attachments=children,
        source=SOURCE,
        notes=notes,
        drawing_ref=mark,
        symbol={
            'connection': True,
            'config': cfg,
            'outline': outer,
            'w': max(x for x, y in outer) - min(x for x, y in outer),
            'h': h,
            'body_width': width,
            'rafter_depth': d,
            'pitch_deg': math.degrees(theta),
            'geometry_version': 7,
            'body_depth_normal_in': body_depth,
            'interface_placement': placement,
            'plate_bottom_xy': [px, py],
            'column_depth': float(cs.d),
            'bottom_length_in': B,
            'bottom_y_in': bottom_y,
            'reference_half_in': reference_B,
            'apex_corner_mismatch_in': t * math.tan(theta) if kind == 'apex' else 0.0,
            'inner_plane_intercept_in': A,
            'web_outline': web,
            'back_height_in': back_height,
            'back_bottom_y_in': t,
            'rafter_top_xy': list(e),
            'rafter_center_face_x_in': px - sign * plate_length * sn / 2,
            'top_run_to_body_face_in': e[0] / co,
            'top_run_to_rafter_cut_in': e[0] / co + 2 * et,
            'inner_column_to_rafter_cut_in': (e[0] - float(cs.d)) / co + 2 * et,
            'mate': mate.mark,
            'interfaces': end_count,
            'pending': pending,
            'reference': (
                'HBR10E1' if kind == 'low' else 'HBR10HE1' if kind == 'high' else 'Derived symmetric high-eave pair'
            ),
        },
    )
    root.unit_weight = sum((owned[a.part].weight(job.weights) for a in children), Decimal(0))
    # Clip children belong to their actual weldment; no negative rafter stations.
    root.symbol['roof_clips'] = []
    specs = []
    if kind != 'apex' and cfg.get('start_clip'):
        specs.append(('starting', cfg['start_clip'], -(ext if kind == 'low' else 0), [1]))
    if kind == 'apex' and cfg.get('peak_clip'):
        specs.append(('peak', cfg['peak_clip'], float(cfg['peak_clip']['edge_in']), [1, -1]))
    for role, spec, near, mirrors in specs:
        cp = job.part(spec['part'])
        mode = spec.get('mode', 'bypass')
        side = spec.get('side', 'NS')
        if cp.kind not in ('clip', 'plate') or any(v is None or f(v) <= 0 for v in (cp.thk, cp.width, cp.length)):
            raise ValueError('Connection roof clip needs positive plate dimensions')
        ct = f(cp.thk)
        z0 = 0 if mode == 'bypass' else -f(spec.get('web_y', '4')) - f(cp.width) / 2
        z1 = f(cp.length) if mode == 'bypass' else z0 + f(cp.width)
        for mirror in mirrors:
            corners = [
                (mirror * (ds * co - sign * sn * z), h + sign * sn * ds + co * z)
                for ds, z in [(near, z0), (near + ct, z0), (near + ct, z1), (near, z1)]
            ]
            record = dict(
                role=role,
                part=cp.mark,
                mode=mode,
                side=side,
                mirror=mirror,
                near_edge_in=near,
                far_edge_in=near + ct,
                station_in=near + ct / 2,
                corners=corners,
                quantity=2 if mode == 'flush' and side == 'both' else 1,
                datum='ridge along roof slope'
                if role == 'peak'
                else 'outside bracket roof edge; clip outside edge aligned',
                station_from_bracket_edge_in=ct / 2 if role == 'starting' else None,
            )
            from .clip_clearance import check_edges

            local_check = check_edges(
                near, near + ct, [(mate.mark, e[0] / co + et, e[0] / co + 2 * et)], mark, role, cp.mark, near + ct / 2
            )
            record['clearance_checks'] = local_check['checks']
            record['warnings'] = local_check['warnings']
            root.symbol['roof_clips'].append(record)
            children.append(
                M.Attachment(
                    cp.mark,
                    'top' if mode == 'bypass' else 'web',
                    precision(ct / 2 if role == 'starting' else near + ct / 2),
                    ref='bracket_outside_edge' if role == 'starting' else 'ridge_centerline',
                    side=side if mode == 'flush' else 'NS',
                    y_from_top=M.D(spec.get('web_y', '4')) if mode == 'flush' else None,
                    label=role.upper() + ' ' + cp.mark,
                    note=role + ' bracket/apex roof clip',
                )
            )
            root.unit_weight += cp.weight(job.weights) * record['quantity']
        pending.append(
            role.capitalize() + ' clip placement shown; weld/support and full secondary profile require review.'
        )

    for name, p in list(job.parts.items()):
        if p.symbol.get("owner") == mark and name not in owned:
            del job.parts[name]
    job.parts.update(owned)
    job.parts[mark] = root
    job.settings.setdefault('connections', {})[mark] = cfg
    return root


def rebuild(job):
    for mark, cfg in list(job.settings.get('connections', {}).items()):
        if cfg.get('welded'):
            continue  # regenerated atomically by sync_frames
        build(job, mark, cfg)


def quantities(job, existing):
    """Connection qty is a standalone fabrication lot, never inferred as frame qty."""
    parts = dict(existing)
    for mark, cfg in job.settings.get('connections', {}).items():
        if not cfg.get('installed') or cfg.get('frame_role') == 'ridge':
            parts[mark] = parts.get(mark, 0) + int(cfg['qty'])
    for mark, n in list(parts.items()):
        p = job.part(mark)
        if not p.symbol.get('connection'):
            continue
        for a in p.attachments:
            parts[a.part] = parts.get(a.part, 0) + n * (2 if a.face == 'web' and a.side == 'both' else 1)
        if not p.symbol['config'].get('installed'):
            mate = p.symbol['mate']
            parts[mate] = parts.get(mate, 0) + n * p.symbol['interfaces']
    # Zoned jobs use the physical wall-clip setout, not an identical-column
    # template multiplied through open bays. Other attachment types unchanged.
    for fid, cfg in job.settings.get('frames', {}).items():
        owner = job.assemblies.get(fid)
        if not owner or not owner.derivation.get('bay_zones'):
            continue
        clip = cfg.get('girt_clip')
        if clip and clip in job.parts and job.parts[clip].kind == 'mark':
            parts.pop(clip, None)  # girts welded directly to the web: nothing counted
            continue
        removed = 0
        for asm in job.assemblies.values():
            if asm.derivation.get('frame_id') != fid or asm.kind != 'COLUMN':
                continue
            removed += sum(
                (2 if att.face == 'web' and att.side == 'both' else 1) * asm.qty
                for att in asm.attachments
                if att.part == clip
            )
        physical = sum(
            r['quantity']
            for r in owner.derivation.get('wall_girt_connections', [])
            if r['scope'] == 'primary_interior' and r['clip'] == clip
        )
        if clip:
            parts[clip] = parts.get(clip, 0) - removed + physical
        if clip and parts[clip] < 0:
            raise ValueError('Zoned girt clip count reconciliation failed')
    return parts
