"""Pinned manufacturer reference library. No inferred steel thickness or capacity."""

import copy
import hashlib
import json
from decimal import Decimal
from pathlib import Path

from .connections import f
from .model import D

PATH = Path(__file__).parent / 'data/mbci_secondaries.json'
ROLES = ('purlin', 'girt', 'endwall_girt', 'eave', 'accessory')


def catalog():
    raw = PATH.read_bytes()
    data = json.loads(raw)
    data['sha256'] = hashlib.sha256(raw).hexdigest()
    return data


def get(ident):
    from .sections import DOUBLED_SUFFIX

    if str(ident).endswith(DOUBLED_SUFFIX) and str(ident).startswith(('SSS-SS', 'MBCI-Channel-')):
        # doubled open-face channel (two welded back to back into an I): the physical product
        # is the single channel, bought twice per member (ordering.py)
        base = get(str(ident)[: -len(DOUBLED_SUFFIX)])
        rec = dict(base)
        rec.update(
            id=str(ident),
            designation=str(base.get('designation', base['id'])) + ' x2 (two welded back to back, I shape)',
            flanges_in=[2 * x for x in base.get('flanges_in') or []] or base.get('flanges_in'),
            weight_lb_ft=None if base.get('weight_lb_ft') is None else 2 * base['weight_lb_ft'],
            weight_by_finish_lb_ft={
                k: (None if v is None else 2 * v) for k, v in (base.get('weight_by_finish_lb_ft') or {}).items()
            },
            doubled=True,
            single=base['id'],
            open_face=False,
        )
        return rec
    if str(ident).startswith('SSS-'):
        from .product_library import secondaries

        try:
            return next(r for r in secondaries() if r['id'] == ident)
        except StopIteration:
            raise ValueError('Unknown SSS physical product: ' + str(ident))
    if str(ident).startswith('USER-Eave-'):
        from .eave_reference import get as user_eave

        return user_eave(ident)
    if str(ident).startswith('MBCI-Channel-'):
        from .channel_catalog import get as channel

        return channel(ident)
    try:
        return next(p for p in catalog()['profiles'] if p['id'] == ident)
    except StopIteration:
        raise ValueError('Unknown MBCI profile ID: ' + str(ident))


def apply(p):
    """Resolve selected nominal depths BEFORE managed frame generation."""
    cat = catalog()
    raw = p.secondary
    if not isinstance(raw, dict):
        raise ValueError('Secondary selections must be an object')
    if raw.get('catalog_sha256') and raw['catalog_sha256'] != cat['sha256']:
        raise ValueError(
            'MBCI library revision differs from this saved job. Explicitly review/reselect the catalog entries before regeneration.'
        )
    selected = {}
    for role in ROLES:
        spec = raw.get(role) or {}
        if not isinstance(spec, dict):
            raise ValueError('Invalid secondary selection: ' + role)
        if not spec.get('profile_id'):
            continue
        profile = get(spec['profile_id'])
        family = profile['family']
        finish = spec.get('finish', 'Red Oxide')
        if role in ('purlin', 'girt', 'endwall_girt') and family not in ('C', 'Z'):
            raise ValueError(role + ' requires a Cee or Zee')
        if role == 'eave' and family not in ('Eave', 'C', 'Z'):
            raise ValueError('Eave selection requires an eave strut or C/Z purlin')
        if role == 'eave' and family in ('C', 'Z') and not 4 <= profile['nominal_depth_in'] <= 8:
            raise ValueError('Eave purlin depth must be4–8in')
        if role == 'eave' and family == 'Eave' and not profile['eave_kind'].startswith('low_'):
            raise ValueError('Select LOW eave; mono high companion is derived explicitly')
        if finish not in profile['finishes']:
            raise ValueError(f'{profile["designation"]}: {finish} not listed in this source')
        q = spec.get('quantity') or 0
        try:
            qn = int(q)
            if qn != float(q) or not 0 <= qn <= 1000000:
                raise ValueError()
        except (ValueError, TypeError):
            raise ValueError('Secondary quantity must be a nonnegative whole number')
        length = spec.get('piece_length') or ''
        if bool(qn) != bool(length):
            raise ValueError(role + ': enter BOTH ordered piece length and TOTAL lot quantity, or leave both blank')
        if length:
            length = D(length)
            if not 0 < f(length) <= 10000:
                raise ValueError('Secondary piece length must be positive and reasonable')
            if profile.get('max_length_ft') and f(length) > profile['max_length_ft'] * 12:
                raise ValueError('Eave strut exceeds catalog maximum 40-foot length')
            if profile.get('stock_length_ft') and abs(f(length) - profile['stock_length_ft'] * 12) > 1e-6:
                raise ValueError(
                    'Selected stock entry has a fixed catalog length; custom lengths need a separate confirmed specification'
                )
        selected[role] = dict(
            profile_id=profile['id'], finish=finish, quantity=qn, piece_length=length.fmt() if length else ''
        )
    if selected:
        selected['catalog_sha256'] = cat['sha256']
    p.secondary = selected
    if 'purlin' in selected:
        p.purlin_depth = D(get(selected['purlin']['profile_id'])['nominal_depth_in'])
    if 'girt' in selected:
        p.girt_depth = D(get(selected['girt']['profile_id'])['nominal_depth_in'])
    if 'eave' in selected:
        p.eave_strut_depth = D(get(selected['eave']['profile_id'])['nominal_depth_in'])


def finish(job, p):
    """Retain source snapshot and explicit takeoff, separately from primary-steel BOM."""
    cat = catalog()
    snap = {}
    warnings = []
    rows = []
    for role in ROLES:
        spec = p.secondary.get(role)
        if not spec:
            continue
        profile = get(spec['profile_id'])
        source = profile.get('source_info', cat['source'])
        snap[role] = dict(selection=copy.deepcopy(spec), profile=profile, source=source, catalog_sha256=cat['sha256'])
        # A catalog product is the shop standard - no per-generation disclaimer (v0.8.40: the
        # "nominal profile selected ... unverified" and the MBCI eave-slope boilerplate were noise
        # on every job).  Only a hand-entered reference profile is still named.
        if profile.get('custom_reference'):
            warnings.append(
                role.upper()
                + ': USER6in reference ONLY; supplier shape, gauge, thickness, finish availability and weight unverified.'
            )
        if role == 'eave' and profile['family'] == 'Eave':
            if p.frame_type == 'monoslope':
                high = get(profile['id'].replace('-low_', '-high_'))
                snap['high_eave_companion'] = dict(
                    profile=high,
                    source=source,
                    selection={'finish': spec['finish'], 'quantity': 0, 'piece_length': ''},
                    catalog_sha256=cat['sha256'],
                )
        if (
            role == 'purlin'
            and p.purlin_mode == 'bypass'
            and f(job.part(p.purlin_clip).length) > profile['nominal_depth_in']
        ):
            warnings.append(
                'PURLIN envelope screen: selected clip is taller than nominal purlin depth. Check attachment geometry; no automatic adjustment.'
            )
        qty = spec['quantity']
        L = spec['piece_length']
        each = total = None
        if qty:
            if profile['weight_lb_ft'] is not None:
                dim = D(L).inches
                each = Decimal(str(profile['weight_lb_ft'])) * Decimal(dim.numerator) / Decimal(dim.denominator) / 12
            elif profile.get('stock_weight_lb', {}).get(spec['finish']) is not None:
                each = Decimal(str(profile['stock_weight_lb'][spec['finish']]))
            total = each * qty if each is not None else None
        rows.append(
            dict(
                frame_id=p.column_mark,
                role=role,
                profile_id=profile['id'],
                designation=profile['designation'],
                finish=spec['finish'],
                gauge=profile['gauge'],
                ordered_piece_length=L,
                total_lot_pieces=qty or '',
                weight_lb_ft=profile['weight_lb_ft'] if profile['weight_lb_ft'] is not None else '',
                estimated_weight_each_lb=str(each.quantize(Decimal('.01'))) if each is not None else '',
                estimated_lot_weight_lb=str(total.quantize(Decimal('.01'))) if total is not None else '',
                status='USER-ENTERED ORDERED PIECES — NOT A BAY/LAP DESIGN'
                if qty
                else 'QUANTITY / LENGTH NOT PROVIDED — NOT INCLUDED IN TOTAL',
                source_revision=source['revision'],
                source_page=profile['pdf_page'],
                source_url=source['url'],
            )
        )
    if p.slab:
        profile = get(p.base_angle['profile_id'])
        spec = p.base_angle
        snap['base_angle'] = dict(
            selection=copy.deepcopy(spec), profile=profile, source=cat['source'], catalog_sha256=cat['sha256']
        )
        if not (isinstance(p.bay_layout, dict) and p.bay_layout.get('enabled')):
            # With automatic bay runs the base angle is cut and counted per bay
            # (secondary_runs); without them its quantity is an open input.
            warnings.append(
                'SLAB base angle quantities missing: enable the automatic bay runs (Building settings > Bays) for base angle cut lengths and counts.'
            )
        rows.append(
            dict(
                frame_id=p.column_mark,
                role='base_angle',
                profile_id=profile['id'],
                designation=profile['designation'],
                finish=spec['finish'],
                gauge=profile['gauge'],
                ordered_piece_length='',
                total_lot_pieces='',
                weight_lb_ft='',
                estimated_weight_each_lb='',
                estimated_lot_weight_lb='',
                status='SLAB BASE ANGLE — RUN LENGTH / QUANTITY PENDING',
                source_revision=cat['source']['revision'],
                source_page=profile['pdf_page'],
                source_url=cat['source']['url'],
            )
        )
    frame = job.settings.get('frame_layouts', {}).get(p.column_mark)
    if frame is not None:
        frame['secondary_catalog'] = snap
        frame['secondary_warnings'] = warnings
        frame['secondary_material_rows'] = rows
    owner = job.assemblies[p.column_mark]
    owner.derivation['secondary_warnings'] = warnings
    owner.derivation['secondary_catalog'] = snap
    owner.derivation['secondary_material_rows'] = rows
    if (
        snap
        and p.connection_style == 'bolted'
        and 'purlin' in snap
        and abs(f(p.purlin_depth) - f(p.eave_strut_depth)) > 1e-8
    ):
        warnings.append(
            'Selected purlin and eave nominal depths differ. Existing bolted strut datum retained; verify roof/support alignment.'
        )
    return snap
