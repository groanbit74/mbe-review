"""User-prescribed section defaults and separately scoped endwall setout.

Not a structural design solver. Mixed-section posts never impersonate rolled W
sections in the primary model. Reference cuts remain held for connection design.
"""

import copy
import math
from fractions import Fraction

from . import foundation as FND
from . import sections
from .connections import f
from .model import D
from .secondary_catalog import catalog, get

INTERIOR = {240: 'W8X10', 360: 'W10X12', 480: 'W12X14', 600: 'W12X19'}
TUBE_SIZES = ('4x4', '4x5', '4x6', '4x7', '4x8', '2x4', '2x5', '2x6', '2x7', '2x8')
WALLS = ('14 ga', '12 ga', '11 ga', '10 ga', '1/8', '3/16', '1/4')


def rules():
    return dict(
        interior_width_inches=INTERIOR,
        reduced='W8X10 through 40 ft; W10X12 above 40 ft',
        basis='USER PRESETS — NOT CAPACITY CHECKED',
        tube_sizes=TUBE_SIZES,
        tube_walls=WALLS,
    )


def wprofile(name):
    s = sections.get_section(name)
    if s.kind == 'HSS':
        from .tube_sections import profile

        return profile(s.name)
    if s.kind != 'W':
        raise ValueError('Column/post reference must be W; channel option is for rafters')
    return dict(
        family='W',
        id=s.name,
        depth=s.d,
        width=s.bf,
        web=s.tw,
        flange=s.tf,
        weight_lb_ft=float(s.plf),
        wall='',
        finish='',
        source='Local nominal rolled-section reference',
    )


def along_wall(prof, outer=False):
    """Extent of a post / column along the end wall.

    Corner (outer) columns stand like the frame columns - web across the building, outside
    flange in the sidewall plane - so their depth runs along the end wall (owner, v0.8.31);
    intermediate posts stand web-normal to the end wall (flange width along the wall).
    """
    return prof['depth'] if outer and prof.get('family') in ('W', 'HSS') else prof['width']


def rafter_profile(name):
    s = sections.get_section(name)
    if s.kind == 'W':
        return wprofile(name)
    if s.kind != 'Channel':
        raise ValueError('Rafter adapter accepts W or supplier channel; tube choices are for columns')
    return dict(
        family='Channel',
        id=s.name,
        depth=s.d,
        width=s.bf,
        # gauge thickness (sections.GAUGE_THICKNESS_IN): web = cut datum, flange = inside-depth datum
        web=s.tw,
        flange=s.tf,
        doubled=bool(getattr(s, 'doubled', False)),
        weight_lb_ft=float(s.plf) if s.plf is not None else None,
        wall=str(s.gauge) + ' ga',
        finish=s.finish,
        source='Supplier open-face channel; purlins inside the open face 1/4 in from the web (shop rule)',
    )


def _endwall_girt_spec(p):
    """Specific endwall product when selected; otherwise follow the sidewall girt."""
    specific = (p.secondary or {}).get('endwall_girt') or {}
    return specific if specific.get('profile_id') else (p.secondary or {}).get('girt') or {}


def _secondaries_supplier(p):
    return 'sss' if str(_endwall_girt_spec(p).get('profile_id', '')).startswith('SSS-') else 'mbci'


def _endwall_girt_depth(p):
    profile_id = _endwall_girt_spec(p).get('profile_id')
    return get(profile_id)['nominal_depth_in'] if profile_id else f(p.girt_depth)


def _include_girts(p, end, enclosure, rec) -> bool:
    """Sheets never without girts (v0.8.39): a sheeted end wall always carries its girts when a
    girt product is selected; the switch only matters for the roof-only outer end of a zoned
    building (and for legacy jobs without a girt product, where the release check reports it)."""
    if enclosure == 'open':
        return False
    if end != 'outer_front_end' and _endwall_girt_spec(p).get('profile_id'):
        from .wall_girts import sheeted_faces

        face = 'front' if end == 'front_end' else 'rear'
        if face in sheeted_faces(p):  # wall sheets switched on for this end
            return True
    return rec.get('include_girts', False)


def apply(p):
    raw = p.section_defaults
    if not isinstance(raw, dict):
        raise ValueError('Section defaults must be an object')
    if not isinstance(raw.get('enabled', False), bool):
        raise ValueError('Section preset enabled must be boolean')
    if raw.get('enabled'):
        name = INTERIOR.get(p.width.inches)
        if name is None:
            raise ValueError(
                'Interior presets apply only at exactly 20, 30, 40 or 50 ft. Choose manual sections for other widths.'
            )
        p.section_defaults = dict(
            enabled=True, column_override=raw.get('column_override', ''), rafter_override=raw.get('rafter_override', '')
        )
        p.column_section = wprofile(p.section_defaults['column_override'] or name)['id']
        p.rafter_section = rafter_profile(p.section_defaults['rafter_override'] or name)['id']
    else:
        p.section_defaults = {}
    raw = p.endwalls
    if not isinstance(raw, dict):
        raise ValueError('Endwalls must be an object')
    if not isinstance(raw.get('enabled', False), bool):
        raise ValueError('Endwall enabled must be boolean')
    if not raw.get('enabled'):
        p.endwalls = {}
        return
    if not p.auto_connections:
        raise ValueError('Endwall setout requires managed frame geometry')
    clean = dict(enabled=True)
    for end in ('front_end', 'rear_end') + (
        ('outer_front_end',)
        if getattr(p, 'bay_zones', {}).get('enabled') and p.bay_zones.get('enclosed_start_line', 0)
        else ()
    ):
        rec = raw.get(end) or {}
        prior = p.bay_layout.get(end) or {}
        if not isinstance(prior, dict):
            raise ValueError('End support references must be objects')
        if not isinstance(rec, dict):
            raise ValueError('Endwall settings must be objects')
        typ = rec.get('type', prior.get('type', 'bearing_endwall'))
        if typ == 'rigid_frame' and end != 'outer_front_end':
            # This end line is a main rigid frame of the primary lot (roof-only buildings, or the
            # open end of a building whose other end was just sheeted): nothing to frame here.
            continue
        if typ not in ('bearing_endwall', 'reduced_rigid'):
            raise ValueError('Unknown endwall support type')
        default = 'W8X10' if p.width.inches <= 480 else 'W10X12'
        enclosure = rec.get('enclosure') or 'sheeted'
        if enclosure not in ('sheeted', 'open'):
            raise ValueError('End wall enclosure must be sheeted or open')
        # Owner rule (2026-10-15): interior end-wall posts are standard only on a SHEETED end wall.
        # An OPEN end wall has none - the end rafter spans corner column to corner column as a rigid
        # end frame of the main sections.  `end_posts` = auto (that rule) | always | never.
        end_posts = rec.get('end_posts', 'auto')
        if end_posts not in ('auto', 'always', 'never'):
            raise ValueError('Interior end posts must be auto, always or never')
        posts_omitted = end_posts == 'never' or (end_posts == 'auto' and enclosure == 'open')
        from .standards import endwall_post_stations as _post_table

        _table = _post_table(f(p.width))
        posts_needed = bool(_table) if _table is not None else f(p.width) > 240
        rigid_end = posts_omitted and posts_needed
        if rigid_end and sections.get_section(p.rafter_section).kind == 'W':
            default = sections.get_section(p.rafter_section).name
        # Shop standard (v0.8.30): W preset end rafters BYPASS like the interior frames - purlins run
        # over the end rafter, the rake angle sits on top of the purlins with its 4 in leg down over
        # the purlin ends and carries the end-wall sheets.  Only open-face CHANNEL end rafters are
        # FLUSH (purlins between the channel flanges, roof line = top of the channel).  Legacy FOLLOW
        # (= copy the interior bypass) resolves to bypass; FLUSH stays an explicit per-end override
        # for W rafters.
        roof_mode = rec.get('roof_mode') or 'bypass'
        if roof_mode not in ('follow', 'flush', 'bypass'):
            raise ValueError('End roof mode must be flush or bypass')
        if roof_mode == 'follow':
            roof_mode = 'bypass'
        confirmed = rec.get('purlin_channel_fit_confirmed', False)
        if not isinstance(confirmed, bool):
            raise ValueError('Purlin/channel fit confirmation must be boolean')
        # Shop standard: a FLUSH (channel) end wall runs its corner columns to the
        # roof line with the rafter welded to the inside face; a BYPASS W end rafter
        # sits ON the corner post (seat) - the seat chooser only overrides by hand.
        head_mode = rec.get('post_head') or (
            'side_welded'
            if p.connection_style != 'bolted' and typ == 'bearing_endwall' and roof_mode == 'flush'
            else 'legacy'
        )
        ridge_mode = rec.get('ridge_joint', 'legacy')
        head_overrides = rec.get('post_head_overrides', {})
        if not isinstance(head_overrides, dict) or any(not isinstance(mark, str) for mark in head_overrides):
            raise ValueError('Per-location endwall head overrides must be an object keyed by column mark')
        head_overrides = {mark: mode for mark, mode in head_overrides.items() if mode not in (None, '')}
        if head_mode not in ('legacy', 'direct_welded', 'side_welded') or ridge_mode not in ('legacy', 'face_clip'):
            raise ValueError('Unknown endwall head/ridge detail')
        if any(mode not in ('legacy', 'direct_welded', 'side_welded') for mode in head_overrides.values()):
            raise ValueError('Per-location corner connection must be seat / direct weld / inside face')
        if ridge_mode == 'face_clip' and p.frame_type != 'gable':
            ridge_mode = 'legacy'  # a mono-slope end rafter has no peak: the face splice is a gable-only detail
        if (
            head_mode != 'legacy' or ridge_mode != 'legacy' or any(mode != 'legacy' for mode in head_overrides.values())
        ) and (p.connection_style == 'bolted' or typ != 'bearing_endwall'):
            raise ValueError('Detailed endwall joints require welded bearing endwall')
        depth_clearance = D('0' if confirmed else rec.get('roof_depth_clearance') or '1/4')
        if not 0 <= f(depth_clearance) <= 2:
            raise ValueError('End roof depth clearance must be0–2in TOTAL')
        raf = rec.get('rafter_override', '')
        col = rec.get('column_override', '')
        if rigid_end and not col and not raf and sections.get_section(p.rafter_section).kind == 'W':
            col = p.column_section  # rigid end frame: corner columns are the main column section
        channel_by_span = raf == 'channel'  # saved-job key; since v0.8.31 "channel matching the purlin depth"
        if channel_by_span:
            # Open-face channel end rafter matching the purlin depth (6 / 8 / 10 in): the purlins
            # sit inside the open face 1/4 in from the web, welded to the flanges top and bottom.
            from .standards import channel_end_rafter

            raf = channel_end_rafter(f(p.purlin_depth), _secondaries_supplier(p))
        if roof_mode == 'flush' and not raf:
            # Default (not an override): the shallowest standard W end rafter whose clear inside depth
            # takes the purlin depth plus the TOTAL depth clearance, never shallower than the width default.
            need = f(p.purlin_depth) + f(depth_clearance)
            base = sections.get_section(default).d
            for cand in ('W8X10', 'W10X12', 'W12X14'):
                sec = sections.get_section(cand)
                if sec.d >= base - 1e-8 and sec.d - 2 * sec.tf >= need - 1e-8:
                    default = cand
                    break
        resolved_raf = rafter_profile(raf or default)['id']
        resolved_col = wprofile(
            col or (resolved_raf if sections.get_section(resolved_raf).kind == 'W' else p.column_section)
        )['id']
        # Channel-only approvals must not lock independent section editing. Retire
        # incompatible details visibly; NEVER apply a channel approval/clip to W steel.
        is_channel = rafter_profile(resolved_raf)['family'] == 'Channel'
        if is_channel:
            roof_mode = 'flush'
        retired_fit = not is_channel and (confirmed or rec.get('channel_fit_retired', False))
        retired_ridge = not is_channel and (ridge_mode == 'face_clip' or rec.get('channel_ridge_retired', False))
        if not is_channel:
            confirmed = False
            if ridge_mode == 'face_clip':
                ridge_mode = 'legacy'
            depth_clearance = D(rec.get('roof_depth_clearance') or '1/4')
        post_layout = rec.get('post_layout', 'bays')
        count = rec.get('bays', '')
        widths = rec.get('bay_widths', [])
        custom_stations = rec.get('post_stations', [])
        if isinstance(custom_stations, str):
            custom_stations = [x.strip() for x in custom_stations.split(',') if x.strip()]
        if not isinstance(custom_stations, list):
            raise ValueError(
                'Interior post stations must be a comma-separated list of dimensions measured from the outside-view left wall'
            )
        if post_layout == 'stations':
            # Station mode is an explicit centerline setout, not bay-width entry.
            # Derive bay count/widths from these stations to avoid stale/default widths
            # conflicting with the custom coordinates.
            from .cladding import inch

            custom_stations = [inch(x) for x in custom_stations]
            if any(not math.isfinite(x) for x in custom_stations):
                raise ValueError('Interior post stations must be finite dimensions')
            if len(set(custom_stations)) != len(custom_stations):
                raise ValueError('Interior post stations must be distinct; enter each centerline once')
            if len(custom_stations) > 39:
                raise ValueError('At most 39 custom interior post stations')
            count = len(custom_stations) + 1
            widths = []
        standard_posts = None
        if posts_omitted:
            # no interior posts: one bay from corner column to corner column
            standard_posts = []
            post_layout = 'standard'
            count = 1
            widths = []
        elif post_layout == 'standard' or (count in ('', None) and not widths and post_layout == 'bays'):
            # Standard posts centred by width (30 ft -> 15/15, 40 ft -> 20/20, 50 ft -> 20/10/20);
            # other widths: equal bays at 20 ft maximum.  The layout stays "standard" so a later
            # width change re-applies the table instead of failing on stored bay widths.
            from .standards import endwall_post_stations

            standard_posts = endwall_post_stations(f(p.width))
            post_layout = 'standard'
            count = ''
            widths = []
        if count in ('', None):
            count = len(standard_posts) + 1 if standard_posts is not None else max(1, math.ceil(f(p.width) / 240))
        try:
            n = int(count)
            if n != float(count) or not 1 <= n <= 40:
                raise ValueError()
        except (ValueError, TypeError, OverflowError):
            raise ValueError('Endwall bay count must be an integer from 1 to 40')
        if isinstance(widths, str):
            widths = [x.strip() for x in widths.split(',') if x.strip()]
        if not isinstance(widths, list):
            raise ValueError('Endwall bay widths must be a list or comma-separated dimensions')
        from .cladding import inch

        widths = [inch(x) for x in widths]
        if widths and (len(widths) != n or any(x <= 0 for x in widths)):
            raise ValueError('Enter one positive post-centerline width for every endwall bay')
        inset = f(p.girt_depth) if p.inset_for_bypass else 0
        span = f(p.width) - 2 * inset - along_wall(wprofile(resolved_col), True)
        edge = inset + along_wall(wprofile(resolved_col), True) / 2
        if standard_posts:
            # Standard post centrelines are measured from the outside wall line.
            stations = [edge] + [float(x) for x in standard_posts] + [edge + span]
            widths = [b - a for a, b in zip(stations, stations[1:])]
            widths[-1] = span - sum(widths[:-1])
        elif post_layout == 'stations':
            bad = [x for x in custom_stations if not edge < x < edge + span]
            if bad:
                raise ValueError(
                    'Interior post centerline must fall between the corner-post centerlines '
                    f'({edge:g}–{edge + span:g} in from the outside-view left wall); got {bad[0]:g} in'
                )
            stations = [edge] + custom_stations + [edge + span]
            widths = [b - a for a, b in zip(stations, stations[1:])]
            if any(x <= 0 for x in widths):
                raise ValueError('Interior post stations must be entered in left-to-right order')
        if widths and abs(sum(widths) - span) > 1e-5:
            raise ValueError(
                'Endwall bay widths must total the actual outer POST-CENTERLINE span ' + str(span) + ' inches'
            )
        maximum = D(rec.get('max_span', "20'"))
        if posts_omitted:
            # the end rafter spans the whole width by rule
            maximum = D(Fraction(round(max(f(maximum), span) * 16), 16))
        base = D(rec.get('base_thickness', '1/2'))
        gap = D(rec.get('top_clearance', '0'))
        if not 0 < maximum.inches <= 1200 or base.inches < 0 or gap.inches < 0:
            raise ValueError('Endwall maximum span must be positive; base/top deductions nonnegative')
        fam = rec.get('post_family', 'W')
        post = dict(family=fam)
        if fam == 'W':
            name = sections.normalize(rec.get('post_section', 'W6X9'))
            if not name.startswith(('W6X', 'W8X')):
                raise ValueError('Intermediate wide-flange posts must use a selectable W6 or W8 section')
            post.update(wprofile(name))
        elif fam in ('C', 'Channel'):
            pid = rec.get('post_profile_id', '')
            if not pid and fam == 'Channel':
                raise ValueError('Select an actual open-face channel for the intermediate post')
            if not pid:
                from .product_library import secondaries

                library = (
                    secondaries()
                    if str(_endwall_girt_spec(p).get('profile_id', '')).startswith('SSS-')
                    else catalog()['profiles']
                )
                candidates = [
                    x
                    for x in library
                    if x['family'] == 'C'
                    and abs(x['nominal_depth_in'] - _endwall_girt_depth(p)) < 1e-8
                    and x['gauge'] == 14
                ]
                if not candidates:
                    raise ValueError('No matching 14-ga Cee at the girt depth; select a source-backed Cee explicitly')
                pid = candidates[0]['id']
            c = get(pid)
            finish = rec.get('post_finish', 'Red Oxide')
            if c['family'] != fam or abs(c['nominal_depth_in'] - _endwall_girt_depth(p)) > (
                0.26 if c['family'] == 'Channel' else 1e-8
            ):
                raise ValueError('Open Cee post depth must match the selected endwall-girt depth')
            if finish not in c['finishes']:
                raise ValueError('Cee post finish not available')
            from .sections import GAUGE_THICKNESS_IN

            post.update(
                id=pid,
                depth=c['nominal_depth_in'],
                width=c['flanges_in'][0],
                # cold-formed web thickness from the gauge table (flush girt cut datum)
                web=GAUGE_THICKNESS_IN.get(int(c['gauge'])) if c.get('gauge') else None,
                weight_lb_ft=c['weight_lb_ft'],
                wall=str(c['gauge']) + ' ga',
                finish=finish,
                source=c.get('source_info', catalog()['source']),
                profile=copy.deepcopy(c),
            )
        elif fam == 'HSS':
            size = rec.get('tube_size', '4x4')
            wall = rec.get('tube_wall', '14 ga')
            if size not in TUBE_SIZES or wall not in WALLS:
                raise ValueError('Choose a requested 2x4–2x8 / 4x4–4x8 tube and 14ga–1/4 wall option')
            actual = rec.get('tube_actual_wall', '')
            if actual:
                try:
                    t = D(Fraction(str(actual).strip().rstrip(chr(34))))
                except (ValueError, ZeroDivisionError):
                    t = D(actual)
                if not 0 < t.inches <= Fraction(1, 4):
                    raise ValueError('Actual tube wall must be positive and at most 1/4 inch')
                actual = str(t.inches) + chr(34)
            elif 'ga' not in wall:
                actual = D(wall).fmt()
            a, b = map(float, size.split('x'))
            from .tube_sections import nominal_wall_in, weight_lb_ft

            t_in = float(Fraction(actual.rstrip(chr(34)))) if actual else nominal_wall_in(wall)
            post.update(
                id='HSS ' + size + ' x ' + wall,
                depth=b,
                width=a,
                web=None,
                weight_lb_ft=weight_lb_ft(a, b, t_in),
                wall=wall,
                actual_wall=actual,
                finish=rec.get('post_finish', 'Unspecified'),
                source='Nominal tube post; weight computed from the ' + ('entered' if actual else 'nominal') + ' wall',
            )
        else:
            raise ValueError('Post family must be W, C or HSS')
        clean[end] = dict(
            post_head=head_mode,
            post_head_overrides={mark: mode for mark, mode in head_overrides.items() if mode},
            ridge_joint=ridge_mode,
            purlin_channel_fit_confirmed=confirmed,
            base_connection=p.base_connection,
            roof_mode=roof_mode,
            roof_depth_clearance=depth_clearance.fmt(),
            type=typ,
            rafter_override=raf,
            column_override=col,
            resolved_rafter=resolved_raf,
            resolved_column=resolved_col,
            bays=n,
            bay_widths=widths,
            max_span=maximum.fmt(),
            base_thickness=base.fmt(),
            top_clearance=gap.fmt(),
            post_family=fam,
            post_section=rec.get('post_section', 'W6X9'),
            post_profile_id=post['id'] if fam in ('C', 'Channel') else rec.get('post_profile_id', ''),
            post_finish=rec.get('post_finish', 'Red Oxide'),
            tube_size=rec.get('tube_size', '4x4'),
            tube_wall=rec.get('tube_wall', '14 ga'),
            tube_actual_wall=rec.get('tube_actual_wall', ''),
            post=post,
            include_girts=_include_girts(p, end, enclosure, rec),
            enclosure=enclosure,
            end_posts=end_posts,
            posts_omitted=posts_omitted,
            rigid_end=rigid_end,
            channel_by_span=channel_by_span,
        )
        if channel_by_span:
            clean[end]['rafter_override'] = 'channel'
        if rec.get('supplier_fit_retired') and not confirmed:
            clean[end]['supplier_fit_retired'] = True
        if retired_fit:
            clean[end]['channel_fit_retired'] = True
        if retired_ridge:
            clean[end]['channel_ridge_retired'] = True
        from .endwall_supports import normalize

        clean[end].update(normalize(dict(rec, post_layout=post_layout)))
        if not isinstance(clean[end]['include_girts'], bool):
            raise ValueError('Include endwall girts must be boolean')
        if p.bay_layout.get('enabled') and end != 'outer_front_end':
            p.bay_layout[end] = dict(
                type=typ, column_section=resolved_col, rafter_section=resolved_raf, post_spacing='', roof_mode=roof_mode
            )
    p.endwalls = clean


def finish(job, p):
    if p.section_defaults:
        owner = job.assemblies[p.column_mark]
        owner.derivation['section_default_rules'] = rules()
        owner.derivation['secondary_warnings'].append(
            'INTERIOR sections use the USER exact-width preset table / overrides; no load or capacity check performed.'
        )
    if not p.endwalls:
        return
    l = job.settings['frame_layouts'][p.column_mark]
    owner = job.assemblies[p.column_mark]
    W = f(p.width)
    m = float(p.slope_rise) / 12
    co = 1 / math.sqrt(1 + m * m)
    roof0 = l['roof_left_in']
    inset = l.get('inset_in', 0)
    models = {}
    for end in ('front_end', 'rear_end') + (
        ('outer_front_end',)
        if getattr(p, 'bay_zones', {}).get('enabled') and p.bay_zones.get('enclosed_start_line', 0)
        else ()
    ):
        cfg = p.endwalls.get(end)
        if not cfg:
            continue  # a main rigid frame of the lot stands on this end line
        raf = rafter_profile(cfg['resolved_rafter'])
        outer = wprofile(cfg['resolved_column'])
        inner = cfg['post']
        N = cfg['bays']
        outer = dict(outer, along_wall_in=along_wall(outer, True))
        left = inset + outer['along_wall_in'] / 2
        right = W - left
        if right <= left:
            raise ValueError('Endwall corner columns consume the wall width')
        B = (right - left) / N
        bay_widths = cfg.get('bay_widths') or [B] * N
        positions = [left]
        for width in bay_widths:
            positions.append(positions[-1] + width)
        resolved_mode = p.purlin_mode if cfg['roof_mode'] == 'follow' else cfg['roof_mode']
        end_roof0 = (
            f(p.eave_height)
            if cfg['roof_mode'] == 'flush'
            else f(p.eave_height) - f(p.purlin_depth)
            if cfg['roof_mode'] == 'bypass'
            else roof0
        )
        roof = lambda x: end_roof0 + m * (x if p.frame_type == 'monoslope' else min(x, W - x))
        tag = 'EW-' + p.column_mark + ('-O' if end == 'outer_front_end' else '-F' if end == 'front_end' else '-R')
        head_overrides = cfg.get('post_head_overrides', {})
        left_corner_mark = tag + '-P01'
        right_corner_mark = tag + '-P' + str(len(positions)).zfill(2)
        corner_modes = {
            'left': head_overrides.get(left_corner_mark, cfg.get('post_head', 'legacy')),
            'right': head_overrides.get(right_corner_mark, cfg.get('post_head', 'legacy')),
        }
        valid_corner_marks = {left_corner_mark, right_corner_mark}
        stale_overrides = set(head_overrides) - valid_corner_marks
        if stale_overrides:
            raise ValueError(
                'Endwall connection overrides do not match current corner-column marks: '
                + ', '.join(sorted(stale_overrides))
            )
        side_welded_left = corner_modes['left'] == 'side_welded'
        side_welded_right = corner_modes['right'] == 'side_welded'
        side_welded = side_welded_left or side_welded_right
        rafter_start = inset + (outer['along_wall_in'] if side_welded_left else 0)
        rafter_end = W - inset - (outer['along_wall_in'] if side_welded_right else 0)
        rafter_spans = (
            [(rafter_start, W / 2), (W / 2, rafter_end)] if p.frame_type == 'gable' else [(rafter_start, rafter_end)]
        )
        members = []
        posts = []
        rafter_cut_planes = []
        warnings = []
        if cfg.get('channel_fit_retired'):
            warnings.append(
                'SECTION CHANGE: prior channel-fit approval is NOT applied to this W rafter. Roof mode and actual section control the fit.'
            )
        if cfg.get('channel_ridge_retired'):
            warnings.append(
                'CONNECTION REVIEW: channel-only 3/16 x5 x7 peak face clips removed from this end; W end-ridge connection is NOT detailed or released. Main-frame ridge is unchanged.'
            )

        def member(mark, role, prof, a, b, low, blank, status):
            row = dict(
                end=end,
                mark=mark,
                role=role,
                profile_id=prof['id'],
                family=prof['family'],
                finish=prof.get('finish', ''),
                wall_label=prof.get('wall', ''),
                actual_wall=prof.get('actual_wall', ''),
                quantity=1,
                x0_in=a[0],
                y0_in=a[1],
                x1_in=b[0],
                y1_in=b[1],
                reference_cut_in=low,
                reference_cut=D(Fraction(round(low * 16), 16)).fmt() if low is not None else '',
                blank_length_in=blank,
                # nearest 1/16 like the main welded frame (the interior and corner columns of one
                # roof line must carry the same blank)
                blank_length=D(Fraction(round(blank * 16), 16)).fmt() if blank is not None else '',
                weight_lb_ft=prof['weight_lb_ft'],
                estimated_weight_lb=round(blank / 12 * prof['weight_lb_ft'], 2)
                if blank is not None and prof['weight_lb_ft'] is not None
                else None,
                status=status,
                cut_basis='',
            )
            members.append(row)
            return row

        def head_contact_geometry(points, role):
            interfaces = []
            uncovered = []
            for p0, p1 in zip(points, points[1:]):
                x0, y0 = p0
                x1, y1 = p1
                if abs(x1 - x0) < 1e-8:
                    continue
                xm = (x0 + x1) / 2
                support_index = next(
                    (j for j, (x_start, x_end) in enumerate(rafter_spans) if x_start - 1e-8 <= xm <= x_end + 1e-8),
                    None,
                )
                if support_index is None:
                    uncovered.append([list(p0), list(p1)])
                    continue
                support_points = [
                    [x0, roof(x0) - raf['depth'] / co],
                    [x1, roof(x1) - raf['depth'] / co],
                ]
                normal_offset = max(abs(y0 - support_points[0][1]), abs(y1 - support_points[1][1])) * co
                interfaces.append(
                    dict(
                        rafter_mark=tag + '-RF' + str(support_index + 1),
                        role=role,
                        contact_face='RAFTER UNDERSIDE',
                        post_head_cut_points_in=[list(p0), list(p1)],
                        rafter_underside_points_in=support_points,
                        maximum_plane_offset_in=normal_offset,
                        nominal_plane_gap_in=0.0 if normal_offset <= 1e-7 else '',
                        geometry_status='COINCIDENT MEMBER CONTACT PLANES'
                        if normal_offset <= 1e-7
                        else 'PLANE OFFSET EXCEEDS GEOMETRY TOLERANCE',
                    )
                )
            resolved = (
                bool(interfaces)
                and not uncovered
                and all(x['geometry_status'] == 'COINCIDENT MEMBER CONTACT PLANES' for x in interfaces)
            )
            return dict(
                geometry_basis='OWNER-CONFIRMED ADDED-POST / BEARING-JAMB PITCH-CUT DIRECT-WELD HEAD',
                connection='PITCH-CUT DIRECT CONTACT TO RAFTER UNDERSIDE; ZERO GAP',
                interfaces=interfaces,
                uncovered_plane_segments_in=uncovered,
                geometry_status='CONTACT PLANES RESOLVED' if resolved else 'PARTIAL / SUPPORT SPAN HOLD',
                fit_status='Post head is pitch-cut to the supporting rafter underside; contact planes coincide at a 0 in gap.',
            )

        from .endwall_supports import endpoint_records, girt_between, plans

        post_plans = plans(p, end, cfg, positions, outer, inner, tag)
        if cfg.get('channel_by_span'):
            warnings.append(
                'CHANNEL END RAFTER: '
                + raf['id']
                + ' matches the '
                + D(Fraction(str(f(p.purlin_depth)))).fmt()
                + ' purlins; purlins sit inside the open face 1/4 in from the web, welded to the flanges top and bottom (flush, no rake angle).'
            )
        if cfg.get('posts_omitted'):
            warnings.append(
                ('OPEN END WALL: ' if cfg.get('enclosure') == 'open' else 'END WALL WITHOUT INTERIOR POSTS: ')
                + 'no interior posts - end rafter '
                + raf['id']
                + ' spans corner column to corner column'
                + (' (rigid end frame of the main sections)' if cfg.get('rigid_end') else '')
                + ('; no girts, base angle or wall sheets on this end.' if cfg.get('enclosure') == 'open' else '.')
            )
        elif cfg.get('enclosure') == 'open':
            warnings.append(
                'OPEN END WALL: posts kept by choice (interior end posts = always) and end rafter; no girts, base angle or wall sheets on this end.'
            )
        for plan in post_plans:
            x = plan['x']
            prof = plan['profile']
            width = prof.get('along_wall_in', prof['width'])
            from .grades import offset as grade_offset
            from .grades import post_key

            grade = grade_offset(p, post_key(plan['mark']))  # top of slab / ground at this post
            y0 = (
                FND.column_bottom_in(
                    p, 0 if cfg.get('base_connection') == 'floor_weld' else f(D(cfg['base_thickness']))
                )
                + grade
            )
            head_clearance = f(D(cfg['top_clearance'])) if plan['role'] == 'outer column' else 0
            yl = min(roof(x - width / 2), roof(x + width / 2)) - raf['depth'] - head_clearance
            yh = (
                roof(x) - raf['depth'] - head_clearance
                if p.frame_type == 'gable' and abs(x - W / 2) < 1e-7
                else max(roof(x - width / 2), roof(x + width / 2)) - raf['depth'] - head_clearance
            )
            if yl <= y0:
                raise ValueError('Endwall deductions leave nonpositive post length')
            head_mode = (
                (corner_modes['left'] if plan['mark'] == left_corner_mark else corner_modes['right'])
                if plan['role'] == 'outer column'
                else 'direct_welded'
            )
            head_source = (
                ('LOCATION OVERRIDE' if plan['mark'] in head_overrides else 'ENDWALL DEFAULT')
                if plan['role'] == 'outer column'
                else 'ADDED POST / JAMB DIRECT-PITCH DEFAULT'
            )
            side_corner = head_mode == 'side_welded' and plan['role'] == 'outer column'
            # Added/interior/bearing-jamb posts retain their established pitch-cut direct contact.
            # Only corner columns use the location-specific seat/inside-face/direct-weld selector.
            direct = head_mode == 'direct_welded'
            if side_corner:
                # column to the roof line (top of the flush rafter); the rafter is welded to its
                # inside face, so no rafter depth or top clearance comes off the column
                yl = min(roof(x - width / 2), roof(x + width / 2))
                yh = max(roof(x - width / 2), roof(x + width / 2))
            if direct and not plan.get('opening_id'):
                correction = raf['depth'] / co - raf['depth']
                yl -= correction
                yh -= correction
            role = plan['role']
            if plan.get('opening_id'):
                # Roof-bearing member reaches actual plumb underside envelope. Thickness,
                # post-head weld and seat adapter are still explicitly held.
                correction = raf['depth'] / co - raf['depth']
                yl -= correction
                yh -= correction
                o = next(o for o in p.cladding['openings'] if o['id'] == plan['opening_id'])
                from .opening_rules import section_for

                hh = section_for(p, p.additions['opening_members'][o['id']], 'header', 'endwall_girt')['width']
                if yl < o['y_in'] + o['height_in'] + hh:
                    raise ValueError(o['id'] + ': header envelope exceeds bearing-jamb roof clearance')
            r = member(
                plan['mark'],
                role,
                prof,
                [x, y0],
                [x, yl],
                yl - y0,
                yh - y0,
                'BOTTOM CUT TO BASE CONTACT DATUM; ZERO GAP',
            )
            if direct or side_corner:
                drop = 0 if side_corner else raf['depth'] / co + head_clearance
                pts = [
                    (x - width / 2, roof(x - width / 2) - drop),
                    (x + width / 2, roof(x + width / 2) - drop),
                ]
                if p.frame_type == 'gable' and x - width / 2 < W / 2 < x + width / 2:
                    pts.insert(1, (W / 2, roof(W / 2) - drop))
                yl = min(y for _, y in pts)
                yh = max(y for _, y in pts)
                r.update(
                    y1_in=yl,
                    reference_cut_in=yl - y0,
                    reference_cut=D(Fraction(round((yl - y0) * 16), 16)).fmt(),
                    blank_length_in=yh - y0,
                    blank_length=D(Fraction(round((yh - y0) * 16), 16)).fmt(),
                    estimated_weight_lb=round((yh - y0) / 12 * prof['weight_lb_ft'], 2)
                    if prof['weight_lb_ft'] is not None
                    else None,
                )
                angles = [math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) for a, b in zip(pts, pts[1:])]
                r.update(
                    top_cut_points=pts,
                    top_cut_angles_deg=angles,
                    top_cut_angle_deg=angles[0],
                    head_connection='COLUMN TO ROOF LINE / RAFTER INSIDE FACE CONTACT'
                    if side_corner
                    else 'PITCH CUT / DIRECT CONTACT TO RAFTER UNDERSIDE / ZERO GAP / NO CAP'
                    if plan['role'] == 'outer column' and head_mode == 'direct_welded'
                    else 'PITCH CUT / DIRECT CONTACT TO RAFTER UNDERSIDE / ZERO GAP / NO CAP (OPEN-FACE CHANNEL)'
                    if prof['family'] == 'Channel'
                    else 'PITCH CUT / DIRECT CONTACT TO RAFTER UNDERSIDE / ZERO GAP / CAP DETAIL UNSPECIFIED',
                    status='TOP CUT TO ROOF-LINE CONTACT DATUM; ZERO GAP'
                    if side_corner
                    else 'PITCH-CUT HEAD / DIRECT RAFTER CONTACT; ZERO GAP; BASE DATUM EXPLICIT',
                )
                if role != 'outer column':
                    r['head_contact_geometry'] = head_contact_geometry(pts, role)
            r['ridge_post'] = p.frame_type == 'gable' and abs(x - W / 2) < 1e-7
            extra = {k: plan[k] for k in ('opening_id', 'opening_side', 'roles') if k in plan}
            r.update(extra)
            r['head_connection_mode'] = head_mode
            r['head_connection_source'] = head_source
            r['head_geometry_status'] = (
                (
                    'RAFTER INSIDE-FACE / ROOF-LINE CONTACT; ZERO GAP'
                    if head_mode == 'side_welded'
                    else 'DIRECT PITCH-CUT CONTACT TO RAFTER UNDERSIDE; ZERO GAP'
                    if head_mode == 'direct_welded'
                    else 'LEGACY COLUMN-SEAT SELECTED; CORNER HEAD FIT REMAINS REFERENCE-ONLY'
                )
                if plan['role'] == 'outer column'
                else (r.get('head_contact_geometry') or {}).get(
                    'geometry_status', 'DIRECT PITCH-CUT CONTACT / ZERO GAP'
                )
            )
            r['grade_in'] = grade
            r['bottom_in'] = y0
            if FND.is_post_footing(p):
                r['base_contact_geometry'] = dict(
                    support='POST FOOTING EMBEDMENT DATUM',
                    column_bottom_y_in=y0,
                    base_surface_y_in=None,
                    physical_gap_in=None,
                    geometry_status='POST EMBEDDED; NO BASE PLATE INTERFACE',
                )
            else:
                floor_weld = cfg.get('base_connection') == 'floor_weld'
                r['base_contact_geometry'] = dict(
                    support='EMBEDDED FLOOR PLATE BY OTHERS' if floor_weld else 'SELECTED BASE PLATE TOP',
                    column_bottom_y_in=y0,
                    base_surface_y_in=y0,
                    physical_gap_in=0.0,
                    plate_by_others=floor_weld,
                    geometry_status='DIRECT CONTACT / ZERO GAP',
                )
            posts.append(
                dict(
                    **extra,
                    mark=r['mark'],
                    x=x,
                    width=width,
                    bottom=y0,
                    grade_in=grade,
                    top_low=yl,
                    top_high=yh,
                    profile=copy.deepcopy(prof),
                    role=role,
                    rotation_deg=0 if 'along_wall_in' in prof else 90 if prof['family'] == 'W' else 0,
                    wall_normal_depth_in=prof['width'] if 'along_wall_in' in prof else prof['depth'],
                    orientation='CORNER: WEB ACROSS THE BUILDING like the frame columns; outside flange in the sidewall plane'
                    if 'along_wall_in' in prof
                    else 'WEB NORMAL TO ENDWALL / perpendicular to rafter'
                    if prof['family'] == 'W'
                    else 'SECTION FACE TO WALL',
                )
            )
        positions = [post['x'] for post in posts]
        bay_widths = [b - a for a, b in zip(positions, positions[1:])]
        if max(bay_widths) > f(D(cfg['max_span'])) + 1e-8:
            warnings.append('POST BAY EXCEEDS entered planning maximum after actual station layout; no capacity check.')
        side_welded = side_welded_left or side_welded_right
        # Side-welded heads shift only their own eave span to that corner-column inside face; the same spans
        # identify the rafter piece supporting each added post-head contact plane.
        spans = rafter_spans
        for i, (a, b) in enumerate(spans):
            length = (b - a) / co
            row = member(
                tag + '-RF' + str(i + 1),
                'endwall rafter',
                raf,
                [a, roof(a)],
                [b, roof(b)],
                length,
                length + raf['depth'] * m,
                (
                    'SIDE WELDED: plumb cut against the corner column inside face; plumb butt at the ridge'
                    if p.frame_type == 'gable'
                    else 'SIDE WELDED: plumb cuts against the low and high corner column inside faces'
                )
                if side_welded
                else 'TOP-LINE REFERENCE / LONG BLANK — EAVE/RIDGE CONNECTION DEDUCTIONS PENDING',
            )
            if side_welded:
                row.update(
                    end_cut_angle_deg=math.degrees(math.atan(m)),
                    cut_planes='PLUMB both ends: corner column inside face / ridge butt'
                    if p.frame_type == 'gable'
                    else 'PLUMB both ends: low and high corner column inside faces',
                    eave_connection='PER-LOCATION CORNER HEAD CONNECTIONS; see the start/end cut-plane schedule',
                )
            if cfg.get('ridge_joint') == 'face_clip':
                row.update(
                    end_cut_angle_deg=math.degrees(math.atan(m)),
                    cut_planes='PLUMB / peak BUTT: no interposed plate or half-plate deduction',
                    status='OWNER PEAK FACE CLIP: PLUMB ENDS / ZERO PEAK GAP / LONG STOCK BLANK',
                )

            def cut_endpoint(x):
                if p.frame_type == 'gable' and abs(x - W / 2) < 1e-7:
                    label = 'PEAK'
                    if cfg.get('ridge_joint') == 'face_clip' and raf['family'] == 'Channel':
                        return dict(
                            label=label,
                            station_x_in=x,
                            plane='PLUMB',
                            contact='ZERO-GAP PEAK BUTT / SELECTED 3/16 x 5 x 7 FACE CLIP',
                            status='GEOMETRIC CUT PLANE RESOLVED',
                        )
                    return dict(
                        label=label,
                        station_x_in=x,
                        plane='REFERENCE ONLY',
                        contact='Selected legacy peak joint; cut/deduction fit not adapted',
                        status='PEAK CONNECTION FIT HELD',
                    )
                label = (
                    ('LEFT EAVE' if x < W / 2 else 'RIGHT EAVE')
                    if p.frame_type == 'gable'
                    else 'LOW EAVE'
                    if x < W / 2
                    else 'HIGH EAVE'
                )
                corner_mode = corner_modes['left'] if x < W / 2 else corner_modes['right']
                if corner_mode == 'side_welded':
                    return dict(
                        label=label,
                        station_x_in=x,
                        plane='PLUMB',
                        contact='CORNER COLUMN INSIDE FACE / DIRECT CONTACT / ZERO GAP',
                        status='GEOMETRIC CUT PLANE RESOLVED',
                    )
                if corner_mode == 'direct_welded':
                    return dict(
                        label=label,
                        station_x_in=x,
                        plane='PLUMB',
                        contact='DIRECT CONTACT TO THE PITCH-CUT CORNER COLUMN / ZERO GAP',
                        status='GEOMETRIC CUT PLANE RESOLVED',
                    )
                return dict(
                    label=label,
                    station_x_in=x,
                    plane='REFERENCE ONLY',
                    contact='Corner column seat/legacy detail selected; eave cut/seat fit not adapted',
                    status='EAVE CONNECTION FIT HELD',
                )

            start_detail = cut_endpoint(a)
            end_detail = cut_endpoint(b)
            both_planes = all(x['status'] == 'GEOMETRIC CUT PLANE RESOLVED' for x in (start_detail, end_detail))
            resolved_labels = [
                x['label'] for x in (start_detail, end_detail) if x['status'] == 'GEOMETRIC CUT PLANE RESOLVED'
            ]
            if both_planes and p.frame_type == 'gable':
                row['cut_basis'] = 'PLUMB / EAVE AND PEAK CUT PLANES SET'
            elif both_planes:
                row['cut_basis'] = 'PLUMB / BOTH CORNER FACE CUT PLANES SET'
            elif resolved_labels == ['PEAK']:
                row['cut_basis'] = 'PEAK PLUMB / EAVE FIT HELD'
            elif resolved_labels:
                row['cut_basis'] = 'EAVE PLUMB / PEAK FIT HELD'
            else:
                row['cut_basis'] = 'TOP-LINE REFERENCE / END FIT HELD'
            row['cut_planes'] = '; '.join(
                x['label'] + ': ' + x['plane'] + ' / ' + x['status'] for x in (start_detail, end_detail)
            )
            row['cut_geometry_status'] = 'BOTH CUT PLANES RESOLVED' if both_planes else 'PARTIAL / REFERENCE ONLY'
            row['status'] = (
                'ENDWALL RAFTER: BOTH PLUMB MEMBER CONTACT PLANES RESOLVED / ZERO GAP'
                if both_planes
                else 'ENDWALL RAFTER: ' + row['cut_basis'] + '; selected connection plane remains unresolved'
            )
            rafter_cut_planes.append(
                dict(
                    mark=row['mark'],
                    profile_id=row['profile_id'],
                    start=start_detail,
                    end=end_detail,
                    top_line_span_in=length,
                    long_blank_reference_in=length + raf['depth'] * m,
                    section_depth_in=raf['depth'],
                    plumb_depth_in=raf['depth'] / co,
                    cut_angle_from_square_deg=abs(math.degrees(math.atan(m))),
                    geometry_status='BOTH CUT PLANES RESOLVED' if both_planes else 'PARTIAL GEOMETRY / REFERENCE BLANK',
                    fit_status='Rafter ends are cut to the selected contact planes; coincident end planes have zero gap.',
                )
            )
        sheeted_end = cfg.get('enclosure', 'sheeted') != 'open'
        if cfg['include_girts'] or (p.slab and p.starting_wall_run and end != 'outer_front_end' and sheeted_end):
            spec = _endwall_girt_spec(p)
            prof = None
            if cfg['include_girts']:
                if not spec:
                    raise ValueError('Endwall girt layout requires a selected supplier girt profile')
                g = get(spec['profile_id'])
                prof = dict(family=g['family'], id=g['id'], finish=spec['finish'], weight_lb_ft=g['weight_lb_ft'])
            side_lines = [f(x) for x in p.girt_elevations] if cfg['include_girts'] else []
            extra_lines = []
            if cfg['include_girts'] and p.frame_type == 'gable' and side_lines:
                # Shop rule: when the peak is more than 7 ft above the top sidewall girt the end
                # wall gets extra girt lines continuing the sidewall spacing (gable triangle).
                from .standards import gable_extra_girt_lines

                peak = roof(W / 2) - raf['depth']
                extra_lines = [float(x) for x in gable_extra_girt_lines(side_lines, max(side_lines), peak)]
            elevs = sorted(set(side_lines + extra_lines + ([f(p.starting_run)] if p.starting_wall_run else [])))
            if extra_lines:
                warnings.append(
                    'GABLE GIRTS: extra end-wall girt line(s) at '
                    + ', '.join(D(Fraction(round(x * 16), 16)).fmt() for x in extra_lines)
                    + ' (peak more than 7 ft above the top sidewall girt).'
                )
            for k, y in enumerate(elevs):
                for i, (a, b) in enumerate(zip(posts, posts[1:])):
                    if y > min(a['top_low'], b['top_low']) or not girt_between(p, a, b, y):
                        continue
                    isbase = p.slab and p.starting_wall_run and abs(y - f(p.starting_run)) < 1e-8
                    yb = y
                    if isbase:
                        # Column grades (v0.8.43): the base angle of a bay follows the slab of that bay - the
                        # grade shared by its two posts, or the higher / lower one of a mixed bay (grades.MIXED_BAY).
                        pick = min if (getattr(p, 'grades', None) or {}).get('mixed_bay') == 'lower' else max
                        yb = y + pick(float(a.get('grade_in') or 0.0), float(b.get('grade_in') or 0.0))
                    bay_span = b['x'] - a['x']
                    gp = prof
                    L = bay_span - 0.5
                    status = 'PROJECT SIMPLE BUTT FIT — CLIP / ANCHOR / END FIT PENDING'
                    endwall_contacts = None
                    if isbase:
                        g = get(p.base_angle['profile_id'])
                        gp = dict(
                            family='Angle',
                            id=g['id'],
                            finish=p.base_angle['finish'],
                            weight_lb_ft=(
                                g['stock_weight_lb'][p.base_angle['finish']] / 20
                                if g['stock_weight_lb'].get(p.base_angle['finish']) is not None
                                else None
                            ),
                        )
                        if L > 240:
                            # 20 ft stock angle anchored to the slab: lay full sticks plus the remainder,
                            # butted (end wall without interior posts / bay over 20 ft) - no fit consequence
                            n = math.ceil(L / 240 - 1e-9)
                            x = a['x'] + 0.25
                            for j in range(n):
                                Lj = 240.0 if j < n - 1 else L - 240.0 * (n - 1)
                                run = member(
                                    tag + '-BA' + str(k + 1) + '-' + str(i + 1) + '-S' + str(j + 1),
                                    'base angle',
                                    gp,
                                    [x, yb],
                                    [x + Lj, yb],
                                    Lj,
                                    Lj,
                                    'BASE ANGLE: 20 FT STOCK, STICK '
                                    + str(j + 1)
                                    + ' OF '
                                    + str(n)
                                    + ' BETWEEN THE CORNER COLUMNS (butted on the slab)',
                                )
                                endpoint_records(run, a, b, p)
                                x += Lj
                            continue
                    elif p.girt_mode == 'flush':
                        # Geometric end-wall fit: butted members meet the selected support datum
                        # with zero gap. The sole exception is a girt entering an open-face channel,
                        # where its end is set 1/4 in from the channel web.
                        from .standards import CHANNEL_PURLIN_SETBACK_IN

                        def _contact(post, which):
                            """(deduction from the post station, note, butt?) for the girt end at a post.

                            Corner column: inside flange (W) / inside face (tube).  Tube post: flat face.
                            W post: web.  Cold-formed channel / Cee post (owner convention): the web sits
                            ON the station with the body toward the far end - the girt on the flat side
                            (end of the bay before the post) butts the web at the station (the gauge is
                            not figured: "there is leeway here") and the girt on the open side (start of
                            the bay after the post) sits inside the open face 1/4 in from the web exactly
                            like a purlin in a channel rafter; a lipped Cee cannot take the girt inside,
                            so that girt butts the lips at the full depth."""
                            pr = post['profile']
                            if 'along_wall_in' in pr:
                                face = (
                                    'inside face of corner tube ' if pr.get('family') == 'HSS' else 'inside flange of '
                                )
                                return pr['along_wall_in'] / 2, face + post['mark'], True
                            if pr.get('family') == 'HSS':
                                return pr['width'] / 2, 'face of tube ' + post['mark'], True
                            if pr.get('family') in ('Channel', 'C'):
                                if which == 'end':
                                    return 0, 'flat (web) side of ' + post['mark'], True
                                if pr['family'] == 'Channel' or pr.get('open_face'):
                                    return (
                                        CHANNEL_PURLIN_SETBACK_IN,
                                        'open face of ' + post['mark'] + ' (1/4 in from the web)',
                                        False,
                                    )
                                return pr['depth'], 'lips of Cee ' + post['mark'], True
                            if pr['web'] is not None:
                                return pr['web'] / 2, 'web of ' + post['mark'], True
                            return None, '', True

                        ca, na, ba = _contact(a, 'start')
                        cb, nb, bb = _contact(b, 'end')
                        if ca is None or cb is None:
                            L = None
                            status = 'FLUSH FIT PENDING: ATTACHMENT FACE NOT CONFIRMED'
                        else:
                            # All butt contacts are direct: no general end allowance is added.
                            # The open-face-channel setback is already included in ca or cb and is
                            # the only nonzero gap for this endwall girt.
                            L = math.floor((bay_span - ca - cb) * 16) / 16
                            open_face_ends = [n for n in (na, nb) if 'open face of ' in n]
                            status = (
                                'FLUSH END-WALL GIRT: direct-contact setout to '
                                + na
                                + ' and '
                                + nb
                                + (
                                    '; 1/4 in gap inside open-face channel only'
                                    if open_face_ends
                                    else '; zero gap at both supports'
                                )
                            )
                            endwall_contacts = [
                                dict(
                                    endpoint_side='left',
                                    support_mark=a['mark'],
                                    support_face=na,
                                    member_end_x_in=a['x'] + ca,
                                    physical_gap_in=0.25 if 'open face of ' in na else 0.0,
                                    geometry_status='1/4 IN GAP INSIDE OPEN-FACE CHANNEL'
                                    if 'open face of ' in na
                                    else 'DIRECT CONTACT / ZERO GAP',
                                ),
                                dict(
                                    endpoint_side='right',
                                    support_mark=b['mark'],
                                    support_face=nb,
                                    member_end_x_in=b['x'] - cb,
                                    physical_gap_in=0.25 if 'open face of ' in nb else 0.0,
                                    geometry_status='1/4 IN GAP INSIDE OPEN-FACE CHANNEL'
                                    if 'open face of ' in nb
                                    else 'DIRECT CONTACT / ZERO GAP',
                                ),
                            ]
                    if L is not None and L <= 0:
                        raise ValueError('Endwall girt deductions consume bay')
                    run = member(
                        tag + '-' + ('BA' if isbase else 'G') + str(k + 1) + '-' + str(i + 1),
                        'base angle' if isbase else 'endwall girt',
                        gp,
                        [a['x'], yb],
                        [b['x'], yb],
                        L,
                        L,
                        status,
                    )
                    if endwall_contacts and run['role'] == 'endwall girt':
                        run['end_contact_geometry'] = endwall_contacts
                    endpoint_records(run, a, b, p)
        depth_fit = dict(
            mode=resolved_mode,
            required_purlin_depth_in=f(p.purlin_depth),
            total_depth_clearance_in=f(D(cfg['roof_depth_clearance'])),
            rafter_outside_depth_in=raf['depth'],
            actual_inside_depth_in=None if raf['flange'] is None else raf['depth'] - 2 * raf['flange'],
        )
        inside = depth_fit['actual_inside_depth_in']
        if resolved_mode == 'flush' and raf['family'] == 'Channel':
            # Shop rule (v0.8.31): the open-face channel matches the purlin depth; the purlin sits
            # inside the open face 1/4 in from the web and is welded to the flanges top and bottom.
            # The catalog pairing (6 3/16 channel / 6 in purlin ...) IS the fit - no clearance hold.
            fits = inside is not None and f(p.purlin_depth) <= inside + 1e-8
            depth_fit['fit_basis'] = 'Purlin inside the open-face channel; channel depth class = purlin depth'
            depth_fit['purlin_setback_in'] = 0.25
            if fits:
                depth_fit['status'] = 'IN CHANNEL: purlin inside the open face, welded to the flanges'
            else:
                projection = f(p.purlin_depth) - raf['depth']
                depth_fit['status'] = 'TOP FLUSH / PURLIN PROJECTS BELOW CHANNEL'
                depth_fit['purlin_projection_below_channel_in'] = max(0.0, projection)
                warnings.append(
                    'CHANNEL DEPTH MISMATCH: '
                    + f'{f(p.purlin_depth):g}'
                    + ' in purlins do not fit inside the '
                    + raf['id']
                    + ' open face (inside depth '
                    + (f'{inside:g}' if inside is not None else 'unknown')
                    + ' in); the shop rule pairs the channel with the purlin depth - choose the matching channel. Purlins would project '
                    + f'{max(0.0, projection):g}'
                    + ' in below the channel.'
                )
        elif resolved_mode == 'flush':
            confirmed = cfg.get('purlin_channel_fit_confirmed', False) and f(p.purlin_depth) <= raf['depth'] + 1e-8
            available = None if confirmed else inside
            depth_fit['owner_confirmed_fit'] = confirmed
            depth_fit['fit_basis'] = (
                'Owner confirms purlin fits; no added depth clearance; end-fit rules retained'
                if confirmed
                else 'Geometric depth envelope'
            )
            maximum = raf['depth'] if available is None else available
            required = f(p.purlin_depth) + depth_fit['total_depth_clearance_in']
            depth_fit['status'] = (
                'FAIL'
                if required > maximum + 1e-8
                else 'UNVERIFIED THICKNESS / LIPS / RADII'
                if available is None
                else 'DEPTH ENVELOPE ONLY; LIPS / RADII / WELD ACCESS UNVERIFIED'
            )
            if confirmed and required <= maximum + 1e-8:
                depth_fit['status'] = 'OWNER CONFIRMED FIT / NO ADDED DEPTH CLEARANCE'
            if required > maximum + 1e-8:
                warnings.append(
                    f'END ROOF FIT FAIL: purlin depth plus TOTAL clearance requires {required:g}in; rafter '
                    + ('OUTSIDE depth is only ' if available is None else 'inside depth is only ')
                    + f'{maximum:g}in. No section resized/substituted.'
                )
        else:
            depth_fit['status'] = 'BYPASS; NO INSIDE-DEPTH FIT CLAIM'
        if raf['family'] == 'Channel':
            warnings.append(
                'Open-face channel end rafter: purlins inside the open face 1/4 in from the web, welded to the '
                'flanges top and bottom. End rafter references are NOT final knee/ridge cut deductions; end welds remain separate.'
            )
        warnings.extend(
            [
                'USER SECTION PRESETS ONLY — no loads, capacity, foundation or substitution approval.',
                'End members counted ONCE for this endwall, independent of primary interior-frame lot quantity.',
                'Added endwall posts and bearing jambs: pitch-cut to the supporting rafter underside with coincident contact planes and zero gap. Corner/main columns retain their selected connection; each post bottom is set directly on its base contact datum.',
                'Endwall girts use the selected endwall girt product (or follow the sidewall girt) at existing shared wall elevations and simple butt-fit / flush planning, not sidewall lap patterns. Roof-triangle framing and openings need separate detailing.',
            ]
        )
        if cfg.get('supplier_fit_retired'):
            warnings.append(
                'SUPPLIER CHANGED: prior channel fit confirmation retired. Recheck actual purlin/channel compatibility before confirming the new supplier product.'
            )
        if inner['family'] == 'HSS' or outer['family'] == 'HSS':
            warnings.append(
                'Requested tube sizes/wall labels are not a verified product catalog. Gauge thickness not inferred; weight unavailable; no HSS NC emitted.'
            )
        if inner['family'] == 'C':
            warnings.append(
                'Cee nominal depth matches girt; lips/radii/thickness and open-face orientation/connection fit need review. No Cee NC emitted.'
            )
        if cfg.get('ridge_joint') == 'face_clip':
            warnings = [
                w.replace(
                    'End rafter references are NOT final knee/ridge cut deductions; end welds remain separate.',
                    'End rafters use plumb eave planes, zero-gap peak butt and specified web-face clip; weld procedure/capacity remain separate.',
                )
                for w in warnings
            ]
        groups = {}
        for row in members:
            key = (
                row['role'],
                row['profile_id'],
                row['finish'],
                round(row['reference_cut_in'], 6) if row['reference_cut_in'] is not None else None,
                round(row['blank_length_in'], 6) if row['blank_length_in'] is not None else None,
                row['status'],
                row.get('cut_basis', ''),
            )
            if key not in groups:
                groups[key] = {
                    k: row[k]
                    for k in (
                        'role',
                        'profile_id',
                        'finish',
                        'reference_cut',
                        'reference_cut_in',
                        'blank_length',
                        'blank_length_in',
                        'status',
                        'cut_basis',
                    )
                }
                groups[key].update(cut_group=tag + '-C' + str(len(groups)).zfill(2), quantity=0)
            groups[key]['quantity'] += 1
            row['cut_group'] = groups[key]['cut_group']
        ridge_clip = None
        if cfg.get('ridge_joint') == 'face_clip':
            if p.frame_type != 'gable' or raf['family'] != 'Channel':
                raise ValueError('Peak face clip adapter requires gable channel rafters')
            cx = W / 2
            cy = roof(cx) - raf['depth'] / co / 2
            h = 5.0
            w = 7.0
            corners = [
                (cx - w / 2, cy - h / 2),
                (cx + w / 2, cy - h / 2),
                (cx + w / 2, cy + h / 2),
                (cx - w / 2, cy + h / 2),
            ]
            if any(y > roof(x) + 1e-8 or y < roof(x) - raf['depth'] / co - 1e-8 for x, y in corners):
                raise ValueError('5x7 ridge face clip does not fit inside selected channel web envelope at this pitch')
            ridge_clip = dict(
                mark=tag + '-PKC',
                quantity=1,
                thickness_in=0.1875,
                height_in=h,
                width_in=w,
                center_x_in=cx,
                center_y_in=cy,
                outline=corners,
                weight_lb=0.1875 * h * w * 0.2836,
                mount='FLAT TO WEB FACE / centered horizontally at peak and vertically in plumb web depth',
                joint='Rafters BUTT at ridge center; no interposed plate',
                weld_size=p.weld_size,
                status='OWNER3/16 x5 TALL x7 WIDE; no holes; weld procedure/capacity not inferred',
            )
        if ridge_clip:
            from .model import Part

            existing = job.parts.get(ridge_clip['mark'])
            if existing and existing.symbol.get('welded_frame_id') != p.column_mark:
                raise ValueError('Peak face clip mark already belongs to an unrelated part')
            job.parts[ridge_clip['mark']] = Part(
                ridge_clip['mark'],
                'clip',
                D('3/16'),
                D(5),
                D(7),
                holes=[],
                source='Owner end-channel peak face clip',
                notes='5in TALL x7in WIDE; FLAT TO WEB FACE; no holes; not interposed between rafter ends. Weld procedure/capacity review separate.',
                symbol=dict(endwall_peak_face_clip=True, outline_rect=True, welded_frame_id=p.column_mark),
            )
        models[end] = dict(
            ridge_face_clip=ridge_clip,
            roof_mode=resolved_mode,
            roof_depth_fit=depth_fit,
            cuts=list(groups.values()),
            config=copy.deepcopy(cfg),
            width_in=W,
            roof_left_in=end_roof0,
            pitch_rise=str(p.slope_rise),
            centerline_bay_in=B,
            bay_widths_in=bay_widths,
            post_positions_in=positions,
            mandatory_ridge_post=False,
            enclosure=cfg.get('enclosure', 'sheeted'),
            post_lines=len(posts),
            posts=posts,
            members=members,
            rafter_cut_planes=rafter_cut_planes,
            warnings=warnings,
            quantity_scope='ONE ENDWALL; SEPARATE FROM INTERIOR PRIMARY AND LONGITUDINAL SECONDARIES',
            preset_source=rules(),
        )
    owner.derivation['endwalls'] = models
    l['endwalls'] = models
    owner.derivation['secondary_warnings'].append(
        'ENDWALL SETOUT / SEPARATE QUANTITIES GENERATED; connection and foundation designs pending. See ENDWALL sheets and endwall_members.csv.'
    )
    if l.get('secondary_runs'):
        old = 'End support designs/quantities are PENDING: bearing endwalls are post-supported; reduced rigid frames are not automatically sized or substituted.'
        new = 'Endwall reference setout / quantities are in SEPARATE endwall sheets/CSVs. End connections, anchors and structural checks remain PENDING.'
        for warnings in (l['secondary_runs']['warnings'], owner.derivation['secondary_warnings']):
            if old in warnings:
                warnings[warnings.index(old)] = new
        for s in l['secondary_runs']['support_lines']:
            if s['line'] in (1, len(l['secondary_runs']['support_lines'])):
                s['design_status'] = 'SEPARATE ENDWALL SETOUT / MEMBER COUNTS GENERATED — CONNECTION DESIGN PENDING'
