"""Confirmed Cee orientation and within-bay opening placement. No section design."""

import math

from .cladding import inch
from .secondary_catalog import catalog, get

DOOR_KINDS = ('door', 'overhead')  # floor-level openings without a sill (walk door / overhead door)


def _girt_spec(p, girt_role):
    spec = (p.secondary or {}).get(girt_role) or {}
    return spec if spec.get("profile_id") else (p.secondary or {}).get("girt", {}) or {}


def section_for(p, rec, role="header", girt_role="girt"):
    override = rec.get(role + "_override", "")
    girt_spec = _girt_spec(p, girt_role)
    if override:
        if role == 'jamb' and str(override).upper().startswith('HSS '):
            from .tube_sections import profile as tube_profile

            tube = tube_profile(override, girt_spec.get('finish', 'Unspecified'))
            tube.update(
                finish=girt_spec.get('finish', 'Unspecified'),
                source='Explicit HSS tube upright selection; actual wall / weld and connection fit to be confirmed',
                closed_section=True,
                open_face=False,
            )
            return tube
        r = get(override)
        if r["family"] not in ("C", "Channel"):
            raise ValueError("Opening header/jamb must be a Cee or actual unlipped channel")
        finish = girt_spec.get("finish", "Red Oxide")
        if finish not in r["finishes"]:
            raise ValueError("Opening section finish is not available")
        return dict(
            id=r["id"],
            family="C",
            depth=r["nominal_depth_in"],
            width=max(r["flanges_in"]),
            wall=str(r["gauge"]) + " ga",
            gauge=r["gauge"],
            open_face=r.get("open_face", False),
            weight_lb_ft=r.get("weight_by_finish_lb_ft", {}).get(finish, r["weight_lb_ft"]),
            finish=finish,
            web=None,
            thickness_in=None,
            lip_in=r.get("lip_in"),
            source="Explicit catalog opening selection; thickness/radius and connection fit unverified",
        )
    selected = girt_spec.get('profile_id')
    source = get(selected) if selected else None
    depth = source['nominal_depth_in'] if source else float(p.girt_depth.inches)
    if source and source.get('supplier') == 'sss':
        if source['family'] == 'C' and not rec.get('open_face'):
            return section_for(p, dict(rec, **{role + '_override': source['id']}), role, girt_role)
        # Shop default (v0.8.30): the SSS Cee at the wall-girt depth (PN8 for 8 in girts); an
        # open-face request takes the SSS channel at that depth.  Override per opening if needed.
        from .product_library import secondaries

        wanted = 'Channel' if rec.get('open_face') else 'C'
        pool = [
            r
            for r in secondaries()
            if r['family'] == wanted and abs(r['nominal_depth_in'] - depth) < (0.26 if wanted == 'Channel' else 1e-6)
        ]
        if not pool:
            raise ValueError('Choose explicit SSS Cee/channel jamb and header products at the wall-girt depth')
        pick = min(pool, key=lambda r: (abs(max(r['flanges_in']) - 2.5), r['id']))
        out = section_for(p, dict(rec, **{role + '_override': pick['id']}), role, girt_role)
        out['source'] = 'SSS shop default at the wall-girt depth (' + pick['id'] + '); override per opening'
        return out
    candidates = [
        r
        for r in catalog()['profiles']
        if r['family'] == 'C' and r['nominal_depth_in'] == depth and (not source or r['gauge'] == source['gauge'])
    ]
    if not candidates:
        raise ValueError('No matching Cee depth/gauge for the selected wall girt; select a supported wall-girt section')
    # Match NOMINAL designation, not actual unequal Zee flange dimensions.
    candidates = (
        [r for r in candidates if r['nominal_size'] == source['nominal_size']]
        if source
        else [r for r in candidates if r['flanges_in'][0] == 2.5]
    )
    if not candidates:
        raise ValueError('No exact nominal Cee match for selected wall girt; no nearest-section substitution')
    match = min(candidates, key=lambda r: abs(r['gauge'] - 14))
    unlipped = rec.get('open_face', False)
    if unlipped:
        from .channel_catalog import section

        return section(depth, match['gauge'], girt_spec.get('finish', 'Red Oxide'))
    return dict(
        id=('UNLIPPED:' if unlipped else '') + match['id'],
        family='C',
        depth=depth,
        width=match['flanges_in'][0],
        wall=str(match['gauge']) + ' ga',
        weight_lb_ft=None if unlipped else match['weight_lb_ft'],
        open_face=unlipped,
        catalog_reference=match['id'],
        gauge=match['gauge'],
        thickness_in=None,
        lip_in=0 if unlipped else match.get('lip_in'),
        bend_radius_in=None,
        source='USER UNLIPPED SECTION ENVELOPE, NOT A CATALOG PRODUCT'
        if unlipped
        else 'MBCI nominal Cee matched to wall girt; lip/radius/thickness unverified',
        section_basis='Wall-normal web depth; flange width in elevation',
    )


def apply(p):
    for o in p.cladding.get('openings', []):
        rec = p.additions['opening_members'].setdefault(o['id'], {})
        if not isinstance(rec.get('open_face', False), bool):
            raise ValueError('Open-face Cee option must be boolean')
        rec.setdefault('open_face', False)
        fresh = rec.get('framing_rule_version') not in (1, 2)
        if fresh:
            previous = {k: rec[k] for k in ('jamb', 'header', 'jamb_face', 'header_face') if k in rec}
            if previous:
                rec['superseded_member_selection'] = previous
        # Shop door standard (v0.8.30), applied to NEW openings only (saved ones keep their framing):
        #   walk door  - header = the wall girt above the head (7'-3 header girt), jambs up to it;
        #   overhead   - jambs full height to the eave strut / end rafter, header at the door height.
        rec.setdefault('header_mode', 'girt' if fresh and o['kind'] == 'door' else 'member')
        if rec['header_mode'] not in ('member', 'girt'):
            raise ValueError('Opening header mode must be member or girt')
        rec.setdefault('jamb_extent', 'full' if fresh and o['kind'] == 'overhead' else 'header')
        if rec['jamb_extent'] not in ('header', 'full'):
            raise ValueError('Opening jamb extent must be header or full')
        for role in ('jamb', 'header'):
            gr = 'endwall_girt' if o.get('surface') in ('front', 'rear') else 'girt'
            pr = section_for(p, rec, role, gr)
            rec[role] = pr['id']
            rec[role + '_face'] = pr['width']
        rec['framing_rule_version'] = 2
        rec.setdefault('opening_mode', 'ordinary')
        if rec['opening_mode'] not in ('ordinary', 'walk_slip_in'):
            raise ValueError('Opening mode must be ordinary or walk_slip_in')
        if rec['opening_mode'] == 'walk_slip_in':
            if o['kind'] not in DOOR_KINDS or o['surface'] not in ('front', 'rear'):
                raise ValueError('Walk slip-in adapter currently supports endwall doors')
            if rec.get('jamb_role') == 'roof_bearing' or rec.get('connection_template'):
                raise ValueError('Walk slip-in frame is not a bearing jamb or ordinary source-kit assembly')
            rec['header_orientation'] = 'down'
            rec['walk_inside_gap'] = '1/2'
            for key in ('walk_head_face', 'walk_jamb_face'):
                if rec.get(key) not in ('', None):
                    value = inch(rec[key])
                    if not math.isfinite(value) or not 0 < value <= 12:
                        raise ValueError('Walk frame face must be positive and at most12in')
                    rec[key] = str(value)
            if rec.get('walk_head_face') not in ('', None):
                derived = o['y_in'] + o['height_in'] + inch(rec['walk_head_face']) + 0.5
                if (
                    rec.get('walk_girt_web_underside') not in ('', None)
                    and abs(inch(rec['walk_girt_web_underside']) - derived) > 1e-8
                ):
                    raise ValueError(
                        'Walk frame head and entered web underside conflict; clear explicit underside to derive from head'
                    )
            if rec.get('walk_girt_web_underside') not in ('', None):
                if (
                    not math.isfinite(inch(rec['walk_girt_web_underside']))
                    or inch(rec['walk_girt_web_underside']) <= o['y_in'] + o['height_in'] + 0.5
                ):
                    raise ValueError(
                        'Walk girt web underside must leave positive frame head above clear opening and1/2in inside gap'
                    )
        rec.setdefault(
            'girt_insertion', '2' if p.connection_style != 'bolted' and p.welded_fit_rules.get('enabled') else '0'
        )
        insertion = inch(rec['girt_insertion'])
        if not math.isfinite(insertion) or not 0 <= insertion <= rec['jamb_face']:
            raise ValueError(
                'Girt insertion must be nonnegative and no greater than jamb elevation envelope; no intrusion into clear opening'
            )
        if insertion and (p.connection_style == 'bolted' or rec.get('connection_template')):
            raise ValueError('Inserted welded girt rule cannot be applied to bolted/source-kit opening')
        rec['girt_insertion'] = str(insertion)
        rec.setdefault('coordinate_girts', False)
        if not isinstance(rec['coordinate_girts'], bool):
            raise ValueError('Coordinate opening girts must be boolean')
        if rec['coordinate_girts'] and o['surface'] not in ('front', 'rear'):
            raise ValueError('Explicit jamb run coordination currently supports endwalls only')
        rec.setdefault('jamb_role', 'ordinary')
        if rec['jamb_role'] not in ('ordinary', 'roof_bearing'):
            raise ValueError('Jamb role must be ordinary or roof_bearing')
        rec.setdefault('header_orientation', 'up')
        if rec['header_orientation'] not in ('up', 'down'):
            raise ValueError('Header orientation must be up or down')
        if rec['jamb_role'] == 'roof_bearing':
            if o['surface'] not in ('front', 'rear') or not p.endwalls.get('enabled'):
                raise ValueError(o['id'] + ': bearing jambs require enabled endwall framing')
            if p.connection_style == 'bolted':
                raise ValueError(o['id'] + ': bearing jamb connection adapter currently supports welded review only')
            if rec.get('connection_template'):
                raise ValueError('Bearing jambs cannot use the ordinary SD85C/SD95 jamb template')
            if o['kind'] not in DOOR_KINDS or o['y_in'] != 0:
                raise ValueError('Bearing jamb mode currently requires a floor-level door')
        placement = rec.get('placement')
        if not placement:
            # Existing positioned jobs retain their positions; new GUI roll-up doors
            # explicitly ask for centering. Never recenter a saved aperture on rebuild.
            placement = 'existing'
        if placement not in ('existing', 'centered', 'offset', 'wall_centered'):
            raise ValueError('Opening placement must be centered, offset, wall_centered or existing')
        rec['placement'] = placement
        if placement == 'wall_centered':
            W = float(p.width.inches) if o['surface'] in ('front', 'rear') else float(p.length.inches)
            x = (W - o['width_in']) / 2
            o.update(x_in=x, x=str(x))
            o.pop('relocation', None)
        if rec['jamb_role'] == 'roof_bearing' and placement not in ('existing', 'wall_centered'):
            raise ValueError('Bearing jambs use entered X or whole-wall centering; no automatic bay relocation')
        if rec.get('bay') not in (None, ''):
            try:
                n = int(rec['bay'])
                if n != float(rec['bay']) or not 1 <= n <= 100:
                    raise ValueError()
            except (TypeError, ValueError, OverflowError):
                raise ValueError('Opening bay must be a positive integer')
            rec['bay'] = n
        if rec.get('bay_offset') not in (None, ''):
            if not math.isfinite(inch(rec['bay_offset'])):
                raise ValueError('Opening offset must be finite')


def locate(p, o, posts):
    """Center once by explicit selection or preserve offset; bay limits remain fixed."""
    rec = p.additions['opening_members'][o['id']]
    if rec.get('jamb_role') == 'roof_bearing' or rec['placement'] == 'wall_centered':
        return None
    w = o['width_in']
    x = o['x_in']
    mode = rec['placement']
    if len(posts) < 2:
        return None
    pairs = list(zip(posts, posts[1:]))
    chosen = rec.get('bay')
    if chosen is None or chosen == '':
        chosen = min(range(len(pairs)), key=lambda i: abs((pairs[i][0]['x'] + pairs[i][1]['x']) / 2 - (x + w / 2))) + 1
    if chosen > len(pairs):
        raise ValueError(o['id'] + ': selected bay does not exist on this elevation')
    rec['bay'] = chosen
    left, right = pairs[chosen - 1]
    mid = (left['x'] + right['x']) / 2
    center = mid - w / 2
    if mode == 'centered':
        x = center
    elif mode == 'offset':
        x = center + inch(rec.get('bay_offset') or 0)
    if mode != 'existing':
        o.update(x_in=x, x=str(x))
        o.pop('relocation', None)
    # All placements, including legacy editable X, remain in the selected bay.
    return dict(
        number=chosen,
        left_mark=left['mark'],
        right_mark=right['mark'],
        left_center_in=left['x'],
        right_center_in=right['x'],
        left_edge_in=left['x'] + left['width'] / 2,
        right_edge_in=right['x'] - right['width'] / 2,
        centered_x_in=center,
        requested_offset_in=x - center,
        mode=mode,
    )
