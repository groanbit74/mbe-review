"""Purchasing policy and flat-bar blank planning, separate from installed geometry.
Shear loss is a user allowance per operation, NOT a machine kerf/toolpath.
"""

import copy
import hashlib
import json
from collections import defaultdict

DEFAULT = dict(enabled=False, heavy_shear_loss_in=1.0, thin_shear_loss_in=None, flat_stock=[], clip_options={})


def settings(raw):
    from .ordering import number

    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise ValueError('Material engine settings must be an object')
    if set(raw) - set(DEFAULT):
        raise ValueError('Unknown material engine setting')
    c = copy.deepcopy(DEFAULT)
    c.update(copy.deepcopy(raw))
    if not isinstance(c['enabled'], bool):
        raise ValueError('Material engine enabled must be boolean')
    for key in ('heavy_shear_loss_in', 'thin_shear_loss_in'):
        if c[key] in ('', None) and key == 'thin_shear_loss_in':
            c[key] = None
            continue
        c[key] = number(c[key])
        if not 0 <= c[key] <= 12 or abs(c[key] * 16 - round(c[key] * 16)) > 1e-7:
            raise ValueError('Shear loss must be 0..12 inches on 1/16 increments')
    if not isinstance(c['flat_stock'], list) or len(c['flat_stock']) > 100:
        raise ValueError('Enter at most 100 flat-bar stock sizes')
    seen = set()
    for i, r in enumerate(c['flat_stock']):
        if not isinstance(r, dict) or set(r) - {'id', 'thickness_in', 'width_in', 'length_in', 'grade', 'finish'}:
            raise ValueError('Invalid flat-bar stock fields')
        for key, limit in [('thickness_in', 4), ('width_in', 120), ('length_in', 1440)]:
            r[key] = number(r.get(key, 0))
            if not 0 < r[key] <= limit or abs(r[key] * 16 - round(r[key] * 16)) > 1e-7:
                raise ValueError('Flat-bar dimensions must be positive, on 1/16 increments and within limits')
        for key in ('grade', 'finish'):
            r[key] = r.get(key, 'UNSPECIFIED')
            if not isinstance(r[key], str) or not r[key].strip() or len(r[key]) > 80:
                raise ValueError('Flat stock needs a short grade/finish label')
        r['id'] = r.get('id') or 'FB-' + hashlib.sha256(json.dumps(r, sort_keys=True).encode()).hexdigest()[:8]
        if not isinstance(r['id'], str) or not r['id'].strip() or len(r['id']) > 60 or r['id'] in seen:
            raise ValueError('Flat-stock IDs must be unique short labels')
        seen.add(r['id'])
    if not isinstance(c['clip_options'], dict) or len(c['clip_options']) > 500:
        raise ValueError('Invalid clip choices')
    for mark, r in c['clip_options'].items():
        if (
            not isinstance(mark, str)
            or not isinstance(r, dict)
            or set(r)
            - {
                'mode',
                'supplier_code',
                'grade',
                'finish',
                'blank_width_in',
                'blank_length_in',
                'shear_cuts_per_blank',
                'route_confirmed',
            }
        ):
            raise ValueError('Invalid clip option fields')
        if r.get('mode', 'supplier') not in ('supplier', 'shop', 'blank'):
            raise ValueError('Choose supplier, shop, or purchased blank')
        for key in ('supplier_code', 'grade', 'finish'):
            if key in r and (
                not isinstance(r[key], str) or len(r[key]) > 100 or (key != 'supplier_code' and not r[key].strip())
            ):
                raise ValueError('Clip grade/finish/code must be short text')
        for key in ('blank_width_in', 'blank_length_in'):
            if r.get(key) in ('', None):
                r.pop(key, None)
                continue
            r[key] = number(r[key])
            if not 0 < r[key] <= 1440 or abs(r[key] * 16 - round(r[key] * 16)) > 1e-7:
                raise ValueError('Verified blank dimensions must be positive on 1/16 increments')
        if ('blank_width_in' in r) != ('blank_length_in' in r):
            raise ValueError('Enter BOTH verified blank dimensions')
        cuts = r.get('shear_cuts_per_blank')
        if cuts in ('', None):
            r.pop('shear_cuts_per_blank', None)
        else:
            if isinstance(cuts, bool) or not str(cuts).isdigit() or not 1 <= int(cuts) <= 20:
                raise ValueError('Reviewed cuts per blank must be an integer 1..20')
            r['shear_cuts_per_blank'] = int(cuts)
        if not isinstance(r.get('route_confirmed', False), bool):
            raise ValueError('Shear route confirmation must be boolean')
    return c


def catalog(job, items, c):
    from .ordering import up
    from .plasma_layout import collect

    parts, holds = collect(job)
    geometries = defaultdict(list)
    for r in parts:
        geometries[r['mark']].append(r)
    standard = set()
    for p in job.settings.get('frames', {}).values():
        standard.update(p.get(k) for k in ('purlin_clip', 'girt_clip'))
    for a in job.assemblies.values():
        standard.update(a.derivation.get('end_girt_clip_counts', {}))
    rows = {}
    for i, r in enumerate(items):
        if r['family'] not in ('plate', 'clip'):
            continue
        mark = r['material'].split()[0]
        part = job.parts.get(mark)
        gs = geometries.get(mark, [])
        g = gs[0] if gs else None
        isclip = (part is not None and part.kind == 'clip') or 'CLIP' in r['material'].upper()
        if mark not in rows:
            formed = bool(part and ('formed' in part.notes.lower() or part.symbol.get('formed')))
            thk = g['thickness_in'] if g else float(part.thk.inches) if part and part.thk else None
            w = up(g['width_in']) if g else float(part.width.inches) if part and part.width else None
            L = up(g['height_in']) if g else float(part.length.inches) if part and part.length else None
            rectangle = False
            if g:
                poly = g['contour_in']
                area = abs(sum(x * y2 - x2 * y for (x, y), (x2, y2) in zip(poly, poly[1:] + poly[:1]))) / 2
                rectangle = abs(area - g['width_in'] * g['height_in']) < 1e-7
            conflict = (
                len({json.dumps([v['thickness_in'], v['contour_in'], v['holes_in']], sort_keys=True) for v in gs}) > 1
            )
            rows[mark] = dict(
                mark=mark,
                kind='clip' if isclip else 'plate',
                # Standard catalog clips and formed clips are bought finished unless the
                # user explicitly routes them to the shop; flat clips are shop-cut.
                default_mode='supplier' if mark in standard or formed else 'shop' if isclip else 'blank',
                quantity=0,
                thickness_in=thk,
                envelope_width_in=w,
                envelope_length_in=L,
                rectangular=rectangle,
                formed=formed,
                geometry_conflict=conflict,
                holes=part.to_json()['holes'] if part else (g['holes_in'] if g else []),
                holes_known=bool(part or g),
                source=part.source if part else 'Modeled custom connection',
                grade=r['grade'],
                finish=r['finish'],
                item_indices=[],
                references=[],
            )
        row = rows[mark]
        row['quantity'] += r['quantity']
        row['item_indices'].append(i)
        row['references'].append(r['references'])
        if row['grade'] != r['grade'] or row['finish'] != r['finish']:
            row['geometry_conflict'] = True
    for row in rows.values():
        opt = c['material_engine']['clip_options'].get(row['mark'], {})
        row['mode'] = opt.get('mode', row['default_mode'])
        row['grade'] = opt.get('grade', row['grade'])
        row['finish'] = opt.get('finish', row['finish'])
        row['supplier_code'] = opt.get('supplier_code', '')
    return sorted(rows.values(), key=lambda r: r['mark'])


def flat_pack(pieces, stocks):
    """Deterministic orientation-aware best-fit trials; minimize purchased AREA.
    Exact stock width must match a verified blank side; no unmodeled ripping.
    The last separation is omitted ONLY when the finished stock end fits exactly.
    Never silently consume a partial 1-inch shear allowance.
    """
    if len(pieces) > 2000:
        raise ValueError('Flat-bar optimizer limit: 2000 blanks; split the batch')

    def orientation(piece, bar):
        if any(piece[k] != bar[k] for k in ('thickness_in', 'grade', 'finish')):
            return []
        choices = []
        w, L = piece['blank_width_in'], piece['blank_length_in']
        loss = piece['loss_per_cut_in']
        cuts = piece['shear_cuts_per_blank']
        remaining = bar['length_in'] - bar.get('used_in', 0)
        for width, length, angle in ((w, L, 0), (L, w, 90)):
            if abs(width - bar['width_in']) > 1e-8:
                continue
            if length + cuts * loss <= remaining + 1e-8:
                choices.append((length, cuts, angle))
            elif abs(length + (cuts - 1) * loss - remaining) < 1e-8:
                choices.append((length, cuts - 1, angle))
        return choices

    candidates = []
    # Single-width policies and all-width trials avoid a tiny early row forcing
    # every following blank into an unnecessarily wide stock size.
    for reverse in (True, False):
        order = sorted(
            pieces,
            key=lambda p: (max(p['blank_width_in'], p['blank_length_in']), p['mark'], p['instance']),
            reverse=reverse,
        )
        policies = [stocks] + [
            [s for s in stocks if s['width_in'] == w] for w in sorted({s['width_in'] for s in stocks})
        ]
        for allowed in policies:
            bars = []
            unplaced = []
            for piece in order:
                options = []
                for i, b in enumerate(bars):
                    for length, cuts, angle in orientation(piece, b):
                        options.append(
                            (
                                (b['length_in'] - b['used_in'] - length - cuts * piece['loss_per_cut_in'])
                                * b['width_in'],
                                i,
                                length,
                                cuts,
                                angle,
                            )
                        )
                if options:
                    _, i, length, cuts, angle = min(options)
                    b = bars[i]
                else:
                    choices = []
                    for i, s in enumerate(allowed):
                        for length, cuts, angle in orientation(piece, s):
                            choices.append(
                                (s['width_in'] * s['length_in'], s['length_in'], s['id'], i, length, cuts, angle)
                            )
                    if not choices:
                        unplaced.append(piece)
                        continue
                    *_, i, length, cuts, angle = min(choices)
                    b = dict(allowed[i], used_in=0, cuts=[], blank_feed_in=0, shear_loss_in=0, shear_cuts=0)
                    bars.append(b)
                allocation = dict(
                    mark=piece['mark'],
                    instance=piece['instance'],
                    start_in=b['used_in'],
                    feed_length_in=length,
                    blank_width_in=b['width_in'],
                    rotation_deg=angle,
                    shear_cuts=cuts,
                    shear_loss_in=cuts * piece['loss_per_cut_in'],
                    loss_per_cut_in=piece['loss_per_cut_in'],
                    separation_omitted=cuts < piece['shear_cuts_per_blank'],
                )
                b['cuts'].append(allocation)
                b['used_in'] += length + allocation['shear_loss_in']
                b['blank_feed_in'] += length
                b['shear_loss_in'] += allocation['shear_loss_in']
                b['shear_cuts'] += cuts
            candidates.append(
                (len(unplaced), sum(b['width_in'] * b['length_in'] for b in bars), len(bars), bars, unplaced)
            )
    best = min(enumerate(candidates), key=lambda x: (x[1][:3], x[0]))[1]
    return best[3], best[4]


def source_clips(job, c, items, hold):
    from .ordering import fmt

    e = c['material_engine']
    rows = catalog(job, items, c)
    result = dict(clip_requirements=rows, flat_bars=[], flat_allocations=[])
    if not e['enabled']:
        return items, result
    removed = set()
    new = []
    pieces = []

    def order_row(material, grade, finish, length, quantity, basis, status, refs, family):
        return dict(
            department='Frame',
            material=material,
            finish=finish,
            grade=grade,
            order_length_in=length,
            order_length=fmt(length) if length is not None else '',
            quantity=quantity,
            unit='ea',
            basis=basis,
            status=status,
            references=refs,
            material_group='',
            family=family,
            custom_mark='',
        )

    for r in rows:
        mode = r['mode']
        opt = e['clip_options'].get(r['mark'], {})
        r['planned_quantity'] = 0
        r['unplanned_quantity'] = 0
        if mode == 'blank':
            r['planned_quantity'] = r['quantity']
            r['status'] = 'BUY RECTANGULAR BLANK: prior plate policy'
            for i in r['item_indices']:
                items[i].update(grade=r['grade'], finish=r['finish'])
            continue
        removed.update(r['item_indices'])
        if mode == 'supplier':
            dims = (
                ' / PL '
                + fmt(r['thickness_in'])
                + ' x '
                + fmt(r['envelope_width_in'])
                + ' x '
                + fmt(r['envelope_length_in'])
                + ' ENVELOPE'
                if r['thickness_in'] is not None
                else ''
            )
            dims += (
                ('; ' + str(len(r['holes'])) + ' hole(s), see drawing' if r['holes'] else '; NO HOLES')
                if r['holes_known']
                else '; hole specification unresolved'
            )
            desc = (
                'FINISHED '
                + r['kind'].upper()
                + ' '
                + r['mark']
                + (' / supplier ' + r['supplier_code'] if r['supplier_code'] else '')
                + dims
            )
            new.append(
                order_row(
                    desc,
                    r['grade'],
                    r['finish'],
                    None,
                    r['quantity'],
                    'BUY FINISHED — NOT RAW STOCK',
                    'Confirm supplier match, forming and hole specification against part drawing; no vendor SKU inferred',
                    r['mark'] + ' / ' + '; '.join(r['references']),
                    'finished_clip',
                )
            )
            r['planned_quantity'] = r['quantity']
            r['status'] = 'BUY FINISHED per part drawing'
            continue
        reason = None
        w = opt.get('blank_width_in', r['envelope_width_in'])
        L = opt.get('blank_length_in', r['envelope_length_in'])
        loss = (
            e['heavy_shear_loss_in']
            if r['thickness_in'] is not None and r['thickness_in'] > 1 / 8
            else e['thin_shear_loss_in']
        )
        if r['geometry_conflict']:
            reason = 'Conflicting geometry or material under one clip mark; separate before procurement'
        elif not all(x is not None and x > 0 for x in (w, L, r['thickness_in'])):
            reason = 'Clip blank dimensions/thickness unresolved'
        elif r['formed'] and not (
            'blank_width_in' in opt and opt.get('route_confirmed') and 'shear_cuts_per_blank' in opt
        ):
            reason = 'Formed clip: enter verified DEVELOPED blank dimensions, cut count and confirm route'
        elif (
            (not r['rectangular'] or sorted((w, L)) != sorted((r['envelope_width_in'], r['envelope_length_in'])))
            and not r['formed']
            and not (opt.get('route_confirmed') and 'shear_cuts_per_blank' in opt)
        ):
            reason = 'Shaped clip: confirm reviewed shear route and cuts per blank; no cut count invented'
        elif not r['formed'] and any(
            a + 1e-8 < b for a, b in zip(sorted((w, L)), sorted((r['envelope_width_in'], r['envelope_length_in'])))
        ):
            reason = 'Entered blank is smaller than modeled contour envelope'
        elif loss is None:
            reason = 'Enter shear allowance for material at or below 1/8 inch'
        cuts = opt.get('shear_cuts_per_blank', 1)
        r.update(blank_width_in=w, blank_length_in=L, shear_cuts_per_blank=cuts, loss_per_cut_in=loss)
        if reason:
            r['status'] = 'UNRESOLVED: ' + reason
            r['unplanned_quantity'] = r['quantity']
            hold('Frame', 'SHOP ' + r['mark'], r['quantity'], r['mark'], reason)
            continue
        if r['quantity'] + len(pieces) > 2000:
            r['status'] = 'UNRESOLVED: flat-bar batch exceeds 2000 blanks'
            r['unplanned_quantity'] = r['quantity']
            hold('Frame', 'SHOP ' + r['mark'], r['quantity'], r['mark'], r['status'])
            continue
        r['status'] = 'SHOP: rectangular blank reservations; final contour/holes per reviewed route'
        for i in range(r['quantity']):
            pieces.append(dict(r, instance=i + 1))
    if pieces:
        bars, unplaced = flat_pack(pieces, e['flat_stock'])
        bymark = {r['mark']: r for r in rows}
        for i, b in enumerate(bars, 1):
            b['stock_id'] = 'FLAT-' + str(i).zfill(4)
            b['remnant_in'] = b['length_in'] - b['used_in']
            b['quantity'] = 1
            for a in b['cuts']:
                a['stock_id'] = b['stock_id']
                result['flat_allocations'].append(a)
                bymark[a['mark']]['planned_quantity'] += 1
            result['flat_bars'].append(b)
            new.append(
                order_row(
                    'FLAT BAR ' + fmt(b['thickness_in']) + ' x ' + fmt(b['width_in']),
                    b['grade'],
                    b['finish'],
                    b['length_in'],
                    1,
                    'STOCK FLAT BAR / SHEAR PLAN',
                    'Full allowance per reviewed shear cut; no unmodeled ripping; not a machine program',
                    b['stock_id'],
                    'flat_bar',
                )
            )
        pending = defaultdict(int)
        for p in unplaced:
            pending[p['mark']] += 1
        for mark, q in pending.items():
            r = bymark[mark]
            r['unplanned_quantity'] += q
            r['status'] = (
                'UNRESOLVED: enter compatible flat-bar thickness / exact blank width / usable length / grade / finish'
            )
            hold('Frame', 'SHOP ' + mark, q, mark, r['status'])
    return [r for i, r in enumerate(items) if i not in removed] + new, result
