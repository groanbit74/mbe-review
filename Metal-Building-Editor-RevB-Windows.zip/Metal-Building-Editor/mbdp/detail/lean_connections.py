"""Explicit user flush-clip geometry and source-specific bypass bolt preset.
Part geometry is distinct from installation/connection approval. No G-code.
"""

import math
import re
from fractions import Fraction

from .cladding import ceil16, fmt, inch
from .model import D, Part

BYPASS_PRESET = dict(
    id='1277345-R5-SP2',
    source='Erection Dwgs.pdf /1277345 /R5-R6 /PDF7-8 /8-17-23 REVIEW',
    count=4,
    grade='A325',
    diameter_in=0.625,
    length_in=2.0,
    scope='SELECTABLE SOURCE PRESET, not global approval; hole diameter, layout, grip and edge distances NOT inferred',
)


def flush_clip(rafter, pitch, peak, web_thickness=None, pair=1, hand=1, weld=0.25, fit_rule="legacy"):
    """6in HORIZONTAL projection; constant finished vertical height at root N-2.
    Z=rafter peak at the column face. Center from the ACTUAL plumb section depth at the vertical column face.
    W nominal size defines
    plate height, NOT the rolled section actual depth. Separate bounding blank.
    """
    if rafter['family'] == 'W':
        nom = float(re.match(r'W(\d+)', rafter['id']).group(1))
        tw = rafter['web']
    elif rafter['family'] == 'C':
        nom = float(rafter['depth'])
        tw = web_thickness
    else:
        raise ValueError('Flush clip requires W or open Cee rafter')
    m = float(pitch) / 12
    H = nom - 2
    if fit_rule not in ('legacy', 'gap_overlap', 'owner_gap'):
        raise ValueError('Unknown lean high clip fit rule')
    co = 1 / math.hypot(1, m)
    overlap = 6.0
    if fit_rule == 'owner_gap':
        # Shop option (v0.8.34): 2 in HORIZONTAL gap between the rafter end and the column face,
        # 6 in of clip along the rafter web.
        gap = 2.0 / co
        run = 2.0 + overlap * co
    elif fit_rule == 'gap_overlap':
        gap = 1.5
        run = (gap + overlap) * co
    else:
        gap = 0.0
        run = 6.0
    thick = 0.5
    drop = run * m
    if not 0 <= m <= 1 or H <= 0 or pair not in (1, 2) or hand not in (-1, 1):
        raise ValueError('Invalid flush clip geometry')
    if not math.isfinite(peak) or not 0 < weld <= 0.5:
        raise ValueError('Invalid peak elevation or weld size')
    if tw is not None and not 0 < tw <= 1:
        raise ValueError('Actual web thickness must be positive and at most1in')
    # Root and free edge are plumb. The same vertices drive ALL exports.
    contour = [[0, drop], [run, 0], [run, H], [0, H + drop]]
    plumb_depth = rafter['depth'] * math.hypot(1, m)
    center = peak - plumb_depth / 2
    bottom = center - H / 2
    total_web = None if tw is None else pair * tw
    offset = None if total_web is None else hand * (total_web + thick) / 2
    installed = [[x, bottom - drop + y] for x, y in contour]
    issues = []
    if total_web is None and fit_rule != 'owner_gap':
        issues.append('CEE WEB THICKNESS PENDING: offset cannot be inferred from gauge label')
    if nom - rafter['depth'] > 2:
        issues.append('Clip nominal height does not fit actual rafter envelope')
    return dict(
        fit_rule=fit_rule,
        rafter_gap_along_in=gap,
        web_overlap_along_in=overlap if fit_rule in ('gap_overlap', 'owner_gap') else 6 / co,
        rafter_start_x_in=gap * co,
        rafter_start_drop_in=gap * co * m,
        thickness_in=thick,
        projection_in=run,
        nominal_rafter_depth_in=nom,
        actual_rafter_depth_in=rafter['depth'],
        plumb_rafter_depth_in=plumb_depth,
        finished_height_in=H,
        pitch_rise=float(pitch),
        cut_angle_deg=math.degrees(math.atan(m)),
        drop_in=drop,
        contour_in=contour,
        blank_length_in=run,
        blank_height_in=ceil16(H + drop),
        exact_bounding_height_in=H + drop,
        area_sqin=run * H,
        peak_height_in=peak,
        center_height_in=center,
        root_bottom_in=bottom,
        root_top_in=bottom + H,
        tip_bottom_in=bottom - drop,
        tip_top_in=bottom + H - drop,
        installed_contour_in=installed,
        web_thickness_each_in=tw,
        web_count=pair,
        combined_web_thickness_in=total_web,
        clip_center_offset_in=offset,
        clip_contact_face_offset_in=None if total_web is None else hand * total_web / 2,
        hand=hand,
        weld_size_in=weld,
        holes=[],
        issues=issues,
        datum='Peak at column face minus ACTUAL PLUMB rafter depth/2; plumb depth = section depth x sqrt(1+(pitch/12)^2); finished clip height NOMINAL depth minus2; projection follows selected fit rule',
        weld_note='WELDED TO COLUMN FLANGE AND RAFTER WEB; weld size editable, extent/access/sequence/design remain review-held',
        scope='USER GEOMETRY / REVIEW ONLY; no kerf compensation, lead-ins or machine commands',
    )


def part(mark, c):
    def dim(n):
        return D(Fraction(str(n)))

    return Part(
        mark,
        'plate',
        dim(c['thickness_in']),
        dim(c['blank_height_in']),
        dim(c['blank_length_in']),
        holes=[],
        symbol=dict(
            cut_contour=[[str(Fraction(str(x))) + '"', str(Fraction(str(y))) + '"'] for x, y in c['contour_in']],
            draft_connection=True,
            interface_placement={
                k: c.get(k)
                for k in (
                    'main_mark',
                    'station_in',
                    'peak_height_in',
                    'peak_basis',
                    'root_bottom_in',
                    'root_top_in',
                    'tip_bottom_in',
                    'tip_top_in',
                    'clip_center_offset_in',
                    'clip_contact_face_offset_in',
                    'web_count',
                )
            },
            review_hold=' / '.join(c.get('issues', [])) or 'Final fit/weld/design review',
            role='flush lean-to high clip',
            fit='tight',
            bevel='none',
            weld_size=dim(c['weld_size_in']).fmt(),
        ),
        source='USER flush lean-to instruction',
        notes='REVIEW ONLY. Sloped top AND bottom. No bolt holes. No automatic machine post.',
    )


def attach(p, r, z, rf, posts, fid):
    """Attach exact connection geometry per physical station, not per primary lot."""
    overrides = r.get('high_connection_overrides') or {}
    if overrides:
        grouped = {}
        schedule = []
        for i, post in enumerate(posts):
            key = str(int(post.get('frame_line') or i + 1))
            mode = overrides.get(key) or r['high_connection']
            grouped.setdefault(mode, []).append(post)
            schedule.append(
                dict(
                    station=int(key),
                    main_mark=post['mark'],
                    mode=mode,
                    source='override' if key in overrides else 'inherited',
                )
            )
        z['flush_clips'] = []
        z['bolt_preset'] = None
        z['end_plate_geometry'] = None
        station_details = {}
        for mode, group_posts in grouped.items():
            marks = {post['mark'] for post in group_posts}
            sub = dict(z)
            sub['stations'] = [s for s in z.get('stations', []) if s.get('main_mark') in marks]
            sub['issues'] = z['issues']
            sub['flush_clips'] = []
            sub['end_plate_geometry'] = None
            rsub = dict(
                r,
                high_connection=mode,
                high_connection_overrides={},
                bolt_preset=r.get('bolt_preset') if mode == 'end_plate' else '',
            )
            attach(p, rsub, sub, rf, group_posts, fid)
            if mode == 'end_plate':
                end_plate(rsub, sub, fid)
                if sub.get('end_plate_geometry'):
                    z['end_plate_geometry'] = sub['end_plate_geometry']
                    if not sub['end_plate_geometry'].get('geometry_valid'):
                        z['issues'].append(
                            'HIGH end-plate support geometry does not fit its entered dimensions and hole layout; correct the plate width/height or hole spacing.'
                        )
                else:
                    z['issues'].append(
                        'Enter plate dimensions and four-hole gauge, pitch, and diameter for the HIGH end-plate support.'
                    )
            z['flush_clips'].extend(sub.get('flush_clips', []))
            if sub.get('bolt_preset'):
                z['bolt_preset'] = sub['bolt_preset']
            for item in (sub.get('high_connection_detail') or {}).get('stations', []):
                if item.get('main_mark'):
                    station_details[item['main_mark']] = item
            for item in sub.get('flush_clips', []):
                station_details[item['main_mark']] = item
            if sub.get('end_plate_geometry'):
                for post in group_posts:
                    station_details[post['mark']] = dict(
                        mode='end_plate',
                        plate_mark=sub['end_plate_geometry']['mark'],
                        plate_geometry_valid=sub['end_plate_geometry']['geometry_valid'],
                    )
        details = [dict(row, detail=station_details.get(row['main_mark'])) for row in schedule]
        z['high_connection_schedule'] = schedule
        modes = {row['mode'] for row in schedule}
        z['high_connection_detail'] = dict(
            mode='per_support'
            if len(modes) > 1 or any(row['source'] == 'override' for row in schedule)
            else r['high_connection'],
            summary='Per-support connection schedule; each physical station uses the listed mode.',
            stations=details,
        )
        return
    z['flush_clips'] = []
    z['bolt_preset'] = None
    if r.get('bolt_preset'):
        z['bolt_preset'] = dict(BYPASS_PRESET, total_bolts=4 * len(posts))
        if r.get('hole_diameter') and inch(r['hole_diameter']) <= BYPASS_PRESET['diameter_in']:
            z['issues'].append('SP2 bolt diameter is NOT smaller than the entered hole: revise hole specification')
    if r['high_connection'] == 'welded_direct' and rf:
        _welded_direct(p, r, z, rf, posts)
        return
    if r['high_connection'] != 'clip' or not rf:
        return
    owner = r.get('high_clip_fit') == 'owner_gap'
    actual_face = r.get('high_clip_fit') in ('gap_overlap', 'owner_gap') and r['face'] in ('left', 'right')
    inset = float(p.girt_depth.inches) if p.inset_for_bypass and actual_face else 0
    peak = (
        inch(r['rafter_peak_height'])
        if r.get('rafter_peak_height')
        else z['high_eave_in'] - z.get('purlin_deduction_in', r['purlin_depth_in']) + inset * r['pitch'] / 12
    )
    if p.girt_mode != 'flush' and not actual_face:
        z['issues'].append(
            'FLUSH CLIP selected on a BYPASS main wall: reconcile main-wall system/inset before installation'
        )
    from .framing_additions import station_fit, station_rafter

    for i, u in enumerate(posts):
        rfi, pair = station_rafter(r, rf, i, len(posts))
        ded_i = station_fit(r, rfi, pair)[1]
        peak_i = peak if r.get('rafter_peak_height') else peak + z.get('purlin_deduction_in', 0.0) - ded_i
        c = flush_clip(
            rfi,
            r['pitch'],
            peak_i,
            inch(r['cee_web_thickness']) if r.get('cee_web_thickness') else None,
            pair,
            (-1 if r.get('clip_hand') == 'negative' else 1),
            inch(r.get('clip_weld_size', 0.25)),
            r.get('high_clip_fit', 'legacy'),
        )
        c.update(
            mark=fid + '-' + r['id'] + '-FC' + str(i + 1),
            main_mark=u['mark'],
            station_in=u['x'],
            quantity=1,
            main_column_profile=u['profile'],
            main_face_width_in=u['face_width'],
            peak_basis='USER ENTERED RAFTER PEAK'
            if r.get('rafter_peak_height')
            else 'DERIVED REFERENCE high eave minus nominal purlin depth; verify actual high cut-plane datum',
        )
        if actual_face and not r.get('rafter_peak_height'):
            c['peak_basis'] = 'DERIVED MAIN OUTSIDE COLUMN FACE: roof at wall minus purlin depth plus inset x pitch'
        if c['root_bottom_in'] < u['bottom'] or c['root_top_in'] > u['top']:
            c['issues'].append('Column-edge weld extends outside upright height')
        if c['clip_center_offset_in'] is not None and abs(c['clip_center_offset_in']) + 0.25 > u['face_width'] / 2:
            c['issues'].append('Offset clip extends outside column flange width')
        if not u['profile'].startswith(('W', 'HSS')):
            c['issues'].append(
                'MAIN POST WEB/FLANGE DATUM NOT CONFIRMED: non-W main upright requires explicit face/orientation detail'
            )
        if p.girt_mode != 'flush' and not actual_face:
            c['issues'].append('MAIN WALL SYSTEM MISMATCH: flush clip on bypass model')
        if not r.get('rafter_peak_height') and not actual_face:
            c['issues'].append('Final high-cut-plane peak elevation not confirmed')
        if owner:
            c['weld_note'] = (
                'CLIP WELDED TO THE MAIN COLUMN FACE AND TO THE RAFTER WEB; rafter end 2 in clear of the column'
            )
            c['scope'] = 'SHOP OPTION: welded clip, 2 in gap'
        else:
            c['issues'] += [
                'Check rolled fillets, actual clear web depth, weld access/extent and connection design before cutting/welding.'
            ]
        z['flush_clips'].append(c)


SEAT_TOLERANCE_IN = 0.5  # leeway between the lean roof line on a seat and the main roofline


def _welded_direct(p, r, z, rf, posts):
    """Shop standard: the rafter's plumb high end is welded directly at the main column line.

    Owner rules (2026-10-15): the roofline always follows the top of purlin (purlins in a channel
    rafter: rafter top = roofline; bypass: rafter top = bottom of purlin).  Where the main member
    runs to its rafter top line (inside-flange column, flush channel end rafter) the lean rafter is
    welded to the member's OUTSIDE FACE - the part of its end above the column top stands in the
    eave strut zone, which is no issue.  Where the main rafter sits ON the member (outside-seat
    column, bypass end rafter on the posts) a lean rafter that continues the main roof plane SITS
    ON THE SAME SEAT beside the main rafter end and is welded to it; its roof line (rafter + purlin)
    must then meet the main roofline.
    """
    from .framing_additions import station_fit, station_rafter

    m = r['pitch'] / 12
    co = 1 / math.hypot(1, m)
    inset = float(p.girt_depth.inches) if p.inset_for_bypass and r['face'] in ('left', 'right') else 0
    lean_ded = z.get('purlin_deduction_in', r['purlin_depth_in'])
    top = z['high_eave_in'] - lean_ded + inset * m
    plumb = rf['depth'] / co
    main_purlin = float(p.purlin_depth.inches)
    stations = []
    for i, u in enumerate(posts):
        # section and purlin fit of THIS frame line (rafter_lines override; channels in channel)
        rfi, pair = station_rafter(r, rf, i, len(posts))
        ded_i = station_fit(r, rfi, pair)[1]
        top_i = z['high_eave_in'] - ded_i + inset * m
        plumb_i = rfi['depth'] / co
        rec = dict(
            station=i + 1,
            main_mark=u['mark'],
            station_in=u['x'],
            main_column_profile=u['profile'],
            main_face_width_in=u['face_width'],
            rafter_profile=rfi['id'],
            rafter_top_in=top_i,
            rafter_bottom_in=top_i - plumb_i,
            plumb_rafter_depth_in=plumb_i,
            purlin_deduction_in=ded_i,
            web_count=pair,
            issues=[],
        )
        top, plumb = top_i, plumb_i
        mr = u.get('main_rafter') or {}
        roofline = u.get('roofline', z['high_eave_in'])
        bottom = top - plumb
        seat_top = None
        main_top = None
        if mr:
            main_plumb = mr['depth'] / co
            main_top = roofline - (0.0 if mr.get('in_channel') else main_purlin)
            if mr.get('on_top'):
                seat_top = main_top - main_plumb
        if seat_top is not None and abs(bottom - seat_top) <= SEAT_TOLERANCE_IN:
            rec.update(
                fit='seat',
                seat_top_in=seat_top,
                main_rafter=mr['id'],
                seat_step_in=bottom - seat_top,
                note='main rafter '
                + mr['id']
                + ' sits on this member: the lean rafter sits on the same seat beside the main rafter end and is welded directly to the seat (outside-seat detail)'
                + (
                    '; ' + fmt(abs(bottom - seat_top)) + ' taken up at the seat (within the 1/2 in leeway)'
                    if abs(bottom - seat_top) > 1e-6
                    else ''
                ),
            )
        else:
            # Welded to whatever stands on the column line over the rafter end: the column face up
            # to the column top, the main rafter end above an outside seat, the eave strut on top.
            behind = []
            if bottom < u['top'] - 1e-6:
                behind.append('column face')
            if seat_top is not None and top > seat_top + 1e-6 and bottom < main_top - 1e-6:
                behind.append('main rafter end (' + mr['id'] + ')')
            strut_bottom = (
                roofline - float(p.eave_strut_depth.inches)
                if getattr(p, 'eave_strut_depth', None)
                else roofline - main_purlin
            )
            if top > strut_bottom + 1e-6:
                behind.append('eave strut')
            note = 'plumb end welded directly at the column line to the ' + (' / '.join(behind) or 'column face')
            if top > u['top'] + 1e-6:
                note += (
                    '; the upper '
                    + fmt(top - u['top'])
                    + ' of the rafter end stands above the column top (roofline = top of the rafter = top of purlin)'
                )
            rec.update(fit='face', note=note, behind=behind)
            if bottom < u['bottom'] - 1e-6:
                rec['issues'].append(
                    'Rafter end plane reaches below the column base: the lean roof must be above the floor'
                )
        stations.append(rec)
    fits = sorted({rec['fit'] for rec in stations})
    behind = sorted(
        {b.split(' (')[0] for rec in stations for b in rec.get('behind', [])},
        key=('column face', 'main rafter end', 'eave strut').index,
    )
    if fits == ['seat']:
        summary = 'on the main column seat beside the main rafter end, welded to the seat (plumb end, no gap)'
    elif 'seat' in fits:
        summary = 'welded directly at the main column line: on the main column seat where the main rafter sits on the member (both tops at the roof line), to the column face elsewhere (plumb end, no gap)'
    elif any(b != 'column face' for b in behind):
        summary = (
            'welded directly at the main column line to the '
            + ' / '.join(behind)
            + ' over the plumb end (no gap); the rafter top follows the roofline'
        )
    else:
        summary = 'welded directly to the main column outside face (plumb end, no gap)'
    top = z['high_eave_in'] - lean_ded + inset * m
    plumb = rf['depth'] / co
    z['high_connection_detail'] = dict(
        mode='welded_direct',
        summary=summary,
        rule=(
            'SHOP STANDARD: rafter cut PLUMB, welded directly at the main column - to the OUTSIDE FACE where the lean rafter top is at the column top line, ON THE COLUMN SEAT where the main rafter sits on the member and both tops meet the roof line; no gap, no clip'
            if 'seat' in fits
            else 'SHOP STANDARD: rafter cut PLUMB, welded directly to the OUTSIDE face of the main column; no gap, no clip'
        ),
        gap_in=0.0,
        rafter_top_at_face_in=top,
        plumb_rafter_depth_in=plumb,
        fits=fits,
        weld=(
            'Fillet all round the rafter end contact to the column face / to the seat plate and the main rafter end'
            if 'seat' in fits
            else 'Fillet all round the rafter end contact (web and flanges) to the column face'
        ),
        stations=stations,
    )
    for rec in stations:
        for s_ in rec['issues']:
            z['issues'].append(rec['main_mark'] + ': ' + s_)


def end_plate(r, z, fid):
    """A rectangular high plate ONLY when every size and hole input is explicit."""
    z['end_plate_geometry'] = None
    if r['high_connection'] != 'end_plate':
        return
    z['end_plate_envelope'] = {
        k: inch(r[k]) for k in ('plate_width', 'plate_height', 'plate_thickness') if r.get(k) not in ('', None)
    }
    keys = ('plate_width', 'plate_height', 'plate_thickness', 'hole_gauge', 'hole_pitch', 'hole_diameter')
    if not all(r.get(k) for k in keys):
        return
    W, H, T, G, V, DIA = (inch(r[k]) for k in keys)
    rec = dict(
        mark=fid + '-' + r['id'] + '-HIGH-EP',
        quantity=len(z['stations']),
        width_in=W,
        height_in=H,
        thickness_in=T,
        hole_gauge_in=G,
        hole_pitch_in=V,
        hole_diameter_in=DIA,
        holes_in=[
            [W / 2 + dx, H / 2 + dy, DIA]
            for dx, dy in ((-G / 2, -V / 2), (G / 2, -V / 2), (-G / 2, V / 2), (G / 2, V / 2))
        ],
        scope='EXPLICIT USER RECTANGULAR PLATE /4-HOLE GEOMETRY; column/grip/weld/edge-distance review; NOT source-inferred plate dimensions',
        geometry_valid=True,
    )
    from .contours import validate_contour

    try:
        validate_contour(end_plate_part(rec))
    except ValueError as e:
        rec['geometry_valid'] = False
        z['issues'].append('HIGH PLATE CONTOUR HOLD: ' + str(e))
    z['end_plate_geometry'] = rec


def end_plate_part(c):
    from .model import Hole

    def dim(n):
        return D(Fraction(str(n)))

    W, H = c['width_in'], c['height_in']
    return Part(
        c['mark'],
        'plate',
        dim(c['thickness_in']),
        dim(ceil16(H)),
        dim(ceil16(W)),
        holes=[Hole(dim(x), dim(y), dim(d)) for x, y, d in c['holes_in']],
        symbol=dict(
            cut_contour=[
                [str(Fraction(str(x))) + '"', str(Fraction(str(y))) + '"'] for x, y in ((0, 0), (W, 0), (W, H), (0, H))
            ],
            draft_connection=True,
            role='High end plate: USER width/height/thickness and4-hole pattern; NOT inferred from SP2 bolts',
            interface_placement=dict(
                quantity=c['quantity'],
                datum='Plate center aligned to high rafter web center; per-station column hole coordinates in lean_to_holes.csv',
            ),
            review_hold='Verify weld attachment, edge distances, grip and main-column drilled variants; no column CNC is changed',
        ),
        source='USER dimensions; optional SP2 bolt specification is separate',
        notes='REVIEW ONLY: dimensions entered, not an engineered end-plate connection approval.',
    )
