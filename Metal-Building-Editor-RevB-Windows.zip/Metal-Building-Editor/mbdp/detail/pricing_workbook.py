"""Simple pricing workbook built from the material (supplier order) list.

Modelled on the supplier's own quotation format (owner samples, Oct 2026):

* beams / purlins / channel / tube / strip are priced by weight - LBS @ $/CWT
* sheets are priced by area - SFT @ $/CSF (per 100 sq ft, 38.25 in gross width)
* trim is priced by the foot - $/FT
* accessories, clips and doors are priced per each - $/EA

The 'Pricing' sheet is editable: Material and Unit are dropdowns, Size is a
dropdown of the sizes on the job for that material, Quantity / basis / unit
price can all be typed over. Unit prices are pulled from the editable
'Price book' sheet (seeded from the owner's recent supplier quotes - most
recent quote wins) with a VLOOKUP, so repricing the book reprices the job.
Footer follows the quote: Material subtotal + freight/processing + tax =
ORDER AMT. Nothing here blocks a job: an unpriced line is simply blank.
"""

from __future__ import annotations

import re

from .ordering import build, fmt
from .purchasing import _is_special_clip, _location, _part_marks, _strip_supplier_prefix, _supplier_part, supplier_plan

STEEL_LB_FT_PER_IN2 = 3.4  # lb per foot of steel per square inch of section
GA_THICKNESS = {14: 0.0747, 16: 0.0598, 12: 0.1046, 11: 0.1196}

# Seeded from the owner's SSS quotes (RS-887777 / RS-900986 Oct 2026, RS-902863):
# (material type, size or '', unit, unit price). Most recent quote wins.
PRICE_BOOK_SEED = [
    ('WIDE FLANGE BEAM', '', 'CWT', 140.00),
    ('COLD FORMED PURLIN', '', 'CWT', 85.00),
    ('OPEN FACE CHANNEL', '', 'CWT', 75.00),
    ('SQUARE TUBING', '', 'CWT', 140.00),
    ('HOT ROLLED STRIP', '', 'CWT', 113.00),
    ('PLATE', '', 'CWT', 113.00),
    ('R-PANEL GALVALUME', '', 'CSF', 106.00),
    ('R-PANEL COLOR', '', 'CSF', 128.00),
    ('BUILDING TRIM', 'RIDGE CAP FLAT', 'FT', 2.53),
    ('BUILDING TRIM', 'STANDARD RAKE TRIM', 'FT', 2.26),
    ('BUILDING TRIM', 'SCULPTURED CORNER', 'FT', 2.67),
    ('BUILDING TRIM', 'DOOR JAMB TRIM', 'FT', 1.16),
    ('BUILDING TRIM', 'DOOR HEAD TRIM', 'FT', 1.17),
    ('BUILDING TRIM', 'CAP TRIM', 'FT', 4.65),
    ('BUILDING ACCESSORIES', 'PRLIN CLP 3 X 5', 'EA', 0.75),
    ('BUILDING ACCESSORIES', 'PRLIN CLP 5 X 7', 'EA', 2.95),
]

MATERIAL_TYPES = [
    'WIDE FLANGE BEAM',
    'COLD FORMED PURLIN',
    'OPEN FACE CHANNEL',
    'SQUARE TUBING',
    'HOT ROLLED STRIP',
    'PLATE',
    'BASE ANGLE',
    'R-PANEL GALVALUME',
    'R-PANEL COLOR',
    'BUILDING TRIM',
    'BUILDING ACCESSORIES',
    'DOOR',
    'OTHER',
]

_TRIM_NAMES = {
    'corner': 'SCULPTURED CORNER',
    'rake': 'STANDARD RAKE TRIM',
    'ridge': 'RIDGE CAP FLAT',
    'jamb': 'DOOR JAMB TRIM',
    'head': 'DOOR HEAD TRIM',
    'cap': 'CAP TRIM',
    'eave': 'EAVE TRIM',
    'base': 'BASE TRIM',
    'sill': 'SILL TRIM',
    'transition': 'TRANSITION TRIM',
}


def _developed_lb_ft(depth, flange, lip, gauge=14):
    t = GA_THICKNESS.get(gauge, 0.0747)
    return (depth + 2 * flange + 2 * lip) * t * STEEL_LB_FT_PER_IN2


def _classify(row, part, items):
    """(material type, size, unit, lb/ft or None, panel color class) in the
    supplier's quotation vocabulary."""
    mat = str(row.get('material') or '')
    cat = str(row.get('category') or '')
    head = _strip_supplier_prefix(mat.split(' / ')[0].split(' — ')[0].strip())
    finish = str(row.get('finish') or '')
    if 'panel' in mat or head in ('PBR', 'PBU'):
        color = 'GALVALUME' if 'galvalume' in (mat + finish).lower() else 'COLOR'
        return ('R-PANEL ' + color, '26GA X 38.2500"', 'CSF', None)
    if cat == 'trim':
        role = ''
        low = mat.lower()
        for k, v in _TRIM_NAMES.items():
            if k in low or v.lower() in low:
                role = v
                break
        if not role:
            label = mat.split(' — ', 1)[1].split(' / ')[0].upper() if ' — ' in mat else part
            role = label[:28]
        return ('BUILDING TRIM', role, 'FT', None)
    m = re.match(r'W(\d+)X([\d.]+)', head)
    if m:
        return ('WIDE FLANGE BEAM', f'{m.group(1)} X {float(m.group(2)):g}#', 'CWT', float(m.group(2)))
    m = re.search(r'HSS\s*([\d.]+)\s*[xX]\s*([\d.]+)\s*x\s*(\d+)\s*ga', mat, re.I)
    if m:
        a, b, ga = float(m.group(1)), float(m.group(2)), int(m.group(3))
        t = GA_THICKNESS.get(ga, 0.12)
        area = a * b - (a - 2 * t) * (b - 2 * t)
        return ('SQUARE TUBING', f'{a:g} X {b:g} X {ga} GA', 'CWT', area * STEEL_LB_FT_PER_IN2)
    m = re.match(r'SS(\d)(\d)14', head)  # open face channel SS6214 -> 6-3/16 x 2 x 14 ga
    if m:
        depth = int(m.group(1)) + int(m.group(2)) / 16
        return (
            'OPEN FACE CHANNEL',
            f'{m.group(1)}-{int(m.group(2))}/16 X 2 X 14 GA',
            'CWT',
            _developed_lb_ft(depth, 2.0, 0.0),
        )
    m = re.match(r'PN(\d+)ZEE', head)
    if m:
        d = float(m.group(1))
        return ('COLD FORMED PURLIN', f'{d:g} X 2.5 .075 NOM ZEE', 'CWT', _developed_lb_ft(d, 2.5, 0.75))
    m = re.match(r'PN(\d+)SSES', head)
    if m:
        d = float(m.group(1))
        return ('COLD FORMED PURLIN', f'{d:g} X 2.5 .075 NOM ES', 'CWT', _developed_lb_ft(d, 2.5, 0.75))
    m = re.match(r'PN(\d+)', head)
    if m:
        d = float(m.group(1))
        return ('COLD FORMED PURLIN', f'{d:g} X 2 X .075 NOM', 'CWT', _developed_lb_ft(d, 2.0, 0.75))
    if head.startswith('CAB'):
        # base angle is a secondary: priced by weight like the rest (owner 0.8.57);
        # 2 x 4 x 3/16 angle assumed at 3.7 lb/ft, see Notes
        return ('BASE ANGLE', 'CAB1 2 X 4', 'CWT', 3.7)
    if cat in ('plate', 'flat_bar'):
        return ('PLATE', head[:30], 'CWT', None)
    if cat in ('clip', 'finished_clip', 'hardware') or head.startswith('PC'):
        return ('BUILDING ACCESSORIES', head[:30], 'EA', None)
    if 'door' in cat or 'DOOR' in mat.upper():
        return ('DOOR', head[:30], 'EA', None)
    return ('OTHER', head[:30], 'EA', None)


def _plate_weight_lb(mat):
    m = re.search(r'PL\s+([0-9/ ]+)"?\s*x\s*([0-9/ ]+)"?\s*x\s*([0-9\'\-/ ]+)', mat)
    if not m:
        return None

    def num(tok):
        tok = tok.replace("'", ' ').strip()
        total = 0.0
        for q in tok.split():
            if '/' in q:
                a, b = q.split('/')
                total += float(a) / float(b)
            elif q:
                total += float(q)
        return total

    try:
        thk = num(m.group(1))
        w = num(m.group(2))
        rest = m.group(3).strip()
        feet = 0.0
        inches = num(rest) if "'" not in rest else num(rest.split("'")[1]) if rest.split("'")[1].strip() else 0.0
        if "'" in rest:
            feet = float(rest.split("'")[0] or 0)
        length = feet * 12 + inches
        return thk * w * length * 0.2836
    except Exception:
        return None


def pricing_rows(job, plan=None):
    """One row per supplier-order line x length, classified and based for pricing."""
    p = plan or build(job)
    s = supplier_plan(job, p)
    by_order = {r['order_id']: r for r in p['items']}
    for r in s['rows']:
        r['order_ids_all'] = [x['internal_order_id'] for x in s['crosswalk'] if x['supplier_id'] == r['supplier_id']]
    traces = {}
    for t in p.get('piece_trace') or []:
        traces.setdefault(t['supplier_id'], []).append(str(t.get('location') or ''))
    out = []
    special_clips = 0
    for r in s['rows']:
        if _is_special_clip(r):
            special_clips += r['quantity']
            continue  # one full hot rolled strip, appended below (owner 0.8.57)
        items = [by_order[o] for o in r['order_ids_all'] if o in by_order]
        part = _supplier_part(r)
        mtype, size, unit, lb_ft = _classify(r, part, items)
        loc = _location(r, items, traces.get(r['supplier_id']) or [])
        for length in r['lengths']:
            qty = length['quantity']
            L = length['length_in']
            if unit == 'CWT':
                if lb_ft is not None and L:
                    basis = round(lb_ft * (L / 12) * qty, 1)
                elif r['category'] in ('plate', 'flat_bar'):
                    w = _plate_weight_lb(str(r.get('material') or ''))
                    basis = round(w * qty, 1) if w else ''
                else:
                    basis = ''
            elif unit == 'CSF':
                basis = round(qty * 38.25 * (L or 0) / 144, 2) if L else ''
            elif unit == 'FT':
                basis = round(qty * (L or 0) / 12, 2) if L else qty
            else:
                basis = qty
            out.append(
                dict(
                    lb_ft=lb_ft,
                    part_number=_part_marks(r, by_order, L),
                    material=mtype,
                    size=size,
                    description=part or size,
                    location=loc,
                    quantity=qty,
                    length=fmt(L) if L is not None else '',
                    length_in=round(L, 3) if L is not None else '',
                    unit=unit,
                    basis=basis,
                )
            )
    if special_clips:
        out.append(
            dict(
                lb_ft=2.55,
                part_number='SPECIAL CLIPS (ALL)',
                material='HOT ROLLED STRIP',
                size='3/16 X 4 X 20 FT',
                description='Special clips - one full strip',
                location='clips',
                quantity=1,
                length=fmt(240.0),
                length_in=240.0,
                unit='CWT',
                basis=51.0,  # 3/16 x 4 x 20 ft strip = 51 lb on the supplier quote
            )
        )
    return out


def _book_price(book_rows, material, size):
    """Stored unit price: exact Material+Size, else the Material-only price."""
    for m, s2, _u, price in book_rows:
        if m == material and s2 == size and price not in (None, ''):
            return price
    for m, s2, _u, price in book_rows:
        if m == material and not s2 and price not in (None, ''):
            return price
    return ''


def _size_order(material, size):
    """Human section order for editable material tables and dropdowns."""
    import re

    text = str(size or '').strip()
    if material == 'WIDE FLANGE BEAM':
        common = ('6 X 9#', '8 X 10#', '10 X 12#', '10 X 15#', '12 X 14#', '12 X 16#', '12 X 19#', '12 X 22#')
        normalized = re.sub(r'\s+', ' ', text.upper())
        if normalized in common:
            return (0, common.index(normalized), 0, normalized)
        match = re.search(r'(\d+)\s*X\s*([\d.]+)', normalized)
        return (1, int(match[1]), float(match[2]), normalized) if match else (2, 0, 0, normalized)
    if material == 'SQUARE TUBING':
        common = (
            'HSS 4X4 X 14 GA',
            'HSS 4X4 X 11 GA',
            'HSS 4X4 X 3/16',
            'HSS 4X6 X 14 GA',
            'HSS 4X6 X 11 GA',
            'HSS 4X6 X 3/16',
        )
        normalized = re.sub(r'\s+', ' ', text.upper())
        if normalized in common:
            return (0, common.index(normalized), 0, normalized)
        match = re.search(r'HSS\s*(\d+)X(\d+)', normalized)
        return (1, int(match[1]), int(match[2]), normalized) if match else (2, 0, 0, normalized)
    match = re.match(r'(\d+(?:[ -]\d+/\d+|\.\d+)?)', text)
    return (0, float(match[1].replace('-', '.')) if match else 999, text)


def _line_total(basis, price, unit):
    if basis in ('', None) or price in ('', None):
        return ''
    return round(basis * price / 100 if unit in ('CWT', 'CSF') else basis * price, 2)


def _cache_values(path, sheet_values):
    """Set standards-compliant cached formula results using XML nodes.

    The prior regex-based XML splice produced a workbook Excel sometimes repaired
    on open (sheet1.xml).  Parse and update the actual OOXML worksheet cell nodes,
    preserving the formulas while storing their initial result for immediate display.
    """
    import xml.etree.ElementTree as ET
    import zipfile

    NS = {
        'm': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
        'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
        'p': 'http://schemas.openxmlformats.org/package/2006/relationships',
    }
    ET.register_namespace('', NS['m'])
    ET.register_namespace('r', NS['r'])
    q = lambda ns, tag: '{' + NS[ns] + '}' + tag
    with zipfile.ZipFile(path, 'r') as src:
        blobs = {n: src.read(n) for n in src.namelist()}
    wb = ET.fromstring(blobs['xl/workbook.xml'])
    rels = ET.fromstring(blobs['xl/_rels/workbook.xml.rels'])
    relmap = {r.get('Id'): r.get('Target') for r in rels.findall(q('p', 'Relationship'))}
    targets = {}
    for sh in wb.findall('.//' + q('m', 'sheet')):
        rid = sh.get(q('r', 'id'))
        target = relmap.get(rid, '')
        if target.startswith('/'):
            path_in_zip = target.lstrip('/')
        elif target.startswith('worksheets/'):
            path_in_zip = 'xl/' + target
        else:
            path_in_zip = 'xl/' + target
        targets[sh.get('name')] = path_in_zip
    for sheet, values in sheet_values.items():
        target = targets.get(sheet)
        if target not in blobs:
            continue
        root = ET.fromstring(blobs[target])
        cells = {c.get('r'): c for c in root.findall('.//' + q('m', 'c'))}
        for coord, value in values.items():
            if value in ('', None):
                continue
            cell = cells.get(coord)
            if cell is None or cell.find(q('m', 'f')) is None:
                continue
            cached = cell.find(q('m', 'v'))
            if cached is None:
                cached = ET.SubElement(cell, q('m', 'v'))
            cached.text = format(float(value), '.15g')
        blobs[target] = ET.tostring(root, encoding='UTF-8', xml_declaration=False)
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as dst:
        for name, data in blobs.items():
            dst.writestr(name, data)


QUICK_TYPES = ['BEAM', 'PURLIN', 'OPEN FACE', 'TUBING', 'BASE ANGLE', 'RAKE ANGLE', 'SHEETS', 'TRIM']
QUICK_SIZES = {
    'BEAM': [
        'W6X9',
        'W8X10',
        'W10X12',
        'W10X15',
        'W12X14',
        'W12X16',
        'W12X19',
        'W12X22',
        'W8X13',
        'W12X26',
        'W14X22',
        'W16X26',
    ],
    'PURLIN': ['PN4', 'PN6', 'PN8', 'PN4ZEE', 'PN6ZEE', 'PN8ZEE', 'PN8SSES', 'PN10ZEE'],
    'OPEN FACE': ['SS4214', 'SS6214', 'SS8214', 'SS10214'],
    'TUBING': [
        'HSS 4X4 X 14 GA',
        'HSS 4X4 X 11 GA',
        'HSS 4X4 X 3/16',
        'HSS 4X6 X 14 GA',
        'HSS 4X6 X 11 GA',
        'HSS 4X6 X 3/16',
        'HSS 2X4 X 14 GA',
        'HSS 2X6 X 14 GA',
        'HSS 6X6 X 3/16',
    ],
    'BASE ANGLE': ['CAB1 2 X 4'],
    'RAKE ANGLE': ['2 X 2 X 3/16', '2 X 4 X 3/16'],
    'SHEETS': ['PBR 26GA GALVALUME', 'PBR 26GA COLOR', 'PBU 26GA GALVALUME', 'PBU 26GA COLOR'],
    'TRIM': [
        'STANDARD RAKE TRIM',
        'DOOR HEAD TRIM',
        'DOOR JAMB TRIM',
        'RIDGE CAP FLAT',
        'SCULPTURED CORNER',
        'EAVE TRIM',
        'BASE TRIM',
        'SILL TRIM',
    ],
}
QUICK_ROWS = [
    ('BEAM', 3),
    ('PURLIN', 5),
    ('OPEN FACE', 4),
    ('TUBING', 2),
    ('BASE ANGLE', 2),
    ('RAKE ANGLE', 2),
    ('SHEETS', 5),
    ('TRIM', 16),
]


def _quick_size_rows():
    """(size, price-book material, price-book size, lb/ft, width in) for Quick order."""
    out = []
    for sz in QUICK_SIZES['BEAM']:
        m = re.match(r'W(\d+)X([\d.]+)', sz)
        out.append((sz, 'WIDE FLANGE BEAM', f'{m.group(1)} X {float(m.group(2)):g}#', float(m.group(2)), ''))
    zee = {
        'PN4ZEE': (4, 2.5, 'ZEE'),
        'PN6ZEE': (6, 2.5, 'ZEE'),
        'PN8ZEE': (8, 2.5, 'ZEE'),
        'PN10ZEE': (10, 2.5, 'ZEE'),
        'PN4': (4, 2, ''),
        'PN6': (6, 2, ''),
        'PN8': (8, 2, ''),
        'PN8SSES': (8, 2.5, 'ES'),
    }
    for sz, (d, f, kind) in zee.items():
        psz = f'{d:g} X {f:g} .075 NOM' + (' ' + kind if kind else '')
        out.append((sz, 'COLD FORMED PURLIN', psz, _developed_lb_ft(d, f, 0.75), ''))
    chan = {'SS4214': 4.1875, 'SS6214': 6.1875, 'SS8214': 8.1875, 'SS10214': 10.1875}
    for sz, d in chan.items():
        whole = int(d)
        out.append(
            (
                sz,
                'OPEN FACE CHANNEL',
                f'{whole}-{int(round((d - whole) * 16))}/16 X 2 X 14 GA',
                _developed_lb_ft(d, 2.0, 0.0),
                '',
            )
        )
    tube = {
        'HSS 4X4 X 14 GA': (4, 4, 0.0747),
        'HSS 4X4 X 11 GA': (4, 4, 0.1196),
        'HSS 4X4 X 3/16': (4, 4, 0.1875),
        'HSS 4X6 X 14 GA': (4, 6, 0.0747),
        'HSS 4X6 X 11 GA': (4, 6, 0.1196),
        'HSS 4X6 X 3/16': (4, 6, 0.1875),
        'HSS 2X4 X 14 GA': (2, 4, 0.0747),
        'HSS 2X6 X 14 GA': (2, 6, 0.0747),
        'HSS 6X6 X 3/16': (6, 6, 0.1875),
    }
    from .tube_sections import weight_lb_ft as _tube_weight

    for sz, (a, b, t) in tube.items():
        out.append((sz, 'SQUARE TUBING', sz, _tube_weight(a, b, t), ''))
    out.append(('CAB1 2 X 4', 'BASE ANGLE', 'CAB1 2 X 4', 3.7, ''))
    for sz, (a, b) in {'2 X 2 X 3/16': (2, 2), '2 X 4 X 3/16': (2, 4)}.items():
        out.append((sz, 'HOT ROLLED STRIP', '', (a + b - 0.1875) * 0.1875 * STEEL_LB_FT_PER_IN2, ''))
    for sz in QUICK_SIZES['SHEETS']:
        out.append((sz, 'R-PANEL GALVALUME' if 'GALVALUME' in sz else 'R-PANEL COLOR', '26GA X 38.2500"', '', 38.25))
    for sz in QUICK_SIZES['TRIM']:
        out.append((sz, 'BUILDING TRIM', sz, '', ''))
    return out


def write_pricing_workbook(job, path, plan=None):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation

    p = plan or build(job)
    rows = pricing_rows(job, p)
    wb = Workbook()
    wb.calculation.fullCalcOnLoad = True
    ws = wb.active
    ws.title = 'Pricing'
    headers = [
        'Part number',
        'Material',
        'Size',
        'Description',
        'Location',
        'Quantity',
        'Length',
        'Length (in)',
        'Unit',
        'Basis (lb / sq ft / ft / ea)',
        'Unit price',
        'Line total',
    ]
    ws.append(
        [str(job.job_no) + ' | PRICING (prices stored from the Price book; edit the book and Excel updates this sheet)']
    )
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
    ws.append(headers)
    sizes_by_type = {}
    for r in rows:
        sizes_by_type.setdefault(r['material'], set()).add(r['size'])
    book_rows = list(PRICE_BOOK_SEED)
    additional_book_rows = []
    for mtype, sizes in sorted(sizes_by_type.items()):
        for size in sizes:
            if (mtype, size) not in {(m, s) for m, s, *_ in book_rows}:
                additional_book_rows.append((mtype, size, '', ''))
    additional_book_rows.sort(key=lambda row: (row[0], _size_order(row[0], row[1])))
    book_rows.extend(additional_book_rows)
    first = 3
    cached = {}
    for r in rows:
        ws.append(
            [
                r['part_number'],
                r['material'],
                r['size'],
                r['description'],
                r['location'],
                r['quantity'],
                r['length'],
                r['length_in'],
                r['unit'],
                r['basis'],
                None,  # unit price: stored from the Price book (live VLOOKUP)
                None,  # line total formula
            ]
        )
    last = max(ws.max_row, first - 1)
    subtotal = 0.0
    for i in range(first, last + 1):
        r = rows[i - first] if i - first < len(rows) else None
        ws.cell(i, 11).value = (
            f'=IFERROR(VLOOKUP($B{i}&"|"&$C{i},\'Price book\'!$A:$F,6,FALSE),'
            f'IFERROR(VLOOKUP($B{i}&"|",\'Price book\'!$A:$F,6,FALSE),""))'
        )
        ws.cell(
            i, 12
        ).value = f'=IF(OR($K{i}="",$J{i}=""),"",ROUND(IF(OR($I{i}="CWT",$I{i}="CSF"),$J{i}*$K{i}/100,$J{i}*$K{i}),2))'
        if r is not None:
            price = _book_price(book_rows, r['material'], r['size'])
            total = _line_total(r['basis'], price, r['unit'])
            if price not in ('', None):
                cached[f'K{i}'] = float(price)
            if total not in ('', None):
                cached[f'L{i}'] = float(total)
                subtotal += float(total)
    foot = last + 2
    tax_rate = 8.25
    freight = 0.0
    tax = round((subtotal + freight) * tax_rate / 100, 2)
    order_amt = round(subtotal + freight + tax, 2)
    ws.cell(foot, 11).value = 'Material subtotal'
    ws.cell(foot, 12).value = f'=SUM(L{first}:L{max(last, first)})'
    cached[f'L{foot}'] = subtotal
    ws.cell(foot + 1, 11).value = 'Freight / processing'
    ws.cell(foot + 1, 12).value = freight
    ws.cell(foot + 2, 11).value = 'Tax rate %'
    ws.cell(foot + 2, 12).value = tax_rate
    ws.cell(foot + 3, 11).value = 'Tax'
    ws.cell(foot + 3, 12).value = f'=ROUND((L{foot}+L{foot + 1})*L{foot + 2}/100,2)'
    cached[f'L{foot + 3}'] = tax
    ws.cell(foot + 4, 11).value = 'ORDER AMT'
    ws.cell(foot + 4, 12).value = f'=L{foot}+L{foot + 1}+L{foot + 3}'
    cached[f'L{foot + 4}'] = order_amt
    ws.cell(foot + 6, 11).value = 'Markup %'
    ws.cell(foot + 6, 12).value = 0
    ws.cell(foot + 7, 11).value = 'Markup'
    ws.cell(foot + 7, 12).value = f'=ROUND(L{foot + 4}*L{foot + 6}/100,2)'
    cached[f'L{foot + 7}'] = 0.0
    ws.cell(foot + 8, 11).value = 'Labor'
    ws.cell(foot + 8, 12).value = 0
    ws.cell(foot + 9, 11).value = 'FINAL BUILDING PRICE'
    ws.cell(foot + 9, 12).value = f'=L{foot + 4}+L{foot + 7}+L{foot + 8}'
    cached[f'L{foot + 9}'] = order_amt
    for row in ws:
        for c in row:
            if isinstance(c.value, str):
                c.data_type = 's' if not c.value.startswith('=') else 'f'
            c.alignment = Alignment(wrap_text=True, vertical='top')
            if c.row <= 2:
                c.font = Font(bold=True, color='FFFFFF')
                c.fill = PatternFill('solid', fgColor='213D53')
    for i in range(foot, foot + 10):
        ws.cell(i, 11).font = Font(bold=True)
        ws.cell(i, 12).font = Font(bold=True)
    for col, w in enumerate((30, 20, 20, 18, 24, 10, 13, 11, 8, 16, 12, 13), 1):
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.freeze_panes = 'A3'
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0

    book = wb.create_sheet('Price book')
    book.append(['Key', 'Material', 'Size', 'Unit', 'Basis note', 'Unit price'])
    for mtype, size, unit, price in book_rows:
        book.append(
            [mtype + '|' + size, mtype, size, unit, 'per ' + unit if unit else 'add a price and unit here', price]
        )
    for row in book:
        for c in row:
            if isinstance(c.value, str):
                c.data_type = 's'
            c.alignment = Alignment(wrap_text=True, vertical='top')
            if c.row == 1:
                c.font = Font(bold=True, color='FFFFFF')
                c.fill = PatternFill('solid', fgColor='213D53')
    for col, w in enumerate((34, 22, 22, 8, 22, 12), 1):
        book.column_dimensions[get_column_letter(col)].width = w
    book.column_dimensions['A'].hidden = True

    _conversions_sheet(wb, rows, book_rows)
    _quick_order_sheet(wb, DataValidation)
    _pricing_validations(wb, ws, sizes_by_type, first, last, DataValidation)
    notes = wb.create_sheet('Notes')
    notes.append(['How this workbook works'])
    notes.append(
        [
            'Pricing: every field is filled at the start (stored unit prices and line totals). Unit price is a live '
            'lookup into the Price book, so editing the Price book updates the Pricing sheet in Excel; the values '
            'are also stored in the file so the total shows before any recalculation. Weights: W sections at their '
            'lb/ft on the ORDER (stock) length, cold-formed from developed width at 14 ga, plate from volume, base '
            'angle CAB1 as a 2 x 4 x 3/16 angle at 3.7 lb/ft. Sheets basis uses the 38.25 in gross width. Special '
            'clips are figured as one full hot rolled strip (3/16 x 4 x 20 ft, 51 lb). Fill Markup % and Labor to '
            'reach the FINAL BUILDING PRICE. Quick order is a blank standard order sheet with dropdowns.'
        ]
    )
    notes.column_dimensions['A'].width = 130
    wb.save(path)
    _cache_values(path, {'Pricing': cached})
    return str(path)


def _conversions_sheet(wb, rows, book_rows):
    """Price-per-foot calculator for every CWT and CSF item (owner 0.8.57)."""
    from openpyxl.styles import Alignment, Font, PatternFill

    ws = wb.create_sheet('Conversions')
    ws.append(['PRICE PER FOOT CALCULATOR - type a price in the yellow cells'])
    ws.append(['CWT price ($ per 100 lb)', 140, '-> $ per lb', '=ROUND(B2/100,4)'])
    ws.append(
        [
            'CSF price ($ per 100 sq ft)',
            128,
            '-> $ per sq ft',
            '=ROUND(B3/100,4)',
            '-> $ per lin ft (38.25 in gross)',
            '=ROUND(B3/100*38.25/12,4)',
            '-> $ per lin ft (36 in cover)',
            '=ROUND(B3/100*3,4)',
        ]
    )
    ws.append([])
    ws.append(['Material', 'Size', 'lb/ft', 'Unit price (book)', '$ per ft'])
    seen = set()
    y = 6
    for r in rows:
        if r['unit'] != 'CWT' or not r.get('lb_ft'):
            continue
        key = (r['material'], r['size'])
        if key in seen:
            continue
        seen.add(key)
        price = _book_price(book_rows, r['material'], r['size'])
        ws.append(
            [
                r['material'],
                r['size'],
                round(r['lb_ft'], 2),
                price,
                f'=IF(OR(C{y}="",D{y}=""),"",ROUND(C{y}*D{y}/100,4))',
            ]
        )
        y += 1
    ws.append([])
    ws.append(['Material', 'Size', 'sq ft per lin ft', 'Unit price (book)', '$ per lin ft'])
    y += 1
    seen = set()
    for r in rows:
        if r['unit'] != 'CSF':
            continue
        key = (r['material'], r['size'])
        if key in seen:
            continue
        seen.add(key)
        price = _book_price(book_rows, r['material'], r['size'])
        ws.append(
            [
                r['material'],
                r['size'],
                round(38.25 / 12, 4),
                price,
                f'=IF(OR(C{y}="",D{y}=""),"",ROUND(C{y}*D{y}/100,4))',
            ]
        )
        y += 1
    for row in ws:
        for c in row:
            if isinstance(c.value, str):
                c.data_type = 's' if not c.value.startswith('=') else 'f'
            c.alignment = Alignment(wrap_text=True, vertical='top')
            if c.row in (1, 5):
                c.font = Font(bold=True)
    for cell in ('B2', 'B3'):
        ws[cell].fill = PatternFill('solid', fgColor='FFF3B0')
    for col, w in enumerate((24, 22, 14, 16, 14, 22, 14), 1):
        from openpyxl.utils import get_column_letter

        ws.column_dimensions[get_column_letter(col)].width = w


def _pricing_validations(wb, ws, sizes_by_type, first, last, DataValidation):
    """Use named ranges on the hidden reference sheet, not fragile inline lists.

    Inline dropdown strings break when values contain commas or quote characters
    (common in plate/HSS dimensions) and Excel strips the sheet validations while
    repairing the workbook. Named ranges also keep the Material -> Size list dynamic.
    """
    import re

    from openpyxl.utils import get_column_letter
    from openpyxl.workbook.defined_name import DefinedName

    ref = wb['QuickSizes']
    col = 7  # G onward is separate from the A:E Quick order lookup table.

    def add_list(name, values):
        nonlocal col
        values = list(values) or ['']
        letter = get_column_letter(col)
        ref.cell(1, col).value = name
        for row, value in enumerate(values, 2):
            ref.cell(row, col).value = value
        wb.defined_names.add(DefinedName(name, attr_text=f"'QuickSizes'!${letter}$2:${letter}${len(values) + 1}"))
        col += 1

    def token(value):
        return re.sub(r'[^A-Za-z0-9_]', '_', value).upper()

    add_list('PricingMaterialTypes', MATERIAL_TYPES)
    add_list('PricingUnitTypes', ('CWT', 'CSF', 'FT', 'EA'))
    for mtype in MATERIAL_TYPES:
        sizes = sorted((x for x in sizes_by_type.get(mtype, set()) if x), key=lambda x: _size_order(mtype, x))
        add_list('PricingSize_' + token(mtype), sizes)

    if last < first:
        return
    dv_mat = DataValidation(type='list', formula1='=PricingMaterialTypes', allow_blank=True)
    dv_unit = DataValidation(type='list', formula1='=PricingUnitTypes', allow_blank=True)
    dv_size = DataValidation(
        type='list',
        formula1='=INDIRECT("PricingSize_"&SUBSTITUTE(SUBSTITUTE(SUBSTITUTE($B3," ","_"),"-","_"),"/","_"))',
        allow_blank=True,
    )
    for dv in (dv_mat, dv_unit, dv_size):
        ws.add_data_validation(dv)
    dv_mat.add(f'B{first}:B{last}')
    dv_unit.add(f'I{first}:I{last}')
    dv_size.add(f'C{first}:C{last}')


def _quick_order_sheet(wb, DataValidation):
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    size_rows = _quick_size_rows()
    ref = wb.create_sheet('QuickSizes')
    ref.append(['Size', 'Material', 'PriceSize', 'LbFt', 'WidthIn'])
    for row in size_rows:
        ref.append(list(row))
    ref.sheet_state = 'hidden'
    nref = ref.max_row
    ws = wb.create_sheet('Quick order')
    headers = [
        'Type',
        'Size',
        'Quantity',
        'Length (in)',
        'Unit',
        'Basis (lb / sq ft / ft / ea)',
        'Unit price',
        'Line total',
    ]
    ws.append(['QUICK ORDER - blank standard order sheet (choose Type and Size, type Quantity and Length in inches)'])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
    ws.append(headers)
    y = 3
    starts = {}
    for typ, count in QUICK_ROWS:
        starts[typ] = y
        for _ in range(count):
            ws.append([typ, '', '', '', None, None, None, None])
            ws.cell(
                y, 5
            ).value = f'=IF(OR(A{y}="BEAM",A{y}="PURLIN",A{y}="OPEN FACE",A{y}="TUBING",A{y}="BASE ANGLE",A{y}="RAKE ANGLE"),"CWT",IF(A{y}="SHEETS","CSF",IF(A{y}="TRIM","FT","EA")))'
            ws.cell(y, 6).value = (
                f'=IF(OR(C{y}="",D{y}=""),"",IF(E{y}="CWT",ROUND(C{y}*D{y}/12*IFERROR(VLOOKUP(B{y},QuickSizes!$A$2:$E${nref},4,FALSE),0),1),'
                f'IF(E{y}="CSF",ROUND(C{y}*D{y}/144*38.25,2),IF(E{y}="FT",ROUND(C{y}*D{y}/12,2),C{y}))))'
            )
            ws.cell(y, 7).value = (
                f'=IF(B{y}="","",IFERROR(VLOOKUP(IFERROR(VLOOKUP(B{y},QuickSizes!$A$2:$E${nref},2,FALSE),"")&"|"&IFERROR(VLOOKUP(B{y},QuickSizes!$A$2:$E${nref},3,FALSE),""),\'Price book\'!$A:$F,6,FALSE),'
                f'IFERROR(VLOOKUP(IFERROR(VLOOKUP(B{y},QuickSizes!$A$2:$E${nref},2,FALSE),"")&"|",\'Price book\'!$A:$F,6,FALSE),"")))'
            )
            ws.cell(
                y, 8
            ).value = f'=IF(OR(G{y}="",F{y}=""),"",ROUND(IF(OR(E{y}="CWT",E{y}="CSF"),F{y}*G{y}/100,F{y}*G{y}),2))'
            y += 1
    last = y - 1
    ws.cell(last + 2, 7).value = 'Quick order subtotal'
    ws.cell(last + 2, 8).value = f'=SUM(H3:H{last})'
    dv_type = DataValidation(type='list', formula1='"' + ','.join(QUICK_TYPES) + '"', allow_blank=True)
    ws.add_data_validation(dv_type)
    dv_type.add(f'A3:A{last}')
    for typ, sizes in QUICK_SIZES.items():
        dv = DataValidation(type='list', formula1='"' + ','.join(sizes) + '"', allow_blank=True)
        ws.add_data_validation(dv)
        for i in range(starts[typ], starts[typ] + dict(QUICK_ROWS)[typ]):
            dv.add(ws.cell(i, 2))
    for row in ws:
        for c in row:
            if isinstance(c.value, str):
                c.data_type = 's' if not c.value.startswith('=') else 'f'
            c.alignment = Alignment(wrap_text=True, vertical='top')
            if c.row <= 2:
                c.font = Font(bold=True, color='FFFFFF')
                c.fill = PatternFill('solid', fgColor='213D53')
    ws.cell(last + 2, 7).font = Font(bold=True)
    ws.cell(last + 2, 8).font = Font(bold=True)
    for col, w in enumerate((14, 22, 10, 12, 8, 18, 12, 13), 1):
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.freeze_panes = 'A3'
