"""User-requested nominal six-inch strut, NOT an invented MBCI product."""

SOURCE = dict(revision='USER NOMINAL6in REQUEST / supplier section pending', url='', title='User eave strut reference')


def get(ident='USER-Eave-6-low_reference'):
    if ident not in ('USER-Eave-6-low_reference', 'USER-Eave-6-high_reference'):
        raise ValueError('Unknown user eave reference')
    return dict(
        id=ident,
        family='Eave',
        designation='USER6in EAVE STRUT / supplier shape and weight pending',
        nominal_depth_in=6.0,
        flanges_in=None,
        gauge=None,
        weight_lb_ft=None,
        finishes=['UNSPECIFIED', 'Red Oxide', 'Galvanized'],
        eave_kind='high_reference' if '-high_' in ident else 'low_reference',
        pdf_page=None,
        source_info=SOURCE,
        custom_reference=True,
        stock_weight_lb={},
        max_length_ft=None,
    )
