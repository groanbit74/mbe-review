"""Explicit layout options, not engineering or connection design."""

import copy
import math

from .connections import f
from .model import D


def equal_stations(end, origin=0):
    """Grid-rounded intermediate centers; leave the supplied endpoint fixed.
    Reserve 1/16 for rounding so no resulting interval exceeds 60 inches.
    """
    total = end - origin
    if total <= 0:
        raise ValueError('Automatic roof spacing needs a positive eave-to-end span')
    count = max(1, math.ceil((total + 1 / 16) / 60))
    return [round((origin + total * i / count) * 16) / 16 for i in range(1, count)]


def validate(p):
    if p.auto_roof_spacing and not p.auto_connections:
        raise ValueError("Equal roof spacing requires managed frame geometry")
    if p.inset_for_bypass and (p.girt_mode != 'bypass' or f(p.girt_depth) <= 0):
        raise ValueError('Column bypass inset requires a positive WALL GIRT depth and bypass girts')
    if p.inset_for_bypass and not p.auto_connections:
        raise ValueError('Column inset requires managed frame geometry')
    if f(p.starting_run) < 0:
        raise ValueError('Starting wall run must be at or above floor zero')
    if p.slab and not p.starting_wall_run:
        raise ValueError('Slab requires the starting wall run')
    if p.slab:
        from .secondary_catalog import get

        a = get(p.base_angle.get('profile_id', 'MBCI-Angle-2x4-G14'))
        if a['id'] not in (
            'MBCI-Angle-2x4-G14',
            'MBCI-Angle-2x4-G16',
            'SSS-CAB1',
            'SSS-CAB125',
            'SSS-CAB1GALV',
            'SSS-CAB125GALV',
        ):
            raise ValueError('Slab base requires a catalog 2x4 angle')
        finish = p.base_angle.get('finish', 'Red Oxide')
        if finish not in a['finishes']:
            raise ValueError('Base angle finish is unavailable')
        p.base_angle = dict(profile_id=a['id'], finish=finish)


def geometry_params(p):
    q = copy.deepcopy(p)
    if p.connection_style == 'bolted' and p.inset_for_bypass:
        q.width = p.width - p.girt_depth * 2
        q.eave_height = p.eave_height + p.girt_depth * (p.slope_rise / 12)
        if f(q.width) <= 0:
            raise ValueError('Girt-depth insets consume wall width')
    return q


def finish(job, p):
    from .frame import dependency_key, grid16

    l = job.settings.get('frame_layouts', {}).get(p.column_mark)
    if not l:
        return
    if p.connection_style == 'bolted' and p.inset_for_bypass:
        inset = f(p.girt_depth)
        m = float(p.slope_rise) / 12
        for c in l['columns']:
            c['x0'] += inset
            c['x1'] += inset
        for r in l['rafters']:
            for key in ('top_start', 'top_end'):
                r[key][0] += inset
        for c in l['connections']:
            c['x'] += inset
        l['width_in'] = f(p.width)
        l['inset_in'] = inset
        l['low_eave_in'] -= inset * m
        l['high_eave_in'] = l['low_eave_in'] + f(p.width) * m if p.frame_type == 'monoslope' else l['low_eave_in']
        l['roof_left_in'] -= inset * m
        l['datum'] = 'Fixed outside WALL lines; columns inset by WALL GIRT depth; floor zero'
    raf = job.assemblies[p.rafter_mark]
    if p.auto_roof_spacing:
        raf.derivation['first_purlin_formula'] = (
            'AUTO EQUAL: eave zero to peak (or last usable high-end row), maximum 5 ft; manual first/spacing ignored.'
        )
        l['roof_spacing_rule'] = raf.derivation['first_purlin_formula']
    l['starting_wall_runs'] = []
    if p.starting_wall_run:
        for c in l['columns']:
            if f(p.starting_run) >= min(c.get('top_y0', c['y1']), c.get('top_y1', c['y1'])):
                raise ValueError('Starting wall run must lie below column top')
            l['starting_wall_runs'].append(
                dict(
                    side=c['side'],
                    x=(
                        (0 if c['side'] == 'left' else l['width_in'])
                        if p.slab
                        else (c['x0'] if c['side'] == 'left' else c['x1'])
                    ),
                    elevation_in=f(p.starting_run),
                    role='base_angle' if p.slab else 'girt',
                    vertical_leg_in=2 if p.slab else None,
                    horizontal_leg_in=4 if p.slab else None,
                    status='Starting wall run: attachment/anchor design pending',
                )
            )
    for a in job.assemblies.values():
        if a.derivation.get('frame_id') != p.column_mark:
            continue
        a.derivation['params'] = p.to_json()
        if a.kind == 'COLUMN':
            col = next(x for x in l['columns'] if x['mark'] == a.mark)
            low = min(col.get('top_y0', col['y1']), col.get('top_y1', col['y1'])) - col['y0']
            a.derivation['column_low_cut_in'] = float(grid16(low))
            a.derivation['column_cut_datum'] = 'LOW POINT; long-point blank retained separately'
            col['shop_cut'] = D(grid16(low)).fmt()
            col['blank_length'] = a.main.cut_length.fmt()
            for row in l['schedule']:
                if row['mark'] == a.mark:
                    row['cut'] = col['shop_cut'] + ' LOW'
    params = p.to_json()
    params['dependency_key'] = dependency_key(job, p)
    job.settings['frames'][p.column_mark] = params


def draw_starting(c, a, layout):
    rows = layout.get('starting_wall_runs', [])
    if not rows:
        return
    from .drawing.canvas import S_NOTE

    for r in rows:
        x, y = r['x'], r['elevation_in']
        sign = 1 if r['side'] == 'left' else -1
        if r['role'] == 'base_angle':
            a.poly([(x, y + 2), (x, y), (x + sign * 4, y)], False, S_NOTE)
        else:
            a.line(x, y, x - sign * 6, y, S_NOTE)
    r = rows[0]
    c.ptext(
        110,
        132,
        ('SLAB: 2 x 4 BASE ANGLE (2 VERTICAL / 4 ON SLAB)' if r['role'] == 'base_angle' else 'STARTING SIDEWALL GIRT')
        + ' @ '
        + D(r['elevation_in']).fmt()
        + '; attachment/anchors pending.',
        9,
        style=S_NOTE,
    )
