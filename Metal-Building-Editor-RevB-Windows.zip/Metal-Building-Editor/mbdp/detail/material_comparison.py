"""Stock/custom alternatives, never two simultaneous supplier orders."""


def compare(gid, ds, stocks, c):
    from .ordering import pack

    head = ds[0]
    q = sum(d['quantity'] for d in ds)
    blank = sum(d['blank_length_in'] * d['quantity'] for d in ds)
    custom = blank
    r = dict(
        material_group=gid,
        profile=head['profile'],
        grade=head['grade'],
        finish=head['finish'],
        quantity=q,
        blank_length_in=blank,
        custom_ordered_length_in=custom,
        stock_ordered_length_in=None,
        stock_remnant_in=None,
        stock_kerf_in=None,
        stock_end_loss_in=None,
        stock_bars=None,
        stock_length_cuts=None,
        custom_shop_length_cuts=0,
        selected_purchase='stock',
        status='COMPARISON ONLY: supplier order uses STOCK. Select exact/custom to change purchasing; no price assumptions.',
    )
    if not stocks or any(d['blank_length_in'] + 2 * c['end_allowance_in'] > max(stocks) for d in ds):
        r['status'] = (
            'Stock cannot supply all blanks. Custom alternative shown; switch to exact/custom explicitly. Stock holds remain.'
        )
        return r
    if q > 2000:
        r['status'] = 'Stock search limit (>2000 blanks). Custom alternative shown; select it explicitly.'
        return r
    bars = pack(
        tuple(d['blank_length_in'] for d in ds for _ in range(d['quantity'])),
        tuple(stocks),
        c['kerf_in'],
        c['end_allowance_in'],
    )
    r.update(
        stock_ordered_length_in=sum(b['stock_length_in'] for b in bars),
        stock_remnant_in=sum(b['remnant_in'] for b in bars),
        stock_kerf_in=sum(b['kerf_loss_in'] for b in bars),
        stock_end_loss_in=sum(b['end_loss_in'] for b in bars),
        stock_bars=len(bars),
    )
    r['stock_length_cuts'] = sum(
        len(b['indices'])
        - 1
        + int(
            b['stock_length_in'] - b['end_loss_in'] - b['blank_length_in'] - (len(b['indices']) - 1) * c['kerf_in']
            > 1e-8
        )
        + (2 if c['end_allowance_in'] else 0)
        for b in bars
    )
    return r
