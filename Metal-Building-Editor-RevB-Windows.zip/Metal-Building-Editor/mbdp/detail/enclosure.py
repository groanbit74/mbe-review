"""Explicit sheeted / open choice for every wall of the main building (v0.8.35).

``cladding.wall_states`` = ``{left, right, front, rear: 'sheeted' | 'open'}``.

* Sidewalls are served through the bay-enclosure helpers (``bay_zones.framed`` /
  ``bay_zones.intervals``): an OPEN sidewall has no girt pieces, no base angle and no sheet
  surface (per-bay enclosure keeps precedence when it is switched on).
* End walls write the per-end ``enclosure`` of the end-wall model so the posts-and-rafter-only
  end wall, the rake/base angles and the sheet takeoff all agree.

Nothing is inferred: a missing map means every wall sheeted (the legacy behaviour) and
``cladding.walls = false`` (roof only) means every wall open - unless the map itself names a
SHEETED wall, which switches the wall takeoff on (the per-wall choice is authoritative, v0.8.39;
``wall_girts`` then supplies the girts).
"""

FACES = ('left', 'right', 'front', 'rear')
STATES = ('sheeted', 'open')
_END = {'front': 'front_end', 'rear': 'rear_end'}


def _cladding(p):
    c = getattr(p, 'cladding', None)
    return c if isinstance(c, dict) else {}


def apply(p):
    """Validate the map and push the end-wall states into the end-wall records.

    Runs first in ``generate_frame`` so the end-wall model sees the choice.  The map is
    completed from the end records when it is missing, so a generated job always carries an
    explicit state for all four walls.
    """
    c = _cladding(p)
    if not c:
        return
    raw = c.get('wall_states')
    ends = p.endwalls if isinstance(getattr(p, 'endwalls', None), dict) else {}
    if raw is None:
        raw = {}
        for face, end in _END.items():
            rec = ends.get(end)
            if isinstance(rec, dict) and rec.get('enclosure') in STATES:
                raw[face] = rec['enclosure']
    if not isinstance(raw, dict) or any(k not in FACES for k in raw) or any(raw[k] not in STATES for k in raw):
        raise ValueError('Wall states: left, right, front and rear are each "sheeted" or "open"')
    full = {k: raw.get(k, 'sheeted') for k in FACES}
    if c.get('enabled') and not c.get('walls', True):
        if any(raw.get(k) == 'sheeted' for k in FACES):
            # The per-wall choice is authoritative: a wall set SHEETED on a roof-only job switches
            # the wall takeoff on (v0.8.39) instead of being silently ignored.
            c['walls'] = True
            full = {k: raw.get(k, 'open') for k in FACES}
        else:
            full = {k: 'open' for k in FACES}
    zones = p.bay_zones if isinstance(getattr(p, 'bay_zones', None), dict) else {}
    if zones.get('enabled') and isinstance(zones.get('bays'), list):
        # Per-bay enclosure refines the sidewalls: an OPEN sidewall opens every bay on that
        # side; a SHEETED sidewall keeps the bay states (and is reported open only when no
        # bay on that side is sheeted).
        for side in ('left', 'right'):
            bays = [b for b in zones['bays'] if isinstance(b, dict)]
            if side in raw and raw[side] == 'open':
                for b in bays:
                    b[side] = 'open'
                    b[side + '_girts_now'] = False
            full[side] = 'sheeted' if any(b.get(side, 'sheeted') == 'sheeted' for b in bays) else 'open'
    c['wall_states'] = full
    if not ends.get('enabled'):
        return
    for face, end in _END.items():
        rec = ends.get(end)
        if rec is None:
            rec = ends[end] = {}
        if isinstance(rec, dict):
            rec['enclosure'] = full[face]


def states(p):
    """Resolved state for all four walls (``sheeted`` unless chosen otherwise)."""
    c = _cladding(p)
    raw = c.get('wall_states') or {}
    if c.get('enabled') and not c.get('walls', True):
        if any(raw.get(k) == 'sheeted' for k in FACES):
            return {k: raw.get(k, 'open') for k in FACES}
        return {k: 'open' for k in FACES}
    out = {k: raw.get(k, 'sheeted') for k in FACES}
    ends = p.endwalls if isinstance(getattr(p, 'endwalls', None), dict) else {}
    for face, end in _END.items():
        rec = ends.get(end)
        if isinstance(rec, dict) and rec.get('enclosure') in STATES and face not in raw:
            out[face] = rec['enclosure']
    return out


def is_open(p, face):
    return states(p).get(face) == 'open'


def label(face):
    from .building import name

    return name(face)
