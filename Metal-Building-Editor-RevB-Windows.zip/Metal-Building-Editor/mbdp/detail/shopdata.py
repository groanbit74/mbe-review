"""Review shop data, drawings, contours and reference plasma placement.

Legacy DSTV-style helper functions remain for regression tests only; ordinary
exports do NOT call them. No machine-specific post has been verified.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
from datetime import datetime, timezone
from decimal import Decimal

import ezdxf

from ..dims import Dim
from . import model as M
from . import sections
from .drawing import all_sheets, render_dxf, render_pdf, render_svg
from .drawing.sheet import usage

MM = 25.4


def _mm(d: Dim | float) -> str:
    v = float(d.inches) if isinstance(d, Dim) else float(d)
    return f"{v * MM:.2f}"


# --------------------------------------------------------------------------- lists
def cut_list_rows(job: M.Job) -> list[dict]:
    mains, _ = usage(job)
    rows = []
    seen = set()
    for a in job.assemblies.values():
        mm = a.main
        if mm.mark in seen:
            continue
        seen.add(mm.mark)
        w = job.weights.member(mm.sec.plf, mm.cut_length)
        used = [b.mark for b in job.assemblies.values() if b.main.mark == mm.mark]
        rows.append(
            {
                "cut_mark": mm.mark,
                "section": mm.section,
                "cut_length": M.D(a.derivation.get("column_low_cut_in", mm.cut_length.inches)).fmt(),
                "cut_length_in": f"{float(a.derivation.get('column_low_cut_in', mm.cut_length.inches)):.4f}",
                "cut_length_datum": "LOW POINT" if "column_low_cut_in" in a.derivation else "BLANK",
                "blank_length": mm.cut_length.fmt(),
                "qty": mains[mm.mark],
                "weight_each": f"{w}" if w is not None else "UNKNOWN",
                "weight_total": f"{(w * mains[mm.mark]).quantize(Decimal('0.01'))}" if w is not None else "UNKNOWN",
                "left_cut": mm.left_cut.type + (f" {mm.left_cut.angle:g}deg" if mm.left_cut.type == "bevel" else ""),
                "right_cut": mm.right_cut.type
                + (f" {mm.right_cut.angle:g}deg" if mm.right_cut.type == "bevel" else ""),
                "web_holes": sum(w.rows * w.cols for w in mm.web_holes),
                "used_in": " ".join(used),
            }
        )
    return rows


def plate_list_rows(job: M.Job) -> list[dict]:
    _, parts = usage(job)
    rows = []
    for mark, q in parts.items():
        p = job.part(mark)
        if p.kind not in ("plate", "clip"):
            continue
        w = p.weight(job.weights)
        rows.append(
            {
                "mark": mark,
                "kind": p.kind,
                "thk": p.thk.fmt(),
                "width": p.width.fmt(),
                "length": p.length.fmt(),
                "holes": len(p.holes),
                "hole_dia": p.hole_dia().fmt() if p.holes else "",
                "qty": q,
                "weight_each": f"{w}",
                "weight_total": f"{(w * q).quantize(Decimal('0.01'))}",
                "source": p.source,
                "notes": p.notes,
            }
        )
    return rows


def write_csv(rows: list[dict], path: str) -> str:
    with open(path, "w", newline="") as fh:
        if rows:
            w = csv.DictWriter(fh, fieldnames=list(dict.fromkeys(k for row in rows for k in row)))
            w.writeheader()
            w.writerows(rows)
    return path


# --------------------------------------------------------------------------- plate DXF 1:1
def plate_dxf(p: M.Part, path: str) -> str:
    if p.symbol.get("contour"):
        # Generated connection plates carry their finished contour; cut that, not the blank.
        from .contours import dxf as contour_dxf

        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        return contour_dxf(p, path, "inch")
    doc = ezdxf.new("R2013")
    doc.header["$INSUNITS"] = 1
    doc.layers.add("OUTLINE", color=7)
    doc.layers.add("HOLES", color=1)
    doc.layers.add("TEXT", color=3)
    msp = doc.modelspace()
    L, W = float(p.length.inches), float(p.width.inches)
    msp.add_lwpolyline([(0, 0), (L, 0), (L, W), (0, W)], close=True, dxfattribs={"layer": "OUTLINE"})
    for h in p.holes:
        msp.add_circle((float(h.x.inches), float(h.y.inches)), float(h.dia.inches) / 2, dxfattribs={"layer": "HOLES"})
    t = msp.add_text(
        f"{p.mark}  PL {p.thk.fmt()} x {p.width.fmt()} x {p.length.fmt()}",
        height=min(0.5, W / 6),
        dxfattribs={"layer": "TEXT"},
    )
    t.set_placement((L / 2, W / 2), align=ezdxf.enums.TextEntityAlignment.MIDDLE_CENTER)
    doc.saveas(path)
    return path


# --------------------------------------------------------------------------- DSTV-style NC1
def _st_header(
    job: M.Job,
    drawing: str,
    mark: str,
    qty: int,
    profile: str,
    code: str,
    length_in: float,
    height_in: float,
    width_in: float,
    tf_in: float,
    tw_in: float,
    weight_lb_per_ft: float,
    text: str,
) -> list[str]:
    kg_per_m = weight_lb_per_ft * 0.45359237 / 0.3048
    return [
        "ST",
        f"  {job.job_no}",  # order identification
        f"  {drawing}",  # drawing identification
        "  1",  # phase
        f"  {mark}",  # piece identification
        "  A992" if code == "I" else "  A36",  # steel grade (placeholder - set from job spec)
        f"  {qty}",
        f"  {profile}",
        f"  {code}",
        f"  {length_in * MM:.2f}",
        f"  {height_in * MM:.2f}",
        f"  {width_in * MM:.2f}",
        f"  {tf_in * MM:.2f}",
        f"  {tw_in * MM:.2f}",
        "  0.00",  # radius
        f"  {kg_per_m:.2f}",
        "  0.000",  # painting surface
        "  0.00",
        "  0.00",
        "  0.00",
        "  0.00",  # web/flange start/end cuts
        f"  {text}",
        "  ",
        "  ",
        "  ",
    ]


def plate_nc1(job: M.Job, p: M.Part, qty: int, path: str) -> str:
    L, W, T = float(p.length.inches), float(p.width.inches), float(p.thk.inches)
    plf = float(sections.STEEL_DENSITY_LB_PER_IN3) * W * T * 12
    lines = _st_header(
        job,
        p.mark,
        p.mark,
        qty,
        f"PL{p.thk.fmt().rstrip(chr(34))}x{p.width.fmt().rstrip(chr(34))}",
        "B",
        L,
        W,
        T,
        T,
        T,
        plf,
        f"{p.mark} {p.bom_description()}",
    )
    if p.holes:
        lines.append("BO")
        for h in p.holes:
            lines.append(
                f"  v  {float(h.x.inches) * MM:8.2f}u {float(h.y.inches) * MM:8.2f} {float(h.dia.inches) * MM:6.2f}"
            )
    lines += [
        "AK",
        f"  v  {0.0:8.2f}u {0.0:8.2f}  0.00",
        f"     {L * MM:8.2f}  {0.0:8.2f}  0.00",
        f"     {L * MM:8.2f}  {W * MM:8.2f}  0.00",
        f"     {0.0:8.2f}  {W * MM:8.2f}  0.00",
        f"     {0.0:8.2f}  {0.0:8.2f}  0.00",
        "EN",
    ]
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


def member_nc1(job: M.Job, a: M.Assembly, qty: int, path: str) -> str:
    mm = a.main
    s = mm.sec
    if s.kind != 'W':
        raise ValueError('Legacy NC helper supports W sections only; no channel or HSS machine post verified')
    L = float(mm.cut_length.inches)
    lines = _st_header(
        job, mm.mark, mm.mark, qty, s.name, "I", L, s.d, s.bf, s.tf, s.tw, float(s.plf), f"{mm.mark} {a.kind}"
    )
    holes = []
    for wh in mm.web_holes:
        for x, y in wh.positions():
            # DSTV web face 'v': x along member, y from the bottom of the profile
            holes.append((float(x.inches), s.d - float(y.inches), float(wh.dia.inches)))
    if holes:
        lines.append("BO")
        for x, y, dia in holes:
            lines.append(f"  v  {x * MM:8.2f}u {y * MM:8.2f} {dia * MM:6.2f}")
    if mm.left_cut.type == "bevel" or mm.right_cut.type == "bevel":
        lines.append(
            f"** end cuts: left {mm.left_cut.type} {mm.left_cut.angle:g} deg, right {mm.right_cut.type} {mm.right_cut.angle:g} deg"
        )
    lines.append("EN")
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return path


# --------------------------------------------------------------------------- package
def _write_text(path: str, text: str) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as fh:
        fh.write(text)
    return path


def _sha(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def export_package(job: M.Job, out_dir: str, issues: list[M.ModelIssue] | None = None, with_svg: bool = True) -> dict:
    """Write drawings (PDF/DXF/SVG), lists, plate DXF, NC files and a hashed manifest into ``out_dir``."""
    if os.path.isdir(os.path.join(out_dir, 'nc')) and os.listdir(os.path.join(out_dir, 'nc')):
        raise ValueError(
            'Export folder contains legacy NC files. Choose a fresh export folder; old files are not a machine release.'
        )
    os.makedirs(out_dir, exist_ok=True)
    for sub in ("drawings", "dxf", "svg", "plates_dxf", "nc"):
        os.makedirs(os.path.join(out_dir, sub), exist_ok=True)
    issues = issues if issues is not None else M.validate(job)
    sheets = all_sheets(job, issues)
    from .ordering import export_order_files

    files: list[str] = export_order_files(job, out_dir)
    files.append(
        render_pdf(sheets, os.path.join(out_dir, "drawings", f"{job.job_no}_shop_drawings.pdf"), f"Job {job.job_no}")
    )
    for sh in sheets:
        files.append(render_pdf([sh], os.path.join(out_dir, "drawings", f"{sh.name}.pdf"), sh.name))
        files.append(render_dxf(sh, os.path.join(out_dir, "dxf", f"{sh.name}.dxf")))
        if with_svg:
            p = os.path.join(out_dir, "svg", f"{sh.name}.svg")
            with open(p, "w") as fh:
                fh.write(render_svg(sh))
            files.append(p)
    files.append(write_csv(cut_list_rows(job), os.path.join(out_dir, "cut_list.csv")))
    files.append(write_csv(plate_list_rows(job), os.path.join(out_dir, "plate_list.csv")))
    moves = [
        dict(frame_id=a.mark, **row)
        for a in job.assemblies.values()
        for row in a.derivation.get('girt_clip_adjustments', [])
    ]
    if moves:
        files.append(write_csv(moves, os.path.join(out_dir, 'girt_clip_adjustments.csv')))
    secondary_rows = [row for a in job.assemblies.values() for row in a.derivation.get('secondary_material_rows', [])]
    if secondary_rows:
        files.append(write_csv(secondary_rows, os.path.join(out_dir, 'secondary_material_schedule.csv')))
        sp = os.path.join(out_dir, 'secondary_catalog_snapshot.json')
        with open(sp, 'w') as fh:
            json.dump(
                {
                    a.mark: a.derivation['secondary_catalog']
                    for a in job.assemblies.values()
                    if a.derivation.get('secondary_catalog')
                },
                fh,
                indent=2,
            )
        files.append(sp)
    additions = {
        a.mark: a.derivation['framing_additions']
        for a in job.assemblies.values()
        if a.derivation.get('framing_additions')
    }
    if additions:
        path = os.path.join(out_dir, 'framing_additions.json')
        with open(path, 'w') as fh:
            json.dump(additions, fh, indent=2)
        files.append(path)
        from .contours import export as export_clip_contour
        from .lean_connections import end_plate_part
        from .lean_connections import part as lean_clip_part

        for m in additions.values():
            for z in m['lean_tos']:
                ep = z.get('end_plate_geometry')
                if ep and ep['geometry_valid']:
                    files.extend(
                        export_clip_contour(job, end_plate_part(ep), os.path.join(out_dir, 'lean_end_plate_review'))
                    )
                for clip in z.get('flush_clips', []):
                    files.extend(
                        export_clip_contour(
                            job, lean_clip_part(clip['mark'], clip), os.path.join(out_dir, 'lean_clip_review')
                        )
                    )
        from .contours import export as export_low_part

        for fid, model in additions.items():
            for lean in model['lean_tos']:
                for rec in lean.get('low_connection_parts', []):
                    part = M.Part.from_json(rec['part'])
                    files.extend(export_low_part(job, part, os.path.join(out_dir, 'lean_low_review')))
        for filename, rows in [
            (
                'lean_high_connection_schedule.csv',
                [
                    dict(frame_id=fid, lean_to=z['id'], **r)
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    for r in z.get('high_connection_schedule', [])
                ],
            ),
            (
                'lean_end_plates.csv',
                [
                    dict(
                        frame_id=fid,
                        lean_to=z['id'],
                        **{
                            k: json.dumps(v) if isinstance(v, (dict, list)) else v
                            for k, v in z['end_plate_geometry'].items()
                        },
                    )
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    if z.get('end_plate_geometry')
                ],
            ),
            (
                'lean_flush_clips.csv',
                [
                    dict(
                        frame_id=fid,
                        lean_to=z['id'],
                        **{k: json.dumps(v) if isinstance(v, (dict, list)) else v for k, v in r.items()},
                    )
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    for r in z.get('flush_clips', [])
                ],
            ),
            (
                'lean_rafter_cut_planes.csv',
                [
                    dict(frame_id=fid, lean_to=z['id'], **z['rafter_cut_detail'])
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    if z.get('rafter_cut_detail')
                ],
            ),
            (
                'lean_low_connections.csv',
                [
                    dict(
                        frame_id=fid,
                        lean_to=z['id'],
                        **{
                            k: json.dumps(v) if isinstance(v, (dict, list)) else v
                            for k, v in z.get('low_connection_detail', {}).items()
                            if k != 'template_job'
                        },
                    )
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                ],
            ),
            (
                'lean_roof_purlins.csv',
                [
                    dict(frame_id=fid, lean_to=z['id'], **r)
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    for r in z.get('roof_purlin_layout', {}).get('pieces', [])
                ],
            ),
            (
                'lean_roof_purlin_rows.csv',
                [
                    dict(frame_id=fid, lean_to=z['id'], **r)
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    for r in z.get('roof_purlin_layout', {}).get('rows', [])
                ],
            ),
            (
                'lean_to_members.csv',
                [
                    dict(frame_id=fid, lean_to=z['id'], **r)
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    for r in z['members']
                ],
            ),
            (
                'lean_transition_trim.csv',
                [
                    dict(
                        frame_id=fid,
                        lean_to=z['id'],
                        piece=i + 1,
                        cut_length_in=L,
                        profile=z['transition_trim']['profile'],
                        material_gauge=z['transition_trim']['material_gauge'],
                        fabrication=z['transition_trim']['fabrication'],
                        status=z['transition_trim']['status'],
                    )
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    for i, L in enumerate(z['transition_trim']['pieces_in'])
                ],
            ),
            (
                'lean_to_holes.csv',
                [
                    dict(frame_id=fid, lean_to=z['id'], **r)
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    for r in z['holes']
                ],
            ),
            (
                'opening_connection_templates.csv',
                [
                    dict(
                        frame_id=fid,
                        opening=o['id'],
                        **{
                            k: json.dumps(v) if isinstance(v, (list, dict)) else v
                            for k, v in o['connection_detail'].items()
                        },
                    )
                    for fid, m in additions.items()
                    for o in m['openings']
                    if o.get('connection_detail')
                ],
            ),
            (
                'opening_girt_interruptions.csv',
                [dict(frame_id=fid, **r) for fid, m in additions.items() for r in m.get('girt_interruptions', [])],
            ),
            (
                'lean_transition_components.csv',
                [
                    dict(frame_id=fid, lean_to=z['id'], template=z['transition_detail']['template'], **r)
                    for fid, m in additions.items()
                    for z in m['lean_tos']
                    if z.get('transition_detail')
                    for r in z['transition_detail']['components']
                ],
            ),
            (
                'walk_door_slip_fit.csv',
                [
                    dict(frame_id=fid, opening=o['id'], **o['walk_slip_fit'])
                    for fid, m in additions.items()
                    for o in m['openings']
                    if o.get('walk_slip_fit')
                ],
            ),
            (
                'opening_members.csv',
                [
                    dict(frame_id=fid, opening=o['id'], **r)
                    for fid, m in additions.items()
                    for o in m['openings']
                    for r in o['members']
                ],
            ),
            (
                'opening_relocations.csv',
                [
                    dict(
                        frame_id=fid,
                        opening=o['id'],
                        face=o['face'],
                        requested_x_in=o['requested_x_in'],
                        x_in=o['x_in'],
                        status=o['status'],
                        issues=' / '.join(o['issues']),
                    )
                    for fid, m in additions.items()
                    for o in m['openings']
                ],
            ),
            (
                'sheet_base_supports.csv',
                [dict(frame_id=fid, **r) for fid, m in additions.items() for r in m.get('base_supports', [])],
            ),
            (
                'wall_girt_connections.csv',
                [
                    dict(frame_id=a.mark, **r)
                    for a in job.assemblies.values()
                    for r in a.derivation.get('wall_girt_connections', [])
                ],
            ),
            ('rake_angles.csv', [dict(frame_id=fid, **r) for fid, m in additions.items() for r in m['rake_angles']]),
        ]:
            if rows:
                safe = [
                    {
                        k: ("'" + v if isinstance(v, str) and v.lstrip().startswith(('=', '+', '-', '@')) else v)
                        for k, v in r.items()
                    }
                    for r in rows
                ]
                files.append(write_csv(safe, os.path.join(out_dir, filename)))
    building_models = {
        fid: l['building_geometry']
        for fid, l in job.settings.get('frame_layouts', {}).items()
        if l.get('building_geometry')
    }
    if building_models:
        path = os.path.join(out_dir, 'building_geometry.json')
        with open(path, 'w') as fh:
            json.dump(building_models, fh, indent=2)
        files.append(path)

    def oriented_row(row):
        from .building import code as face_code
        from .building import name as face_name

        r = dict(row)
        if 'surface' in r:
            r['legacy_surface_id'] = r['surface']
            r['surface'] = face_name(r['surface'])
        if r.get('kind') in ('wall', 'roof') and 'id' in r:
            r['legacy_surface_id'] = r['id']
            r['id'] = face_code(r['id'])
        if 'end' in r:
            r['legacy_end_id'] = r['end']
            r['end'] = face_name(r['end'])
        return r

    cladding_models = {
        a.mark: a.derivation['cladding'] for a in job.assemblies.values() if a.derivation.get('cladding')
    }
    if cladding_models:
        path = os.path.join(out_dir, 'cladding_layouts.json')
        with open(path, 'w') as fh:
            json.dump(cladding_models, fh, indent=2)
        files.append(path)
        for name, key in [
            ('panel_pieces', 'panels'),
            ('panel_order_schedule', 'groups'),
            ('trim_runs', 'trim_runs'),
            ('trim_pieces', 'trim_pieces'),
            ('trim_cut_list', 'trim_groups'),
            ('surface_summary', 'surfaces'),
        ]:
            rows = [
                dict(
                    frame_id=fid,
                    **{k: json.dumps(v) if isinstance(v, (dict, list)) else v for k, v in oriented_row(r).items()},
                )
                for fid, m in cladding_models.items()
                for r in m[key]
            ]
            if rows:
                files.append(write_csv(rows, os.path.join(out_dir, name + '.csv')))
        rows = [
            dict(frame_id=fid, **oriented_row(r)) for fid, m in cladding_models.items() for r in m['config']['openings']
        ]
        if rows:
            files.append(write_csv(rows, os.path.join(out_dir, 'opening_schedule.csv')))
        header_joint_rows = [
            oriented_row(
                dict(
                    frame_id=fid,
                    end='front_end' if o['face'] == 'front' else 'rear_end',
                    **joint,
                )
            )
            for fid, model in additions.items()
            for o in model['openings']
            for joint in o.get('header_end_joints', [])
        ]
        if header_joint_rows:
            files.append(write_csv(header_joint_rows, os.path.join(out_dir, 'endwall_header_end_joints.csv')))
    lean_clip_rows = [
        dict(frame_id=a.mark, lean_id=z['id'], **r)
        for a in job.assemblies.values()
        for z in a.derivation.get('framing_additions', {}).get('lean_tos', [])
        for r in z.get('roof_clip_schedule', [])
    ]
    if lean_clip_rows:
        files.append(write_csv(lean_clip_rows, os.path.join(out_dir, 'lean_roof_clips.csv')))
    end_models = {a.mark: a.derivation['endwalls'] for a in job.assemblies.values() if a.derivation.get('endwalls')}
    if end_models:
        path = os.path.join(out_dir, 'endwall_layouts.json')
        with open(path, 'w') as fh:
            json.dump(end_models, fh, indent=2)
        files.append(path)
        rows = [
            dict(frame_id=fid, **oriented_row(r))
            for fid, ends in end_models.items()
            for end in ends.values()
            for r in end['members']
        ]
        files.append(write_csv(rows, os.path.join(out_dir, 'endwall_members.csv')))
        clips = [
            dict(
                frame_id=fid,
                end=key,
                **{k: json.dumps(v) if isinstance(v, (dict, list)) else v for k, v in wall['ridge_face_clip'].items()},
            )
            for fid, ends in end_models.items()
            for key, wall in ends.items()
            if wall.get('ridge_face_clip')
        ]
        if clips:
            files.append(write_csv(clips, os.path.join(out_dir, 'endwall_ridge_face_clips.csv')))
        cuts = [
            dict(frame_id=fid, **oriented_row(dict(end=key, **r)))
            for fid, ends in end_models.items()
            for key, end in ends.items()
            for r in end['cuts']
        ]
        files.append(write_csv(cuts, os.path.join(out_dir, 'endwall_cut_list.csv')))
        rafter_cuts = []
        for fid, ends in end_models.items():
            for key, end in ends.items():
                for row in end.get('rafter_cut_planes', []):
                    rafter_cuts.append(
                        oriented_row(
                            dict(
                                frame_id=fid,
                                end=key,
                                mark=row['mark'],
                                profile_id=row['profile_id'],
                                start_end=row['start']['label'],
                                start_station_x_in=row['start']['station_x_in'],
                                start_plane=row['start']['plane'],
                                start_contact=row['start']['contact'],
                                start_status=row['start']['status'],
                                end_end=row['end']['label'],
                                end_station_x_in=row['end']['station_x_in'],
                                end_plane=row['end']['plane'],
                                end_contact=row['end']['contact'],
                                end_status=row['end']['status'],
                                top_line_span_in=row['top_line_span_in'],
                                long_blank_reference_in=row['long_blank_reference_in'],
                                section_depth_in=row['section_depth_in'],
                                plumb_depth_in=row['plumb_depth_in'],
                                cut_angle_from_square_deg=row['cut_angle_from_square_deg'],
                                geometry_status=row['geometry_status'],
                                fit_status=row['fit_status'],
                            )
                        )
                    )
        if rafter_cuts:
            files.append(write_csv(rafter_cuts, os.path.join(out_dir, 'endwall_rafter_cut_planes.csv')))
        head_contacts = []
        for fid, ends in end_models.items():
            for key, end in ends.items():
                for member in end['members']:
                    detail = member.get('head_contact_geometry')
                    if not detail:
                        continue
                    interfaces = detail.get('interfaces') or [None]
                    for index, interface in enumerate(interfaces, 1):
                        points = (interface or {}).get('post_head_cut_points_in') or [[], []]
                        support_points = (interface or {}).get('rafter_underside_points_in') or [[], []]
                        start = points[0] if points else []
                        finish = points[1] if len(points) > 1 else []
                        support_start = support_points[0] if support_points else []
                        support_finish = support_points[1] if len(support_points) > 1 else []
                        head_contacts.append(
                            oriented_row(
                                dict(
                                    frame_id=fid,
                                    end=key,
                                    post_mark=member['mark'],
                                    post_role=member['role'],
                                    post_profile_id=member['profile_id'],
                                    interface_index=index,
                                    rafter_mark=(interface or {}).get('rafter_mark', ''),
                                    contact_face=(interface or {}).get('contact_face', ''),
                                    start_x_in=start[0] if len(start) > 0 else '',
                                    start_y_in=start[1] if len(start) > 1 else '',
                                    end_x_in=finish[0] if len(finish) > 0 else '',
                                    end_y_in=finish[1] if len(finish) > 1 else '',
                                    rafter_start_x_in=support_start[0] if len(support_start) > 0 else '',
                                    rafter_start_y_in=support_start[1] if len(support_start) > 1 else '',
                                    rafter_end_x_in=support_finish[0] if len(support_finish) > 0 else '',
                                    rafter_end_y_in=support_finish[1] if len(support_finish) > 1 else '',
                                    maximum_plane_offset_in=(interface or {}).get('maximum_plane_offset_in', ''),
                                    nominal_plane_gap_in=(interface or {}).get('nominal_plane_gap_in', ''),
                                    interface_status=(interface or {}).get('geometry_status', ''),
                                    geometry_status=detail['geometry_status'],
                                    geometry_basis=detail['geometry_basis'],
                                    fit_status=detail['fit_status'],
                                )
                            )
                        )
        if head_contacts:
            files.append(write_csv(head_contacts, os.path.join(out_dir, 'endwall_post_head_contacts.csv')))
        head_schedule = [
            oriented_row(
                dict(
                    frame_id=fid,
                    end=key,
                    post_mark=member['mark'],
                    post_role=member['role'],
                    post_profile_id=member['profile_id'],
                    station_x_in=next(
                        (post['x'] for post in end.get('posts', []) if post['mark'] == member['mark']), ''
                    ),
                    connection_mode=member.get('head_connection_mode', ''),
                    connection_source=member.get('head_connection_source', ''),
                    connection_detail=member.get('head_connection', ''),
                    geometry_status=member.get(
                        'head_geometry_status', (member.get('head_contact_geometry') or {}).get('geometry_status', '')
                    ),
                )
            )
            for fid, ends in end_models.items()
            for key, end in ends.items()
            for member in end['members']
            if member.get('head_connection_mode')
        ]
        if head_schedule:
            files.append(write_csv(head_schedule, os.path.join(out_dir, 'endwall_post_head_schedule.csv')))
        receiver_rows = [
            oriented_row(
                dict(
                    frame_id=fid,
                    end=key,
                    member_mark=member['mark'],
                    member_role=member['role'],
                    profile_id=member['profile_id'],
                    **interface,
                )
            )
            for fid, ends in end_models.items()
            for key, end in ends.items()
            for member in end['members']
            for interface in member.get('girt_receiving_interfaces', [])
        ]
        if receiver_rows:
            files.append(write_csv(receiver_rows, os.path.join(out_dir, 'endwall_girt_receiving_faces.csv')))
        girt_contact_rows = [
            oriented_row(
                dict(
                    frame_id=fid,
                    end=key,
                    member_mark=member['mark'],
                    profile_id=member['profile_id'],
                    **contact,
                )
            )
            for fid, ends in end_models.items()
            for key, end in ends.items()
            for member in end['members']
            if member.get('role') == 'endwall girt'
            for contact in member.get('end_contact_geometry', [])
        ]
        if girt_contact_rows:
            files.append(write_csv(girt_contact_rows, os.path.join(out_dir, 'endwall_girt_contacts.csv')))
        base_contact_rows = [
            oriented_row(
                dict(
                    frame_id=fid,
                    end=key,
                    member_mark=member['mark'],
                    member_role=member['role'],
                    profile_id=member['profile_id'],
                    x_in=member['x0_in'],
                    **member['base_contact_geometry'],
                )
            )
            for fid, ends in end_models.items()
            for key, end in ends.items()
            for member in end['members']
            if member.get('base_contact_geometry')
        ]
        if base_contact_rows:
            files.append(write_csv(base_contact_rows, os.path.join(out_dir, 'endwall_base_contacts.csv')))
    run_models = {
        a.mark: a.derivation['secondary_runs'] for a in job.assemblies.values() if a.derivation.get('secondary_runs')
    }
    if run_models:
        path = os.path.join(out_dir, 'secondary_run_layouts.json')
        with open(path, 'w') as fh:
            json.dump(run_models, fh, indent=2)
        files.append(path)
        for name, key in [
            ('secondary_run_pieces', 'pieces'),
            ('secondary_run_cut_list', 'cuts'),
            ('secondary_run_stations', 'lanes'),
            ('end_support_references', 'support_lines'),
        ]:
            rows = [
                dict(frame_id=fid, **{k: v for k, v in r.items() if k != 'frame_id'})
                for fid, layout in run_models.items()
                for r in layout[key]
            ]
            files.append(write_csv(rows, os.path.join(out_dir, name + '.csv')))
    clips = []
    for a in job.assemblies.values():
        deriv = a.derivation
        if not deriv.get('first_purlin_formula'):
            continue
        clip = deriv['params']['purlin_clip']
        for i, att in enumerate([x for x in a.attachments if x.part == clip and x.station is not None], 1):
            clips.append(
                dict(
                    assembly=a.mark,
                    clip=clip,
                    index=i,
                    station_from_steel_cut=att.station.fmt(),
                    role='peak'
                    if att.note.startswith('peak ')
                    else 'starting'
                    if att.note.startswith('starting')
                    else 'regular',
                    datum='ridge_to_nearest_clip_edge_along_slope'
                    if att.note.startswith('peak ')
                    else deriv['first_purlin_datum'],
                    input_distance=str(deriv['peak_clip']['input_edge_in']) + ' in'
                    if att.note.startswith('peak ')
                    else deriv['first_purlin_input'],
                    bracket_occupied_slope_in=deriv['bracket_occupied_slope_in'],
                    formula=deriv['peak_clip']['datum']
                    + '; station rounded toward eave; actual edge '
                    + str(deriv['peak_clip']['actual_edge_in'])
                    + ' in'
                    if att.note.startswith('peak ')
                    else deriv['first_purlin_formula'],
                )
            )
        peak = deriv.get('peak_clip')
        if peak and peak.get('support') == 'apex':
            clips.append(
                dict(
                    assembly=a.mark,
                    clip=clip,
                    index='peak',
                    station_from_steel_cut=peak['station_from_cut'],
                    role='peak on apex',
                    datum='ridge_to_nearest_clip_edge_along_slope',
                    input_distance=str(peak['input_edge_in']) + ' in',
                    bracket_occupied_slope_in=deriv['bracket_occupied_slope_in'],
                    formula='APEX-mounted: ' + peak['datum'],
                )
            )
    if clips:
        files.append(write_csv(clips, os.path.join(out_dir, 'rafter_clip_schedule.csv')))
    checks = []
    bracket_clips = []
    for a in job.assemblies.values():
        for rec in a.derivation.get('clip_clearances', []):
            for check in rec['checks']:
                checks.append(
                    dict(
                        frame_id=a.derivation['frame_id'],
                        owner=rec['owner'],
                        role=rec['role'],
                        part=rec['part'],
                        datum=rec['datum'],
                        clip_low_in=rec['clip_low_in'],
                        clip_high_in=rec['clip_high_in'],
                        required_clearance_in=3,
                        **check,
                    )
                )
    for mark, cfg in job.settings.get('connections', {}).items():
        for rec in job.part(mark).symbol.get('roof_clips', []):
            bracket_clips.append(
                dict(
                    connection=mark,
                    role=rec['role'],
                    part=rec['part'],
                    mirror=rec['mirror'],
                    quantity_per_connection=rec['quantity'],
                    quantity_total=rec['quantity'] * int(cfg['qty']),
                    near_edge_in=0 if rec['role'] == 'starting' else rec['near_edge_in'],
                    center_station_in=rec['station_from_bracket_edge_in']
                    if rec['role'] == 'starting'
                    else rec['station_in'],
                    datum=rec['datum'],
                )
            )
    if checks:
        files.append(write_csv(checks, os.path.join(out_dir, 'clip_clearance_schedule.csv')))
    if bracket_clips:
        files.append(write_csv(bracket_clips, os.path.join(out_dir, 'connection_clip_schedule.csv')))
    layouts = job.settings.get('frame_layouts', {})
    if layouts:
        weld_rows = []
        for fid, layout in layouts.items():
            if layout.get('welded'):
                for col in layout['columns']:
                    weld_rows.append(
                        dict(
                            frame_id=fid,
                            column=col['mark'],
                            side=col['side'],
                            inset_in=layout['inset_in'],
                            low_column_top_in=min(col['top_y0'], col['top_y1']),
                            long_column_top_in=max(col['top_y0'], col['top_y1']),
                            rafter_top_at_low_column_side_in=min(col['top_y0'], col['top_y1'])
                            + (
                                0
                                if layout.get('welded_knee') == 'inside_flange'
                                else job.assemblies[layout['rafters'][0]['mark']].main.sec.d
                                * math.hypot(1, float(layout['slope_rise']) / 12)
                            ),
                            applied_plumb_depth_correction_in=layout.get('nominal_depth_correction_in', 0),
                            purlin_depth_in=layout['nominal_roof_purlin_depth_in'],
                            roof_eave_wall_in=layout['low_eave_in']
                            if col['side'] == 'left'
                            else layout['high_eave_in'],
                            depth_fit_difference_in=layout['nominal_depth_fit_difference_in'],
                        )
                    )
        if weld_rows:
            files.append(write_csv(weld_rows, os.path.join(out_dir, 'welded_elevation_schedule.csv')))
        lp = os.path.join(out_dir, 'frame_layouts.json')
        with open(lp, 'w') as fh:
            json.dump(layouts, fh, indent=2)
        files.append(lp)
        schedule = []
        for frame_id, layout in layouts.items():
            for entry in layout['schedule']:
                schedule.append(
                    dict(
                        frame_id=frame_id,
                        frame_type=layout['frame_type'],
                        **entry,
                        low_eave_in=layout['low_eave_in'],
                        high_eave_in=layout['high_eave_in'],
                    )
                )
        files.append(write_csv(schedule, os.path.join(out_dir, 'frame_assembly_schedule.csv')))

    mains, parts = usage(job)
    for mark, q in parts.items():
        p = job.part(mark)
        if p.kind in ("plate", "clip") and None not in (p.thk, p.width, p.length):
            files.append(plate_dxf(p, os.path.join(out_dir, "plates_dxf", f"{mark}.dxf")))
            if p.symbol.get("contour"):
                from .contours import export as export_contour

                files.extend(export_contour(job, p, os.path.join(out_dir, "plate_contours")))
            # No automatic legacy machine placeholders: no verified controller post.
    seen = set()
    no_nc = []
    for a in job.assemblies.values():
        if a.main.mark in seen:
            continue
        seen.add(a.main.mark)
        if a.main.sec.kind == 'W':
            files.append(
                member_nc1(job, a, mains.get(a.main.mark, a.qty), os.path.join(out_dir, "nc", f"{a.main.mark}.nc1"))
            )
        else:
            no_nc.append(f"{a.main.mark} ({a.main.section}: NC1 helper covers W sections only)")
    if no_nc:
        files.append(_write_text(os.path.join(out_dir, "nc", "NO_NC1_MEMBERS.txt"), "\n".join(no_nc) + "\n"))
    if any(p.symbol.get("plate_rule_generated") for p in job.parts.values()):
        from .plate_rules import EVIDENCE, VERSION, rules

        rp = os.path.join(out_dir, "plate_rules.json")
        with open(rp, "w") as fh:
            json.dump(
                {
                    "version": VERSION,
                    "rules": rules(job),
                    "evidence": EVIDENCE,
                    "status": "RULE-DERIVED - edit plate_rules on the job to change",
                },
                fh,
                indent=2,
            )
        files.append(rp)
        rows = []
        for mark, qty in parts.items():
            p = job.part(mark)
            ref = mark if p.symbol.get("plate_rule_generated") else p.symbol.get("plate_rule_ref")
            if not ref:
                continue
            src = job.part(ref)
            rows.append(
                dict(
                    part=mark,
                    qty=qty,
                    family=src.symbol['plate_family'],
                    rule_variant=ref,
                    size=p.bom_description(),
                    weld_leg=p.symbol.get('weld_size', ''),
                    members='; '.join(src.symbol['member_contexts']),
                    geometry_key=src.symbol['geometry_key'],
                    status=src.symbol['review_hold'],
                )
            )
        files.append(write_csv(rows, os.path.join(out_dir, "generated_plate_schedule.csv")))
    mp = os.path.join(out_dir, "model.json")
    with open(mp, "w") as fh:
        fh.write(job.dumps())
    files.append(mp)
    if job.settings.get("connections"):
        from .connections import connection_bom

        cp = os.path.join(out_dir, "connection_bom.csv")
        rows = []
        for mark, cfg in job.settings["connections"].items():
            p = job.part(mark)
            for line in connection_bom(job, mark):
                rows.append(
                    dict(
                        connection=mark,
                        part=line.part,
                        role=job.part(line.part).symbol.get("role", ""),
                        qty_per=line.qty,
                        connection_qty=cfg["qty"],
                        qty_total=line.qty * cfg["qty"],
                        status="PER MODEL REVISION " + job.revision(),
                    )
                )
            if p.symbol['interfaces']:
                rows.append(
                    dict(
                        connection=mark,
                        part=p.symbol["mate"],
                        role="loose rafter mating plates",
                        qty_per=p.symbol["interfaces"],
                        connection_qty=cfg["qty"],
                        qty_total=p.symbol["interfaces"] * cfg["qty"],
                        status="PER MODEL REVISION " + job.revision(),
                    )
                )
        files.append(write_csv(rows, cp))
        rp = os.path.join(out_dir, "CONNECTIONS_README.txt")
        with open(rp, "w") as fh:
            fh.write(
                "Connection plates: 1:1 finished contours (DXF/SVG/JSON/CSV) are in plate_contours; plates_dxf holds the cutting outline per plate.\n"
            )
            fh.write("Drawing DXFs are paper-space drawings, not cutting files.\n")
            fh.write(
                "Standalone connection quantities are additional; frame-managed connections are counted from the frame without duplicating mating plates.\n"
            )
            for mark in job.settings["connections"]:
                fh.write("\n" + mark + "\n" + "\n".join(job.part(mark).symbol["pending"]) + "\n")
        files.append(rp)
    ip = os.path.join(out_dir, "model_issues.json")
    with open(ip, "w") as fh:
        json.dump([i.to_json() for i in issues], fh, indent=2)
    files.append(ip)
    from .release_checks import report as release_report
    from .release_checks import sheets as release_sheets

    release = release_report(job)
    rp = os.path.join(out_dir, 'release_status.json')
    with open(rp, 'w') as fh:
        json.dump(release, fh, indent=2)
    files.append(rp)
    files.append(write_csv(release['blockers'], os.path.join(out_dir, 'release_blockers.csv')))
    rp = os.path.join(out_dir, 'release_checks.pdf')
    render_pdf(release_sheets(job, release), rp)
    files.append(rp)
    from .plasma_layout import export as export_plasma

    files.extend(export_plasma(job, out_dir))
    machine_note = os.path.join(out_dir, 'MACHINE_OUTPUT.txt')
    with open(machine_note, 'w') as fh:
        fh.write(
            'Plate DXF files are 1:1 finished contours without kerf compensation; plasma layouts are nest positions. '
            'Apply the machine post (kerf, feeds, lead-ins) in the CAM software.\n'
        )
    files.append(machine_note)
    files = list(dict.fromkeys(files))
    manifest = {
        'issue_status': release['issue_status'],
        'fabrication_releasable': release['fabrication_releasable'],
        'machine_releasable': release['machine_releasable'],
        'open_items': release['blocking_count'],
        "job": job.job_no,
        "customer": job.customer,
        "model_revision": job.revision(),
        "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "status": "BLOCKED - model errors" if M.has_errors(issues) else "OK",
        "sheets": [{"name": s.name, "kind": s.kind} for s in sheets],
        "files": [{"path": os.path.relpath(f, out_dir), "sha256": _sha(f)} for f in files],
    }
    with open(os.path.join(out_dir, "manifest.json"), "w") as fh:
        json.dump(manifest, fh, indent=2)
    return manifest
