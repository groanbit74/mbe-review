"""Condensed supplier view; internal allocation remains authoritative and separate.
Stock rows are consolidated; custom lengths retain marks. Finished clips are distinct from raw blanks.
"""

from .ordering import DEPARTMENTS, build, fmt, up


def supplier_plan(job, plan=None):
    p = plan or build(job)
    from .plasma_layout import collect

    pieces, _ = collect(job)
    geometry = {r['mark']: (r['thickness_in'], *sorted((up(r['width_in']), up(r['height_in'])))) for r in pieces}
    merged = {}
    crosswalk = []
    for r in p['items']:
        dep = r['department']
        material = r['material'] + (' / MARK ' + r['custom_mark'] if r.get('custom_mark') else '')
        basis = r['basis']
        blank = geometry.get(r['material'].split()[0]) if r['family'] in ('plate', 'clip') else None
        if blank:
            dep = 'Frame'
            material = 'PL ' + fmt(blank[0]) + ' x ' + fmt(blank[1]) + ' x ' + fmt(blank[2]) + ' rectangular blanks'
            basis = 'PLATE BLANKS (NOT NESTED SHEET)'
        # Different lengths share a supplier material line, but never lose their quantities.
        key = (
            dep,
            material,
            r['finish'],
            r['grade'],
            r['unit'],
            basis,
            r.get('supplier_status', ''),
            r.get('supplier_note', ''),
            r.get('supplier_name', ''),
            r.get('supplier_code', ''),
        )
        if key not in merged:
            merged[key] = dict(
                department=dep,
                material=material,
                finish=r['finish'],
                grade=r['grade'],
                unit=r['unit'],
                basis=basis,
                category='plate' if blank else r['family'],
                lengths={},
                quantity=0,
                notes=set(),
                order_ids=[],
                supplier=r.get('supplier_name', ''),
                supplier_code=r.get('supplier_code', ''),
                catalog_page=r.get('supplier_page'),
                supplier_label=r.get('supplier_label', '') if r.get('supplier_catalog_id') else '',
            )
        row = merged[key]
        row['notes'].add(r.get('supplier_status', ''))
        row['notes'].add(r.get('supplier_note', ''))
        row['quantity'] += r['quantity']
        row['lengths'][r['order_length_in']] = row['lengths'].get(r['order_length_in'], 0) + r['quantity']
        row['order_ids'].append(r['order_id'])
        if 'SUPPLY LENGTH HOLD' in r['status']:
            row['notes'].add(
                'Short/long panel lengths require supplier confirmation; proposed quantities included once.'
            )
        if blank:
            row['notes'].add('SHOP-CUT BLANK')
        elif r['family'] in ('plate', 'clip'):
            row['notes'].add('Fabricated specification not reduced to a flat blank; confirm before purchase.')
        if r['family'] == 'flat_bar':
            row['notes'].add('Shop shear plan; entered stock size/grade/finish. Not finished clips.')
        if r['family'] == 'finished_clip':
            row['notes'].add(
                'BUY FINISHED; match part drawing including holes/forming; no raw flat-bar quantity for these pieces.'
            )
        if r.get('custom_mark'):
            row['notes'].add('CUSTOM: exact ordered blank with piece mark; no shop stock-end allowance added.')
        if 'OWNER-FL1010-A4' in material:
            row['notes'].add('Custom formed section, not stock FL-1010; attach rake section drawing.')
    rows = sorted(
        merged.values(),
        key=lambda r: (
            DEPARTMENTS.index(r['department']),
            {
                'beam': 0,
                'hss': 1,
                'channel': 2,
                'purlin': 3,
                'plate': 5,
                'clip': 5,
                'flat_bar': 5,
                'finished_clip': 6,
                'hardware': 6,
                'door frame assembly': 7,
                'panel': 0,
                'trim': 1,
            }.get(r['category'], 4),
            r['material'],
            r['finish'],
            r['grade'],
            r['basis'],
        ),
    )
    for n, r in enumerate(rows, 1):
        r['supplier_id'] = 'S' + str(n).zfill(3)
        r['supplier_item'] = r.get('supplier_label') or r.get('supplier_code') or ''
        r['display_material'] = (
            r['supplier']
            + ' | '
            + (r['supplier_code'] + ' — ' if r['supplier_code'] else '')
            + r.pop('supplier_label')
            + ' | AS DRAWN: '
            + r['material']
            if r.get('supplier_label')
            else r['supplier'] + ' | ' + r['material']
        )
        r['lengths'] = [
            dict(length_in=L, quantity=q)
            for L, q in sorted(r['lengths'].items(), key=lambda x: -1 if x[0] is None else x[0])
        ]
        r['order_sizes'] = '; '.join(
            str(x['quantity']) + ' @ ' + fmt(x['length_in'])
            if x['length_in'] is not None
            else str(x['quantity']) + ' ' + r['unit']
            for x in r['lengths']
        )
        r['notes'] = ' '.join(sorted(filter(None, r['notes']), key=lambda n: (not n.startswith('Short/long'), n)))
        for oid in r.pop('order_ids'):
            crosswalk.append(dict(supplier_id=r['supplier_id'], internal_order_id=oid))
    assert sum(r['quantity'] for r in rows) == sum(r['quantity'] for r in p['items'])
    return dict(
        job_no=job.job_no,
        revision=job.revision(),
        rows=rows,
        crosswalk=crosswalk,
        unresolved_entries=len(p['pending']),
        note='PROPOSED supplier request. Confirm grade, finish, stock availability and special lengths. Unquantified requirements are not silently included; internal review register is separate. No prices or capacity approval.',
    )


def _strip_supplier_prefix(code):
    code = str(code or '').strip()
    for pre in ('SSS-', 'MBCI-'):
        if code.startswith(pre):
            return code[len(pre) :]
    return code


def _short_spec(material, category):
    """Short specification, e.g. 'PBR 26ga' (owner 0.8.55)."""
    mat = str(material or '')
    head = _strip_supplier_prefix(mat.split(' / ')[0].split(' — ')[0].strip())
    gauge = ''
    for tok in mat.replace('/', ' ').split():
        if tok.lower().endswith('ga'):
            gauge = tok.lower()
    if 'panel' in mat or head.endswith('PBR') or head.endswith('PBU'):
        prof = head.replace(' panel', '').strip()
        return (prof + ' ' + gauge).strip()
    if category == 'trim':
        return gauge
    if head.startswith(('PN', 'CAB', 'SS', 'TR')):
        return ''  # the catalog code in the part-number column carries the spec
    return head


def _trim_role(material):
    mat = str(material or '')
    label = mat.split(' — ', 1)[1].split(' / ')[0] if ' — ' in mat else ''
    for word, role in (
        ('Corner', 'Corner'),
        ('Rake', 'Rake'),
        ('Ridge', 'Ridge'),
        ('Eave', 'Eave'),
        ('Base', 'Base'),
        ('Jamb', 'Door jamb'),
        ('Head', 'Door head'),
        ('Sill', 'Sill'),
        ('Gutter', 'Gutter'),
        ('Transition', 'Transition'),
    ):
        if word.lower() in label.lower():
            return role
    return label[:24]


def _supplier_part(row):
    code = _strip_supplier_prefix(row.get('supplier_code') or '')
    mat = str(row.get('material') or '').split(' / ')[0].split(' — ')[0].strip()
    cand = _strip_supplier_prefix(mat.split()[0]) if mat.startswith(('SSS-', 'MBCI-')) else ''
    cand = cand.split('-low_single')[0].split('-high_single')[0]
    if cand and (not code or cand.startswith(code)):
        return cand  # full catalog code from the material, e.g. PN8ZEE-F2 not PN8ZEE
    return code  # blank when unspecified (owner 0.8.55)


def _part_marks(row, by_order, length_in='__any__'):
    marks = []
    for oid in row.get('order_ids_all') or []:
        it = by_order.get(oid)
        if not it:
            continue
        if length_in != '__any__' and it.get('order_length_in') != length_in:
            continue  # marks belong to their own length line, not the whole material
        if it.get('custom_mark'):
            marks.append(it['custom_mark'])
        mat = str(it.get('material') or '')
        if ' / MARK ' in mat:
            marks.append(mat.split(' / MARK ', 1)[1].strip())
        for tok in str(it.get('references') or '').split(';'):
            tok = tok.strip()
            if not tok or tok.startswith('STOCK-'):
                continue
            marks.append(tok.split(' cut ')[0].strip())
    out = []
    for m in marks:
        if m and m not in out:
            out.append(m)
    return ', '.join(out)


def _location(row, items, traces):
    text = ' '.join(str(it.get('references') or '') + ' ' + str(it.get('material') or '') for it in items)
    cat = str(row.get('category') or '')
    if cat == 'trim':
        role = _trim_role(row.get('material'))
        return {
            'Corner': 'corner trim',
            'Rake': 'rake trim',
            'Ridge': 'ridge',
            'Eave': 'eave trim',
            'Base': 'base trim',
        }.get(role, 'door trim' if 'Door' in role else 'trim')
    if 'panel' in str(row.get('material')):
        if 'ROOF' in text:
            return 'roof sheets'
        if 'SIDEWALL' in text:
            return 'side wall'
        if 'ENDWALL' in text:
            return 'end wall'
        return 'sheets'
    clean = [t for t in traces if t and not t.startswith('LOCATION REVIEW')]
    if clean:
        return clean[0].split(';')[0].split(', station')[0].strip()
    low = text.lower()
    if 'eave' in low:
        return 'eave strut'
    if 'girt' in low:
        return 'sidewall girt'
    if 'purlin' in low:
        return 'roof purlins'
    if cat in ('plate', 'clip'):
        return 'frame plates / clips'
    return {'Frame': 'main frame', 'Secondaries': 'secondaries', 'Sheets / Trim': 'sheets / trim'}.get(
        row.get('department'), ''
    )


def _is_special_clip(row):
    """Fabricated (special) clips, as opposed to catalog accessories: on the
    supplier order these are figured as ONE full hot rolled strip (owner 0.8.57)."""
    return str(row.get('category') or '') in ('clip', 'finished_clip') and not str(
        row.get('material') or ''
    ).startswith('#')


def write_supplier_workbook(job, path, plan=None):
    """The supplier order: one short line per part - drawing part number, quantity,
    length, supplier part number (no SSS-/MBCI- prefix, blank when unspecified),
    a short specification, a brief description and where it goes (owner 0.8.55)."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    p = plan or build(job)
    s = supplier_plan(job, p)
    by_order = {r['order_id']: r for r in p['items']}
    for r in s['rows']:
        r['order_ids_all'] = [x['internal_order_id'] for x in s['crosswalk'] if x['supplier_id'] == r['supplier_id']]
    traces = {}
    trace_marks = {}
    for t in p.get('piece_trace') or []:
        traces.setdefault(t['supplier_id'], []).append(str(t.get('location') or ''))
        trace_marks.setdefault((t['supplier_id'], t.get('blank_length_in')), []).append(str(t.get('cut_mark') or ''))
    wb = Workbook()
    wb.remove(wb.active)
    headers = [
        'Part number',
        'Quantity',
        'Length',
        'Length (in)',
        'Supplier part number',
        'Specification',
        'Description',
        'Location',
    ]
    special_clips = 0
    for dep in DEPARTMENTS:
        ws = wb.create_sheet(dep.replace(' / ', ' and '))
        ws.append([str(job.job_no) + ' | SUPPLIER ORDER'])
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
        ws.append(headers)
        for r in s['rows']:
            if r['department'] != dep:
                continue
            if _is_special_clip(r):
                special_clips += r['quantity']
                continue  # figured below as one full hot rolled strip (owner 0.8.57)
            items = [by_order[o] for o in r['order_ids_all'] if o in by_order]
            part = _supplier_part(r)
            if r['category'] == 'trim':
                desc = (part + ' - ' + _trim_role(r['material'])).strip(' -')
            else:
                _tr = [t for t in (traces.get(r['supplier_id']) or []) if not t.startswith('LOCATION REVIEW')]
                _segs = [q.strip() for t in _tr[:1] for q in t.split(';')]
                desc = next(
                    (
                        q.split(',')[0].strip()
                        for q in _segs
                        if any(k in q.lower() for k in ('column', 'rafter', 'purlin', 'girt', 'post', 'strut', 'angle'))
                    ),
                    _location(r, items, _tr),
                )
            for length in r['lengths']:
                ws.append(
                    [
                        _part_marks(r, by_order, length['length_in'])
                        or ', '.join(sorted(set(trace_marks.get((r['supplier_id'], length['length_in']), [])))),
                        length['quantity'],
                        fmt(length['length_in']) if length['length_in'] is not None else '',
                        round(length['length_in'], 3) if length['length_in'] is not None else '',
                        part,
                        _short_spec(r['material'], r['category']),
                        desc,
                        _location(r, items, traces.get(r['supplier_id']) or []),
                    ]
                )
        if dep == 'Secondaries' and special_clips:
            ws.append(
                [
                    'SPECIAL CLIPS (ALL)',
                    1,
                    fmt(240.0),
                    240.0,
                    '',
                    'HOT ROLLED STRIP',
                    'Special clips - one full strip',
                    'clips',
                ]
            )
        for row in ws:
            for c in row:
                if isinstance(c.value, str):
                    c.data_type = 's'
                c.alignment = Alignment(wrap_text=True, vertical='top')
                if c.row <= 2:
                    c.font = Font(bold=True, color='FFFFFF')
                    c.fill = PatternFill('solid', fgColor='213D53')
            ws.row_dimensions[row[0].row].height = 30 if row[0].row > 2 else 26
        for col, w in enumerate((34, 10, 14, 12, 20, 16, 26, 22), 1):
            ws.column_dimensions[get_column_letter(col)].width = w
        ws.freeze_panes = 'A3'
        ws.auto_filter.ref = f'A2:H{max(2, ws.max_row)}'
        ws.print_title_rows = '1:2'
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.orientation = 'landscape'
        ws.page_setup.paperSize = ws.PAPERSIZE_A3
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
    # One-page consolidated order: every department on one worksheet, with a simple
    # category heading between blocks (the original department sheets remain available).
    all_ws = wb.create_sheet('All items', 0)
    all_ws.append([str(job.job_no) + ' | SUPPLIER ORDER - ALL CATEGORIES'])
    all_ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
    all_ws.append(headers)
    for dep in DEPARTMENTS:
        source = wb[dep.replace(' / ', ' and ')]
        all_ws.append([dep.upper()])
        all_ws.merge_cells(start_row=all_ws.max_row, start_column=1, end_row=all_ws.max_row, end_column=len(headers))
        for source_row in source.iter_rows(min_row=3, values_only=True):
            if any(v not in (None, '') for v in source_row):
                all_ws.append(list(source_row))
    for row in all_ws:
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical='top')
            if cell.row in (1, 2) or (cell.column == 1 and cell.value in [d.upper() for d in DEPARTMENTS]):
                cell.font = Font(bold=True, color='FFFFFF')
                cell.fill = PatternFill('solid', fgColor='213D53' if cell.row in (1, 2) else '547386')
        all_ws.row_dimensions[row[0].row].height = 24 if row[0].row <= 2 else 30
    for col, w in enumerate((30, 8, 12, 10, 18, 15, 24, 19), 1):
        all_ws.column_dimensions[get_column_letter(col)].width = w
    all_ws.freeze_panes = 'A3'
    all_ws.sheet_properties.pageSetUpPr.fitToPage = True
    all_ws.page_setup.orientation = 'landscape'
    all_ws.page_setup.paperSize = all_ws.PAPERSIZE_A3
    all_ws.page_setup.fitToWidth = 1
    all_ws.page_setup.fitToHeight = 1
    all_ws.print_area = f'A1:H{all_ws.max_row}'
    all_ws.sheet_properties.pageSetUpPr.autoPageBreaks = False
    wb.active = 0
    wb.save(path)
    return str(path)
