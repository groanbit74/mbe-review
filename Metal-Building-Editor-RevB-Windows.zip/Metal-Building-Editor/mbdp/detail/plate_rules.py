"""Member-sized plate families. Geometric detailing proposals, not connection design.

B-8/B-10/B-14 and K-10/K-14 envelope sizes are documented. The extrapolation
formula and complete hole patterns are NOT dimensioned in those source sheets.
Generated parts remain review-held and carry the rule/provenance snapshot.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from fractions import Fraction

from . import sections
from .model import D, Part, rect_holes

VERSION = 'plate-families-3'
DEFAULT_WELD = '1/4"'
DEFAULTS = {
    'min_width': '6"',
    'width_allowance': '1"',
    'width_grid': '1/2"',
    'base_thk': '1/2"',
    'base_depth_allowance': '1/4"',
    'base_length_grid': '1/2"',
    'base_hole_dia': '13/16"',
    'base_first_row': '2 1/2"',
    'base_row_pitch': '3"',
    'base_transverse_edge': '1 1/2"',
    'connection_thk': '1/2"',
    'connection_extension': '7 1/4"',
    'connection_length_grid': '1/4"',
    'connection_hole_dia': '9/16"',
    'connection_end_edge': '2"',
    'connection_row_pitch': '3 1/2"',
    'connection_transverse_edge': '1 1/2"',
}
EVIDENCE = {
    'base_thk': 'SOURCE: SHOP1 pp2/7/25 BOM: B10/B14/B8 thickness 1/2.',
    'min_width': 'SOURCE floor: documented B and K plates are 6 wide; use on wider members is a proposed rule.',
    'base_first_row': 'USER CONFIRMED: first hole center 2 1/2 inward from EXTERIOR face of OUTSIDE column flange, not plate edge or inside flange.',
    'base_row_pitch': 'PROVISIONAL: 3-inch pitch illustrates the one-end two-row sketch; no dimension confirms it.',
    'base_hole_dia': 'PROVISIONAL: legacy assumed 13/16 anchor-hole diameter, NOT a bolt specification.',
    'base_transverse_edge': 'PROVISIONAL: 1 1/2-inch side margin; not dimensioned in uploaded base details.',
    'width_allowance': 'PROPOSED: add 1 inch total to the largest mating flange/body width, minimum 6.',
    'width_grid': 'PROPOSED: round width UP to 1/2-inch stock increment.',
    'base_depth_allowance': 'PROPOSED: actual column depth + 1/4, rounded UP to 1/2. Reproduces B8/B10/B14 sample envelopes.',
    'base_length_grid': 'PROPOSED: 1/2-inch increment, fitted to sample envelopes, not a stated general shop rule.',
    'connection_thk': 'SOURCE: SHOP1 pp12/18 and SHOP2 pp1/2 show K14/K10 at 1/2 thick; adequacy for other members unverified.',
    'connection_extension': 'SOURCE envelopes: K10 length 17 1/4; K14 length 21 1/4. PROPOSED general rule: max(nominal, actual depth) + 7 1/4.',
    'connection_length_grid': 'PROPOSED: round length UP to 1/4 inch.',
    'connection_hole_dia': 'PROVISIONAL: 9/16 legacy assumed K-plate hole size; adjacent clip hole notes do not verify K-plate holes.',
    'connection_end_edge': 'USER STANDARD: 2 inches from each end to first row center.',
    'connection_row_pitch': 'USER STANDARD: next row 3 1/2 inches from each end row; four rows total.',
    'connection_transverse_edge': 'USER STANDARD: hole columns 1 1/2 inches from each side edge.',
}


def migrate_plate_defaults(job):
    if job.settings.get('plate_standard_version', 0) >= 6:
        return
    raw = job.settings.get('plate_rules', {})
    for key, old in [('connection_end_edge', '1 1/2'), ('connection_row_pitch', '3')]:
        if key in raw and D(raw[key]) == D(old):
            raw[key] = DEFAULTS[key]
    job.settings['plate_standard_version'] = 6


def rules(job):
    return validate_rules(job.settings.get('plate_rules', {}))


def connecting_holes(job, length, width, diameter=None):
    r = rules(job)
    L = D(length).inches
    W = D(width).inches
    e = D(r['connection_end_edge']).inches
    p = D(r['connection_row_pitch']).inches
    y = D(r['connection_transverse_edge']).inches
    dia = D(diameter or r['connection_hole_dia']).inches
    if 2 * (e + p) >= L or 2 * y >= W:
        raise ValueError('Connecting plate too small for the specified four-row / two-column hole rule')
    if min(e, y) <= dia / 2:
        raise ValueError('Connection hole intersects plate edge')
    return rect_holes(D(dia), [D(x) for x in (e, e + p, L - e - p, L - e)], [D(y), D(W - y)])


def validate_rules(raw):
    if not isinstance(raw, dict):
        raise ValueError('Plate rules must be an object')
    unknown = set(raw) - set(DEFAULTS)
    if unknown:
        raise ValueError('Unknown plate rules: ' + ', '.join(sorted(unknown)))
    out = {**DEFAULTS, **raw}
    for k, v in out.items():
        d = D(v)
        if d.inches <= 0:
            raise ValueError(k + ' must be positive')
        out[k] = d.fmt()
    return out


def _num(v):
    return Fraction(str(v))


def _up(x, increment):
    return math.ceil(x / increment) * increment


def make(job, family, section, other_section=None, weld_size=DEFAULT_WELD, profile=None):
    """Get/add a deterministic geometry variant; never overwrite a source mark."""
    migrate_plate_defaults(job)
    if family not in ('B', 'K', 'R'):
        raise ValueError('Plate family must be B, K or R')
    if profile is not None:
        if family != 'B':
            raise ValueError('Profile envelope adapter is BASE PLATE ONLY')
        from types import SimpleNamespace

        sec = SimpleNamespace(name=profile['id'], d=profile['depth'], bf=profile['width'], kind=profile.get('family'))
        other = sec
    else:
        sec = sections.get_section(section)
        other = sections.get_section(other_section or section)
    r = rules(job)
    v = {k: D(x).inches for k, x in r.items()}
    nominal = int(re.match(r'W(\d+)', sec.name).group(1)) if sec.name.startswith('W') else math.ceil(sec.d)
    width = _up(max(v['min_width'], max(_num(sec.bf), _num(other.bf)) + v['width_allowance']), v['width_grid'])
    if family == 'B':
        length = _up(_num(sec.d) + v['base_depth_allowance'], v['base_length_grid'])
        thk = v['base_thk']
        outside = (length + _num(sec.d)) / 2
        xs = [outside - v['base_first_row'], outside - v['base_first_row'] - v['base_row_pitch']]
        edge = v['base_transverse_edge']
        dia = v['base_hole_dia']
        formula = f'L = ceil_grid(actual depth {sec.d} + {r["base_depth_allowance"]}, {r["base_length_grid"]}); W = ceil_grid(max({r["min_width"]} minimum, flange + {r["width_allowance"]}), {r["width_grid"]})'
        hold = 'Anchor pattern per job plate rules: first row 2.5 in (or rule override) inward from the outside flange; pitch, gauge and diameter from the rules.'
    else:
        length = _up(max(Fraction(nominal), _num(sec.d)) + v['connection_extension'], v['connection_length_grid'])
        thk = v['connection_thk']
        e = v['connection_end_edge']
        pitch = v['connection_row_pitch']
        if 2 * (e + pitch) >= length:
            raise ValueError('Connecting-plate row groups overlap; increase length or reduce row offsets')
        xs = [e, e + pitch, length - e - pitch, length - e]
        edge = v['connection_transverse_edge']
        dia = v['connection_hole_dia']
        formula = f'L = ceil_grid(max(nominal {nominal}, actual {sec.d}) + {r["connection_extension"]}, {r["connection_length_grid"]}); W covers column/bracket AND rafter flange + allowance'
        hold = 'Hole centers per job plate rules (editable on the connection); diameter and bolt specification from the rules.'
    tube_base = family == 'B' and getattr(sec, 'kind', None) == 'HSS'
    if tube_base:
        xs = []
        hold = 'HSS base plate blank: no W anchor pattern inherited; enter the anchor layout on the connection.'
    if not tube_base and edge * 2 >= width:
        raise ValueError('Transverse margins leave no hole gauge')
    if xs and (min(xs) - dia / 2 <= 0 or max(xs) + dia / 2 >= length or edge - dia / 2 <= 0):
        raise ValueError('Plate rule places a hole outside or tangent to the contour')
    weld = D(weld_size or DEFAULT_WELD)
    if weld.inches <= 0:
        raise ValueError('Weld leg must be positive')
    holes = rect_holes(D(dia), [D(x) for x in xs], [D(edge), D(width - edge)])
    geometry = {
        'family': family,
        'nominal': nominal,
        'thk': str(thk),
        'width': str(width),
        'length': str(length),
        'holes': [(h.x.rational(), h.y.rational(), h.dia.rational()) for h in holes],
        'weld_leg': weld.rational(),
    }
    key = hashlib.sha256(json.dumps(geometry, sort_keys=True).encode()).hexdigest()
    label = f'{family}-{nominal}'
    mark = label + '-' + key[:8].upper()
    existing = job.parts.get(mark)
    if existing:
        if existing.symbol.get('geometry_key') != key:
            raise ValueError('Generated plate mark collision: ' + mark)
        actual_holes = [(h.x.rational(), h.y.rational(), h.dia.rational()) for h in existing.holes]
        if (
            existing.thk.inches != thk
            or existing.width.inches != width
            or existing.length.inches != length
            or actual_holes != geometry['holes']
        ):
            raise ValueError('Generated plate was manually modified without a new mark: ' + mark)
        # Geometry identity is stable; record all generating member contexts, never
        # quietly change an existing plate's size to accommodate a new section.
        contexts = set(existing.symbol.get('member_contexts', []))
        contexts.add(sec.name + ' / ' + other.name)
        existing.symbol['member_contexts'] = sorted(contexts)
        return existing
    cut = [[D(x).to_json(), D(y).to_json()] for x, y in [(0, 0), (length, 0), (length, width), (0, width)]]
    p = Part(
        mark,
        'plate',
        D(thk),
        D(width),
        D(length),
        holes=holes,
        source=f'{VERSION}: documented envelopes + proposed sizing rule; '
        + ('provisional anchor holes' if family == 'B' else 'user hole-center standard; diameter/adequacy unverified'),
        notes=hold,
        symbol={
            'plate_family': label,
            'plate_rule_generated': True,
            'geometry_key': key,
            'member_contexts': [sec.name + ' / ' + other.name],
            'rule_version': VERSION,
            'rule_snapshot': r,
            'formula': formula,
            'cut_contour': cut,
            'draft_connection': True,
            'weld_size': weld.fmt(),
            'weld_provenance': 'job default 1/4 unless overridden on the connection',
            'role': label
            + ' member-sized '
            + ('base plate' if family == 'B' else 'knee plate' if family == 'K' else 'ridge plate'),
            'fit': 'member envelope',
            'bevel': 'none',
            'review_hold': hold,
            'finished_length_in': float(length),
            'finished_width_in': float(width),
        },
    )
    if family == 'B':
        p.symbol.update(
            base_hole_datum='HSS_UNRESOLVED_NO_HOLES' if tube_base else 'outside_flange_inward',
            column_depth_in=float(sec.d),
            outside_flange_x_in=float(outside),
            base_first_row_in=float(v['base_first_row']),
            column_flange_width_in=float(sec.bf),
            column_flange_thickness_in=float(sec.tf) if getattr(sec, 'tf', None) is not None else None,
            column_web_thickness_in=float(sec.tw) if getattr(sec, 'tw', None) is not None else None,
            column_family=getattr(sec, 'kind', getattr(sec, 'family', 'PROFILE')),
        )
    from .contours import validate_contour

    validate_contour(p)
    job.parts[mark] = p
    return p


def catalog_rows(job):
    """Preview every supported W shape without populating the active job library."""
    from .model import Job

    preview = Job.loads(job.dumps())
    rows = []
    for sec in sections.SECTIONS:
        for family in ('B', 'K', 'R'):
            try:
                p = make(preview, family, sec)
                rows.append(
                    dict(
                        section=sec,
                        family=p.symbol['plate_family'],
                        mark=p.mark,
                        size=p.bom_description(),
                        holes=len(p.holes),
                        status='RULE-DERIVED',
                    )
                )
            except ValueError as e:
                rows.append(dict(section=sec, family=family, mark='', size='', holes=0, status=str(e)))
    return rows


def refresh(job):
    """Called transactionally after standards edits; rebind every managed frame."""
    from .connections import rebuild
    from .frame import FrameParams, generate_frame

    for params in list(job.settings.get('frames', {}).values()):
        generate_frame(job, FrameParams.from_json(params))
    rebuild(job)


def migrate_weld_defaults(job):
    """Explicit user instruction: fill previously unspecified connections with 1/4."""
    for cfg in job.settings.get('connections', {}).values():
        if not cfg.get('weld_size'):
            cfg['weld_size'] = DEFAULT_WELD
    for cfg in job.settings.get('frames', {}).values():
        if not cfg.get('weld_size'):
            cfg['weld_size'] = DEFAULT_WELD
    for a in job.assemblies.values():
        if a.derivation.get('frame_id') and not a.derivation.get('params', {}).get('weld_size'):
            a.derivation.setdefault('params', {})['weld_size'] = DEFAULT_WELD
    job.settings['weld_default'] = DEFAULT_WELD
