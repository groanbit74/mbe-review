"""Transactional, job-wide supplier PRODUCT changes (not purchasing aliases)."""

import copy

from .model import Job
from .product_library import secondaries


def categories(raw=None):
    raw = raw or {}
    primary = raw.get('primary', 'sss')  # shop standard: SSS primary, MBCI the option
    if primary not in ('mbci', 'sss'):
        raise ValueError('Choose SSS or MBCI primary supplier')
    out = {'primary': primary}
    for k in ('secondaries', 'sheets', 'trim'):
        out[k] = raw.get(k, primary)
        if out[k] not in ('sss', 'mbci'):
            raise ValueError('Invalid category supplier: ' + k)
    return out


def supplier(ident):
    return 'sss' if str(ident).startswith(('SSS-', 'SSS / ')) else 'mbci'


def libraries():
    from .cladding import catalog as clad
    from .secondary_catalog import catalog, get
    from .sections import channel_names

    c = clad('all')
    profiles = list(
        {r['id']: r for r in catalog()['profiles'] + [get(n) for n in channel_names()] + secondaries()}.values()
    )
    family_rank = {'C': 0, 'Channel': 1, 'Z': 2, 'Eave': 3, 'Angle': 4}
    profiles.sort(
        key=lambda r: (
            family_rank.get(r.get('family'), 9),
            float(r.get('nominal_depth_in') or 0),
            str(r.get('nominal_size') or ''),
            int(r.get('gauge') or 0),
            r.get('id', ''),
        )
    )
    return dict(
        secondaries=profiles,
        colors=c['colors'],
        trims=c['trims'],
    )


def inputs(raw):
    """Only editable settings, excluding cached resolved geometry/source snapshots."""

    def walk(v, path=()):
        if isinstance(v, dict):
            for k, x in v.items():
                if k in (
                    'post',
                    'profile',
                    'source',
                    'source_info',
                    'catalog_sha256',
                    'rule_sha256',
                    'surface_finishes_resolved',
                    'superseded_member_selection',
                    # derived end-wall sections (the ``channel`` keyword resolves to a generic
                    # open-face channel envelope sized by span; it is not a supplier choice)
                    'resolved_rafter',
                    'resolved_column',
                    'rafter_section',
                    'column_section',
                ):
                    continue
                yield from walk(x, path + (k,))
        elif isinstance(v, list):
            for i, x in enumerate(v):
                yield from walk(x, path + (i,))
        elif isinstance(v, str):
            yield path, v

    yield from walk(raw)


def kind(path, value):
    if len(path) > 1 and path[0] == 'cladding':
        if path[-1] == 'color':
            return 'trim' if path[1] == 'trim_finish' else 'sheets'
        if path[1] == 'trim_stock':
            return 'trim'
        return None
    if value.startswith(
        (
            'MBCI-C-',
            'MBCI-Z-',
            'MBCI-Channel-',
            'MBCI-Angle-',
            'MBCI-Eave-',
            'SSS-PN',
            'SSS-SS',
            'SSS-CAB',
            'USER-Eave-',
        )
    ):
        return 'secondaries'
    return None


def plan(job, cfg):
    cfg = categories(cfg)
    lib = libraries()
    fields = {}
    for fid, p in job.settings.get('frames', {}).items():
        for path, value in inputs(p):
            cat = kind(path, value)
            if not cat or not value or supplier(value) == cfg[cat]:
                continue
            typ = 'color' if path[-1] == 'color' else 'trim' if path[0] == 'cladding' else 'section'
            key = typ + '|' + value
            if key in fields:
                fields[key]['uses'].append(fid + '/' + '/'.join(map(str, path)))
                continue
            options = []
            suggested = ''
            if typ == 'color':
                options = [
                    dict(id=r['name'], label=r['name'] + ' / ' + r['coating'])
                    for r in lib['colors']
                    if supplier(r['name']) == cfg[cat]
                ]
            elif typ == 'trim':
                role = path[-1]
                options = [
                    dict(id=r['id'], label=r['label'])
                    for r in lib['trims']
                    if r['role'] == role and supplier(r['id']) == cfg[cat]
                ]
                # Explicit incomplete state, never silently ordered as another vendor's trim.
                options.append(
                    dict(id='__PENDING__', label='Unlisted / not selected — leave a visible trim purchasing hold')
                )
            else:
                from .secondary_catalog import get

                old = get(value)
                family = old['family']
                options = [
                    dict(id=r['id'], label=r['designation'])
                    for r in lib['secondaries']
                    if supplier(r['id']) == cfg[cat] and r['family'] == family
                ]
                matching = [
                    r
                    for r in lib['secondaries']
                    if any(o['id'] == r['id'] for o in options)
                    and abs(r['nominal_depth_in'] - old['nominal_depth_in']) < 0.26
                ]
                if family == 'Eave':
                    matching = [r for r in matching if r.get('eave_kind') == old.get('eave_kind')]
                if cfg[cat] == 'mbci' and family == 'Z' and abs(old['nominal_depth_in'] - 8) < 0.26:
                    # Owner standard: 8 in MBCI Zee, 16 ga at 20 ft bays and 14 ga at 25 ft bays.
                    from .standards import mbci_secondary_profile

                    longest = 0.0
                    for frame in job.settings.get('frames', {}).values():
                        layout = frame.get('bay_layout') or {}
                        lengths = layout.get('bay_lengths') or []
                        if lengths:
                            from .model import D

                            longest = max(longest, max(float(D(x).inches) for x in lengths))
                        elif layout.get('spacing'):
                            from .model import D

                            longest = max(longest, float(D(layout['spacing']).inches))
                    want = mbci_secondary_profile(longest)
                    if any(r['id'] == want for r in options):
                        suggested = want
                if family == 'Angle':
                    matching = [
                        r for r in matching if sorted(r.get('flanges_in') or []) == sorted(old.get('flanges_in') or [])
                    ]
                if len(matching) == 1:
                    suggested = matching[0]['id']
            fields[key] = dict(
                key=key,
                type=typ,
                category=cat,
                old=value,
                options=options,
                suggested=suggested,
                uses=[fid + '/' + '/'.join(map(str, path))],
            )
    return dict(
        categories=cfg,
        fields=list(fields.values()),
        notes=[
            'Preview applies to all SAVED frames. Applying regenerates actual sections, cuts, fits and cladding. It is not a relabel operation.',
            'Colors from a different supplier require an explicit new selection. No color-equivalence substitutions.',
            'Unlisted trim may be explicitly left pending; it is NOT ordered or represented as a selected formed product. Choose a category override to retain another supplier.',
            'SSS Zee laps/unknown main-channel weight data are not invented. Unsupported combinations are rejected without changing the saved job.',
            'Unrelated manually fabricated clips remain project specifications; selecting a supplier is not fabrication release.',
        ],
    )


def put(raw, path, value):
    v = raw
    for k in path[:-1]:
        v = v[k]
    v[path[-1]] = value


def validate_frame(job, p):
    policy = job.settings.get('product_suppliers')
    if not policy:
        return
    cfg = categories(policy)
    raw = p.to_json()
    for path, value in inputs(raw):
        cat = kind(path, value)
        if cat and value and supplier(value) != cfg[cat]:
            raise ValueError(
                'Supplier product required: '
                + '/'.join(map(str, path))
                + ' uses '
                + value
                + ' but '
                + cat
                + ' supplier is '
                + cfg[cat]
                + '. Use Supplier products / category overrides and select the actual product.'
            )
    if cfg['secondaries'] == 'sss':
        for role in ('purlin', 'girt'):
            if not p.secondary.get(role, {}).get('profile_id'):
                raise ValueError('Choose an SSS ' + role + ' product')
    if p.cladding.get('enabled'):
        ident = p.cladding.get('panel_profile_id', 'MBCI-PBR')
        if supplier(ident) != cfg['sheets']:
            raise ValueError('Select a panel product from the selected sheet supplier')


def apply(job, cfg, choices):
    from .frame import FrameParams, generate_frame

    proposal = plan(job, cfg)
    cfg = proposal['categories']
    choices = choices or {}
    for f in proposal['fields']:
        if choices.get(f['key']) not in {o['id'] for o in f['options']}:
            raise ValueError('Select replacement for ' + f['old'] + ' (' + f['category'] + ')')
    work = Job.loads(job.dumps())
    work.settings['product_suppliers'] = cfg
    # Retire purchasing-only aliases: products now determine supplier labels.
    work.settings['sourcing'] = {'primary': cfg['primary'], 'overrides': {}}
    for fid, original in list(work.settings.get('frames', {}).items()):
        raw = copy.deepcopy(original)
        for path, value in list(inputs(raw)):
            cat = kind(path, value)
            if not cat or not value or supplier(value) == cfg[cat]:
                continue
            typ = 'color' if path[-1] == 'color' else 'trim' if path[0] == 'cladding' else 'section'
            new = choices[typ + '|' + value]
            put(raw, path, '' if new == '__PENDING__' else new)
            if len(path) == 3 and path[0] == 'endwalls' and path[-1] == 'rafter_override':
                rec = raw['endwalls'][path[1]]
                if rec.get('purlin_channel_fit_confirmed'):
                    rec['purlin_channel_fit_confirmed'] = False
                    rec['supplier_fit_retired'] = True
            if typ == 'color':
                parent = raw
                for k in path[:-1]:
                    parent = parent[k]
                if cfg[cat] == 'sss':
                    parent['gauge'] = 26
        raw.setdefault('cladding', {})['supplier_products'] = True
        if (
            supplier(raw['cladding'].get('panel_profile_id', 'MBCI-PBR')) != cfg['sheets']
            or 'panel_profile_id' not in raw['cladding']
        ):
            raw['cladding']['panel_profile_id'] = 'SSS-PBR' if cfg['sheets'] == 'sss' else 'MBCI-PBR'
        # Resolve incidental cached secondary face dimensions through regeneration.
        before = {
            o['id']: (o.get('x'), o.get('y'), o.get('width'), o.get('height'))
            for o in original.get('cladding', {}).get('openings', [])
        }
        generate_frame(work, FrameParams.from_json(raw))
        after = {
            o['id']: (o.get('x'), o.get('y'), o.get('width'), o.get('height'))
            for o in work.settings['frames'][fid].get('cladding', {}).get('openings', [])
        }
        from .cladding import inch

        if before.keys() != after.keys() or any(
            any(abs(inch(a) - inch(b)) > 1e-7 for a, b in zip(before[k], after[k])) for k in before
        ):
            raise ValueError(
                'Supplier change would relocate/resize an opening. Resolve that layout explicitly before applying; no change saved.'
            )
    return work
