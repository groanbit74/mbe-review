"""Frame-line index: one record per cross-building frame line.

Owner rules (spec §11 / §13, corrected round 15):
  * the ROOF LINE is the TOP OF THE PURLIN and EAVE HEIGHT is the top of the eave purlin; the
    building has an eave height AND a peak height, and a lean-to has its own eave height;
  * BYPASS (the standard fit): the purlin bears ON the rafter top flange, so the rafter top sits
    one purlin depth under the roof line; the terminal piece runs to the end-wall rafter flange
    OUTER EDGE and the interior pieces butt at the rafter centerline;
  * FLUSH MOUNT: the purlin top is flush with the rafter top (a clip welded to a W rafter web and
    the purlin cut 1/8 in clear of the flange edge; purlin inside the flanges of an open-face
    channel 1/4 in from the web), so the rafter top IS the roof line;
  * end-wall W rafters are BYPASS (the rake angle sits on the purlin ends); only a sheeted
    open-face CHANNEL end rafter is FLUSH;
  * lean-tos follow their own per-line fit.

The index is derived from the longitudinal layout that already drives the secondary runs
(``secondary_runs.support_lines`` or ``bay_zones.stations_in``) so every drawing – frame-line
elevations, sidewall framing elevations and the roof framing plan – agrees on what sits at
frame line *n*.
"""

from __future__ import annotations

import math
from fractions import Fraction

from .connections import f

EPS = 1e-6

END_LABEL = {
    'outer_front_end': 'OUTER LEFT END (ROOF-ONLY BAY)',
    'front_end': 'LEFT END WALL',
    'rear_end': 'RIGHT END WALL',
}
END_SHORT = {'outer_front_end': 'O', 'front_end': 'F', 'rear_end': 'R'}


def _layout(job, fid):
    return job.settings.get('frame_layouts', {}).get(fid) or {}


def _derivation(job, fid):
    asm = job.assemblies.get(fid)
    return asm.derivation if asm is not None else {}


def length_in(job, fid):
    """Master outside-wall length of the building this frame belongs to (inches)."""
    layout = _layout(job, fid)
    geo = layout.get('building_geometry') or {}
    if geo.get('length_in'):
        return float(geo['length_in'])
    sr = _derivation(job, fid).get('secondary_runs') or {}
    if sr.get('support_length_in'):
        return float(sr['support_length_in'])
    p = job.settings['frames'][fid]
    try:
        return f(p['length'])
    except Exception:
        return 0.0


def _stations(job, fid):
    """[(station_in, kind, wall_key)] in station order, from the most authoritative source."""
    p = job.settings['frames'][fid]
    deriv = _derivation(job, fid)
    sr = deriv.get('secondary_runs') or {}
    if sr.get('support_lines'):
        rows = sr['support_lines']
        ends = deriv.get('endwalls') or {}
        out = []
        for i, s in enumerate(rows):
            kind = 'end' if s.get('type') in ('bearing_endwall', 'reduced_rigid') or s.get('wall_key') else 'interior'
            key = s.get('wall_key')
            if kind == 'end' and not key:
                # Un-zoned layouts only carry the line type: first = left end, last = right end,
                # an end line in between is the enclosed junction wall.
                key = (
                    ('outer_front_end' if 'outer_front_end' in ends else 'front_end')
                    if i == 0
                    else 'rear_end'
                    if i == len(rows) - 1
                    else 'front_end'
                )
            if kind == 'end' and key not in ends:
                # No end-wall model for this line (e.g. reduced rigid frame without separate framing): draw it as a rigid frame line.
                kind, key = 'interior', None
            out.append((float(s['station_in']), kind, key))
        return out
    bz = _layout(job, fid).get('bay_zones') or {}
    ends_on = bool((p.get('endwalls') or {}).get('enabled', True)) and bool(deriv.get('endwalls'))
    if bz.get('stations_in'):
        st = [float(x) for x in bz['stations_in']]
        junction = bz.get('enclosed_left_station_in')
        out = []
        for i, x in enumerate(st):
            if ends_on and i == 0:
                out.append(
                    (x, 'end', 'outer_front_end' if junction not in (None, 0, 0.0) and junction > EPS else 'front_end')
                )
            elif ends_on and i == len(st) - 1:
                out.append((x, 'end', 'rear_end'))
            elif ends_on and junction is not None and abs(x - float(junction)) < EPS:
                out.append((x, 'end', 'front_end'))
            else:
                out.append((x, 'interior', None))
        return out
    # Equal bays: N frames + end walls (or N rigid frames when no end walls are framed).
    L = length_in(job, fid)
    n_frames = int(p.get('frames') or 1)
    if ends_on:
        bays = n_frames + 1
        st = [L * i / bays for i in range(bays + 1)] if L else [0.0] * (bays + 1)
        return [(st[0], 'end', 'front_end')] + [(x, 'interior', None) for x in st[1:-1]] + [(st[-1], 'end', 'rear_end')]
    bays = max(n_frames - 1, 1)
    st = [L * i / bays for i in range(bays + 1)] if L else [0.0] * (bays + 1)
    return [(x, 'interior', None) for x in st]


def purlin_depth_in(job, fid):
    p = job.settings['frames'][fid]
    try:
        return f(p['purlin_depth'])
    except Exception:
        return 0.0


def lean_tos_at(job, fid, station):
    """Lean-tos whose longitudinal run covers this station (sidewall-attached lean-tos only)."""
    out = []
    for z in (_layout(job, fid).get('framing_additions') or {}).get('lean_tos', []):
        if z.get('face') not in ('left', 'right'):
            continue
        start = float(z.get('start_in') or 0)
        end = start + float(z.get('length_in') or 0)
        if z.get('face') == 'left':
            # lean coordinates are the outside view of the back wall (mirrored along the frame)
            L = length_in(job, fid)
            start, end = L - end, L - start
        if start - EPS <= station <= end + EPS:
            out.append(z)
    return out


def layout_for_station(job, fid, station):
    """Shallow copy of the frame layout whose lean-to list is limited to the lean-tos spanning
    ``station`` (None = keep all) – used by elevations that cut the building at one frame line."""
    layout = _layout(job, fid)
    if station is None or not layout:
        return layout
    fa = dict(layout.get('framing_additions') or {})
    fa['lean_tos'] = lean_tos_at(job, fid, float(station))
    out = dict(layout)
    out['framing_additions'] = fa
    return out


def lines(job, fid):
    """Ordered frame-line records for frame family ``fid``.

    Each record: index (1-based), station_in, kind ('end' | 'interior'), wall_key (ends),
    frame_mark (interior), label, roof_mode ('flush' | 'bypass'), roof_offset_in (vertical
    distance from the rafter top to the roof line at the wall), rafter (section id), lean_tos.
    """
    p = job.settings['frames'][fid]
    deriv = _derivation(job, fid)
    ends = deriv.get('endwalls') or {}
    layout = _layout(job, fid)
    pd = purlin_depth_in(job, fid)
    slope = float(Fraction(str(p.get('slope_rise') or 0))) / 12.0  # saved as a fraction string ("1/4") or a number
    normal_to_vertical = math.hypot(1, slope)  # purlin depth is measured normal to the roof slope
    interior_mode = 'flush' if p.get('purlin_mode') == 'flush' else 'bypass'
    stations = _stations(job, fid)
    total = len(stations)
    out = []
    for i, (x, kind, wall_key) in enumerate(stations, start=1):
        rec = {
            'index': i,
            'count': total,
            'station_in': x,
            'kind': kind,
            'wall_key': wall_key,
            'frame_mark': None,
            'purlin_depth_in': pd,
            'lean_tos': [z['id'] for z in lean_tos_at(job, fid, x)],
        }
        if kind == 'end':
            end = ends.get(wall_key) or {}
            mode = end.get('roof_mode') or ((end.get('config') or {}).get('roof_mode')) or 'flush'
            if mode == 'follow':
                mode = interior_mode
            rec['roof_mode'] = mode
            rec['rafter'] = (end.get('config') or {}).get('resolved_rafter') or ''
            rec['label'] = END_LABEL.get(wall_key, 'END WALL')
            rec['sheet_suffix'] = END_SHORT.get(wall_key, 'E')
            rec['framed'] = bool(end)
        else:
            rec['roof_mode'] = interior_mode
            rec['rafter'] = p.get('rafter_section') or ''
            rec['frame_mark'] = fid
            rec['label'] = ('END RIGID FRAME ' if i in (1, total) else 'INTERIOR RIGID FRAME ') + fid
            rec['sheet_suffix'] = 'I'
            rec['framed'] = bool(layout)
        rec['roof_offset_in'] = pd * normal_to_vertical if rec['roof_mode'] == 'bypass' else 0.0
        rec['lean_roof_mode'] = 'flush' if kind == 'end' else 'bypass'
        out.append(rec)
    physical = layout.get('physical_connection_schedule') or []
    ordinal = 0
    for rec in out:
        if rec['kind'] != 'interior':
            continue
        ordinal += 1
        rec['primary_connections'] = [x for x in physical if x.get('frame_ordinal') == ordinal]
    return out


def line(job, fid, index):
    for rec in lines(job, fid):
        if rec['index'] == int(index):
            return rec
    raise KeyError(f'frame line {index} of {fid}')


def roof_line(job, fid):
    """Roof-line (TOP OF PURLIN) height above floor as a function of frame x (0 = left/back wall).

    The plane passes through the eave height at each outside wall line at the frame pitch;
    it is the same for every frame line – only the rafter sits lower (bypass) or on it (flush).
    """
    layout = _layout(job, fid)
    W = float(layout.get('width_in') or 0)
    eave = float(layout.get('low_eave_in') or 0)
    m = float(Fraction(str(layout.get('slope_rise') or 0))) / 12.0
    mono = layout.get('frame_type') == 'monoslope'
    if mono:
        return lambda x: eave + m * x
    return lambda x: eave + m * min(x, W - x)


def heights(job, fid, rec):
    """The height datum line of a frame line (owner, round 15): EAVE AT THE LEAN-TO (top of the lean
    eave purlin, when a lean-to runs on this line), EAVE AT THE MAIN BUILDING (eave height = top of
    the eave purlin) and the PEAK OF THE BUILDING (the actual highest point of the roof line = top
    of the peak purlin).

    The roof line is the top of the purlin: on the BYPASS fit the rafter top is one purlin depth
    below it, on the FLUSH fit the rafter top IS it (the purlin top flange flush with the rafter).
    """
    from .connections import q as _q

    def rnd(v):
        return round(v * 16) / 16

    layout = _layout(job, fid)
    eave = float(layout.get('low_eave_in') or 0)
    peak = float(layout.get('peak_height_in') or 0)
    pd = purlin_depth_in(job, fid)
    flush = rec.get('roof_mode') == 'flush'
    parts = []
    for z in lean_tos_at(job, fid, rec['station_in']):
        lo = z.get('low_eave_in')
        if lo:
            parts.append(z['id'] + ' EAVE (TOP OF LEAN EAVE PURLIN) ' + _q(rnd(float(lo))).fmt())
    parts.append(
        'EAVE (TOP OF EAVE PURLIN) '
        + _q(rnd(eave)).fmt()
        + ' = '
        + (
            'COLUMN TOP, eave purlin welded flush to the column flange'
            if flush
            else 'COLUMN TOP + PURLIN ' + _q(rnd(pd)).fmt() + ' (eave purlin on the column seat)'
        )
    )
    if peak:
        parts.append('PEAK (TOP OF PEAK PURLIN = HIGHEST POINT OF THE ROOF LINE) ' + _q(rnd(peak)).fmt())
    return ' | '.join(parts)


def banner(rec):
    """Two-line caption used by every frame-line drawing."""
    mode = rec['roof_mode'].upper()
    if rec['kind'] == 'end':
        rule = (
            'END RAFTER FLUSH (OPEN-FACE CHANNEL) — PURLINS IN THE CHANNEL; ROOF LINE = TOP OF END RAFTER = TOP OF PURLIN'
            if mode == 'FLUSH'
            else 'END RAFTER BYPASS (W PRESET, RAKE ANGLE) — PURLINS ON THE RAFTER; ROOF LINE = RAFTER TOP + PURLIN DEPTH'
        )
    else:
        rule = (
            'RAFTER BYPASS — PURLINS SIT ON THE RAFTER; ROOF LINE (TOP OF PURLIN) = RAFTER TOP + PURLIN DEPTH'
            if mode == 'BYPASS'
            else 'RAFTER FLUSH MOUNT — PURLIN TOP FLUSH WITH THE RAFTER TOP; ROOF LINE = TOP OF PURLIN = RAFTER TOP'
        )
    return (
        'FRAME LINE %d OF %d — %s — STATION %s' % (rec['index'], rec['count'], rec['label'], _ft(rec['station_in'])),
        rule,
    )


def _ft(x):
    from .connections import q

    try:
        return q(x).fmt()
    except Exception:
        return f'{x:.2f} in'
