"""Separate removable base plates from existing floor weld-plate datum."""

from .connections import f
from .plate_rules import make


def resolve(job, p, section, profile=None, post_footing=None):
    from . import foundation as FND

    embedded = FND.is_post_footing(p) if post_footing is None else bool(post_footing)
    if p.base_connection == 'floor_weld' or embedded:
        return None  # floor weld plate / embedded post: no removable base plate
    return (
        make(job, 'B', section, weld_size=p.weld_size, profile=profile)
        if p.plate_mode == 'member'
        else job.part(p.base_plate)
    )


def thickness(part):
    return f(part.thk) if part is not None else 0.0


def mark(part):
    return part.mark if part is not None else None
