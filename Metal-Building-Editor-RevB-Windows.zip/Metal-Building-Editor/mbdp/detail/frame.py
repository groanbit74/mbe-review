"""Rigid-frame wizard: explicit parameters -> column and rafter assemblies.

Nothing here is "engineering": the wizard only turns geometry the user states
(width, eave height, slope, sections, plate/clip standards, purlin and girt
layout) into member lengths and attachment stations, and it writes the formula
it used into every derived value so a checker can follow it.  Every generated
assembly can be edited afterwards like a hand-built one.
"""

from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Optional

from ..dims import Dim
from . import sections
from .model import Assembly, Attachment, D, Job, MainMember


def grid16(x: float) -> Fraction:
    return Fraction(round(x * 16), 16)


def _grades_json(raw):
    """Column grades always serialize in their normalized form (idempotent save / regenerate)."""
    from .grades import normalize as normalize_grades

    try:
        return normalize_grades(raw)
    except ValueError:
        return copy.deepcopy(raw)


# Bump when derived detail data changes shape or rules; saved jobs regenerate once on load.
# 27 (v0.8.45, round 15): the roof line is the TOP OF THE PURLIN again and eave height is the top of
# the eave purlin - the round-14 "welded frames are always flush" normalization is withdrawn (bypass
# is the standard fit, the column is cut to eave height less the purlin depth) and every welded frame
# saved by 0.8.44 regenerates once.
DETAIL_VERSION = 29


@dataclass
class FrameParams:
    bay_zones: dict = field(default_factory=dict)
    welded_fit_rules: dict = field(default_factory=lambda: {"enabled": True})
    section_defaults: dict = field(default_factory=dict)
    endwalls: dict = field(default_factory=dict)
    cladding: dict = field(default_factory=dict)
    additions: dict = field(default_factory=dict)
    grades: dict = field(
        default_factory=dict
    )  # column grades per column key (grades.py); standard = all at the set level
    length: Optional[Dim] = None
    auto_roof_spacing: bool = False
    starting_wall_run: bool = False
    starting_run: Dim = D(0)
    slab: bool = False
    base_angle: dict = field(default_factory=dict)
    bay_layout: dict = field(default_factory=dict)
    secondary: dict = field(default_factory=dict)
    girt_clip_adjustments: list = field(default_factory=list)
    eave_clip: str = ""
    welded_knee: str = "inside_flange"  # round 14: welded inside flange = shop standard; outside seat = option
    welded_knee_overrides: dict = field(default_factory=dict)  # per physical primary column: <frame ordinal>:left/right
    base_connection: str = "base_plate"
    foundation: str = "slab"  # slab | post_footing (embedded posts; see foundation.py)
    footing_depth: Dim = D("3'")  # post footing hole depth below the floor datum
    footing_diameter: Dim = D(18)  # post footing hole diameter
    clip_policy: str = "legacy"
    connection_style: str = "bolted"
    purlin_depth: Dim = D(8)
    eave_plate_extension: Dim = D(3)
    inset_for_bypass: bool = False
    girt_depth: Dim = D(8)
    frame_type: str = "gable"
    high_column_mark: str = "COL-2"
    high_column_cut_mark: str = "RF-300"
    high_column_section: str = ""  # empty => follow low column
    high_girt_elevations: Optional[list[Dim]] = None  # None follows low; [] explicitly none
    prefix: str = "RF1"
    frames: int = 1  # identical frames (quantity multiplier)
    width: Dim = D("50'")  # out-to-out of column steel lines
    eave_height: Dim = D("14'")  # floor to TOP OF EAVE STRUT
    slope_rise: Fraction = Fraction(1)  # rise per 12
    column_section: str = "W14X22"
    rafter_section: str = "W14X22"
    column_mark: str = "COL-1"
    rafter_mark: str = "RF1-2"
    column_cut_mark: str = "RF-100"
    rafter_cut_mark: str = "RF-200"
    base_plate: str = "B-14"
    knee_bracket: str = "BR14HE1"
    rafter_end_plate: str = "K-14"  # at the knee and at the ridge
    column_top_gap: Dim = D("0")  # deduction at the column top for the knee seat
    knee_setback: Dim = D("0")  # horizontal distance from column steel line to the knee plate face
    ridge_half_gap: Dim = D("0")  # optional extra horizontal ridge allowance
    girt_clip: str = "PC8D"
    girt_elevations: list[Dim] = field(default_factory=list)  # from base, e.g. 7'-6", 11'-6"
    purlin_clip: str = "PC8D"
    first_purlin: Dim = D("4'-10\"")  # along slope from column inner face
    first_purlin_datum: str = "column_face"  # legacy: rafter_cut
    purlin_spacing: Dim = D("4'-4\"")
    flange_brace_clip: str = "CLF2"
    flange_brace_at: list[int] = field(default_factory=lambda: [0, 2, 4])  # purlin indices that get a brace pair
    flange_brace_y: Dim = D("11")  # hole from top of rafter
    eave_strut_depth: Dim = D("8")
    base_elevation: Dim = D("0")  # floor to bottom of base plate, positive above floor
    box_height: Dim = D("14")  # used only when auto_connections is false
    height_mode: str = "top_eave_strut"
    auto_connections: bool = True
    apex_bottom_half: Optional[Dim] = None  # explicit finished half; new UI defaults to 6 inches
    eave_start_clip: bool = False  # new wizard enables; preserve old saved layouts
    peak_clip_edge: Optional[Dim] = None  # ridge to near edge along slope; new UI 11 inches
    apex_reference_half: Optional[Dim] = None  # gable-only override; None follows shared rule
    connection_bottom_mode: str = "column_depth"
    connection_bottom: Dim = D("10 1/2")
    top_extension: Dim = D("0")
    flange_thk: Dim = D("1/4")
    web_thk: Dim = D("3/16")
    weld_size: str = '1/4"'
    plate_mode: str = "member"
    girt_mode: str = "bypass"
    purlin_mode: str = "bypass"
    girt_attachment: str = "web_weld"  # flush girts on W columns: web_weld (coped) | web_clip (plate clips)
    # Welded W gable ridge: standard (cut-and-fold one-piece rafter wherever it applies - the shop
    # standard since v0.8.39, the shared ridge plate elsewhere) | cut_and_fold | plate (option).
    ridge_fabrication: str = "standard"
    girt_web_y: Dim = D("4")
    purlin_web_y: Dim = D("4")
    girt_side: str = "NS"
    purlin_side: str = "NS"
    kind_column: str = "COLUMN"
    kind_rafter: str = "RAFTER"

    def to_json(self) -> dict:
        return {
            "bay_zones": copy.deepcopy(self.bay_zones),
            "welded_fit_rules": copy.deepcopy(self.welded_fit_rules),
            "girt_clip_adjustments": copy.deepcopy(self.girt_clip_adjustments),
            "eave_clip": self.eave_clip,
            "welded_knee": self.welded_knee,
            "welded_knee_overrides": copy.deepcopy(self.welded_knee_overrides),
            "base_connection": self.base_connection,
            "foundation": self.foundation,
            "footing_depth": self.footing_depth.fmt(),
            "footing_diameter": self.footing_diameter.fmt(),
            "clip_policy": self.clip_policy,
            "additions": self.additions,
            "grades": _grades_json(self.grades),
            "section_defaults": self.section_defaults,
            "endwalls": self.endwalls,
            "cladding": self.cladding,
            "length": None if self.length is None else self.length.fmt(),
            "auto_roof_spacing": self.auto_roof_spacing,
            "starting_wall_run": self.starting_wall_run,
            "starting_run": self.starting_run.fmt(),
            "slab": self.slab,
            "base_angle": self.base_angle,
            "bay_layout": self.bay_layout,
            "secondary": self.secondary,
            "connection_style": self.connection_style,
            "purlin_depth": self.purlin_depth.fmt(),
            "eave_plate_extension": self.eave_plate_extension.fmt(),
            "inset_for_bypass": self.inset_for_bypass,
            "girt_depth": self.girt_depth.fmt(),
            "high_girt_elevations": None
            if self.high_girt_elevations is None
            else [x.fmt() for x in self.high_girt_elevations],
            "frame_type": self.frame_type,
            "high_column_mark": self.high_column_mark,
            "high_column_cut_mark": self.high_column_cut_mark,
            "high_column_section": self.high_column_section,
            "prefix": self.prefix,
            "frames": self.frames,
            "width": self.width.fmt(),
            "eave_height": self.eave_height.fmt(),
            "slope_rise": str(self.slope_rise),
            "column_section": self.column_section,
            "rafter_section": self.rafter_section,
            "column_mark": self.column_mark,
            "rafter_mark": self.rafter_mark,
            "column_cut_mark": self.column_cut_mark,
            "rafter_cut_mark": self.rafter_cut_mark,
            "base_plate": self.base_plate,
            "knee_bracket": self.knee_bracket,
            "rafter_end_plate": self.rafter_end_plate,
            "column_top_gap": self.column_top_gap.fmt(),
            "knee_setback": self.knee_setback.fmt(),
            "ridge_half_gap": self.ridge_half_gap.fmt(),
            "girt_clip": self.girt_clip,
            "girt_elevations": [g.fmt() for g in self.girt_elevations],
            "purlin_clip": self.purlin_clip,
            "first_purlin_datum": self.first_purlin_datum,
            "first_purlin": self.first_purlin.fmt(),
            "purlin_spacing": self.purlin_spacing.fmt(),
            "flange_brace_clip": self.flange_brace_clip,
            "flange_brace_at": list(self.flange_brace_at),
            "flange_brace_y": self.flange_brace_y.fmt(),
            "eave_strut_depth": self.eave_strut_depth.fmt(),
            "base_elevation": self.base_elevation.fmt(),
            "box_height": self.box_height.fmt(),
            "height_mode": self.height_mode,
            "auto_connections": self.auto_connections,
            "detail_version": DETAIL_VERSION,
            "eave_start_clip": self.eave_start_clip,
            "apex_bottom_half": None if self.apex_bottom_half is None else self.apex_bottom_half.fmt(),
            "peak_clip_edge": None if self.peak_clip_edge is None else self.peak_clip_edge.fmt(),
            "apex_reference_half": None if self.apex_reference_half is None else self.apex_reference_half.fmt(),
            "connection_bottom_mode": self.connection_bottom_mode,
            "connection_bottom": self.connection_bottom.fmt(),
            "top_extension": self.top_extension.fmt(),
            "flange_thk": self.flange_thk.fmt(),
            "web_thk": self.web_thk.fmt(),
            "weld_size": self.weld_size,
            "girt_mode": self.girt_mode,
            "purlin_mode": self.purlin_mode,
            "girt_attachment": self.girt_attachment,
            "ridge_fabrication": self.ridge_fabrication,
            "girt_web_y": self.girt_web_y.fmt(),
            "purlin_web_y": self.purlin_web_y.fmt(),
            "girt_side": self.girt_side,
            "purlin_side": self.purlin_side,
            "geometry_version": 7,
            "plate_mode": self.plate_mode,
        }

    @classmethod
    def from_json(cls, d: dict) -> "FrameParams":
        p = cls()
        import copy

        for key in ('auto_roof_spacing', 'starting_wall_run', 'slab'):
            if key in d:
                if not isinstance(d[key], bool):
                    raise ValueError(key + ' must be true or false')
                setattr(p, key, d[key])
        p.starting_run = D(d.get('starting_run', '0'))
        p.base_angle = copy.deepcopy(d.get('base_angle') or {})
        p.bay_zones = copy.deepcopy(d.get("bay_zones") or {})
        p.section_defaults = copy.deepcopy(d.get("section_defaults") or {})
        p.welded_fit_rules = copy.deepcopy(d.get("welded_fit_rules") or {})  # legacy files keep explicit old allowances
        p.endwalls = copy.deepcopy(d.get("endwalls") or {})
        p.cladding = copy.deepcopy(d.get("cladding") or {})
        p.additions = copy.deepcopy(d.get("additions") or {})
        from .grades import normalize as normalize_grades

        p.grades = normalize_grades(d.get("grades"))
        p.length = D(d["length"]) if d.get("length") not in (None, "") else None
        p.bay_layout = copy.deepcopy(d.get("bay_layout") or {})
        p.secondary = copy.deepcopy(d.get("secondary") or {})
        p.girt_clip_adjustments = copy.deepcopy(d.get('girt_clip_adjustments') or [])
        if not isinstance(p.girt_clip_adjustments, list) or len(p.girt_clip_adjustments) > 1000:
            raise ValueError('Girt adjustments must be a list of at most1000 entries')
        p.eave_clip = d.get('eave_clip', '')
        p.welded_knee = d.get('welded_knee', 'inside_flange')
        if p.welded_knee not in ('outside_seat', 'inside_flange'):
            raise ValueError('Unknown welded knee option')
        overrides = d.get('welded_knee_overrides') or {}
        if not isinstance(overrides, dict):
            raise ValueError('welded_knee_overrides must map physical frame/side locations to seat modes')
        clean_overrides = {}
        for location, mode in overrides.items():
            if not isinstance(location, str) or not re.fullmatch(r'[1-9][0-9]{0,4}:(left|right)', location):
                raise ValueError('Primary connection override keys are frame ordinal:side, e.g. 2:left')
            if mode in ('', None, 'inherit'):
                continue
            if mode not in ('outside_seat', 'inside_flange'):
                raise ValueError('Primary support mode must be inside_flange or outside_seat')
            clean_overrides[location] = mode
        p.welded_knee_overrides = clean_overrides
        p.base_connection = d.get('base_connection', 'base_plate')
        p.clip_policy = d.get('clip_policy', 'legacy')
        if p.base_connection not in ('base_plate', 'floor_weld'):
            raise ValueError('Unknown base connection')
        p.foundation = str(d.get('foundation') or 'slab').strip().lower()
        for key in ('footing_depth', 'footing_diameter'):
            if d.get(key) not in (None, ''):
                setattr(p, key, D(d[key]))
        from . import foundation as FND

        for err in FND.validate(p):
            raise ValueError(err)
        if p.clip_policy not in ('legacy', 'member_sized'):
            raise ValueError('Unknown clip policy')
        p.connection_style = d.get('connection_style', 'bolted')
        for key in ('purlin_depth', 'eave_plate_extension', 'girt_depth'):
            if d.get(key) not in (None, ''):
                setattr(p, key, D(d[key]))
        if 'inset_for_bypass' in d:
            if not isinstance(d['inset_for_bypass'], bool):
                raise ValueError('inset_for_bypass must be true or false')
            p.inset_for_bypass = d['inset_for_bypass']
        if "eave_start_clip" in d:
            if not isinstance(d["eave_start_clip"], bool):
                raise ValueError("eave_start_clip must be true or false")
            p.eave_start_clip = d["eave_start_clip"]
        p.connection_bottom_mode = d.get(
            "connection_bottom_mode",
            "manual" if D(d.get("connection_bottom", "10 1/2")) != D("10 1/2") else "column_depth",
        )
        for name in ('apex_bottom_half', 'peak_clip_edge'):
            if d.get(name) not in (None, ''):
                setattr(p, name, D(d[name]))
        if d.get("apex_reference_half") not in (None, ""):
            p.apex_reference_half = D(d["apex_reference_half"])
        p.first_purlin_datum = d.get("first_purlin_datum", "rafter_cut")
        p.plate_mode = d.get("plate_mode", "library")  # preserve old saved frames
        for k in (
            "frame_type",
            "high_column_mark",
            "high_column_cut_mark",
            "high_column_section",
            "prefix",
            "column_section",
            "rafter_section",
            "column_mark",
            "rafter_mark",
            "column_cut_mark",
            "rafter_cut_mark",
            "base_plate",
            "knee_bracket",
            "rafter_end_plate",
            "girt_clip",
            "purlin_clip",
            "flange_brace_clip",
            "height_mode",
            "weld_size",
            "girt_mode",
            "purlin_mode",
            "girt_attachment",
            "ridge_fabrication",
            "girt_side",
            "purlin_side",
        ):
            if d.get(k) not in (None, ""):
                setattr(p, k, str(d[k]).strip())
        for k in (
            "width",
            "eave_height",
            "column_top_gap",
            "knee_setback",
            "ridge_half_gap",
            "first_purlin",
            "purlin_spacing",
            "flange_brace_y",
            "eave_strut_depth",
            "base_elevation",
            "box_height",
            "connection_bottom",
            "top_extension",
            "flange_thk",
            "web_thk",
            "girt_web_y",
            "purlin_web_y",
        ):
            if d.get(k) not in (None, ""):
                setattr(p, k, D(d[k]))
        if "auto_connections" in d:
            if not isinstance(d['auto_connections'], bool):
                raise ValueError('auto_connections must be true or false')
            p.auto_connections = d['auto_connections']
        if 'frames' in d:
            p.frames = int(d["frames"])
            if p.frames != float(d['frames']):
                raise ValueError('Frames must be an integer')
        if d.get("slope_rise") not in (None, ""):
            p.slope_rise = Fraction(str(d["slope_rise"]))
        if "girt_elevations" in d:
            g = d["girt_elevations"]
            if isinstance(g, str):
                g = [x for x in g.replace(";", ",").split(",") if x.strip()]
            p.girt_elevations = [D(x) for x in g]
        if d.get('high_girt_elevations') is not None:
            value = d['high_girt_elevations']
            if isinstance(value, str):
                if not value.strip():
                    value = None
                elif value.strip().lower() == 'none':
                    value = []
                else:
                    value = [x.strip() for x in value.replace(';', ',').split(',') if x.strip()]
            p.high_girt_elevations = None if value is None else [D(x) for x in value]
        if "flange_brace_at" in d:
            fa = d["flange_brace_at"]
            if isinstance(fa, str):
                fa = [x for x in fa.replace(";", ",").split(",") if x.strip()]
            p.flange_brace_at = [int(x) for x in fa]
        p.column_section = sections.normalize(p.column_section)
        p.rafter_section = sections.normalize(p.rafter_section)
        return p


def slope_deg(rise: Fraction) -> float:
    return math.degrees(math.atan(float(rise) / 12.0))


def dependency_key(job, p):
    """Track actual selected clip/library geometry as well as frame drivers."""
    from .plate_rules import rules

    names = {p.girt_clip, p.purlin_clip, p.flange_brace_clip}
    if p.eave_clip:
        names.add(p.eave_clip)
    if p.girt_clip == 'PC6D-MBCI':
        names.add('PC8D')
    if p.plate_mode == 'library':
        names.update([p.base_plate, p.rafter_end_plate])
    if not p.auto_connections:
        names.add(p.knee_bracket)
    parts = {}
    for mark in sorted(names):
        part = job.part(mark)
        raw = part.to_json()
        parts[mark] = {k: raw.get(k) for k in ('kind', 'thk', 'width', 'length', 'holes', 'section', 'cut_length')}
        parts[mark]['shape'] = {k: part.symbol.get(k) for k in ('w', 'h', 'cut_contour')}
    data = dict(params=p.to_json(), parts=parts, rules=rules(job), order_options=job.settings.get('order_options', {}))
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def ridge_fabrication_resolved(p) -> str:
    """``cut_and_fold`` or ``plate`` for this frame.

    ``standard`` (the default) is the shop standard: the one-piece cut-and-fold rafter on every
    fully welded gable frame with W rafters, the shared ridge plate wherever that does not apply
    (bolted / welded box / mono-slope / channel rafters).  An explicit choice is kept.
    """
    v = getattr(p, 'ridge_fabrication', 'standard') or 'standard'
    if v != 'standard':
        return v
    welded_gable_w = (
        p.connection_style == 'fully_welded'
        and p.frame_type != 'monoslope'
        and str(p.rafter_section or '').upper().startswith('W')
    )
    return 'cut_and_fold' if welded_gable_w else 'plate'


def generate_frame(job: Job, p: FrameParams) -> list[Assembly]:
    """Atomic parametric frame generation, including low knees and symmetric apex."""
    import copy

    from .building import apply as apply_building
    from .building import finish as finish_building
    from .cladding import apply as apply_cladding
    from .cladding import finish as finish_cladding
    from .endwalls import apply as apply_ends
    from .endwalls import finish as finish_ends
    from .framing_additions import apply as apply_additions
    from .framing_additions import finish as finish_additions
    from .secondary_catalog import apply, finish
    from .secondary_runs import apply as apply_runs
    from .secondary_runs import finish as finish_runs

    p = copy.deepcopy(p)
    from .bay_zones import apply as apply_zones
    from .bay_zones import finish as finish_zones
    from .enclosure import apply as apply_enclosure

    apply_enclosure(p)
    from .wall_girts import apply as apply_wall_girts

    apply_wall_girts(p)  # sheets never without girts: standard lines / base angle / end framing
    apply_zones(p)
    apply_building(p)
    apply(p)
    if not isinstance(p.welded_fit_rules, dict) or not isinstance(p.welded_fit_rules.get("enabled", False), bool):
        raise ValueError("Welded fit rules enabled must be boolean")
    work = Job.loads(job.dumps())
    for k in [
        k
        for k, b in work.assemblies.items()
        if b.derivation.get('grade_variant') and b.derivation.get('frame_id') == p.column_mark
    ]:
        del work.assemblies[k]  # column grade variants (COL-1A ...) are rebuilt by grades.finish
    from .girt_clips import prepare as prepare_clips

    prepare_clips(work, p)
    apply_ends(p)  # resolves the width-preset column / rafter sections first
    if p.girt_mode == 'flush':
        # Outside girt datum stays fixed. Seat the selected clip inside the
        # flange, rather than forcing a6in clip through a column flange.
        from .sections import get_section

        sec = get_section(p.column_section)
        clip = work.part(p.girt_clip)
        p.girt_side = 'both'
        # girt welded directly to the web: the girt centre sits half the girt depth inside the flange
        clip_half = float(clip.width.inches) / 2 if clip.width is not None else float(p.girt_depth.inches) / 2
        p.girt_web_y = D(Fraction(str(max(float(p.girt_depth.inches) / 2, (sec.tf or 0) + clip_half))))
    apply_runs(p)
    apply_cladding(p)
    apply_additions(p)
    from .grades import normalize as normalize_grades

    p.grades = normalize_grades(p.grades)
    from .layout_options import finish as finish_options
    from .layout_options import geometry_params, validate

    validate(p)
    from .supplier_products import validate_frame

    validate_frame(work, p)
    made = _generate_frame(work, geometry_params(p))
    from .girt_adjustments import apply as apply_girt_adjustments

    apply_girt_adjustments(work, p)
    finish_options(work, p)
    finish(work, p)
    finish_runs(work, p)
    finish_ends(work, p)
    finish_zones(work, p)
    finish_additions(work, p)
    from .wall_connections import finish as finish_wall_connections

    finish_wall_connections(work, p)
    from .grades import finish as finish_grades

    finish_grades(work, p)  # column grade schedule / main-column variants / wall base steps
    finish_cladding(work, p)
    from .wall_girts import check as check_wall_girts

    work.assemblies[p.column_mark].derivation['secondary_warnings'].extend(check_wall_girts(work, p))
    finish_building(work, p)
    finish_zones(work, p)
    if p.welded_knee_overrides:
        from .welded_frame import split_physical_frame_connections

        made.extend(split_physical_frame_connections(work, p))
    work.settings['frames'][p.column_mark]['dependency_key'] = dependency_key(work, p)
    job.parts = work.parts
    job.assemblies = work.assemblies
    job.settings = work.settings
    return made


def _generate_frame(job: Job, p: FrameParams) -> list[Assembly]:
    from .base_options import mark as base_mark
    from .base_options import resolve as resolve_base
    from .base_options import thickness as base_thickness
    from .connections import build as build_connection

    mono = p.frame_type == 'monoslope'
    if p.frame_type not in ('gable', 'monoslope'):
        raise ValueError('Frame type must be gable or monoslope')
    old_frame = job.settings.get('frames', {}).get(p.column_mark)
    if old_frame and old_frame.get('frame_type', 'gable') != p.frame_type:
        raise ValueError('Use new member marks for a different frame type; existing managed type cannot be switched')
    if old_frame and (
        old_frame['rafter_mark'] != p.rafter_mark or (mono and old_frame.get('high_column_mark') != p.high_column_mark)
    ):
        raise ValueError('Managed assembly marks are fixed; use new frame marks instead of leaving orphaned members')
    if mono and (not p.auto_connections or p.height_mode != 'top_eave_strut'):
        raise ValueError('Mono-slope requires generated connections and top-of-eave-strut height datum')
    if mono and p.ridge_half_gap.inches != 0:
        raise ValueError('Mono-slope has no ridge allowance; set it to zero')
    if p.width.inches <= 0:
        raise ValueError('Building width must be positive')
    if mono and (
        len({p.column_mark, p.rafter_mark, p.high_column_mark}) != 3
        or len({p.column_cut_mark, p.rafter_cut_mark, p.high_column_cut_mark}) != 3
    ):
        raise ValueError('Low column, high column and rafter require distinct assembly and cut marks')
    if (
        p.connection_style != 'fully_welded'
        and p.apex_bottom_half is not None
        and not mono
        and p.apex_bottom_half.inches <= 0
    ):
        raise ValueError('Apex bottom half-length must be positive')
    if p.peak_clip_edge is not None and not mono and (p.peak_clip_edge.inches <= 0 or not p.auto_connections):
        raise ValueError('Peak clip requires a positive ridge-to-nearest-edge distance and linked connections')
    if p.frames < 1 or p.frames > 10000:
        raise ValueError('Frame quantity must be 1..10000')
    if p.welded_knee_overrides:
        if p.connection_style == 'bolted':
            raise ValueError('Per-column seat overrides are only supported on welded primary frames')
        stale = sorted(
            int(key.split(':', 1)[0]) for key in p.welded_knee_overrides if int(key.split(':', 1)[0]) > p.frames
        )
        if stale:
            raise ValueError(
                'Primary connection override refers to frame %d, but only %d rigid-frame lines are generated'
                % (stale[0], p.frames)
            )
    if p.column_mark == p.rafter_mark or p.column_cut_mark == p.rafter_cut_mark:
        raise ValueError('Column and rafter need distinct assembly and cut marks')
    if p.purlin_spacing.inches <= 0:
        raise ValueError('Purlin spacing must be positive')
    if p.first_purlin_datum not in ('outside_column', 'column_face', 'rafter_cut'):
        raise ValueError('First purlin datum must be outside_column, column_face (legacy inside), or rafter_cut')
    if p.first_purlin_datum in ('outside_column', 'column_face') and not p.auto_connections:
        raise ValueError('Column-face clip datum requires generated connections; use rafter_cut for manual connections')
    if p.first_purlin.inches < 0:
        raise ValueError('First purlin must be nonnegative')
    if not 0 <= p.slope_rise <= 12:
        raise ValueError('Pitch must be 0..12 rise per 12')
    if p.connection_style == 'bolted' and not p.secondary.get('eave') and p.eave_strut_depth.inches not in (6, 8):
        raise ValueError('Eave strut must be 6 or 8 inches')
    if p.height_mode not in ('top_eave_strut', 'legacy_column'):
        raise ValueError('Unknown height datum')
    if p.girt_attachment not in ('web_weld', 'web_clip'):
        raise ValueError('Flush girt attachment must be web_weld (coped, welded to the web) or web_clip (plate clips)')
    if p.ridge_fabrication not in ('standard', 'plate', 'cut_and_fold'):
        raise ValueError('Ridge fabrication must be plate (shared ridge plate) or cut_and_fold (one-piece rafter)')
    if p.ridge_fabrication == 'cut_and_fold':
        if p.connection_style != 'fully_welded':
            raise ValueError(
                'Cut-and-fold ridge must be fully welded (the rafter is one piece; there is no ridge connection)'
            )
        if mono:
            raise ValueError('Cut-and-fold ridge must be a gable frame (a mono-slope rafter has no ridge)')
        if not p.rafter_section.upper().startswith('W'):
            raise ValueError(
                'Cut-and-fold ridge must use a W rafter (channel rafters butt at the ridge with face plates)'
            )
    if p.girt_mode not in ('bypass', 'flush') or p.purlin_mode not in ('bypass', 'flush'):
        raise ValueError('Girt and purlin arrangements must be bypass or flush')
    if p.girt_side not in ('NS', 'FS', 'both') or p.purlin_side not in ('NS', 'FS', 'both'):
        raise ValueError('Flush clip side must be NS, FS or both')
    for value in (p.column_top_gap, p.knee_setback, p.ridge_half_gap, p.base_elevation, p.box_height):
        if value.inches < 0:
            raise ValueError('Offsets and gaps must be nonnegative')
    if p.plate_mode not in ('member', 'library'):
        raise ValueError('Plate mode must be member or library')
    from .plate_rules import migrate_plate_defaults

    migrate_plate_defaults(job)
    p.weld_size = p.weld_size or '1/4"'
    required = [p.girt_clip, p.purlin_clip, p.flange_brace_clip]
    if p.plate_mode == 'library':
        required += ([p.base_plate] if p.base_connection == 'base_plate' else []) + (
            [p.rafter_end_plate] if p.connection_style == 'bolted' else []
        )
    for mark in required:
        if mark and mark not in job.parts:
            raise KeyError(f'Part {mark!r} is not defined')
    if not p.auto_connections and p.knee_bracket not in job.parts:
        raise KeyError(p.knee_bracket)
    cs = sections.get_section(p.column_section)
    rs = sections.get_section(p.rafter_section)
    hs = sections.get_section(p.high_column_section or p.column_section)
    if cs.kind not in ('W', 'HSS') or hs.kind not in ('W', 'HSS'):
        raise ValueError('Primary columns require W or selected HSS tube; channels are rafter options')
    if rs.kind not in ('W', 'Channel'):
        raise ValueError('Tube library currently covers columns, not primary rafters')
    if rs.kind == 'Channel' and p.connection_style == 'bolted':
        raise ValueError('Supplier channel primary rafters currently require welded connections')
    theta = slope_deg(p.slope_rise)
    rad = math.radians(theta)
    sn, co = math.sin(rad), math.cos(rad)
    if p.connection_style not in ('bolted', 'fully_welded', 'welded_box'):
        raise ValueError('Unknown connection style')
    if p.connection_style != 'bolted':
        from .welded_frame import generate

        return generate(job, p)
    if old_frame and old_frame.get('connection_style', 'bolted') != 'bolted':
        from .welded_frame import clear_owned

        clear_owned(job, p.column_mark)
    if p.plate_mode == 'member':
        from .plate_rules import make

        bp = resolve_base(job, p, p.column_section)
        ep = make(job, 'K', p.rafter_section, p.column_section, p.weld_size)
        ridge_ep = make(job, 'K' if mono else 'R', p.rafter_section, hs.name if mono else p.column_section, p.weld_size)
        high_bp = resolve_base(job, p, hs.name) if mono else bp
    else:
        bp = resolve_base(job, p, p.column_section)
        ep = job.part(p.rafter_end_plate)
        ridge_ep = ep
        high_bp = bp
    if (bp is not None and bp.thk is None) or ep.thk is None:
        raise ValueError('Base and end plates require thickness')
    column = Assembly(
        p.column_mark,
        p.kind_column,
        (1 if mono else 2) * p.frames,
        MainMember(p.column_cut_mark, p.column_section, D('1')),
    )
    rafter = Assembly(
        p.rafter_mark,
        p.kind_rafter,
        (1 if mono else 2) * p.frames,
        MainMember(p.rafter_cut_mark, p.rafter_section, D('1')),
    )
    high_column = (
        Assembly(p.high_column_mark, p.kind_column, p.frames, MainMember(p.high_column_cut_mark, hs.name, D(1)))
        if mono
        else None
    )
    members = [column, rafter] + ([high_column] if mono else [])
    params = p.to_json()
    for a in members:
        a.derivation = {'wizard': 'rigid-frame', 'params': params, 'frame_id': p.column_mark}
    # Do not replace an unrelated assembly silently when the user chooses a used mark.
    for a in members:
        old = job.assemblies.get(a.mark)
        if old and old.derivation.get('frame_id') != p.column_mark:
            raise ValueError(f'{a.mark} already exists; choose unused frame member marks')
    for a in members:
        if any(
            b.main.mark == a.main.mark and b.derivation.get('frame_id') != p.column_mark
            for b in job.assemblies.values()
        ):
            raise ValueError('Cut mark already belongs to another assembly: ' + a.main.mark)
        job.assemblies[a.mark] = a
    box = float(p.box_height.inches)
    knee = p.knee_bracket
    mate = ep.mark
    ridge_mate = ridge_ep.mark
    projection_knee = projection_ridge = 0.0
    connection_plates = 0.0
    if p.auto_connections:
        knee = 'KB-' + p.column_mark
        ridge = ('KB-' + p.high_column_mark) if mono else 'AP-' + p.column_mark
        oldcfg = job.settings.get('connections', {})
        for mark in (knee, ridge):
            if mark in oldcfg and oldcfg[mark].get('frame_id') != p.column_mark:
                raise ValueError('Connection mark belongs to another lot: ' + mark)
        common = dict(
            column=p.column_mark,
            rafter=p.rafter_mark,
            rise=str(p.slope_rise),
            pitch_source='frame',
            bottom=p.connection_bottom.fmt(),
            bottom_mode=p.connection_bottom_mode,
            top_extension=p.top_extension.fmt(),
            flange_thk=p.flange_thk.fmt(),
            web_thk=p.web_thk.fmt(),
            weld_size=p.weld_size,
            end_plate=ep.mark,
            plate_mode=p.plate_mode,
            frame_id=p.column_mark,
            installed=True,
        )
        start_spec = (
            {'start_clip': dict(part=p.purlin_clip, mode=p.purlin_mode, web_y=p.purlin_web_y.fmt(), side=p.purlin_side)}
            if p.eave_start_clip
            else {}
        )
        low = build_connection(
            job,
            knee,
            {**common, **start_spec, 'kind': 'low', 'qty': (1 if mono else 2) * p.frames, 'frame_role': 'knee'},
        )
        ridge_overrides = (
            {}
            if mono or p.apex_reference_half is None
            else dict(bottom_mode='manual', bottom=p.apex_reference_half.fmt())
        )
        if not mono and p.apex_bottom_half is not None:
            ridge_overrides = {'apex_bottom_half': p.apex_bottom_half.fmt()}
        apex = build_connection(
            job,
            ridge,
            {
                **common,
                **ridge_overrides,
                **(start_spec if mono else {}),
                'kind': 'high' if mono else 'apex',
                'column': p.high_column_mark if mono else p.column_mark,
                'end_plate': ridge_ep.mark,
                'qty': p.frames,
                'frame_role': 'high_eave' if mono else 'ridge',
            },
        )
        box = low.symbol['h']
        mate = low.symbol['mate']
        ridge_mate = apex.symbol['mate']
        # Mid-depth mating-plane horizontal projections. Both eave and apex plate
        # stacks are then deducted ALONG the rafter axis, not horizontally.
        projection_knee = low.symbol['rafter_center_face_x_in']
        projection_ridge = apex.symbol['rafter_center_face_x_in']
        connection_plates = float(ep.thk.inches + ridge_ep.thk.inches)
    elif p.column_mark in job.settings.get('frames', {}) and job.settings['frames'][p.column_mark].get(
        'auto_connections'
    ):
        raise ValueError('Create a separate manual frame rather than disabling an existing managed connection set')
    if p.height_mode == 'legacy_column':
        subtract_strut = 0
        subtract_box = 0
    else:
        subtract_strut = float(p.eave_strut_depth.inches)
        subtract_box = box
    from . import foundation as FND

    column_bottom = FND.column_bottom_in(p, base_thickness(bp))  # relative to the floor datum
    exact_col = (
        float(p.eave_height.inches) - subtract_strut - subtract_box - column_bottom - float(p.column_top_gap.inches)
    )
    col_len = Dim(grid16(exact_col))
    if col_len.inches <= 0:
        raise ValueError('Eave deductions leave a nonpositive column cut length')
    col_deriv = (
        f'column cut = floor-to-top-eave {p.eave_height.fmt()} - strut {subtract_strut:.6f} in'
        f' - box {subtract_box:.6f} in'
        + (
            f' + post footing embedment {FND.depth(p).fmt()} (no base plate)'
            if FND.is_post_footing(p)
            else f' - base elevation {p.base_elevation.fmt()} - base plate {base_thickness(bp):g}in'
        )
        + f' - top gap {p.column_top_gap.fmt()} = {col_len.fmt()} (nearest 1/16)'
    )
    column.main.cut_length = col_len
    column.main.derivation = col_deriv
    column.attachments = ([Attachment(bp.mark, 'left_end', show_first_hole_ref=True)] if bp else []) + [
        Attachment(knee, 'right_end', tilt=theta)
    ]
    high_eave = p.eave_height + p.width * (p.slope_rise / 12)
    if mono:
        high_exact = (
            float(high_eave.inches)
            - float(p.eave_strut_depth.inches)
            - apex.symbol['h']
            - FND.column_bottom_in(p, base_thickness(high_bp))
            - float(p.column_top_gap.inches)
        )
        if high_exact <= 0:
            raise ValueError('High-eave deductions leave nonpositive column cut')
        high_column.main.cut_length = Dim(grid16(high_exact))
        high_column.main.derivation = (
            f'high eave = low eave {p.eave_height.fmt()} + width {p.width.fmt()} x {p.slope_rise}/12 = {high_eave.fmt()}; '
            f'column cut subtracts strut, derived HIGH bracket, base elevation/thickness and top gap = {high_column.main.cut_length.fmt()}'
        )
        high_column.attachments = (
            [Attachment(high_bp.mark, 'left_end', show_first_hole_ref=True)] if high_bp else []
        ) + [Attachment(ridge, 'right_end', tilt=-theta)]
        high_column.derivation.update(
            resolved_base_plate=base_mark(high_bp),
            foundation=FND.record(p),
            embed_in=FND.embed_in(p),
            resolved_knee_plate=ridge_ep.mark,
            column_cut_unrounded_in=high_exact,
            box_height_in=apex.symbol['h'],
            high_eave_height=high_eave.fmt(),
            formula=high_column.main.derivation,
            qty=f'1 high column x {p.frames} frames',
            frame_role='high_column',
        )

    def clip(part, mode, station, y, side, note, first=False):
        return Attachment(
            part,
            'top' if mode == 'bypass' else 'web',
            station,
            side=side if mode == 'flush' else 'NS',
            ref='center',
            y_from_top=y if mode == 'flush' else None,
            note=note,
            show_first_hole_ref=first,
        )

    for i, elev in enumerate(p.girt_elevations):
        station = elev - D(Fraction(str(column_bottom)))
        if not 0 <= station.inches <= col_len.inches:
            raise ValueError('Girt elevation falls outside the column: ' + elev.fmt())
        column.attachments.append(
            clip(p.girt_clip, p.girt_mode, station, p.girt_web_y, p.girt_side, 'girt ' + p.girt_mode, i == 0)
        )
    if mono:
        for i, elev in enumerate(p.girt_elevations if p.high_girt_elevations is None else p.high_girt_elevations):
            high_station = elev - D(Fraction(str(FND.column_bottom_in(p, base_thickness(high_bp)))))
            if not 0 <= high_station.inches <= high_column.main.cut_length.inches:
                raise ValueError('Girt elevation outside high column')
            high_column.attachments.append(
                clip(p.girt_clip, p.girt_mode, high_station, p.girt_web_y, p.girt_side, 'girt ' + p.girt_mode, i == 0)
            )
    column_deduction = 0.0 if p.auto_connections else cs.d
    span = float(p.width.inches) / (1 if mono else 2)
    far_allowance = float(p.knee_setback.inches) if mono else float(p.ridge_half_gap.inches)
    run = span - column_deduction - projection_knee - projection_ridge - float(p.knee_setback.inches) - far_allowance
    along = run / co
    mating_plates = float(ep.thk.inches + ridge_ep.thk.inches)
    cut = along - connection_plates - mating_plates
    raf_len = Dim(grid16(cut))
    if raf_len.inches <= 0:
        raise ValueError('Connection projections leave a nonpositive rafter cut length')
    if float(raf_len.inches) / float(p.purlin_spacing.inches) > 10000:
        raise ValueError('Purlin layout exceeds 10000 stations')
    raf_deriv = (
        'run = '
        + ('full width' if mono else 'width/2')
        + f' {span:.6f} - column depth deduction {column_deduction:.6f} (bracket spans column top when linked)'
        f' - knee mid-face projection {projection_knee:.6f} - far connection mid-face projection {projection_ridge:.6f}'
        f' - extra setback {float(p.knee_setback.inches):.6f} - far horizontal allowance {far_allowance:.6f}'
        f' = {run:.6f} in; along = run/cos({theta:.6f} deg);'
        f' subtract connection end plates {connection_plates:.6f} and rafter mating plates {mating_plates:.6f} in;'
        f' cut = {raf_len.fmt()} (nearest 1/16)'
    )
    rafter.main.cut_length = raf_len
    rafter.main.derivation = raf_deriv
    rafter.derivation["rafter_cut_unrounded_in"] = cut
    rafter.attachments = [Attachment(mate, 'left_end'), Attachment(ridge_mate, 'right_end')]
    # Column-face datum is on the top-line extension, at the inner column face.
    # Body top run plus BOTH interface plates is the occupied sloping length.
    # Optional horizontal knee setback is converted once, not mixed with slope.
    occupied = (
        (low.symbol['inner_column_to_rafter_cut_in'] + float(p.knee_setback.inches) / co) if p.auto_connections else 0.0
    )
    if p.first_purlin_datum == 'outside_column':
        occupied += cs.d / co
    first_exact = float(p.first_purlin.inches) - (
        occupied if p.first_purlin_datum in ('outside_column', 'column_face') else 0
    )
    if not p.auto_roof_spacing and first_exact < 0:
        raise ValueError('First purlin falls inside the bracket/plate stack; increase the column-face distance')
    if not p.auto_roof_spacing and first_exact >= float(raf_len.inches) - 6:
        raise ValueError('First purlin lies outside the usable rafter clip range')
    first_station = Dim(grid16(first_exact))
    stations = []
    st = first_station
    peak = None
    limit = raf_len.inches - Fraction(6)
    if not mono and p.peak_clip_edge is not None:
        cp = job.part(p.purlin_clip)
        if cp.kind not in ('clip', 'plate') or cp.thk is None or cp.length is None or cp.width is None:
            raise ValueError('Peak clip needs a defined plate/clip thickness, length and width')
        if min(cp.thk.inches, cp.length.inches, cp.width.inches) <= 0:
            raise ValueError('Peak clip dimensions must be positive')
        thickness = float(cp.thk.inches)
        # Selected clips stand normal to the roof (or project from web): thickness runs along roof.
        ridge_from_start = span / co - (
            low.symbol['rafter_top_xy'][0] / co + 2 * float(ep.thk.inches) + float(p.knee_setback.inches) / co
        )
        exact_station = ridge_from_start - float(p.peak_clip_edge.inches) - thickness / 2
        # Round toward the eave, NEVER closer to the ridge than the requested edge.
        peak_station = Dim(Fraction(math.floor(exact_station * 16 + 1e-8), 16))
        actual_edge = ridge_from_start - float(peak_station.inches) - thickness / 2
        from .drawing.connection_views import side_geometry

        steel_extent = max(
            x * co - (y - apex.symbol['h']) * sn
            for _, pts, _ in side_geometry(job, apex, False, False)[0]
            for x, y in pts
        )
        if peak_station.inches <= 0:
            raise ValueError('Peak clip is outside the roof span; check ridge distance and building width')
        if not p.auto_roof_spacing and float(first_station.inches) + thickness >= float(peak_station.inches):
            raise ValueError('First purlin and peak clip overlap or reverse; revise their distances or span')
        peak = dict(
            input_edge_in=float(p.peak_clip_edge.inches),
            actual_edge_in=actual_edge,
            station_from_cut=peak_station.fmt(),
            station_in=float(peak_station.inches),
            rounding_away_from_ridge_in=actual_edge - float(p.peak_clip_edge.inches),
            thickness_in=thickness,
            height_in=float(cp.length.inches),
            mode=p.purlin_mode,
            web_center_in=float(p.purlin_web_y.inches),
            web_height_in=float(cp.width.inches),
            apex_steel_extent_in=steel_extent,
            clip_clearance_in=actual_edge - steel_extent,
            part=cp.mark,
            datum='ridge centerline to nearest clip edge ALONG SLOPE',
            status='3-inch mating-plate clearance warnings only; location retained; full purlin profile NOT modeled',
        )
        limit = min(limit, peak_station.inches - cp.thk.inches)
    if p.auto_roof_spacing:
        from .layout_options import equal_stations

        endpoint = float(peak_station.inches) if peak is not None else float(limit)
        # Eave zero is outside-column roof-line datum, behind the bolted stack.
        zero = -(low.symbol['inner_column_to_rafter_cut_in'] + float(p.knee_setback.inches) / co + cs.d / co)
        stations = [Dim(grid16(x)) for x in equal_stations(endpoint, zero)]
        if any(x.inches < 0 for x in stations):
            raise ValueError('Equal roof spacing places a regular row inside the eave bracket; revise geometry')
        if peak is None:
            stations.append(Dim(grid16(endpoint)))
    else:
        while st.inches < limit:
            stations.append(st)
            st = st + p.purlin_spacing
    if peak is not None:
        stations.append(peak_station)
    rafter.derivation['peak_clip'] = peak
    # A fixed peak can lie on the rafter, on the apex top, or in the joint zone.
    if peak is not None:
        inner = apex.symbol['rafter_top_xy'][0] / co
        peak['support'] = (
            'apex'
            if peak['actual_edge_in'] + peak['thickness_in'] <= inner + 1e-8
            else 'rafter'
            if peak['actual_edge_in'] >= steel_extent - 1e-8
            else 'interface conflict'
        )
        if peak['support'] == 'apex':
            spec = dict(
                part=p.purlin_clip,
                mode=p.purlin_mode,
                side=p.purlin_side,
                web_y=p.purlin_web_y.fmt(),
                edge_in=peak['actual_edge_in'],
            )
            apex = build_connection(job, ridge, {**job.settings['connections'][ridge], 'peak_clip': spec})
    for i, st in enumerate(stations):
        if peak is not None and i == len(stations) - 1 and peak['support'] == 'apex':
            continue
        att = clip(
            p.purlin_clip,
            p.purlin_mode,
            st,
            p.purlin_web_y,
            p.purlin_side,
            ('peak purlin ' if peak is not None and i == len(stations) - 1 else 'purlin ') + p.purlin_mode,
            i == 0,
        )
        if peak is not None and i == len(stations) - 1:
            att.label = 'PEAK ' + p.purlin_clip
        rafter.attachments.append(att)
    for i in p.flange_brace_at:
        if 0 <= i < len(stations):
            rafter.attachments.append(
                Attachment(p.flange_brace_clip, 'web', stations[i], side='both', y_from_top=p.flange_brace_y)
            )
    for a, part, mode, y in [
        (column, p.girt_clip, p.girt_mode, p.girt_web_y),
        (rafter, p.purlin_clip, p.purlin_mode, p.purlin_web_y),
    ] + ([(high_column, p.girt_clip, p.girt_mode, p.girt_web_y)] if mono else []):
        if mode == 'flush':
            cp = job.part(part)
            if cp.kind == 'mark':
                continue  # girt welded directly to the web: no clip to fit between the flanges
            sec = a.main.sec
            if cp.width is None:
                raise ValueError('Flush clip requires plate geometry')
            # Current attachment renderer uses the clip center on the web; check
            # physical plate envelope, not a guessed flange hole datum.
            half = float(cp.width.inches) / 2
            if sec.kind == 'HSS':
                a.derivation.setdefault('section_fit_holds', []).append(
                    'HSS closed tube: clips on OUTSIDE side faces only; weld/bolt access and load path unverified'
                )
                continue
            if float(y.inches) - half < sec.tf - 1e-8 or float(y.inches) + half > sec.d - sec.tf + 1e-8:
                raise ValueError(f'{part} does not fit between flanges of {sec.name} at the chosen flush center offset')
    column.derivation.update(
        resolved_base_plate=base_mark(bp),
        resolved_knee_plate=ep.mark,
        resolved_ridge_plate=ridge_ep.mark,
        foundation=FND.record(p),
        embed_in=FND.embed_in(p),
        formula=col_deriv,
        box_height_in=subtract_box,
        eave_strut_depth_in=subtract_strut,
        column_cut_unrounded_in=exact_col,
        qty=f'{1 if mono else 2} low columns x {p.frames} frames',
    )
    rafter.derivation.update(
        first_purlin_datum=p.first_purlin_datum,
        first_purlin_input=p.first_purlin.fmt(),
        bracket_occupied_slope_in=occupied,
        first_purlin_unrounded_in=first_exact,
        first_purlin_formula=(
            f'first clip from steel cut = {p.first_purlin.fmt()} ({p.first_purlin_datum}, along slope)'
            + (
                ' - net bracket from '
                + ('OUTSIDE' if p.first_purlin_datum == 'outside_column' else 'INNER')
                + f' column face incl. END/MATE + setback {occupied:.6f} in'
                if p.first_purlin_datum in ('outside_column', 'column_face')
                else ''
            )
            + f' = {first_station.fmt()} (nearest 1/16); then spacing {p.purlin_spacing.fmt()}'
        ),
        formula=raf_deriv,
        purlin_stations=[x.fmt() for x in stations],
        qty=f'{1 if mono else 2} rafters x {p.frames} frames',
    )
    from .clip_clearance import check_edges

    checks = []
    near_gap = float(p.knee_setback.inches) / co
    far_gap = (float(p.knee_setback.inches) if mono else float(p.ridge_half_gap.inches)) / co
    plate_intervals = [
        (mate, -float(ep.thk.inches) - near_gap, -near_gap),
        (ridge_mate, cut + far_gap, cut + far_gap + float(ridge_ep.thk.inches)),
    ]
    cp = job.part(p.purlin_clip)
    ct = float(cp.thk.inches)
    for i, st in enumerate(stations):
        role = 'peak' if peak is not None and i == len(stations) - 1 else 'regular'
        owner = ridge if role == 'peak' and peak['support'] == 'apex' else rafter.mark
        check = check_edges(
            float(st.inches) - ct / 2,
            float(st.inches) + ct / 2,
            plate_intervals,
            owner,
            role,
            cp.mark,
            float(st.inches),
        )
        check['datum'] = 'rafter steel cut along roof slope (frame coordinate, including apex-mounted peak)'
        checks.append(check)
        if role == 'peak':
            peak['clearance_checks'] = check['checks']
            peak['warnings'] = check['warnings']
            if peak['support'] == 'interface conflict':
                peak['warnings'].append(
                    'Peak clip crosses the mating-plate joint zone; support is unresolved. Position retained for review.'
                )
            peak['clip_clearance_in'] = min(x['clearance_in'] for x in check['checks'])
    for conn in ([low, apex] if mono else [low]) if p.auto_connections else []:
        for rec in conn.symbol.get('roof_clips', []):
            if rec['role'] != 'starting':
                continue
            et = float(job.part(conn.mark + '-END').thk.inches)
            plate_at = conn.symbol['rafter_top_xy'][0] / co + et
            record = check_edges(
                rec['near_edge_in'],
                rec['far_edge_in'],
                [(conn.symbol['mate'], plate_at, plate_at + et)],
                conn.mark,
                'starting',
                rec['part'],
                rec['station_in'],
            )
            record['datum'] = 'bracket roof origin; outside edge is minus top extension on LOW, zero on HIGH'
            rec['clearance_checks'] = record['checks']
            rec['warnings'] = record['warnings']
            checks.append(record)
    rafter.derivation['clip_clearances'] = checks
    rafter.derivation['clip_warnings'] = [w for check in checks for w in check['warnings']]
    params['dependency_key'] = dependency_key(job, p)
    job.settings.setdefault('frames', {})[p.column_mark] = params
    if p.auto_connections:
        from .frame_layout import build_layout

        job.settings.setdefault('frame_layouts', {})[p.column_mark] = build_layout(
            job, p, low, apex, column, rafter, high_column
        )
    return members


def sync_frames(job: Job):
    """Regenerate managed geometry if its column/rafter section driver is edited."""
    for frame_id, params in list(job.settings.get('frames', {}).items()):
        if params['column_mark'] not in job.assemblies or params['rafter_mark'] not in job.assemblies:
            raise ValueError('Managed frame member removed; keep both members or use a new job')
        cs = job.assemblies[params['column_mark']].main.section
        rs = job.assemblies[params['rafter_mark']].main.section
        updated = {**params, 'column_section': cs, 'rafter_section': rs}
        high_changed = False
        if params.get('frame_type') == 'monoslope':
            hm = params['high_column_mark']
            if hm not in job.assemblies:
                raise ValueError('Managed high column removed')
            actual = job.assemblies[hm].main.section
            expected = params.get('high_column_section') or params['column_section']
            high_changed = actual != expected
            if high_changed:
                updated['high_column_section'] = actual
        # Rule migration (round 15).  0.8.44 forced a welded frame to FLUSH purlins; that is withdrawn
        # - the standard fit is BYPASS (the purlin bears on the rafter top flange and the eave purlin
        # sits on the column seat).  A job saved by 0.8.44 or earlier regenerates once with the bypass
        # fit stored; a fit chosen from here on is kept as saved.
        mode_migrated = (
            params.get('connection_style') != 'bolted'
            and params.get('purlin_mode') == 'flush'
            and params.get('detail_version', 0) < 27
        )
        if mode_migrated:
            updated['purlin_mode'] = 'bypass'
        drivers = FrameParams.from_json(updated)
        changed_inputs = params.get('dependency_key') != dependency_key(job, drivers)
        # Rule migration: end-wall rafters are FLUSH unless BYPASS is chosen explicitly. Saved jobs
        # whose end walls still follow the interior bypass (no explicit choice) are regenerated once.
        saved_ends = job.assemblies[params['column_mark']].derivation.get('endwalls') or {}
        legacy_end_roof = any(
            v.get('roof_mode') != 'flush'
            and (params.get('endwalls') or {}).get(k, {}).get('roof_mode') in (None, '', 'follow')
            for k, v in saved_ends.items()
            if isinstance(v, dict)
        )
        if legacy_end_roof:
            changed_inputs = True
        missing_peak = (
            drivers.peak_clip_edge is not None
            and drivers.frame_type == 'gable'
            and not job.settings.get('frame_layouts', {}).get(frame_id, {}).get('peak_clip')
        )
        # Rule migration (round 16): per-frame-line lean rafter fits and special open-C end
        # sections must be rebuilt from saved inputs; an older cached layout can show W bypass
        # at endpoints even though the current inputs specify special open-C ends.
        if (
            changed_inputs
            or mode_migrated
            or missing_peak
            or cs != params['column_section']
            or rs != params['rafter_section']
            or high_changed
            or params.get('geometry_version', 0) < 7
            or params.get('detail_version', 0) < DETAIL_VERSION
            or (params.get('auto_connections', True) and frame_id not in job.settings.get('frame_layouts', {}))
        ):
            generate_frame(job, FrameParams.from_json(updated))
