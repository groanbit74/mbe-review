"""Job-scoped proposed purchasing order and deterministic stock packing.
No capacity design, automatic member splice, invented quantity, or price claim.
"""

import copy
import hashlib
import json
import math
from collections import defaultdict
from fractions import Fraction
from functools import lru_cache

from .model import D

DEPARTMENTS = ('Frame', 'Secondaries', 'Sheets / Trim')
DEFAULTS = dict(
    channel_grade='UNSPECIFIED',
    channel_stock_ft=[20, 25],
    channel_mode='stock',
    beam_stock_ft=[20, 30, 40, 50, 60],
    purlin_stock_ft=[20, 25, 30],
    hss_stock_ft=[20, 24, 40],
    beam_mode='stock',
    purlin_mode='stock',
    hss_mode='stock',
    kerf_in=0.25,
    end_allowance_in=0,
    trim_max_in=246,
    trim_policy='exact_short_max_long',
    beam_grade='UNSPECIFIED',
    hss_grade='UNSPECIFIED',
    purlin_grade='UNSPECIFIED',
    plate_grade='UNSPECIFIED',
    beam_finish='UNSPECIFIED',
    hss_finish='UNSPECIFIED',
    mode_overrides={},
    additional_trim_runs=[],
)


def number(x):
    if isinstance(x, bool):
        raise ValueError('Dimension cannot be boolean')
    try:
        r = float(Fraction(str(x).strip().rstrip('"')))
    except (ValueError, ZeroDivisionError):
        r = float(D(x).inches)
    if not math.isfinite(r):
        raise ValueError('Dimension must be finite')
    return r


def up(x):
    return math.ceil(float(x) * 16 - 1e-8) / 16


def fmt(x):
    return D(Fraction(round(x * 16), 16)).fmt() if x is not None else 'PENDING'


def config(job=None, raw=None):
    raw = (job.settings.get('order_options', {}) if job is not None else raw) or {}
    if not isinstance(raw, dict):
        raise ValueError('Order options must be an object')
    c = copy.deepcopy(DEFAULTS)
    c.update(copy.deepcopy(raw))
    if job is not None and any(
        r.get('cladding', {}).get('owner_length_rules')
        or r.get('cladding', {}).get('trim_stock', {}).get('rake') == 'OWNER-FL1010-A4'
        for r in job.settings.get('frames', {}).values()
    ):
        c['trim_policy'] = 'exact_short_max_long'
    for family in ('beam', 'purlin', 'hss', 'channel'):
        values = c[family + '_stock_ft']
        if not isinstance(values, list) or not 1 <= len(values) <= 20:
            raise ValueError('Stock lengths require1..20 values')
        values = sorted(set(number(x) for x in values))
        if any(not 0 < x <= 120 or abs(x * 12 * 16 - round(x * 12 * 16)) > 1e-7 for x in values):
            raise ValueError('Stock lengths must be positive <=120ft and on1/16in increments')
        c[family + '_stock_ft'] = values
        if c[family + '_mode'] not in ('stock', 'exact', 'compare'):
            raise ValueError('Order mode must be stock or exact')
    for k, limit in [('kerf_in', 2), ('end_allowance_in', 12), ('trim_max_in', 246)]:
        c[k] = number(c[k])
        if not 0 <= c[k] <= limit or abs(c[k] * 16 - round(c[k] * 16)) > 1e-7:
            raise ValueError(k + ' must be nonnegative, within limit and on1/16in increments')
    if any(min(c[f + '_stock_ft']) * 12 <= 2 * c['end_allowance_in'] for f in ('beam', 'purlin', 'hss')):
        raise ValueError('End allowances consume shortest stock length')
    if c['trim_max_in'] <= 0:
        raise ValueError('Trim maximum must be positive')
    if c['trim_policy'] not in ('exact_short_max_long', 'catalog'):
        raise ValueError('Unknown trim ordering policy')
    for k in ('channel_grade', 'beam_grade', 'hss_grade', 'purlin_grade', 'plate_grade', 'beam_finish', 'hss_finish'):
        if not isinstance(c[k], str) or not c[k].strip() or len(c[k]) > 80:
            raise ValueError('Grade/finish must be a short nonempty label')
    if not isinstance(c['mode_overrides'], dict) or any(
        v not in ('stock', 'exact', 'compare') for v in c['mode_overrides'].values()
    ):
        raise ValueError('Material overrides must be stock/exact')
    if not isinstance(c['additional_trim_runs'], list) or len(c['additional_trim_runs']) > 100:
        raise ValueError('Maximum100 additional trim runs')
    for r in c['additional_trim_runs']:
        if not isinstance(r, dict):
            raise ValueError('Additional trim run must be an object')
        for k in ('profile', 'finish'):
            if not isinstance(r.get(k), str) or not r[k].strip() or len(r[k]) > 100:
                raise ValueError('Additional trim needs profile and finish/color specification')
        r['length_in'] = number(r.get('length_in', 0))
        r['lap_in'] = number(r.get('lap_in', 2))
        if not 0 < r['length_in'] <= 12000 or not 0 <= r['lap_in'] < c['trim_max_in']:
            raise ValueError('Additional trim length/lap invalid')
        q = r.get('quantity', 1)
        if isinstance(q, bool) or int(q) != float(q) or not 1 <= int(q) <= 100:
            raise ValueError('Additional trim quantity must be1..100')
        r['quantity'] = int(q)
    from .material_engine import settings

    c['material_engine'] = settings(c.get('material_engine'))
    return c


def trim_lengths(length, lap, maximum):
    if length <= 0 or maximum <= lap or lap < 0:
        raise ValueError('Trim length positive; lap must be below maximum')
    n = max(1, math.ceil((length - lap - 1e-8) / (maximum - lap)))
    return [maximum] * (n - 1) + [length - (n - 1) * (maximum - lap)]


def material_id(department, family, profile, finish, grade):
    return hashlib.sha256(json.dumps([department, family, profile, finish, grade]).encode()).hexdigest()[:12]


@lru_cache(maxsize=64)
def pack(lengths, stocks, kerf=0.25, end=0):
    """Compare variable/fixed-stock best-fit plans; minimize footage then bar count.
    All arithmetic in1/16in ticks. Not a global optimum or price optimizer.
    Kerf is reserved between finished blanks; a further cut from the final offcut
    is deducted from the reported remnant (up to remaining material at the end).
    """
    lens = tuple(int(round(up(x) * 16)) for x in lengths)
    sizes = tuple(sorted(int(round(s * 16)) for s in stocks))
    k = int(round(kerf * 16))
    e = int(round(end * 16))
    if any(x <= 0 for x in lens) or not sizes or sizes[0] <= 2 * e:
        raise ValueError('Invalid stock packing dimensions')
    if len(lens) > 2000:
        raise ValueError('More than2000 blanks in one material group: use exact ordering or split into batches')
    if any(x + 2 * e > sizes[-1] for x in lens):
        raise ValueError('Blank exceeds longest selected stock; select exact/custom, never auto-splice')
    candidates = []
    for descending in (True, False):
        indices = sorted(range(len(lens)), key=lambda i: (lens[i], -i), reverse=descending)
        for fixed in (None,) + sizes:
            if fixed is not None and max(lens, default=0) + 2 * e > fixed:
                continue
            bins = []
            for i in indices:
                size = lens[i]
                eligible = [
                    (b['size'] - 2 * e - b['used'] - k - size, j)
                    for j, b in enumerate(bins)
                    if b['used'] + k + size <= b['size'] - 2 * e
                ]
                if eligible:
                    _, j = min(eligible)
                    bins[j]['items'].append(i)
                    bins[j]['used'] += k + size
                else:
                    stock = fixed if fixed is not None else next(s for s in sizes if size + 2 * e <= s)
                    bins.append(dict(size=stock, used=size, items=[i]))
            for b in bins:
                b['size'] = next(s for s in sizes if b['used'] + 2 * e <= s)
            candidates.append(bins)
    # Small mixed-member pools benefit from exact multiset search: greedy
    # decreasing can strand a short rafter after filling a bar with lean members.
    # Bounded by both count and state space; larger pools keep the deterministic
    # heuristic rather than freezing the editor. No dimensions or marks change.
    from collections import Counter
    from itertools import product

    counts = Counter(lens)
    types = tuple(sorted(counts, reverse=True))
    initial = tuple(counts[t] for t in types)
    if len(lens) <= 32 and len(types) <= 6 and math.prod(n + 1 for n in initial) <= 2500:
        patterns = []
        for ns in product(*(range(n + 1) for n in initial)):
            q = sum(ns)
            if not q:
                continue
            need = sum(n * t for n, t in zip(ns, types)) + (q - 1) * k + 2 * e
            stock = next((v for v in sizes if v >= need), None)
            if stock is not None:
                patterns.append((ns, stock))

        @lru_cache(None)
        def solve(state):
            if not any(state):
                return (0, 0, ())
            first = next(i for i, n in enumerate(state) if n)
            best_solution = None
            for ns, stock in patterns:
                if not ns[first] or any(a > b for a, b in zip(ns, state)):
                    continue
                tail = solve(tuple(b - a for a, b in zip(ns, state)))
                candidate = (stock + tail[0], 1 + tail[1], ((stock, ns),) + tail[2])
                if best_solution is None or candidate < best_solution:
                    best_solution = candidate
            return best_solution

        exact = solve(initial)
        available = {t: [i for i, v in enumerate(lens) if v == t] for t in types}
        bins = []
        for stock, ns in exact[2]:
            indices = []
            for t, n in zip(types, ns):
                indices += available[t][:n]
                del available[t][:n]
            bins.append(dict(size=stock, used=sum(lens[i] for i in indices) + (len(indices) - 1) * k, items=indices))
        candidates.append(bins)
    best = min(candidates, key=lambda bs: (sum(b['size'] for b in bs), len(bs), tuple(b['size'] for b in bs)))
    result = []
    for b in best:
        tail = b['size'] - 2 * e - b['used']
        last_loss = min(k, tail) if tail else 0
        result.append(
            dict(
                stock_length_in=b['size'] / 16,
                indices=b['items'],
                blank_length_in=sum(lens[i] for i in b['items']) / 16,
                kerf_loss_in=((len(b['items']) - 1) * k + last_loss) / 16,
                end_loss_in=2 * e / 16,
                remnant_in=(tail - last_loss) / 16,
            )
        )
    return tuple(result)


def stock_lengths_in(job, family, profile, c=None):
    """Stock lengths (inches, ascending) a material is bought in.

    The job's order options by default; a selected SSS product (supplier policy on the job) is bought
    in its own catalog lengths instead (a Zee 21/26/30 ft, a Cee 20/25/30 ft).  The order optimiser and
    the purlin lay (``purlin_lay``) both read this, so a piece is laid out for the stock it is bought in.
    """
    c = c or config(job)
    stocks = [x * 12 for x in c.get(family + '_stock_ft', [])]
    if job.settings.get('product_suppliers') and str(profile).startswith('SSS-'):
        from .secondary_catalog import get as secondary

        stocks = [ft * 12 for ft in secondary(profile).get('available_stock_ft', [])]
    return sorted(float(x) for x in stocks)


def build(job):
    c = config(job)
    demands = []
    pending = []
    advisories = []  # informational notes; never order holds
    items = []
    bars = []
    allocations = []
    groups = []
    comparisons = []

    def item(dept, material, finish, grade, L, q, basis, status, ref, group_id='', family='', unit='ea'):
        r = dict(
            department=dept,
            material=material,
            finish=finish,
            grade=grade,
            order_length_in=L,
            order_length=fmt(L) if L is not None else '',
            quantity=q,
            unit=unit,
            basis=basis,
            status=status,
            references=ref,
            material_group=group_id,
            family=family,
            custom_mark='',
        )
        items.append(r)
        return r

    def hold(dept, material, q, mark, reason, L=None, advisory=False):
        # Policy / disclaimer wording and explicit scope notes are informational;
        # only concrete, input-resolvable gaps are order holds.
        from . import holds as H

        (advisories if advisory or H.is_disclaimer(reason) else pending).append(
            dict(
                department=dept,
                material=material,
                quantity=q,
                reference=mark,
                required_length_in=L,
                required_length=fmt(L),
                reason=reason,
            )
        )

    def demand(dept, family, profile, finish, L, q, mark, owner, status='', grade=None):
        grade = grade or c.get(family + '_grade', 'UNSPECIFIED')
        q = int(q or 0)
        if q <= 0:
            hold(dept, profile, None, mark, 'QUANTITY NOT PROVIDED')
            return
        if L is None:
            hold(dept, profile, q, mark, status or 'CUT LENGTH PENDING')
            return
        if L <= 0:
            hold(dept, profile, q, mark, 'NONPOSITIVE CUT LENGTH', L)
            return
        gid = material_id(dept, family, profile, finish, grade)
        demands.append(
            dict(
                department=dept,
                family=family,
                profile=profile,
                finish=finish,
                grade=grade,
                quantity=q,
                mark=mark,
                owner=owner,
                exact_blank_length_in=float(L),
                blank_length_in=up(L),
                blank_length=fmt(up(L)),
                status=status or 'GEOMETRY REVIEW',
                material_group=gid,
                nominal_span_in=None,
                net_fit_deduction_in=None,
                fit_basis=status or 'Long blank; no nominal span inferred',
            )
        )

    from .secondary_catalog import get as secondary

    def secondary_demand(profile, finish, L, q, mark, owner, status):
        if str(profile).upper().startswith('HSS '):
            # HSS opening uprights use the same nominal tube library and stock/weight
            # calculations as frame columns; they are not cold-formed secondary catalog IDs.
            from .tube_sections import get as tube_section

            try:
                tube_section(profile)
            except (KeyError, ValueError):
                hold('Frame', profile, q, mark, 'UNKNOWN HSS TUBE PROFILE: ' + status, L)
                return
            demand('Frame', 'hss', profile, c['hss_finish'], L, q, mark, owner, status)
            return
        try:
            pr = secondary(profile)
        except ValueError:
            hold('Secondaries', profile, q, mark, 'UNKNOWN PROFILE: ' + status, L)
            return
        family = (
            'channel'
            if pr['family'] == 'Channel'
            else 'purlin'
            if pr['family'] in ('C', 'Z')
            else 'fixed'
            if pr.get('stock_length_ft')
            else 'exact'
        )
        if family == 'fixed':
            family = 'fixed:' + str(pr['stock_length_ft'])
        demand('Frame' if family == 'channel' else 'Secondaries', family, profile, finish, L, q, mark, owner, status)

    # Do not use low-point dimension from cut_list.csv: procure the PHYSICAL LONG BLANK.
    for a in job.assemblies.values():
        is_channel = a.main.sec.kind == 'Channel'
        doubled = is_channel and getattr(a.main.sec, 'doubled', False)
        demand(
            'Frame',
            'channel' if is_channel else 'hss' if a.main.sec.kind == 'HSS' else 'beam',
            # a doubled (back-to-back welded I) rafter is purchased as two single channels
            a.main.sec.single if doubled else a.main.section,
            a.main.sec.finish if is_channel else c['hss_finish'] if a.main.sec.kind == 'HSS' else c['beam_finish'],
            float(a.main.cut_length.inches),
            a.qty * (2 if doubled else 1),
            a.main.mark,
            a.mark,
            'PRIMARY LONG BLANK; connection/seat fit review'
            + ('; TWO CHANNELS WELDED BACK TO BACK (I SHAPE) PER MEMBER' if doubled else ''),
        )
        for end in a.derivation.get('endwalls', {}).values():
            rc = end.get('ridge_face_clip')
            if rc:
                item(
                    'Frame',
                    rc['mark'] + ' PEAK FACE CLIP PL3/16 x5 TALL x7 WIDE',
                    'UNSPECIFIED',
                    c['plate_grade'],
                    None,
                    1,
                    'FABRICATED RECTANGLE / NO HOLES',
                    rc['status'],
                    rc['mark'],
                    family='plate',
                )
            for r in end['members']:
                profile = r['profile_id']
                family = r['family']
                L = r['blank_length_in']
                q = r['quantity']
                status = r['status']
                if family == 'W':
                    demand(
                        'Frame', 'beam', profile, r.get('finish') or c['beam_finish'], L, q, r['mark'], a.mark, status
                    )
                elif family == 'HSS':
                    demand(
                        'Frame',
                        'hss',
                        profile + '; actual wall ' + (r.get('actual_wall') or 'UNCONFIRMED'),
                        r.get('finish') or c['hss_finish'],
                        L,
                        q,
                        r['mark'],
                        a.mark,
                        status,
                    )
                else:
                    secondary_demand(profile, r.get('finish') or 'UNSPECIFIED', L, q, r['mark'], a.mark, status)
        runs = a.derivation.get('secondary_runs', {})
        for r in runs.get('pieces', []):
            before = len(demands)
            secondary_demand(r['profile_id'], r['finish'], r['cut_length_in'], 1, r['piece_id'], a.mark, r['status'])
            if len(demands) > before and r.get('support_start_in') is not None and r.get('support_end_in') is not None:
                span = abs(r['support_end_in'] - r['support_start_in'])
                demands[-1].update(
                    nominal_span_in=span,
                    net_fit_deduction_in=span - r['cut_length_in'],
                    fit_basis=r.get('fit_status') or r['status'],
                )
        if runs and a.mark in job.settings.get('frames', {}):
            expected = runs.get('interior_frame_lines', runs['config']['bays'] - 1)
            entered = job.settings['frames'][a.mark]['frames']
            if entered != expected:
                hold(
                    'Frame',
                    'INTERIOR FRAME LOT / GRID COUNT',
                    None,
                    a.mark,
                    'Entered lot '
                    + str(entered)
                    + ' differs from '
                    + str(expected)
                    + ' interior rigid-frame grid lines. Enter the matching lot quantity.',
                )
        active = set(r['profile_id'] for r in runs.get('pieces', []))
        for r in a.derivation.get('secondary_material_rows', []):
            # With bay runs enabled, non-accessory rows are SUMMARIES of pieces above.
            if runs and r['role'] != 'accessory':
                continue
            q = r['total_lot_pieces']
            L = r['ordered_piece_length']
            if q:
                secondary_demand(
                    r['profile_id'],
                    r['finish'],
                    number(L) if L else None,
                    q,
                    a.mark + '-' + r['role'] + '-MANUAL',
                    a.mark,
                    r['status'],
                )
            elif r['profile_id'] not in active:
                hold('Secondaries', r['profile_id'], None, a.mark + '-' + r['role'], r['status'])
        if a.derivation.get('bay_zones'):
            hold(
                'Sheets / Trim',
                'JUNCTION WALL CLOSURE AND FLASHING',
                None,
                a.mark,
                'Enclosed / future junction wall sits under the continuous roof: its closure trim and fasteners are not in the trim tables (no rake trim is substituted)',
                advisory=True,
            )
            hold(
                'Frame',
                'FUTURE BAY SCOPE',
                None,
                a.mark,
                'Future bay: sheets and trim excluded; only the install-now girts / base angles and clips chosen in the bay settings are included',
                advisory=True,
            )
        additions = a.derivation.get('framing_additions', {})
        for pid, q in a.derivation.get('end_girt_clip_counts', {}).items():
            if q and pid not in job.parts:
                hold(
                    'Secondaries',
                    pid,
                    q,
                    a.mark,
                    'Corner clip depth adaptation: source material-edge hole datum not yet reconciled',
                )
                continue
            if q:
                item(
                    'Frame',
                    pid + ' END COLUMN / ENDWALL GIRT CLIP',
                    'UNSPECIFIED',
                    c['plate_grade'],
                    None,
                    q,
                    'PHYSICAL END-POST CLIPS / NOT PRIMARY LOT',
                    'Q06 orientation/family; source clip fit/punching review',
                    a.mark,
                    family='plate',
                )
        for r in additions.get('rake_angles', []) + additions.get('base_supports', []):
            secondary_demand(r['profile'], r['finish'], r['length_in'], r['quantity'], r['mark'], a.mark, r['status'])
        for z in additions.get('lean_tos', []):
            for r in z.get('roof_clip_schedule', []):
                if not r['quantity']:
                    continue
                item(
                    'Frame',
                    r['part_mark'] + ' LEAN ROOF CLIP ' + r['mount'],
                    'UNSPECIFIED',
                    c['plate_grade'],
                    None,
                    r['quantity'],
                    'SELECTED ROOF CLIP BLANK',
                    r['status'],
                    r['mark'],
                    family='plate',
                )
            for r in z.get('roof_purlin_layout', {}).get('pieces', []):
                secondary_demand(
                    r['profile_id'],
                    r['finish'],
                    r['cut_length_in'],
                    r['quantity'],
                    r['mark'],
                    a.mark + ' ' + z['id'],
                    r['status'],
                )
            # Lean wall girts (v0.8.35): sheeted lean walls under the shop rules.
            for r in z.get('wall_girts', []):
                if r.get('cut_length_in') is None:
                    hold('Secondaries', 'LEAN GIRT ' + r['mark'], 1, a.mark + ' ' + z['id'], r['status'])
                    continue
                secondary_demand(
                    r['profile_id'],
                    r['finish'],
                    r['cut_length_in'],
                    r['quantity'],
                    r['mark'],
                    a.mark + ' ' + z['id'],
                    r['status'],
                )
            for r in z['members']:
                if r.get('blank_length_in') is not None and r['family'] == 'C':
                    secondary_demand(
                        r['profile'],
                        r.get('finish', 'Red Oxide'),
                        r['blank_length_in'],
                        r['quantity'],
                        r['mark'],
                        a.mark,
                        r['status'],
                    )
                elif r.get('blank_length_in') is not None:
                    demand(
                        'Frame',
                        'beam' if r['family'] == 'W' else 'hss',
                        r['profile'],
                        c['beam_finish'] if r['family'] == 'W' else c['hss_finish'],
                        r['blank_length_in'],
                        r['quantity'],
                        r['mark'],
                        a.mark,
                        r['status'],
                    )
                else:
                    hold(
                        'Secondaries' if r['family'] == 'C' else 'Frame',
                        r['profile'],
                        r['quantity'],
                        r['mark'],
                        r['status'],
                        r['reference_length_in'],
                    )
            for x in z.get('low_connection_parts', []):
                part = x['part']
                item(
                    'Frame',
                    part['mark'] + ' LEAN LOW ' + x['role'],
                    'UNSPECIFIED',
                    c['plate_grade'],
                    None,
                    x['quantity'],
                    'SHARED PRIMARY RULE',
                    'Plate geometry generated; fit/anchor/weld review retained',
                    a.mark + ' ' + z['id'],
                    family='plate',
                )
            for clip in z.get('flush_clips', []):
                item(
                    'Frame',
                    clip['mark']
                    + ' FLUSH CLIP PL1/2 x'
                    + fmt(clip['blank_length_in'])
                    + ' x'
                    + fmt(clip['blank_height_in'])
                    + ' envelope',
                    'UNSPECIFIED',
                    c['plate_grade'],
                    None,
                    1,
                    'FABRICATED PIECE / USER PITCH CUT',
                    'GEOMETRY KNOWN; fit/peak/web offset/weld review; plate stock NOT nested',
                    clip['mark'],
                    family='plate',
                )
                if clip['issues']:
                    hold('Frame', 'FLUSH CLIP INSTALLATION', None, clip['mark'], ' / '.join(clip['issues']))
            ep = z.get('end_plate_geometry')
            if ep and ep['geometry_valid']:
                item(
                    'Frame',
                    ep['mark']
                    + ' HIGH END PLATE '
                    + fmt(ep['thickness_in'])
                    + ' x'
                    + fmt(ep['width_in'])
                    + ' x'
                    + fmt(ep['height_in']),
                    'UNSPECIFIED',
                    c['plate_grade'],
                    None,
                    ep['quantity'],
                    'FABRICATED PIECE / USER4-HOLE PLATE',
                    'REVIEW edge distances, weld/grip and column instances; raw plate NOT nested',
                    ep['mark'],
                    family='plate',
                )
            if z.get('bolt_preset'):
                bp = z['bolt_preset']
                item(
                    'Frame',
                    'BOLT 5/8in x2in A325 /SP2 PRESET',
                    'UNSPECIFIED',
                    'A325',
                    None,
                    bp['total_bolts'],
                    'DRAWING-BASED HARDWARE PRESET',
                    'Verify grip/hole/edge distance; nuts/washers NOT quantified',
                    a.mark + ' ' + z['id'],
                    family='hardware',
                )
                hold(
                    'Frame',
                    'SP2 HARDWARE / FIT',
                    None,
                    a.mark + ' ' + z['id'],
                    'Nuts/washers, grip, hole diameter and connection design require review; bolt count already on proposed order',
                )
            td = z.get('transition_detail')
            if td:
                for x in td['components']:
                    item(
                        'Sheets / Trim',
                        x['part'],
                        'UNSPECIFIED',
                        'UNSPECIFIED',
                        None,
                        x['quantity'],
                        x['basis'],
                        'SOURCE NET REQUIREMENT / verify profile, fastener spec and extras',
                        a.mark + ' ' + z['id'] + ' / ' + td['template'],
                        family='accessory',
                        unit=x['unit'],
                    )
            count = len(z['stations'])
            high_schedule = z.get('high_connection_schedule') or [dict(mode=z['high_connection'], quantity=count)]
            high_counts = {}
            for row in high_schedule:
                high_counts[row['mode']] = high_counts.get(row['mode'], 0) + int(row.get('quantity', 1))
            for mode, quantity in high_counts.items():
                hold(
                    'Frame',
                    'LEAN-TO HIGH ' + mode,
                    quantity * (2 if mode == 'double_angle' else 1),
                    a.mark + ' ' + z['id'],
                    'Flush clip geometry/count generated; final placement/weld fit remains held'
                    if mode == 'clip' and z.get('flush_clips')
                    else 'User end-plate geometry/count generated; column/grip/weld fit held'
                    if mode == 'end_plate' and ep and ep['geometry_valid']
                    else 'Connection fit/plates/angles/welds/bolts NOT quantified; selected scheme only',
                )
            if not z.get('transition_not_applicable') and 'walls' not in z:
                # Legacy lean records (pre-0.8.35) without the wall model keep the run note.
                hold(
                    'Sheets / Trim',
                    'WALL-TO-ROOF TRANSITION',
                    z['transition_trim']['quantity'],
                    a.mark + ' ' + z['id'],
                    'RUN KNOWN / PROFILE and developed width pending; apply max20ft6 after selection',
                    z['length_in'],
                )
            if 'walls' not in z:
                if not z.get('open_wall_scope'):
                    hold(
                        'Secondaries',
                        'LEAN-TO WALL GIRTS / BRACING / ROOF ATTACHMENT FIT'
                        if z.get('roof_purlin_layout')
                        else 'LEAN-TO SECONDARIES / BRACING',
                        None,
                        a.mark + ' ' + z['id'],
                        'Roof purlin physical lengths/counts included; wall girts, clips and weld fit pending; bracing BY OTHERS'
                        if z.get('roof_purlin_layout')
                        else 'Not yet quantified: flush/bypass selection does not define installed member lengths',
                    )
                if not z.get('open_wall_scope') or z.get('roof_continuity') != 'main_plane':
                    hold(
                        'Sheets / Trim',
                        'LEAN-TO EXTERIOR WALL SHEETS'
                        if z.get('roof_continuity') == 'main_plane'
                        else 'LEAN-TO ROOF / EXTERIOR WALL SHEETS',
                        None,
                        a.mark + ' ' + z['id'],
                        'Continuous roof included in main roof surface when enabled; lean outer/end wall takeoff pending'
                        if z.get('roof_continuity') == 'main_plane'
                        else 'Main-wall removal modeled separately; lean-to envelope takeoff pending',
                    )
        for o in additions.get('openings', []):
            if o.get('walk_slip_fit'):
                d = o['walk_slip_fit']
                if d.get('door_frame_outside_width_in') is not None:
                    item(
                        'Frame',
                        'COMPLETE WALK FRAME '
                        + fmt(d['door_frame_outside_width_in'])
                        + ' x'
                        + fmt(d['door_frame_outside_height_in'])
                        + ' OUTSIDE /3x7 CLEAR',
                        'UNSPECIFIED',
                        'ASSEMBLY SPECIFICATION',
                        None,
                        1,
                        'COMPLETE ASSEMBLY',
                        'Owner2.5in head/jamb faces; order assembly, not loose duplicate jamb/header steel',
                        a.mark + ' ' + o['id'],
                        family='door frame assembly',
                    )
                else:
                    hold(
                        'Frame',
                        'COMPLETE WALK-DOOR FRAME ASSEMBLY',
                        1,
                        a.mark + ' ' + o['id'],
                        'Slip-in assembly, not duplicate fabricated jambs; actual frame sections / outer dimensions and procurement scope pending',
                    )
            for r in o['members']:
                if r.get('shared_member_ref'):
                    continue  # physical post demand already counted in endwall members
                if r.get('profile', '').startswith('UNLIPPED:'):
                    hold(
                        'Secondaries',
                        r['profile'],
                        1,
                        r['mark'],
                        'User unlipped Cee envelope: supplier section/thickness/weight and clip fit unverified',
                        r.get('cut_length_in', r['reference_length_in']),
                    )
                elif r.get('cut_length_in') is not None:
                    secondary_demand(
                        r['profile'],
                        pfinish
                        if (
                            pfinish := job.settings.get('frames', {})
                            .get(a.mark, {})
                            .get('secondary', {})
                            .get('girt', {})
                            .get('finish')
                        )
                        else 'UNSPECIFIED',
                        r['cut_length_in'],
                        1,
                        r['mark'],
                        a.mark,
                        r['status'],
                    )
                else:
                    hold(
                        'Secondaries' if r['family'] == 'C' else 'Frame',
                        r['profile'],
                        1,
                        r['mark'],
                        r['status'],
                        r['reference_length_in'],
                    )
            detail = o.get('connection_detail')
            if detail:
                for x in detail['components']:
                    item(
                        'Secondaries',
                        x['part'],
                        'UNSPECIFIED',
                        'SOURCE SPEC / VERIFY',
                        None,
                        x['quantity'],
                        'SOURCE OPENING TEMPLATE',
                        'Verify vendor clip/hole match, bolt grip and anchor design',
                        a.mark + ' ' + o['id'] + ' / ' + x['basis'],
                        family='hardware',
                    )
                for issue in detail['issues']:
                    hold('Frame', 'OPENING TEMPLATE ' + o['id'], None, a.mark + ' ' + o['id'], issue)
            for issue in o['issues']:
                hold('Frame', 'OPENING ' + o['id'], None, a.mark + ' ' + o['id'], issue)
        clad = a.derivation.get('cladding')
        if clad:
            for r in clad['groups']:
                if r['supply_length_review']:
                    hold(
                        'Sheets / Trim',
                        'PBR panel / ' + r['color'],
                        r['quantity'],
                        a.mark + ' ' + r['group'],
                        'SUPPLY LENGTH HOLD: outside selected supplier published limits. Proposed count remains on order; confirm supplier.',
                        r['order_length_in'],
                    )
                item(
                    'Sheets / Trim',
                    (r.get('profile', 'PBR') if r.get('profile', '').startswith('SSS-') else 'PBR')
                    + ' panel / '
                    + r['coating']
                    + ' / '
                    + str(r['gauge'])
                    + 'ga',
                    r['color'],
                    'Manufacturer grade UNCONFIRMED',
                    r['order_length_in'],
                    r['quantity'],
                    'EXACT PANEL BLANK',
                    'SUPPLY LENGTH HOLD'
                    if r['supply_length_review']
                    else r['availability'] + '; verify edge/cutout details',
                    a.mark + ' ' + r['group'],
                    family='panel',
                )
            from .cladding import catalog as trim_catalog

            profiles = {r['id']: r for r in trim_catalog('all')['trims']}
            for r in clad['trim_runs']:
                if r.get('not_ordered'):
                    continue
                if r.get('custom_formed'):
                    maximum = c['trim_max_in']
                    for i, L in enumerate(trim_lengths(r['required_run_in'], r['lap_in'], maximum)):
                        item(
                            'Sheets / Trim',
                            'CUSTOM FORMED '
                            + r['role'].upper()
                            + ' TRIM'
                            + (
                                (' / ' + str(r['formed_pitch_rise']) + ':12')
                                if r.get('formed_pitch_rise') is not None
                                else ''
                            )
                            + ' / '
                            + str(r['gauge'])
                            + 'ga',
                            r['color'],
                            'Manufacturer grade UNCONFIRMED',
                            up(L),
                            1,
                            'EXACT FORMED TRIM',
                            'Custom formed to the job pitch; no stock SKU in the supplier pages on file',
                            r['mark'] + '-' + str(i + 1) + ' cut ' + fmt(up(L)),
                            family='trim',
                        )
                    continue
                if not r['profile_id']:
                    hold('Sheets / Trim', r['role'] + ' trim', None, r['mark'], r['status'])
                    continue
                pr = profiles[r['profile_id']]
                maximum = c['trim_max_in'] if c['trim_policy'] == 'exact_short_max_long' else pr['stock_length_in']
                if pr.get('supplier') == 'sss' and pr.get('catalog_length_verified'):
                    maximum = min(maximum, pr['stock_length_in'])
                for i, L in enumerate(trim_lengths(r['required_run_in'], r['lap_in'], maximum)):
                    order = up(L) if c['trim_policy'] == 'exact_short_max_long' else maximum
                    item(
                        'Sheets / Trim',
                        pr['label']
                        + (
                            (' / ' + str(r['formed_pitch_rise']) + ':12')
                            if r.get('formed_pitch_rise') is not None
                            else ''
                        )
                        + ' (PROFILE REF '
                        + r['profile_id']
                        + ') / '
                        + str(r['gauge'])
                        + 'ga',
                        r['color'],
                        'Manufacturer grade UNCONFIRMED',
                        order,
                        1,
                        'EXACT FORMED TRIM' if c['trim_policy'] == 'exact_short_max_long' else 'CATALOG STOCK',
                        'USER LENGTH RULE; confirm supplier, lap/returns/profile; NOT a catalog length SKU',
                        r['mark'] + '-' + str(i + 1) + ' cut ' + fmt(up(L)),
                        family='trim',
                    )
        elif job.settings.get('frames', {}).get(a.mark):
            hold('Sheets / Trim', 'Panels / trim', None, a.mark, 'CLADDING NOT ENABLED — envelope quantities missing')
    # Plate/clip piece requirements, not fictitious sheet nesting; omit parent
    # connection weldments because their plate components are already expanded.
    from .drawing.sheet import usage

    _, parts = usage(job)
    for mark, q in parts.items():
        p = job.part(mark)
        if p.symbol.get('connection'):
            continue
        if p.kind in ('plate', 'clip'):
            desc = (
                mark
                + ' PL '
                + p.thk.fmt()
                + ' x '
                + fmt(up(float(p.width.inches)))
                + ' x '
                + fmt(up(float(p.length.inches)))
                + ' envelope'
            )
            item(
                'Frame' if p.kind == 'plate' else 'Secondaries',
                desc,
                'UNSPECIFIED',
                c['plate_grade'],
                None,
                q,
                'FABRICATED PIECES',
                'PLATE STOCK NOT NESTED; envelope UP1/16; final contour/holes per part drawing',
                mark,
                family=p.kind,
            )
        elif p.section and p.cut_length:
            family = 'beam' if p.section.upper().startswith('W') else 'exact'
            demand(
                'Frame' if family == 'beam' else 'Secondaries',
                family,
                p.section,
                'UNSPECIFIED',
                float(p.cut_length.inches),
                q,
                mark,
                'loose part',
                'LOOSE MEMBER; verify grade/finish',
            )
        else:
            hold('Secondaries', mark, q, mark, 'ACCESSORY / ASSEMBLY: specification or raw stock not resolved')
    specifications = defaultdict(set)
    for d in demands:
        specifications[d['mark']].add((d['profile'], d['exact_blank_length_in']))
    for mark, specs in specifications.items():
        if len(specs) > 1:
            hold(
                'Frame',
                'CONFLICTING CUT MARK',
                None,
                mark,
                'Same mark has different profiles/lengths. Records retained separately; resolve before fabrication.',
            )
    pools = defaultdict(list)
    for d in demands:
        pools[d['material_group']].append(d)
    for gid, ds in sorted(pools.items()):
        head = ds[0]
        family = head['family']
        mode = c['mode_overrides'].get(
            gid, c.get(family + '_mode', 'stock' if family.startswith('fixed:') else 'exact')
        )
        stocks = (
            [float(family.split(':')[1]) * 12]
            if family.startswith('fixed:')
            else stock_lengths_in(job, family, head['profile'], c)
        )
        requested_mode = mode
        if mode == 'compare':
            from .material_comparison import compare

            comparisons.append(compare(gid, ds, stocks, c))
            mode = 'stock'  # comparison is informational, not a second purchase
        stockable = []
        for d in ds:
            if mode == 'stock' and (not stocks or d['blank_length_in'] + 2 * c['end_allowance_in'] > max(stocks)):
                hold(
                    d['department'],
                    d['profile'],
                    d['quantity'],
                    d['owner'] + '/' + d['mark'],
                    'EXCEEDS STOCK: select exact/custom or resolve design. NOT SPLICED.',
                    d['blank_length_in'],
                )
                continue
            stockable.append(d)
        group = dict(
            id=gid,
            department=head['department'],
            family=family,
            profile=head['profile'],
            finish=head['finish'],
            grade=head['grade'],
            mode=mode,
            requested_mode=requested_mode,
            demand_quantity=sum(d['quantity'] for d in ds),
            planned_quantity=sum(d['quantity'] for d in stockable),
            ordered_length_in=0,
            blank_length_in=0,
            kerf_loss_in=0,
            end_loss_in=0,
            remnant_in=0,
            stock_quantity=0,
            baseline_length_in=0,
        )
        groups.append(group)
        if mode == 'exact':
            for d in stockable:
                L = d['blank_length_in']
                q = d['quantity']
                row = item(
                    d['department'],
                    d['profile'],
                    d['finish'],
                    d['grade'],
                    L,
                    q,
                    'EXACT / CUSTOM BLANK',
                    'CUSTOM AVAILABILITY / GEOMETRY REVIEW',
                    d['owner'] + '/' + d['mark'],
                    gid,
                    family,
                )
                row['custom_mark'] = d['mark']
                group['ordered_length_in'] += L * q
                group['blank_length_in'] += d['blank_length_in'] * q
                group['end_loss_in'] += (L - d['blank_length_in']) * q
                group['stock_quantity'] += q
            group['baseline_length_in'] = group['ordered_length_in']
            continue
        if sum(d['quantity'] for d in stockable) > 2000:
            for d in stockable:
                hold(
                    d['department'],
                    d['profile'],
                    d['quantity'],
                    d['mark'],
                    'OPTIMIZER LIMIT: >2000 blanks per group; select exact or split batches',
                    d['blank_length_in'],
                )
            group['planned_quantity'] = 0
            continue
        pieces = [dict(d, instance=i + 1) for d in stockable for i in range(d['quantity'])]
        if not pieces:
            continue
        packed = pack(tuple(p['blank_length_in'] for p in pieces), tuple(stocks), c['kerf_in'], c['end_allowance_in'])
        group['baseline_length_in'] = sum(
            next(s for s in stocks if s >= p['blank_length_in'] + 2 * c['end_allowance_in']) for p in pieces
        )
        for b in packed:
            tag = 'STOCK-' + str(len(bars) + 1).zfill(4)
            bar = {k: v for k, v in b.items() if k != 'indices'}
            bar.update(
                stock_id=tag,
                material_group=gid,
                department=head['department'],
                profile=head['profile'],
                finish=head['finish'],
                grade=head['grade'],
                quantity=1,
                cuts=[],
            )
            pos = c['end_allowance_in']
            for i, index in enumerate(b['indices']):
                p = pieces[index]
                r = dict(
                    stock_id=tag,
                    material_group=gid,
                    cut_sequence=i + 1,
                    owner=p['owner'],
                    cut_mark=p['mark'],
                    instance=p['instance'],
                    start_in=pos,
                    blank_length_in=p['blank_length_in'],
                    blank_length=p['blank_length'],
                    source_status=p['status'],
                )
                allocations.append(r)
                bar['cuts'].append(r)
                pos += p['blank_length_in'] + c['kerf_in']
            bars.append(bar)
            item(
                head['department'],
                head['profile'],
                head['finish'],
                head['grade'],
                b['stock_length_in'],
                1,
                'STOCK / CUT TO PLAN',
                'USER STOCK AVAILABILITY / GEOMETRY REVIEW',
                tag,
                gid,
                family,
            )
            for k in ('blank_length_in', 'kerf_loss_in', 'end_loss_in', 'remnant_in'):
                group[k] += b[k]
            group['ordered_length_in'] += b['stock_length_in']
            group['stock_quantity'] += 1
    for i, r in enumerate(c['additional_trim_runs']):
        for length in trim_lengths(r['length_in'], r['lap_in'], c['trim_max_in']):
            item(
                'Sheets / Trim',
                r['profile'],
                r['finish'],
                'USER SPECIFICATION',
                up(length),
                r['quantity'],
                'EXACT FORMED TRIM',
                'USER-ENTERED RUN; gutter profile/hydraulics/support and joint details NOT designed',
                'ADDITIONAL-TRIM-' + str(i + 1),
                family='trim',
            )
    from .material_engine import source_clips

    items, engine_result = source_clips(job, c, items, hold)
    # Exact matching purchasing specifications only; preserve every origin/reference.
    merged = {}
    for r in items:
        key = tuple(
            r[k]
            for k in (
                'department',
                'material',
                'finish',
                'grade',
                'order_length_in',
                'unit',
                'basis',
                'status',
                'material_group',
                'family',
                'custom_mark',
            )
        )
        if key not in merged:
            merged[key] = dict(r, quantity=0, references=[])
        merged[key]['quantity'] += r['quantity']
        merged[key]['references'].append(r['references'])
    items = sorted(
        merged.values(),
        key=lambda r: (DEPARTMENTS.index(r['department']), r['material'], r['finish'], r['order_length_in'] or 0),
    )
    for i, r in enumerate(items, 1):
        r['order_id'] = 'ORDER-' + str(i).zfill(3)
        r['references'] = '; '.join(r['references'])
    from .supplier_catalog import annotate

    sourcing = annotate(job, items)
    pattern_map = {}
    for b in bars:
        key = (b['material_group'], b['stock_length_in'], tuple(sorted(x['blank_length_in'] for x in b['cuts'])))
        if key not in pattern_map:
            pattern_map[key] = dict(
                pattern_id='PAT-' + str(len(pattern_map) + 1).zfill(3),
                department=b['department'],
                profile=b['profile'],
                finish=b['finish'],
                grade=b['grade'],
                stock_length_in=b['stock_length_in'],
                cut_lengths_in=list(key[-1]),
                quantity=0,
                remnant_each_in=b['remnant_in'],
                kerf_each_in=b['kerf_loss_in'],
                stock_ids=[],
            )
        g = pattern_map[key]
        g['quantity'] += 1
        g['stock_ids'].append(b['stock_id'])
        b['pattern_id'] = g['pattern_id']
    summary = {
        dep: dict(
            order_lines=sum(r['department'] == dep for r in items),
            proposed_pieces=sum(r['quantity'] for r in items if r['department'] == dep),
            pending_entries=sum(r['department'] == dep for r in pending),
        )
        for dep in DEPARTMENTS
    }
    notes = [
        'MASTER ORDER: quantities follow the current model revision; open Holds list the entries that still need input.',
        'Initial stock defaults are USER assumptions: beams20/30/40/50/60ft; C/Z20/25/30ft; HSS20/24/40ft. No section substitution or automatic member splices.',
        'Only identical department/family/profile/finish/grade pools are packed. Known gauge/wall labels stay in profile IDs; unknown grades are explicitly UNSPECIFIED.',
        'Bounded exact search for small mixed-member pools; deterministic best-fit comparison for larger pools. Minimize ordered footage, then stock count; no guarantee of lowest price or global optimum for larger pools. No material prices or inventory remnants assumed.',
        'Kerf reserved between blanks; final offcut separation consumes up to one more kerf. End allowances are per stock end. Long blanks used, never column LOW-point dimensions.',
        'Exact/custom orders are rounded UP to1/16in blanks; supplier availability still needs confirmation.',
        'Trim exact short lengths / maximum20ft6in long segments follow USER rule, not catalog stock availability. Profile IDs are shape references, not custom-length supplier SKUs.',
        'Gutters only included if explicitly entered under additional trim runs. No automatic gutter sizing, peak boxes/end caps, closures, sealants or fastener order.',
        'Plate/clip requirements are fabricated-piece counts, NOT nested plate-stock orders. Pending lengths/quantities remain on Holds, never silently set to zero. Supply/quantity warnings may refer to proposed lines: do NOT add Holds to the order again.',
        'Primary fabrication lots and separate endwall/envelope quantities retain existing model scope; a lot/grid mismatch is reported as a Hold.',
    ]
    result = dict(
        job_no=job.job_no,
        customer=job.customer,
        revision=job.revision(),
        config=c,
        sourcing=sourcing,
        material_comparisons=comparisons,
        **engine_result,
        summary=summary,
        items=items,
        pending=pending,
        advisories=advisories,
        demands=demands,
        groups=groups,
        bars=bars,
        patterns=list(pattern_map.values()),
        allocations=allocations,
        notes=notes,
        ordered_linear_stock_in=sum(g['ordered_length_in'] for g in groups),
        baseline_linear_stock_in=sum(g['baseline_length_in'] for g in groups),
        blank_linear_stock_in=sum(g['blank_length_in'] for g in groups),
        remnant_in=sum(g['remnant_in'] for g in groups),
        kerf_loss_in=sum(g['kerf_loss_in'] for g in groups),
        end_loss_in=sum(g['end_loss_in'] for g in groups),
    )

    from .traceability import enrich

    return enrich(job, result)


def apply_options(job, raw):
    """Return an updated copy; never partially edit a job on a failed calculation."""
    from .frame import FrameParams, generate_frame
    from .model import Job

    work = Job.loads(job.dumps())
    work.settings['order_options'] = config(raw=raw)
    for fid, params in list(work.settings.get('frames', {}).items()):
        generate_frame(work, FrameParams.from_json(params))
    build(work)
    return work


def export_order_files(job, folder, plan=None):
    import csv
    from pathlib import Path

    from .order_workbook import write_workbook

    p = plan or build(job)
    if 'material_list' not in p:
        from .pricing import material_list

        _ml = material_list(job, p)
        p['material_list'] = _ml['rows'] + _ml['job_cost_rows']
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    files = []
    path = folder / 'master_order.json'
    path.write_text(json.dumps(p, indent=2))
    files.append(str(path))
    for name, key in [
        ('piece_trace', 'piece_trace'),
        ('master_order', 'items'),
        ('stock_patterns', 'patterns'),
        ('stock_cut_allocations', 'allocations'),
        ('order_holds', 'pending'),
        ('order_cut_demands', 'demands'),
        ('material_list', 'material_list'),
        ('stock_utilization', 'groups'),
    ] + (
        [
            ('material_comparison', 'material_comparisons'),
            ('clip_sourcing', 'clip_requirements'),
            ('flat_bar_stock', 'flat_bars'),
            ('flat_bar_cuts', 'flat_allocations'),
        ]
        if p['config']['material_engine']['enabled'] or p['material_comparisons']
        else []
    ):
        path = folder / (name + '.csv')
        rows = p[key]
        with path.open('w', newline='') as f:
            if rows:
                w = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for row in rows for k in row)))
                w.writeheader()
                for row in rows:
                    safe = {}
                    for k, v in row.items():
                        if isinstance(v, (dict, list)):
                            v = json.dumps(v)
                        if isinstance(v, str) and v.startswith(('=', '+', '-', '@')):
                            v = "'" + v
                        safe[k] = v
                    w.writerow(safe)
        files.append(str(path))
    files.append(write_workbook(job, folder / 'master_order.xlsx', p))
    return files
