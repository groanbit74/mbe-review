"""Shop-standard part library and the sample job.

The part definitions reproduce the marks used in the Clark Jordan 1277345 package.
Hole layouts marked ``source="assumed-layout"`` were NOT readable from the sample
sheets and must be confirmed against the shop's standard-parts book before the
plate sheets are used for burning – the plate sheets print that note.
"""

from __future__ import annotations

from decimal import Decimal

from .model import Assembly, Attachment, D, Job, MainMember, Part, WebHoles, rect_holes

H916 = "9/16\""  # standard clip hole (1/2" bolts)
H1316 = "13/16\""  # anchor-bolt hole (3/4" bolts) – assumed


def standard_parts() -> dict[str, Part]:
    parts = [
        # purlin / girt clip: 3/16 x 6 x 7, 4 holes 4" gauge x 4" pitch, first row 2 1/4" from the flange (sample section view)
        Part(
            "PC8D",
            "clip",
            D("3/16"),
            D("6"),
            D("7"),
            rect_holes(H916, ["2 1/4", "6 1/4"], ["1", "5"]),
            source="sample section view RF1-9 / RF1-2",
        ),
        # flange-brace clips (formed; weights from the sample BOMs, not plate formula)
        Part(
            "CLF2",
            "clip",
            D("3/16"),
            D("3"),
            D("3"),
            rect_holes(H916, ["1 1/2"], ["1 1/2"]),
            unit_weight=Decimal("0.65"),
            source="sample BOM RF1-2 (weight)",
            notes="formed clip - weight per shop standard",
        ),
        Part(
            "CLF4",
            "clip",
            D("3/16"),
            D("6"),
            D("3"),
            rect_holes(H916, ["1 1/2"], ["1 1/2", "4 1/2"]),
            unit_weight=Decimal("1.25"),
            source="sample BOM MB1-1 (weight)",
            notes="formed clip - weight per shop standard",
        ),
        Part(
            "CLF12",
            "clip",
            D("3/16"),
            D("6"),
            D("11"),
            rect_holes(H916, ["1 1/2", "9 1/2"], ["1 1/2", "4 1/2"]),
            source="assumed-layout",
            notes="hole layout assumed - confirm with shop standard",
        ),
        # end plates
        Part(
            "EP12",
            "plate",
            D("1/2"),
            D("6"),
            D("1'-0 1/4\""),
            rect_holes(H916, ["1 1/2", "4 5/8", "7 5/8", "10 3/4"], ["1 1/2", "4 1/2"]),
            source="assumed-layout",
            notes="hole layout assumed - confirm with shop standard",
        ),
        Part(
            "EP10",
            "plate",
            D("1/2"),
            D("6"),
            D("10 1/8"),
            rect_holes(H916, ["1 1/2", "5 1/16", "8 5/8"], ["1 1/2", "4 1/2"]),
            source="assumed-layout",
            notes="hole layout assumed - confirm with shop standard",
        ),
        # base plates: 2 1/2" first-hole reference from the plate end (sample), 3" gauge assumed
        Part(
            "B-14",
            "plate",
            D("1/2"),
            D("6"),
            D("1'-2\""),
            rect_holes(H1316, ["2 1/2", "11 1/2"], ["1 1/2", "4 1/2"]),
            source="sample (1st hole ref) + assumed gauge",
            notes="gauge / hole dia assumed - confirm",
        ),
        Part(
            "B-10",
            "plate",
            D("1/2"),
            D("6"),
            D("10 1/2"),
            rect_holes(H1316, ["2 1/2", "8"], ["1 1/2", "4 1/2"]),
            source="sample (1st hole ref) + assumed gauge",
            notes="gauge / hole dia assumed - confirm",
        ),
        Part(
            "B-8",
            "plate",
            D("1/2"),
            D("6"),
            D("8 1/2"),
            rect_holes(H1316, ["2 1/2", "6"], ["1 1/2", "4 1/2"]),
            source="assumed-layout",
            notes="gauge / hole dia assumed - confirm",
        ),
        # knee / ridge plates
        Part(
            "K-14",
            "plate",
            D("1/2"),
            D("6"),
            D("1'-9 1/4\""),
            rect_holes(H916, ["1 1/2", "4 1/2", "16 3/4", "19 3/4"], ["1 1/2", "4 1/2"]),
            source="assumed-layout",
            notes="hole layout assumed - confirm with shop standard",
        ),
        Part(
            "K-10",
            "plate",
            D("1/2"),
            D("6"),
            D("1'-5 1/4\""),
            rect_holes(H916, ["1 1/2", "4 1/2", "12 3/4", "15 3/4"], ["1 1/2", "4 1/2"]),
            source="assumed-layout",
            notes="hole layout assumed - confirm with shop standard",
        ),
        # stubs (mezzanine beam seats on the rigid-frame columns)
        Part(
            "MB-2",
            "stub",
            section="W12X22",
            cut_length=D("6"),
            attachments=[Attachment("EP12", "right_end")],
            source="sample RF1-9 detail",
        ),
        Part(
            "MB-3",
            "stub",
            section="W8X10",
            cut_length=D("7 3/4"),
            attachments=[Attachment("PC8D", "top", D("7"), ref="center")],
            source="sample RF1-9 detail",
        ),
        # brackets: weights from their own drawings (sample BOMs); symbols are schematic sizes
        Part(
            "BR14HE1",
            "bracket",
            unit_weight=Decimal("55.9"),
            symbol={"w": 14, "h": 22},
            drawing_ref="HBR14HE1",
            source="sample BOM",
        ),
        Part(
            "BR14E1",
            "bracket",
            unit_weight=Decimal("54.0"),
            symbol={"w": 14, "h": 22},
            drawing_ref="HBR14E1",
            source="assumed weight - confirm",
        ),
        Part(
            "BR10E4",
            "bracket",
            unit_weight=Decimal("33.4"),
            symbol={"w": 10, "h": 16},
            drawing_ref="HBR10E1",
            source="sample bracket sheet HBR10E1",
        ),
        Part(
            "BR10LN3",
            "bracket",
            unit_weight=Decimal("29.05"),
            symbol={"w": 10, "h": 3},
            drawing_ref="BR10LN3",
            source="sample BOM",
        ),
        Part(
            "BR10LN2",
            "bracket",
            unit_weight=Decimal("27.7"),
            symbol={"w": 10, "h": 3},
            drawing_ref="BR10LN2",
            source="assumed weight - confirm",
        ),
        Part(
            "BR10LN4",
            "bracket",
            unit_weight=Decimal("29.05"),
            symbol={"w": 10, "h": 3},
            drawing_ref="BR10LN4",
            source="assumed weight - confirm",
        ),
    ]
    return {p.mark: p for p in parts}


def sample_job() -> Job:
    """Sample assemblies re-modelled from the shop drawings (used for golden-file comparison)."""
    job = Job(job_no="1277345", customer="Clark Jordan", building="Main Bldg.", date="6/14/23", parts=standard_parts())
    slope = 4.7636  # 1:12

    # ---- RF1-9  column (sheet 15) ------------------------------------------------
    rf19 = Assembly(
        mark="RF1-9",
        kind="COLUMN",
        qty=3,
        main=MainMember(
            "RF-300",
            "W14X22",
            D("24'-11 13/16\""),
            derivation="entered from sample cut sheet RF-300",
            web_holes=[
                WebHoles(
                    D("12'-11 5/8\""), D("5 1/2"), D(H916), cols=2, rows=2, pitch_x=D("2 1/2"), pitch_y=D("2 7/16")
                )
            ],
        ),
        attachments=[
            Attachment("B-14", "left_end", show_first_hole_ref=True),
            Attachment("BR14HE1", "right_end", tilt=slope),
            Attachment("MB-3", "top", D("13'-2 1/8\""), ref="left"),
            Attachment("MB-2", "bottom", D("13'-2 1/8\""), ref="left"),
            Attachment("PC8D", "web", D("12'-11 5/8\""), side="both", y_from_top=D("5 1/2"), note="FS/NS"),
            Attachment("BR10LN3", "top", D("21'-7 7/8\""), ref="left", tilt=slope),
            Attachment("PC8D", "top", D("23'-7\""), ref="center"),
        ],
    )
    # ---- RF1-2  rafter (sheet 12) ------------------------------------------------
    stations = ["1'-8 3/16\"", "6'-0 3/16\"", "10'-4 3/16\"", "14'-8 3/16\"", "19'-0 3/16\""]
    rf12 = Assembly(
        mark="RF1-2",
        kind="RAFTER",
        qty=5,
        main=MainMember("RF-200", "W14X22", D("21'-3 1/8\""), derivation="entered from sample cut sheet RF-200"),
        attachments=[Attachment("K-14", "left_end"), Attachment("K-14", "right_end")]
        + [Attachment("PC8D", "top", D(s), ref="center", show_first_hole_ref=(i == 0)) for i, s in enumerate(stations)]
        + [
            Attachment("CLF2", "web", D(s), side="both", y_from_top=D("11"))
            for s in (stations[0], stations[2], stations[4])
        ],
    )
    # ---- MB1-1  mezzanine beam (sheet 4) -----------------------------------------
    mb_st = [
        "1'-1 3/16\"",
        "3'-1 3/16\"",
        "5'-1 3/16\"",
        "7'-1 3/16\"",
        "9'-1 3/16\"",
        "11'-1\"",
        "13'-1\"",
        "15'-1\"",
        "17'-1\"",
        "19'-1\"",
    ]
    mb11 = Assembly(
        mark="MB1-1",
        kind="RAFTER",
        qty=2,
        date="5/16/23",
        main=MainMember("MB-1", "W12X22", D("20'-2 3/8\""), derivation="entered from sample cut sheet MB1"),
        attachments=[Attachment("EP12", "left_end"), Attachment("EP12", "right_end")]
        + [Attachment("PC8D", "top", D(s), ref="center", show_first_hole_ref=(i == 0)) for i, s in enumerate(mb_st)]
        + [Attachment("CLF4", "bottom", D("10'-1 1/4\""), ref="center")],
    )
    for a in (rf19, rf12, mb11):
        job.assemblies[a.mark] = a
    from .connections import normalize_columns

    normalize_columns(job)
    return job
