"""Supplier reference transcription from owner-uploaded SSS Catalog 32 pages.
No capacities, stock availability, material substitutions or fabrication authority.
Catalog entries are not automatically added to a bill of materials.
"""

import hashlib
import json

SUPPLIERS = {'mbci': 'MBCI', 'sss': 'Triple-S Steel', 'other': 'Other / manual quote'}
SOURCES = {
    164: 'p.164-165 sheet profile and color chart.png',
    165: 'p.164-165 sheet profile and color chart.png',
    166: 'p. 166-167 trim profiles and labels.png',
    167: 'p. 166-167 trim profiles and labels.png',
    168: 'p. 168-169 trim profiles and labels.png',
    169: 'p. 168-169 trim profiles and labels.png',
    170: 'p.170-171 trim and secondaries with labels.png',
    171: 'p.170-171 trim and secondaries with labels.png',
    175: 'sss-175.png',
}


def catalog():
    rows = []

    def add(code, label, page, category='trim', **kw):
        rows.append(
            dict(
                id=code or 'SSS-' + label.split()[0].upper(),
                code=code,
                label=label,
                page=page,
                category=category,
                source=SOURCES[page],
                notes=[],
                **kw,
            )
        )
        return rows[-1]

    add(
        '',
        'PBR Panel',
        164,
        'panel',
        gauge=26,
        coverage_in=36,
        overall_width_in=38.25,
        rib_pitch_in=12,
        rib_height_in=1.25,
        stock_lengths_ft=[8, 10, 12, 14, 16, 18, 20],
        custom_max_ft=43,
    )
    add(
        '',
        'PBU Panel',
        164,
        'panel',
        coverage_in=36,
        overall_width_in=38.25,
        rib_pitch_in=6,
        rib_height_in=0.75,
        custom_max_ft=42,
    )
    # Label/code and supply lengths from the supplied pages, NOT physical equivalence mappings.
    specs = [
        ('TRGTRSTD', 'Standard Gutter', 166, [10, 12]),
        ('TRSTG', 'Gutter Strap', 166, None),
        ('TRDSPT', 'Downspout', 166, [10, 12]),
        ('TRETHS', 'Standard High Side Eave Trim', 166, None),
        ('TRRKTSTDU', 'Standard Rake — U panel', 166, [10, 12]),
        ('TRRKTSTD', 'Standard Rake — R panel', 166, [10, 12]),
        ('TRETLSS', 'Sculptured Low Side Eave Trim', 166, None),
        ('TRETHSS', 'Sculptured High Side Eave Trim', 166, None),
        ('TRASG', 'Hang On Sculptured Gutter', 166, None),
        ('TRENDCS', 'Sculptured Gutter End Cap', 166, None),
        ('TRENDCSTD', 'Standard Gutter End Cap', 166, None),
        ('TRKT', 'Downspout Kickout', 166, None),
        ('TRSK', 'Scupper Kickout', 167, None),
        ('TRPB', 'Pitch Break', 167, None),
        ('TRECSR', 'End Caps For Sculpted Rake', 167, None),
        ('TRECBG', 'End Caps For Box Gutter', 167, None),
        ('TRECBR', 'End Caps For Box Rake', 167, None),
        ('TRCRS', 'Sculptured Corner', 167, [10, 12]),
        ('TRETSTD', 'Standard Eave Trim', 167, [10, 12]),
        ('TRPS', 'Peak Sheet — R panel', 167, None),
        ('TRPSU', 'Peak Sheet — U panel', 167, None),
        ('TRVT', 'Valley Trim', 167, None),
        ('TRRCF', 'Flat Ridge Cap', 167, [10, 12]),
        ('TRGTRS', 'Sculptured Gutter', 167, [10, 12]),
        ('TRSTDS', 'Downspout Strap', 168, None),
        ('TRDHT', 'Door Head Trim — R panel', 168, [3 + 5 / 12, 10 + 4 / 12, 12 + 4 / 12]),
        ('TRDHTU', 'Door Head Trim — U panel', 168, [3 + 5 / 12, 10 + 4 / 12, 12 + 4 / 12]),
        ('TRDJMBT', 'Door Jamb Trim — R panel', 168, [7 + 4 / 12, 10 + 4 / 12, 12 + 4 / 12]),
        ('TRDJMBTU', 'Door Jamb Trim — U panel', 168, [7 + 4 / 12, 10 + 4 / 12, 12 + 4 / 12]),
        ('TRFS', 'Flat Sheet', 168, None),
        ('TRCT', 'Cap Trim — R panel', 168, None),
        ('TRCTU', 'Cap Trim — U panel', 168, None),
        ('TRRKTS', 'Sculptured Rake', 168, [10, 12]),
        ('TRBRT', 'Box Rake Trim — R panel', 168, None),
        ('TRBRTU', 'Box Rake Trim — U panel', 168, None),
        ('TRBG', 'Box Gutter', 168, None),
        ('TRHGSTD', 'Hang-On Standard Gutter', 168, None),
        ('TRRSC10', 'Stepped Ridge Cap With Hems — 10 x 10', 169, None),
        ('TRRSC7', 'Stepped Ridge Cap With Hems — 7 x 7', 169, None),
        ('TRCRFC', 'Commercial Flat Ridge Cap', 169, None),
        ('TRCRSU', 'Corner Trim For PBU Panel', 170, None),
        ('TRSRPB', 'Peak Box For Sculptured Rake', 170, None),
        ('TRSRCB', 'Corner Boxes For Sculptured Rake', 170, None),
        ('TRRTRN', 'PBR Transition Trim', 170, None),
        ('TRUTRN', 'PBU Transition Trim', 170, None),
    ]
    for code, label, page, lengths in specs:
        add(code, label, page, stock_lengths_ft=lengths)
    # Stock codes below are read directly from the supplied catalog table.
    for n in (4, 6, 8):
        add(
            'TRPNR' + str(n) + 'S',
            f'Carport Rake For {n} inch Purlin',
            169,
            top_in=5,
            face_in=n + 1.25,
            bottom_in=2,
            stock_lengths_ft=None,
        )
        add(
            'TROCR' + str(n) + 'S',
            f'Carport Rake For {n} inch Open Channel — R panel',
            169,
            top_in=5,
            face_in=n + 1.5,
            bottom_in=2,
            stock_lengths_ft=None,
        )
        add(
            'TROCR' + str(n) + 'SU',
            f'Carport Rake For {n} inch Open Channel — U panel',
            169,
            top_in=5,
            face_in=n + 1,
            bottom_in=2,
            stock_lengths_ft=None,
        )
        add(
            'TRPNR' + str(n), f'Purlin Cap For {n} inch Purlin', 170, face_in=n + 0.125, leg_in=2, stock_lengths_ft=None
        )
    for n in (2, 3, 4, 6):
        add('TROA' + str(n), f'Outside Angle With Hems {n} x {n}', 170, leg_in=n)
    for n in (2, 3, 4):
        add('TRIA' + str(n), f'Inside Angle With Hems {n} x {n}', 170, leg_in=n)
    for code, d, w in [
        ('PN3', 3, 1.5),
        ('PN42', 4, 2),
        ('PN4', 4, 1.5),
        ('PN6', 6, 2),
        ('PN8', 8, 2.5),
        ('PN8312', 8, 3.5),
        ('PN10', 10, 2.75),
    ]:
        add(
            code,
            f'C-Purlin {d} x {w:g} — 14ga',
            171,
            'secondary',
            depth_in=d,
            flange_in=w,
            gauge=14,
            finishes=['Red primed', 'Galvanized'],
            stock_lengths_ft=[20, 25, 30],
        )
    for code, d, widths in [
        ('PN4ZEE', 4, [2, 2.5]),
        ('PN6ZEE', 6, [2, 2.5]),
        ('PN8ZEE', 8, [2, 2.75]),
        ('PN10ZEE', 10, [2, 2.75]),
    ]:
        add(
            code,
            f'Z-Purlin {d} inch — 14ga',
            171,
            'secondary',
            depth_in=d,
            flange_options_in=widths,
            gauge=14,
            finishes=['Red primed', 'Galvanized'],
            stock_lengths_ft=[21, 26, 30],
        )
    for code, d in [('SS4214', 4.1875), ('SS6214', 6.1875), ('SS8214', 8.1875), ('SS10214', 10.1875)]:
        add(
            code,
            f'Open Face Channel {d:g} x 2 — 14ga',
            171,
            'secondary',
            depth_in=d,
            flange_in=2,
            gauge=14,
            finishes=['Red primed', 'Galvanized'],
            stock_lengths_ft=[20, 25, 30],
        )
    for code, legs, length, finish in [
        ('CAB1', [4, 2], 20, 'Red Prime'),
        ('CAB125', [4, 2], 25, 'Red Prime'),
        ('CAB1GALV', [4, 2], 20, 'Galvanized'),
        ('CAB125GALV', [4, 2], 25, 'Galvanized'),
        ('CAB22', [2, 2], 20, 'Red Prime'),
    ]:
        add(
            code,
            f'Base Angle {legs[0]} x {legs[1]} — 14ga',
            171,
            'secondary',
            legs_in=legs,
            gauge=14,
            stock_lengths_ft=[length],
            finishes=[finish],
        )
    for code, label in [('PN8SSES', 'Single Slope Eave Strut'), ('PN8DSES', 'Double Slope Eave Strut')]:
        add(
            code,
            label,
            175,
            'secondary',
            gauge=14,
            finishes=['Red oxide'],
            stock_lengths_ft=[20, 25, 30],
            roof_slopes=['1:12', '2:12', '3:12'],
            supply_note='Low side in stock; high side special order per catalog. Confirm slope and orientation.',
        )
    for n, width in [(4, 3.75), (6, 5.75), (8, 7.75)]:
        r = add(
            'CAPC' + str(n) + 'SCR',
            f'Light Gauge Angle Clip — {n} inch Zee/Cee',
            175,
            'accessory',
            gauge=14,
            legs_in=[2, 4],
            width_in=width,
            holes='No holes',
            fastener_note='Requires #14 x 1-1/4 inch Tek/2 S.D. fasteners; count not specified',
            finishes=['Red primed'],
        )
        if n == 8:
            r['weight_lb'] = 1.1
    add(
        'CAPC57316',
        'Purlin Clip — 5 x 7 x 3/16',
        175,
        'accessory',
        width_in=5,
        length_in=7,
        thickness_in=0.1875,
        finishes=['Plain'],
        application='Standard weld-on purlin clip',
    )
    add(
        'CAPC3518',
        'Purlin Clip — 3 x 5 x 1/8',
        175,
        'accessory',
        width_in=3,
        length_in=5,
        thickness_in=0.125,
        finishes=['Plain'],
        application='Standard weld-on purlin clip',
    )
    add(
        'CAPCG',
        'Girt To Jamb Clip',
        175,
        'accessory',
        gauge=10,
        width_in=6,
        long_leg_in=6.5,
        short_leg_in=3,
        hole_diameter_in=0.5625,
        weight_lb=2.15,
        finishes=['Red primed'],
        application='Pre-punched bolt-on; owner installation requirement: long leg down. Bolt specification/count and joint design not inferred.',
    )
    add(
        'CAPC8',
        'Jamb Base Clip (8 inch)',
        175,
        'accessory',
        gauge=10,
        width_in=6,
        legs_in=[3, 3],
        hole_diameters_in=[0.5625, 0.8125],
        weight_lb=1.45,
        finishes=['Red primed'],
        application='Catalog 8-inch application label is not blank width. Anchor diameter/type/embedment and base connection design not provided.',
    )
    for code, label in [
        ('CASPCW144', 'Polycarbonate Skylight — White / PBR'),
        ('CASPCL144', 'Polycarbonate Skylight — Clear / PBR'),
        ('CA/SPSW144', 'Polycarbonate Skylight — Soft White / PBR'),
        ('CA/SPCWU144', 'Polycarbonate Skylight — White / PBU'),
        ('CA/SPCLU144', 'Polycarbonate Skylight — Clear / PBU'),
        ('CA/SPSWU144', 'Polycarbonate Skylight — Soft White / PBU'),
        ('CASW144', 'Fiberglass Skylight — White / PBR'),
        ('CASU144', 'Fiberglass Skylight — White / PBU'),
    ]:
        add(code, label, 165, 'accessory', length_in=144, overall_width_in=38.25, coverage_in=36)
    for code, label in [
        ('CAMZ36102', 'Vinyl Reinforced Insulation — White / 3 inch x 6 ft x 102 ft / R10'),
        ('CAMZ3150', 'Reinforced Vinyl Patch Tape — 3 inch x 150 ft'),
        ('CAMZ1180', 'Double-Sided Tape — 1-1/2 inch x 180 ft'),
        ('CAMT12350', 'Tape Seal — 1/2 inch x 3/32 inch x 50 ft'),
        ('CAMT11850', 'Tape Seal — 1 inch x 1/8 inch x 50 ft'),
        ('CAPP', 'Touch Up Paint Pen'),
        ('CASEALANTCLEAR', 'Metal Roof Sealant — Clear / 10 oz'),
    ]:
        add(code, label, 165, 'accessory')
    for r in rows:
        if r['code'] in ('TRENDCS', 'TRENDCSTD', 'TRECSR', 'TRECBG', 'TRECBR', 'TRSRCB'):
            r['supply_unit'] = 'pair (confirm pack quantities; no automatic conversion from ea)'
        if r['code'] == 'TRFS':
            r.update(width_in=41.5625, supply_unit='by the foot')
        if r['code'] in ('TRCT', 'TRCTU', 'TRBRT', 'TRBRTU', 'TRBG', 'TRCRFC', 'TRCRSU'):
            r['supply_unit'] = 'by the foot'
        if r['code'] in ('TRETHS', 'TRETLSS', 'TRETHSS', 'TRASG', 'TRVT'):
            r['supply_note'] = 'Special order only per supplied page'
    return dict(
        supplier='Triple-S Steel',
        edition='Catalog 32 / owner supplied images',
        products=rows,
        colors=[
            'Crimson Red',
            'Polar White',
            'Hawaiian Blue',
            'Cocoa Brown',
            'Tan',
            'Burnished Slate',
            'Gray',
            'Fern Green',
            'Gallery Blue',
            'Beige',
            'Charcoal',
            'Rustic Red',
            'Aztec Gold',
            'Emerald Green',
            'Light Stone',
            'Galvalume Plus',
            'Burgundy',
            'Copper Penny',
            'Silver Metallic',
        ],
        notes=[
            'Owner-supplied catalog references, not live branch inventory or pricing.',
            'Use actual finish samples; Tan is not Saddle Tan. Existing finish and coating specifications remain authoritative.',
            'Dimensions are catalog references, not developed blanks, capacities or approved joints.',
            'No automatic purchase quantity for an accessory merely because it appears in this catalog.',
            'Profile references and requested cut lengths remain unchanged when switching supplier.',
            'Some small drawing dimensions are intentionally not transcribed; use the retained reference images/PDF.',
        ],
    )


def config(raw=None):
    raw = raw or {}
    # Shop standard: Triple-S Steel is the primary supplier of every job; MBCI is the option
    primary = raw.get('primary', 'sss')
    if primary not in ('mbci', 'sss'):
        raise ValueError('Primary supplier must be Triple-S Steel or MBCI')
    overrides = {}
    valid = {r['id'] for r in catalog()['products']}
    for key, r in raw.get('overrides', {}).items():
        if not isinstance(key, str) or not key.startswith('SRC-'):
            raise ValueError('Invalid supplier line identity')
        supplier = r.get('supplier', primary)
        code = str(r.get('catalog_id', ''))
        name = str(r.get('vendor', '')).strip()
        if supplier not in SUPPLIERS:
            raise ValueError('Unknown supplier')
        if supplier == 'sss' and code and code not in valid:
            raise ValueError('Unknown SSS catalog item')
        if supplier != 'sss' and code:
            raise ValueError('SSS catalog selections require Triple-S Steel supplier')
        if supplier == 'other' and not name:
            raise ValueError('Enter the other supplier name')
        overrides[key] = dict(supplier=supplier, catalog_id=code, vendor=name, note=str(r.get('note', '')))
    return dict(primary=primary, overrides=overrides)


def line_key(r):
    # Not ORDER-nnn: sorting/insertion must not reassign an override to another material.
    data = {
        k: r.get(k)
        for k in (
            'department',
            'family',
            'material',
            'finish',
            'grade',
            'order_length_in',
            'unit',
            'basis',
            'custom_mark',
        )
    }
    return 'SRC-' + hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:20]


def annotate(job, items):
    cfg = config(job.settings.get('sourcing'))
    cat = {r['id']: r for r in catalog()['products']}
    for r in items:
        key = line_key(r)
        override = cfg['overrides'].get(key, {})
        supplier = override.get('supplier', cfg['primary'])
        name = override.get('vendor') if supplier == 'other' else SUPPLIERS[supplier]
        choice = cat.get(override.get('catalog_id'))
        physical = False
        if job.settings.get('product_suppliers'):
            import re

            found = re.search(r'PROFILE REF ([^)]+)', r['material'])
            ident = (
                found.group(1)
                if found
                else r['material'].split(' panel / ')[0]
                if r['family'] == 'panel'
                else r['material']
            )
            if r['family'] == 'panel' and not ident.startswith('SSS-'):
                ident = 'MBCI-PBR'
            if ident.startswith(('SSS-', 'MBCI-', 'FL-', 'OWNER-FL')):
                physical = True
                supplier = 'sss' if ident.startswith('SSS-') else 'mbci'
                name = SUPPLIERS[supplier]
                choice = None
                if supplier == 'sss':
                    try:
                        from .secondary_catalog import get

                        code = get(ident).get('supplier_code')
                    except ValueError:
                        code = ident.removeprefix('SSS-')
                    choice = cat.get(ident) if ident in ('SSS-PBR', 'SSS-PBU') else cat.get(code)
        # Only the explicitly named existing PBR panel family has an automatic label.
        if (
            supplier == 'sss'
            and choice is None
            and r['family'] == 'panel'
            and 'PBR' in r['material']
            and '26ga' in r['material']
        ):
            choice = cat['SSS-PBR']
        label = choice['label'] if choice else r['material']
        code = choice['code'] if choice else ''
        issues = []
        if supplier == 'sss':
            if not choice:
                issues.append('UNMATCHED: quote AS-DRAWN specification; no verified SSS code selected')
            else:
                if choice.get('supply_unit'):
                    issues.append('Confirm purchasing unit: ' + choice['supply_unit'])
                issues.append(
                    'CATALOG CANDIDATE: verify complete section, finish, grade and connection fit; NOT a substitution approval'
                )
                import re

                gauges = re.findall(r'(?:-G(\d+)|(\d+)ga)', r['material'])
                gauge = next((int(a or b) for a, b in gauges), None)
                if choice.get('gauge') and gauge and choice['gauge'] != gauge:
                    issues.append(f"GAUGE HOLD: AS DRAWN {gauge}ga versus catalog {choice['gauge']}ga")
                try:
                    from .secondary_catalog import get

                    actual = get(r['material'])
                except ValueError:
                    actual = None
                if actual and choice['category'] == 'secondary':
                    if choice.get('depth_in') and abs(actual['nominal_depth_in'] - choice['depth_in']) > 0.0001:
                        issues.append('SECTION HOLD: nominal depth differs from AS DRAWN')
                    if choice.get('flange_in') and any(
                        abs(w - choice['flange_in']) > 0.0001 for w in actual.get('flanges_in', [])
                    ):
                        issues.append('SECTION HOLD: flange width differs from AS DRAWN')
                family = r['family']
                expected = (
                    'panel'
                    if family == 'panel'
                    else 'trim'
                    if family == 'trim'
                    else 'accessory'
                    if family == 'finished_clip'
                    else 'secondary'
                    if family in ('purlin', 'channel') or family.startswith('fixed:')
                    else None
                )
                if expected and expected != choice['category']:
                    issues.append('CATEGORY HOLD: selected catalog item is not the required material family')
                L = r.get('order_length_in')
                if L is not None:
                    if choice.get('custom_max_ft') and L > choice['custom_max_ft'] * 12:
                        issues.append('LENGTH HOLD: exceeds catalog custom maximum; no auto-splice')
                    elif choice.get('stock_lengths_ft') and not any(
                        abs(L - ft * 12) < 0.0001 for ft in choice['stock_lengths_ft']
                    ):
                        issues.append('CUSTOM LENGTH / cut-from-stock confirmation required')
                    elif choice.get('stock_lengths_ft') is None and choice['category'] == 'trim':
                        issues.append('Supply length not stated here; confirm before ordering')
            if 'Signature 200' in r['material']:
                issues.append(
                    'COATING HOLD: saved Signature 200 coating retained; supplied SSS chart describes its own coating options, not equivalence'
                )
            if 'saddle tan' in r['finish'].lower():
                issues.append('COLOR HOLD: Saddle Tan is not listed; SSS Tan is NOT equivalent')
        elif supplier == 'mbci':
            issues.append(
                'AS-DRAWN profile reference; local application IDs are not guaranteed manufacturer order codes'
            )
        else:
            issues.append('MANUAL QUOTE: supplier must confirm the AS-DRAWN specification')
        r.update(
            sourcing_key=key,
            supplier=supplier,
            supplier_name=name,
            supplier_code=code,
            supplier_catalog_id=choice['id'] if choice else '',
            supplier_label=label,
            supplier_page=choice['page'] if choice else None,
            supplier_status='; '.join(issues),
            supplier_note=override.get('note', ''),
            source_material=r['material'],
        )
        if physical and choice:
            r['supplier_status'] = r['supplier_status'].replace(
                'CATALOG CANDIDATE: verify complete section, finish, grade and connection fit; NOT a substitution approval',
                'SELECTED PHYSICAL PRODUCT; model regenerated to this catalog envelope. Grade, stock availability, connection design and final fit remain review items',
            )
        r['display_material'] = name + ' | ' + (code + ' — ' if code else '') + label
        if choice and label != r['material'] and not physical:
            r['display_material'] += ' | AS DRAWN: ' + r['material']
    return cfg


def write_workbook(path):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    c = catalog()
    wb = Workbook()
    wb.remove(wb.active)

    def sheet(name, headers, rows):
        ws = wb.create_sheet(name)
        ws.append(headers)
        for row in rows:
            ws.append(row)
            for cell in ws[ws.max_row]:
                if isinstance(cell.value, str):
                    cell.data_type = 's'
        for cell in ws[1]:
            cell.font = Font(bold=True, color='FFFFFF')
            cell.fill = PatternFill('solid', fgColor='213D53')
        for col in range(1, len(headers) + 1):
            ws.column_dimensions[get_column_letter(col)].width = 24 if col < 4 else 65
        for row in ws:
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical='top')
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions
        return ws

    sheet(
        'Read first',
        ['Topic', 'Requirement'],
        [
            ['Supplier', c['supplier']],
            ['Edition', c['edition']],
            [
                'Scope',
                'Ordering REFERENCE / RFQ candidates; no automatic substitutions, quantities, stock availability or engineering approval.',
            ],
        ]
        + [['Note', n] for n in c['notes']],
    )
    for category in ('panel', 'trim', 'secondary', 'accessory'):
        sheet(
            category.title(),
            [
                'Catalog item',
                'Printed code (blank = not shown)',
                'Page',
                'Supplier label',
                'Specification / supply reference',
            ],
            [
                [
                    r['id'],
                    r['code'],
                    r['page'],
                    r['label'],
                    json.dumps(
                        {k: v for k, v in r.items() if k not in ('id', 'code', 'page', 'label', 'source', 'category')},
                        ensure_ascii=False,
                    ),
                ]
                for r in c['products']
                if r['category'] == category
            ],
        )
    sheet(
        'Colors',
        ['Catalog color / finish', 'Requirement'],
        [
            [
                color,
                'Actual samples and coating specification required. Color chart is not proof of equivalence or local inventory.',
            ]
            for color in c['colors']
        ]
        + [['Saddle Tan', 'NOT listed as that name. Do not substitute Tan without separate owner acceptance.']],
    )
    sheet('Sources', ['Printed page', 'Owner-uploaded file'], [[p, f] for p, f in SOURCES.items()])
    wb.save(path)
    return str(path)
