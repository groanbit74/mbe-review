"""Verified Triple-S candidates, never automatic manufacturer/grade substitution.
Subset relevant to current clip work; not a claim that the entire catalog was imported.
"""

GUIDE = 'https://www.sss-steel.com/assets/images/content/2026-steel-reference-guide.pdf?r=false'
WEST = 'http://ssscatalog.com/Triple%20S%20West_Cat%2032/'


def catalog():
    stock = []
    strip = [0.375, 0.5, 0.625, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.5, 4, 4.5, 5, 6, 8]
    half = [
        0.625,
        0.75,
        0.875,
        1,
        1.125,
        1.25,
        1.375,
        1.5,
        1.625,
        1.75,
        2,
        2.5,
        2.75,
        3,
        3.25,
        3.5,
        4,
        4.5,
        5,
        5.5,
        6,
        7,
        8,
    ]
    for thickness, widths, page in ((0.125, strip, 20), (0.1875, strip, 20), (0.5, half, 22)):
        for w in widths:
            stock.append(
                dict(
                    id=f'SSS-HR-{thickness:g}x{w:g}-20FT',
                    thickness_in=thickness,
                    width_in=w,
                    length_in=240,
                    grade='UNSPECIFIED',
                    finish='UNSPECIFIED',
                )
            )
    return dict(
        supplier='Triple-S Steel',
        scope='Verified hot-rolled strip 1/8 and 3/16, and 1/2 flat bar; other thicknesses remain manual entries.',
        flat_stock=stock,
        stock_source=GUIDE,
        stock_printed_pages=[20, 22],
        notes=[
            'Catalog sizes are quote candidates, not local inventory confirmation.',
            'Hot-rolled 20-ft standard lengths; do not mix with the separate 1018 cold-finished 12-ft product.',
            'Hot-rolled grade and finish must be confirmed; no A36 or coating is inferred.',
            'W shapes and tubing guide remains a supplier reference; existing structural specifications and stock lengths are NOT silently replaced.',
        ],
        panels=dict(
            source=WEST + '?page=166',
            printed_page=164,
            profile='PBR',
            coverage_in=36,
            rib_pitch_in=12,
            rib_height_in=1.25,
            gauge=26,
            stock_lengths_ft=[8, 10, 12, 14, 16, 18, 20],
            custom_max_ft=43,
            notes=[
                'Saddle Tan is not listed by that name in the West chart; Tan is NOT assumed equivalent.',
                'Galvalume Plus and Light Stone appear in the chart; verify coating, matching samples, location and availability.',
                'Catalog maximum differs from MBCI. No automatic panel splice or substitution.',
            ],
        ),
        carport_rakes=[
            dict(
                code='TRPNR' + str(n) + 'S',
                application=str(n) + ' inch purlin',
                top_in=5,
                face_in=n + 1.25,
                bottom_in=2,
                source=WEST + '?page=171',
                printed_page=169,
                stock_length_in=None,
                status='ALTERNATE QUOTE / installed fit and supply length not confirmed',
            )
            for n in (4, 6, 8)
        ],
    )


def clip_candidates(plan):
    thicknesses = {r['thickness_in'] for r in plan['clip_requirements'] if r['mode'] == 'shop'}
    return [r for r in catalog()['flat_stock'] if r['thickness_in'] in thicknesses]


def quote_workbook(job, path):
    """Alternative REQUEST FOR QUOTE, not a second purchase order or SKU substitution."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    from .ordering import build

    p = build(job)
    wb = Workbook()
    wb.remove(wb.active)

    def table(name, heads, rows):
        ws = wb.create_sheet(name)
        ws.append(heads)
        for row in rows:
            ws.append(row)
            for cell, v in zip(ws[ws.max_row], row):
                if isinstance(v, str):
                    cell.data_type = 's'
        for c in ws[1]:
            c.font = Font(bold=True, color='FFFFFF')
            c.fill = PatternFill('solid', fgColor='244559')
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = 25 if col[0].column < 5 else 48
        for row in ws:
            for c in row:
                c.alignment = Alignment(vertical='top', wrap_text=True)
        ws.freeze_panes = 'A2'
        ws.auto_filter.ref = ws.dimensions

    table(
        'Read first',
        ['Scope', 'Requirement'],
        [
            [
                'ALTERNATE RFQ ONLY',
                'Do not buy this plus the active supplier order. No supplier substitution or acceptance is recorded.',
            ],
            ['Job revision', job.revision()],
            ['Roof finish', 'Saved finish retained; Galvalume Plus is NOT galvanized.'],
            [
                'Painted finish',
                'SSS West chart lists Tan, not Saddle Tan. No color equivalence inferred. Approve actual metal samples and coating specifications.',
            ],
            [
                'Trim',
                'Current drawing/profile reference retained. SSS must confirm a matching section or return a proposed substitution for review.',
            ],
            [
                'Panels',
                'SSS 26ga PBR: 36in coverage; 12in rib pitch; 1.25in rib height; catalog custom maximum43ft. No automatic splices.',
            ],
            [
                'Structural steel',
                'Guide link included. Confirm requested W/HSS section, grade, finish, length and wall thickness; no section or grade substitution.',
            ],
            ['Stock', 'Catalog candidates only, not branch/on-hand inventory. Hot-rolled grade/finish not inferred.'],
            ['Steel guide', GUIDE],
            ['West catalog', WEST],
        ],
    )
    panels = []
    trims = []
    for a in job.assemblies.values():
        c = a.derivation.get('cladding', {})
        for r in c.get('groups', []):
            panels.append(
                [
                    r['group'],
                    r['quantity'],
                    r['order_length_in'],
                    r['gauge'],
                    r['color'],
                    r['coating'],
                    'SSS PBR candidate / verify color/coating and exact order length'
                    + (' / EXCEEDS43FT: HOLD' if r['order_length_in'] > 516 else ''),
                    ', '.join(r['marks']),
                ]
            )
        for r in c.get('trim_pieces', []):
            trims.append(
                [
                    r['mark'],
                    r['quantity'],
                    r['cut_length_in'],
                    r['gauge'],
                    r['profile_id'],
                    r['color'],
                    r['coating'],
                    'MATCH CURRENT SECTION DRAWING; not an approved SSS SKU',
                ]
            )
    table(
        'Panel RFQ',
        [
            'Group',
            'Qty',
            'Requested length IN',
            'Gauge',
            'Requested color',
            'Requested coating',
            'SSS review',
            'Piece marks',
        ],
        panels,
    )
    table(
        'Trim RFQ',
        [
            'Mark',
            'Qty',
            'Requested length IN',
            'Gauge',
            'Current profile reference',
            'Requested color',
            'Requested coating',
            'SSS review',
        ],
        trims,
    )
    table(
        'Clip holds',
        ['Mark', 'Source', 'Qty', 'Thickness IN', 'Status', 'Missing quantity'],
        [
            [
                r['mark'],
                r['mode'],
                r['quantity'],
                r['thickness_in'],
                r.get('status', ''),
                r.get('unplanned_quantity', 0),
            ]
            for r in p['clip_requirements']
        ],
    )
    table(
        'Flat stock candidates',
        ['ID', 'Thickness IN', 'Width IN', 'Length IN', 'Grade', 'Finish'],
        [
            [r[k] for k in ('id', 'thickness_in', 'width_in', 'length_in', 'grade', 'finish')]
            for r in clip_candidates(p)
        ],
    )
    table(
        'Rake alternatives',
        ['SSS code', 'Application', 'Top IN', 'Face IN', 'Bottom IN', 'Status'],
        [
            [r['code'], r['application'], r['top_in'], r['face_in'], r['bottom_in'], r['status']]
            for r in catalog()['carport_rakes']
        ],
    )
    wb.save(path)
    return str(path)
