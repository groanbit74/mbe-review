"""Explicit, repeatable vertical adjustments to managed column-lot girt clips.

Each column mark may represent multiple physical columns. Moving it affects
that entire assembly lot and its longitudinal girt rows, not one hidden variant.
"""

from .connections import f
from .model import D


def apply(job, p):
    records = []
    seen = set()
    l = job.settings.get('frame_layouts', {}).get(p.column_mark)
    if not l:
        if p.girt_clip_adjustments:
            raise ValueError('Girt adjustments require a managed frame layout')
        return
    for item in p.girt_clip_adjustments:
        if not isinstance(item, dict):
            raise ValueError('Girt adjustment must specify column, index and offset')
        mark = item.get('column')
        index = item.get('index')
        delta = D(item.get('offset', '0'))
        if not isinstance(index, int) or isinstance(index, bool) or index < 1:
            raise ValueError('Girt clip index is1-based integer')
        if (mark, index) in seen:
            raise ValueError('Duplicate girt clip adjustment')
        seen.add((mark, index))
        a = job.assemblies.get(mark)
        if a is None or a.kind != 'COLUMN' or a.derivation.get('frame_id') != p.column_mark:
            raise ValueError('Girt adjustment column must be a managed column assembly mark in this frame')
        clips = [
            x for x in a.attachments if x.part == p.girt_clip and x.station is not None and x.note.startswith('girt ')
        ]
        if index > len(clips):
            raise ValueError('Girt adjustment index exceeds clip count on ' + mark)
        clip = clips[index - 1]
        old = clip.station
        new = old + delta
        col = next(c for c in l['columns'] if c['mark'] == mark)
        low = min(col.get('top_y0', col['y1']), col.get('top_y1', col['y1'])) - col['y0']
        half = f(job.part(clip.part).width) / 2
        if f(new) - half < 0 or f(new) + half > low:
            raise ValueError('Moved girt clip envelope extends beyond column low-side cut')
        clip.station = new
        records.append(
            dict(
                column=mark,
                index=index,
                part=clip.part,
                old_station_in=f(old),
                new_station_in=f(new),
                offset_in=f(delta),
                floor_elevation_in=col['y0'] + f(new),
                quantity=a.qty,
                scope='ALL INSTANCES OF COLUMN ASSEMBLY LOT; associated sidewall run elevation follows',
            )
        )
    l['girt_clip_adjustments'] = records
    job.assemblies[p.column_mark].derivation['girt_clip_adjustments'] = records
