"""User Q06 clip families;6in flange clip derived from MBCI fixed4in rows."""

import copy

from .model import D, Part


def weld_clip(job, depth):
    sizes = {4: (3, 3), 6: (3, 5), 8: (5, 7)}
    if depth not in sizes:
        raise ValueError(
            'Solid weld clips are specified for4,6,8in members only; intermediate sizes need an explicit plate rule'
        )
    w, h = sizes[depth]
    mark = f'WC{int(depth)}-SOLID'
    part = Part(
        mark,
        'clip',
        D('3/16'),
        D(w),
        D(h),
        holes=[],
        source='User solid welded clip rule',
        notes='SOLID weld clip; no bolt holes.',
        symbol=dict(
            member_depth_in=depth,
            solid_weld_clip=True,
            draft_connection=True,
            review_hold='Attachment fit and weld design review',
        ),
    )
    job.parts[mark] = part
    return part


GIRT_WELD_MARK = 'GIRT-WELD'


def girt_weld_mark(job):
    """Locator for a flush girt welded directly to the column web (shop standard on welded
    buildings, owner 2026-10-15: "welded girts don't have clips standard - the standard is weld to
    web; clips are an option").  It is attached like a clip so the column sheets carry the girt
    stations, but it is no part: nothing is listed, weighed or ordered for it."""
    from decimal import Decimal

    part = Part(
        GIRT_WELD_MARK,
        'mark',
        None,
        None,
        None,
        holes=[],
        unit_weight=Decimal(0),
        description='GIRT welded to the column web (coped) - no clip',
        source='Shop standard: flush girts welded to the web',
        notes='Weld location only; not a part.',
        symbol=dict(weld_mark=True, draft_connection=False),
    )
    job.parts[GIRT_WELD_MARK] = part
    return part


def welded_to_web(p):
    """True when the girts of this frame are welded directly to the column web (no clips)."""
    return (
        p.connection_style != 'bolted'
        and p.girt_mode == 'flush'
        and getattr(p, 'girt_attachment', 'web_weld') == 'web_weld'
    )


def prepare(job, p):
    if p.clip_policy == 'member_sized' and p.connection_style != 'bolted' and welded_to_web(p):
        p.girt_clip = girt_weld_mark(job).mark
        p.purlin_clip = weld_clip(job, float(p.purlin_depth.inches)).mark
        p.eave_clip = (
            weld_clip(job, float(p.eave_strut_depth.inches)).mark if p.secondary.get('eave') else p.purlin_clip
        )
        return
    if p.clip_policy == 'member_sized' and p.connection_style != 'bolted':
        base = weld_clip(job, float(p.girt_depth.inches))
        p.girt_clip = base.mark
        if p.welded_fit_rules.get('enabled') and p.girt_mode == 'flush':
            # Same rectangular blank, rotated in its mounting plane: long edge along
            # the column web depth, short edge projects out. Roof clips unchanged.
            web = copy.deepcopy(base)
            web.mark = base.mark.replace('-SOLID', '-WEB')
            web.width, web.length = base.length, base.width
            web.symbol['mount_orientation'] = 'LONG SIDE PARALLEL TO COLUMN WEB; short projection'
            web.notes += ' Column WEB orientation: long edge across web depth; short edge projects from web. Not a roof-clip rotation.'
            job.parts[web.mark] = web
            p.girt_clip = web.mark
        p.purlin_clip = weld_clip(job, float(p.purlin_depth.inches)).mark
        p.eave_clip = (
            weld_clip(job, float(p.eave_strut_depth.inches)).mark if p.secondary.get('eave') else p.purlin_clip
        )
        return
    if p.clip_policy == 'member_sized':
        gd = float(p.girt_depth.inches)
        pd = float(p.purlin_depth.inches)
        if gd not in (6, 8) or pd not in (6, 8):
            raise ValueError(
                f'Automatic bolted clips are only modelled for 6 in and 8 in girts/purlins (fixed 4 in bolt rows); this job has girt {gd:g} in / purlin {pd:g} in. Choose a 6 in or 8 in product (Building settings > step 4 - Secondaries > Purlin, girt & eave products) or set the clip policy to welded; no substitute clip is made.'
            )
        p.girt_clip = 'PC8D'
        # Generate the shared6in pattern when either selected member requires it.
        if gd == 8 and pd == 6:
            probe = copy.copy(p)
            probe.clip_policy = 'legacy'
            probe.girt_depth = D(6)
            prepare(job, probe)
        p.purlin_clip = 'PC6D-MBCI' if pd == 6 else 'PC8D'
    if p.girt_clip not in ('PC8D', 'PC6D-MBCI'):
        return
    depth = float(p.girt_depth.inches)
    if depth == 8:
        p.girt_clip = 'PC8D'
        return
    if depth != 6:
        return
    src = job.part('PC8D')
    part = copy.deepcopy(src)
    # Keep the4in row spacing.6in web has1in edge offsets,8in web2in.
    # Shift depth-direction rows1in; retain original plate end margin.
    part.mark = 'PC6D-MBCI'
    part.length = src.length - D(1)
    part.unit_weight = None
    for h in part.holes:
        h.x = h.x - D(1)
    part.symbol.update(
        girt_depth_in=6,
        pattern_basis='MBCI CI-19:6in web1+4+1;8in web2+4+2',
        derived_from='PC8D',
        draft_connection=True,
        review_hold='User-directed pattern adaptation; verify mounting datum, flange access and edge distances before fabrication',
    )
    part.source = 'Q06 / MBCI CI-19 / PC8D source'
    part.notes = '6in adaptation:4in hole-row spacing retained; clip thickness/width retained; depth-direction coordinates and length reduced1in. Clip holes retained from source, NOT secondary5/8in holes.'
    part.description = 'PC6 / MBCI4in ROWS / FIT REVIEW'
    job.parts[part.mark] = part
    p.girt_clip = part.mark
