"""User-requested tube COLUMN envelopes.

Outside dimensions are nominal.  Weight per foot is computed from the nominal wall
(sheet gauge decimal or the fractional wall) with 2t outside / t inside corner radii,
the same convention the AISC HSS tables use (HSS4x4x1/4 -> 12.21 lb/ft).  Gauge walls
keep ``tf``/``tw`` = None: the exact mill thickness is not a fit datum, the outside
face is.  No W properties or I-section webs are reused.
"""

import math
import re
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction

SIZES = ('4x4', '4x5', '4x6', '4x7', '4x8', '2x4', '2x5', '2x6', '2x7', '2x8')
WALLS = ('14 ga', '12 ga', '11 ga', '10 ga', '1/8', '3/16', '1/4')
GAUGE_IN = {'14 ga': 0.0747, '12 ga': 0.1046, '11 ga': 0.1196, '10 ga': 0.1345}  # manufacturers' standard gauge
STEEL_LB_PER_IN3 = 0.2836


def nominal_wall_in(wall):
    """Nominal wall thickness in inches for a library wall label."""
    wall = re.sub(r'\s+', ' ', str(wall).strip().lower())
    return GAUGE_IN[wall] if wall in GAUGE_IN else float(Fraction(wall))


def weight_lb_ft(width, depth, t):
    """Nominal HSS weight: wall area with 2t outside / t inside corner radii."""
    area = 2 * t * (width + depth - 2 * t) - (4 - math.pi) * 3 * t * t
    return round(area * STEEL_LB_PER_IN3 * 12, 2)


@dataclass(frozen=True)
class TubeSection:
    name: str
    d: float
    bf: float
    wall: str
    tf: float | None
    tw: float | None
    plf: Decimal | None = None
    kind: str = 'HSS'
    finish: str = 'UNSPECIFIED'


def names():
    return ['HSS ' + size + ' x ' + wall for size in SIZES for wall in WALLS]


def get(name):
    m = re.fullmatch(r'HSS\s+(\d+)[xX](\d+)\s*[xX]\s*(.+)', str(name).strip(), re.I)
    if not m:
        raise KeyError('Tube section must be HSS WIDTHxDEPTH x WALL (e.g. HSS 4x6 x 3/16)')
    size = m[1] + 'x' + m[2]
    wall = re.sub(r'\s+', ' ', m[3].strip().lower())
    if size not in SIZES or wall not in WALLS:
        raise KeyError('Tube size/wall outside the requested column library')
    width, depth = map(float, size.split('x'))
    t = None if 'ga' in wall else float(Fraction(wall))
    plf = Decimal(str(weight_lb_ft(width, depth, nominal_wall_in(wall))))
    return TubeSection('HSS ' + size + ' x ' + wall, depth, width, wall, t, t, plf)


def profile(name, finish='UNSPECIFIED'):
    s = get(name)
    return dict(
        family='HSS',
        id=s.name,
        depth=s.d,
        width=s.bf,
        web=None,
        flange=None,
        weight_lb_ft=float(s.plf),
        wall=s.wall,
        actual_wall=str(s.tf) if s.tf is not None else '',
        finish=finish,
        closed_section=True,
        source='Nominal tube column; weight computed from the nominal wall (' + str(nominal_wall_in(s.wall)) + ' in)',
    )
