"""Internal material-engine reports. Supplier order never buys both alternatives."""

import csv
import json
from pathlib import Path

from .ordering import fmt


def trace_rows(p):
    groups = {}
    for d in p['demands']:
        if d.get('nominal_span_in') is None:
            continue
        key = tuple(
            d[k]
            for k in (
                'profile',
                'nominal_span_in',
                'net_fit_deduction_in',
                'exact_blank_length_in',
                'blank_length_in',
                'fit_basis',
            )
        )
        if key not in groups:
            groups[key] = dict(
                zip(
                    (
                        'profile',
                        'nominal_span_in',
                        'net_fit_deduction_in',
                        'exact_blank_length_in',
                        'blank_length_in',
                        'fit_basis',
                    ),
                    key,
                ),
                quantity=0,
                marks=[],
            )
        groups[key]['quantity'] += d['quantity']
        groups[key]['marks'].append(d['mark'])
    return list(groups.values())


def report_tables(p):
    comparisons = [
        [
            r['profile'] + ' / ' + r['finish'] + ' / ' + r['grade'],
            r['quantity'],
            fmt(r['stock_ordered_length_in']),
            fmt(r['custom_ordered_length_in']),
            fmt(r['stock_remnant_in'])
            + ' / '
            + fmt(None if r['stock_kerf_in'] is None else r['stock_kerf_in'] + r['stock_end_loss_in']),
            str(r['stock_length_cuts']) + ' / 0',
            r['status'],
        ]
        for r in p['material_comparisons']
    ]
    clips = [
        [
            r['mark'],
            r['mode'],
            r['quantity'],
            r.get('planned_quantity', '—'),
            r.get('unplanned_quantity', '—'),
            r.get('status', 'Prior purchased-blank policy'),
        ]
        for r in p['clip_requirements']
    ]
    bars = [
        [
            b['stock_id'],
            fmt(b['thickness_in']) + ' x ' + fmt(b['width_in']) + ' / ' + b['grade'] + ' / ' + b['finish'],
            fmt(b['length_in']),
            b['shear_cuts'],
            fmt(b['shear_loss_in']),
            fmt(b['remnant_in']),
        ]
        for b in p['flat_bars']
    ]
    cuts = [
        [
            r['stock_id'],
            r['mark'] + ' #' + str(r['instance']),
            fmt(r['start_in']),
            fmt(r['feed_length_in']),
            r['shear_cuts'],
            fmt(r['shear_loss_in']),
            str(r['rotation_deg']) + ' deg' + (' / stock end, separation omitted' if r['separation_omitted'] else ''),
        ]
        for r in p['flat_allocations']
    ]
    traces = [
        [
            r['profile'],
            fmt(r['nominal_span_in']),
            fmt(r['net_fit_deduction_in']),
            fmt(r['blank_length_in']),
            str(r['quantity']) + ' / ' + ', '.join(r['marks']),
            r['fit_basis'],
        ]
        for r in trace_rows(p)
    ]
    return [
        (
            'Stock vs Custom',
            ['MATERIAL', 'PIECES', 'STOCK TOTAL', 'CUSTOM TOTAL', 'REMNANT / LOSS', 'SHOP CUTS*', 'STATUS'],
            comparisons,
            [220, 55, 115, 115, 150, 85, 260],
        ),
        (
            'Clip Sourcing',
            ['MARK', 'SOURCE', 'REQUIRED', 'PLANNED', 'UNPLANNED', 'STATUS / ROUTE'],
            clips,
            [190, 80, 70, 70, 90, 400],
        ),
        (
            'Flat Bar Totals',
            ['STOCK ID', 'THICKNESS x WIDTH / SPEC', 'LENGTH', 'SHEAR CUTS', 'LOSS', 'REMNANT'],
            bars,
            [130, 360, 130, 110, 130, 140],
        ),
        (
            'Shear Plan',
            ['STOCK ID', 'CLIP / INSTANCE', 'START', 'BLANK FEED', 'CUTS', 'LOSS', 'ROTATION / NOTE'],
            cuts,
            [110, 210, 110, 130, 70, 110, 260],
        ),
        (
            'Cut Basis',
            ['SECTION', 'NOMINAL SPAN', 'NET DEDUCTION', 'CUT BLANK', 'QTY / MARKS', 'EXISTING FIT RULE'],
            traces,
            [150, 110, 110, 110, 260, 260],
        ),
    ]


def sheets(job, p):
    from .drawing.print_packets import tables

    out = []
    for name, heads, rows, widths in report_tables(p):
        if not rows or (name != 'Stock vs Custom' and not p['config']['material_engine']['enabled']):
            continue
        notes = {
            'Stock vs Custom': [
                'ALTERNATIVES ONLY. Compare mode buys STOCK; choose Custom explicitly to switch. No price assumptions. Totals cover known cut demands only.',
                '*Shop length cuts: STOCK / CUSTOM; includes reserved stock-end trims, NOT profile/angle/connection work. Custom pieces can still need fitting and finishing.',
                'Remnant is potentially reusable. LOSS is kerf + end trim. Custom supplier processing is not assumed free or waste-free.',
            ],
            'Clip Sourcing': [
                'Finished supplier clips, purchased blanks and shop stock are distinct. Unplanned shop quantities are NOT included as a fictitious stock order.'
            ],
            'Flat Bar Totals': [
                'Flat bars are separate from the frame/secondary linear-stock totals. Match thickness, width, grade and finish. No assumed ripping.'
            ],
            'Shear Plan': [
                'Blank feed reservations, NOT machine coordinates. Reserve the full declared allowance for each shear operation.',
                'Above 1/8 inch defaults to 1 inch PER CUT. Thin material requires an entered allowance. Shaped/formed blanks require a reviewed route.',
            ],
            'Cut Basis': [
                'Nominal support span minus EXISTING net fit deduction = modeled cut, then rounded UP to 1/16 for the order blank.',
                'Negative deduction means extension/lap. No second flange/web deduction. Exact roof zero-gap cuts are not shortened to fit stock.',
            ],
        }
        out += tables(job, 'SHOP - ' + name.upper(), heads, widths, rows, notes[name])
    return out


def export_reports(p, folder):
    root = Path(folder)
    root.mkdir(exist_ok=True, parents=True)
    files = []
    rowspec = [
        ('material_comparison', p['material_comparisons']),
        ('clip_sourcing', p['clip_requirements']),
        ('flat_bar_stock', p['flat_bars']),
        ('flat_bar_cuts', p['flat_allocations']),
        ('cut_basis', trace_rows(p)),
    ]
    for name, rows in rowspec:
        path = root / (name + '.csv')
        with path.open('w', newline='', encoding='utf-8') as f:
            if rows:
                writer = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for r in rows for k in r)))
                writer.writeheader()
                for r in rows:
                    safe = {}
                    for k, v in r.items():
                        if isinstance(v, (dict, list)):
                            v = json.dumps(v)
                        if isinstance(v, str) and v.startswith(('=', '+', '-', '@')):
                            v = "'" + v
                        safe[k] = v
                    writer.writerow(safe)
        files.append(str(path))
    return files
