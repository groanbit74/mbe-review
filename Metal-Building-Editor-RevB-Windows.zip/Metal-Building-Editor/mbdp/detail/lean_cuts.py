"""Welded lean rafter cut planes (shop rules), in the lean's face-local coordinates.

The lean rafter is a parallelogram blank with two PLUMB ends:

* HIGH end - at the outside face of the main column.  ``welded_direct`` (shop standard)
  butts the plumb end straight against the column face (no gap); the welded-clip option
  keeps the horizontal gap of the selected fit rule (owner: 2 in; legacy gap_overlap:
  1.5 in along the rafter).
* LOW end - at the lean post.  ``inside_flange`` (shop standard) stops the rafter at the
  INSIDE face of the post (the post runs to the rafter top line); ``outside_seat`` runs the
  rafter over the post to its outside face.

Long blank = top line + section depth x pitch (the two plumb cuts are parallel).
"""

import math


def finish(p, z, rf, col):
    z['rafter_cut_detail'] = None
    if not rf or not col:
        return  # cut planes are face-local (out from the attachment wall), any face
    high_modes = {s.get('high_connection_mode', z['high_connection']) for s in z.get('stations', [])}
    if not high_modes <= {'welded_direct', 'clip', 'end_plate'} or z['low_connection'] not in (
        'fully_welded',
        'welded_box',
    ):
        return
    low = z.get('low_connection_detail', {})
    if 'column_low_cut_in' not in low:
        return
    m = z['pitch'] / 12
    co = 1 / math.hypot(1, m)
    inset = float(p.girt_depth.inches) if p.inset_for_bypass else 0.0
    main_face = -inset
    gap_h = (
        float(z.get('high_gap_in', 0.0))
        if z['high_connection'] == 'clip' and z.get('high_clip_fit') != 'legacy'
        else 0.0
    )
    inside = (z.get('rafter_seat_resolved') or p.welded_knee) == 'inside_flange'
    start = main_face + gap_h
    end = z['projection_in'] - (col['depth'] if inside else 0)
    length = (end - start) / co
    if length <= 6:
        raise ValueError('Lean high gap / column depth consumes rafter span')
    deduction = z.get('purlin_deduction_in', z['purlin_depth_in'])
    high_top = z['high_eave_in'] - deduction + inset * m
    if z.get('rafter_peak_height'):
        from .cladding import inch

        entered = inch(z['rafter_peak_height'])
        if abs(entered - high_top) > 1e-6:
            z['issues'].append(
                'RAFTER CUT HOLD: manually entered high peak does not meet the selected roof/low-seat plane'
            )
            return
    depth = rf['depth'] / co
    long = length + rf['depth'] * m
    direct = z['high_connection'] == 'welded_direct'
    detail = z.get('high_connection_detail') or {}
    fits = detail.get('fits') or []
    high_text = (
        '; high end ' + detail['summary']
        if direct and detail.get('summary')
        else '; high end welded directly to the main column face (no gap)'
    )
    rec = dict(
        high_connection=z['high_connection'],
        high_face_x_in=main_face,
        high_face_rafter_top_in=high_top,
        high_gap_in=gap_h,
        high_gap_along_in=gap_h / co,
        high_cut_x_in=start,
        low_cut_x_in=end,
        low_seat='inside_flange' if inside else 'outside_seat',
        high_top_in=high_top - gap_h * m,
        low_top_in=z['high_eave_in'] - deduction - end * m,
        top_line_length_in=length,
        long_blank_in=long,
        plumb_depth_in=depth,
        high_cut_angle_deg=math.degrees(math.atan(m)),
        low_cut_angle_deg=math.degrees(math.atan(m)),
        high_bottom_in=high_top - gap_h * m - depth,
        low_bottom_in=z['high_eave_in'] - deduction - end * m - depth,
        high_fits=fits,
        status='WELDED PLUMB END PLANES DERIVED'
        + (high_text if direct else '; high end %.4g in clear of the main column face (welded clip)' % gap_h)
        + ('; low end at the post INSIDE face' if inside else '; low end over the post outside face'),
        datum='X horizontal OUTWARD from the main column outside face; Y above floor. Both ends PLUMB.'
        + (
            ' Low cut at the lean post INSIDE face (post to the rafter top line).'
            if inside
            else ' Low cut at the lean post OUTSIDE face.'
        ),
    )
    # Per frame line (rafter_lines override, round 11): the plumb cut planes are common; the
    # section depth and the purlin fit of the line set its blank and its top / bottom lines.
    from .framing_additions import station_fit, station_rafter

    n = len(z['stations'])
    lines = []
    for i in range(n):
        rfi, pair = station_rafter(z, rf, i, n)
        ded_i = station_fit(z, rfi, pair)[1]
        depth_i = rfi['depth'] / co
        top_i = z['high_eave_in'] - ded_i + inset * m
        station = z['stations'][i]
        high_mode = station.get('high_connection_mode', z['high_connection'])
        low_mode = station.get('rafter_seat_mode') or z.get('rafter_seat_resolved') or p.welded_knee
        gap_i = float(z.get('high_gap_in', 0.0)) if high_mode == 'clip' and z.get('high_clip_fit') != 'legacy' else 0.0
        inside_i = low_mode == 'inside_flange'
        start_i = main_face + gap_i
        end_i = z['projection_in'] - (col['depth'] if inside_i else 0)
        length_i = (end_i - start_i) / co
        if length_i <= 6:
            raise ValueError(
                'Lean support connection and seat choices consume rafter span at line %s'
                % station.get('frame_line', i + 1)
            )
        lines.append(
            dict(
                station=i + 1,
                frame_line=station.get('frame_line'),
                main_mark=station.get('main_mark'),
                high_connection=high_mode,
                low_connection=low_mode,
                high_connection_source=station.get('high_connection_source', 'inherited'),
                low_connection_source=station.get('rafter_seat_source', 'inherited'),
                profile_id=rfi['id'],
                pair=pair,
                purlin_fit=station.get('purlin_fit') or station_fit(z, rfi, pair)[2],
                roofline_fit=station.get('roofline_fit')
                or ('flush' if station_fit(z, rfi, pair)[0] else station_fit(z, rfi, pair)[2]),
                purlin_deduction_in=ded_i,
                plumb_depth_in=depth_i,
                high_gap_in=gap_i,
                high_cut_x_in=start_i,
                low_cut_x_in=end_i,
                long_blank_in=length_i + rfi['depth'] * m,
                top_line_length_in=length_i,
                high_top_in=top_i - gap_i * m,
                low_top_in=top_i - end_i * m,
                high_bottom_in=top_i - gap_i * m - depth_i,
                low_bottom_in=top_i - end_i * m - depth_i,
            )
        )
    # special open-C END rafter (owner 0.8.54): the open-face Cee is cut to pitch at
    # the column and stops 1/2 in short of the main wall sheet; its flat welds to the
    # open part of the C purlin, which runs the full slope into the main end rafter
    if z.get('end_rafter_style') == 'special_open_c' and z.get('special_open_c_ends'):
        for q in lines:
            if q['station'] in (1, len(lines)):
                q['special_open_c'] = dict(
                    c_purlin_blank_in=q['long_blank_in'],
                    open_face_blank_in=q['long_blank_in'] - 0.5 * math.hypot(1, m),
                    open_face_stop_in=0.5,
                    note='C purlin full slope into the main open-face end rafter (against its flat face), '
                    'flush-welded to the low lean column; open-face Cee welded to column and C purlin, '
                    'stopping 1/2 in from the sheet, its flat welded to the open part of the C purlin',
                )
    rec['lines'] = lines
    rec['mixed_sections'] = len({(x['profile_id'], x['pair']) for x in lines}) > 1
    z['rafter_cut_detail'] = rec
    by_station = {x['station']: x for x in lines}
    for member in z['members']:
        if member['role'] == 'rafter':
            x = by_station.get(member.get('station')) or {}
            member.update(
                reference_length_in=x.get('long_blank_in', long),
                cut_length_in=x.get('long_blank_in', long),
                blank_length_in=x.get('long_blank_in', long),
                top_line_length_in=x.get('top_line_length_in', length),
                plumb_depth_in=x.get('plumb_depth_in', depth),
                status=rec['status'],
            )
            _sp = x.get('special_open_c')
            if _sp and member.get('end_buildup') == 'special_open_c':
                member.update(
                    blank_length_in=_sp['open_face_blank_in'],
                    cut_length_in=_sp['open_face_blank_in'],
                    status=rec['status'] + '; ' + _sp['note'],
                )
            elif _sp and member.get('end_buildup') == 'special_open_c_c_purlin':
                member.update(blank_length_in=_sp['c_purlin_blank_in'], cut_length_in=_sp['c_purlin_blank_in'])
