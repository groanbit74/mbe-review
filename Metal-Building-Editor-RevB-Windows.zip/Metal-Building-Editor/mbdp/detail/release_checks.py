"""Release gate: a job is COMPLETE when nothing concrete is left to resolve.

The gate has exactly two kinds of entries:

* ``MODEL`` errors from :func:`model.validate` (geometry that cannot be
  fabricated: section not in catalog, nonpositive length, clash, fit FAIL,
  undefined part, incomplete plate size ...);
* **open items** - actionable warnings, opening / lean-to / template issues
  and order *Holds*, i.e. things the user can resolve by entering or changing
  an input.

Policy wording ("not approved", "capacity unverified", "review hold") is not
part of the gate; see :mod:`holds`.
"""

from . import holds as H
from .ordering import build


def _resolve_hint(reason):
    r = reason.lower()
    if 'not in catalog' in r:
        return 'Pick a catalog section for the member.'
    if 'cut length pending' in r or 'pending end support' in r or 'flush fit pending' in r:
        return 'Enter the end support section reference (Frame > Bays > End supports).'
    if 'segmentation' in r:
        return 'Shorten the run or enter stock segmentation (base angle over 20 ft).'
    if 'lot' in r and 'grid' in r or 'quantity mismatch' in r:
        return 'Set the primary frame lot quantity equal to the interior rigid-frame lines.'
    if 'developed blank' in r or 'route' in r:
        return 'Order options > Clips: choose BUY FINISHED or enter the developed blank and shear route.'
    if 'exceeds stock' in r:
        return 'Order options: choose exact/custom length for this profile or shorten the member.'
    if 'not selected' in r or 'select' in r:
        return 'Select the missing profile in Framing additions.'
    if 'no valid position' in r or 'clash' in r:
        return 'Move the opening or enable automatic relocation.'
    if 'cladding not enabled' in r:
        return 'Enable cladding (or remove the sheets/trim scope) in Cladding.'
    if 'quantity not provided' in r:
        return 'Enter the order quantity for the manual secondary line.'
    return 'Enter the missing value named in the item.'


def report(job):
    from .model import validate

    items = []

    def add(scope, ref, reason):
        items.append(dict(scope=scope, reference=ref, reason=reason, resolve=_resolve_hint(reason)))

    issues = validate(job)
    for issue in issues:
        if issue.severity == 'error':
            add('MODEL', issue.assembly, issue.text)
        elif H.is_actionable(issue.text):
            add('MODEL', issue.assembly, issue.text)
    for a in job.assemblies.values():
        d = a.derivation.get('framing_additions', {})
        for z in d.get('lean_tos', []):
            tag = a.mark + ' / ' + z['id']
            for s in H.actionable(z['issues']):
                add('LEAN-TO', tag, s)
            td = z.get('transition_detail')
            if td:
                for s in H.actionable(td['issues']):
                    add('TRANSITION', tag, s)
            for c in z.get('flush_clips', []):
                for s in H.actionable(c['issues']):
                    add('FLUSH CLIP', c['mark'], s)
        for o in d.get('openings', []):
            for s in H.actionable(o['issues']):
                add('OPENING', o['id'], s)
            q = o.get('connection_detail') or o.get('termination')
            if q:
                for s in H.actionable(q['issues']):
                    add('OPENING CONNECTION', o['id'], s)
    plan = build(job)
    for h in plan['pending']:
        add('ORDER / FIT', h['reference'], h['reason'])
    uniq = list({(r['scope'], r['reference'], r['reason']): r for r in items}.values())
    hard = [
        r
        for r in uniq
        if r['scope'] == 'MODEL' and any(i.severity == 'error' and i.text == r['reason'] for i in issues)
    ]
    status = 'COMPLETE' if not uniq else f'OPEN ITEMS ({len(uniq)})'
    return dict(
        job_no=job.job_no,
        revision=job.revision(),
        issue_status=status,
        complete=not uniq,
        permitted_issue='FOR CONSTRUCTION' if not uniq else 'REVIEW',
        fabrication_releasable=not hard,
        machine_releasable=not hard,
        blocking_count=len(uniq),
        hard_error_count=len(hard),
        blockers=uniq,
        advisories=plan.get('advisories', []),
    )


def sheets(job, rep=None):
    import textwrap

    from .drawing.canvas import S_NOTE, Canvas, Sheet
    from .drawing.sheet import _border, _footer, _title_block

    rep = rep or report(job)
    pages = []
    lines = []
    if not rep['blockers']:
        lines.append('No open items. All members, cuts and order lines are resolved for this revision.')
    for i, r in enumerate(rep['blockers'], 1):
        lines.extend(textwrap.wrap(f"{i}. [{r['scope']}] {r['reference']}: {r['reason']}", 140))
        lines.extend(textwrap.wrap('   resolve: ' + r['resolve'], 140))
        lines.append('')
    for n in range(0, len(lines), 36):
        sh = Sheet('RELEASE-CHECK-' + str(n // 36 + 1), 'release')
        c = Canvas(sh)
        _border(c)
        _title_block(c, job, 1, sh.name, 'RELEASE CHECK', job.date)
        c.ptext(110, 65, 'RELEASE CHECK — ' + rep['issue_status'], 17, bold=True, style=S_NOTE)
        c.ptext(
            110,
            91,
            f"{rep['blocking_count']} open item(s) | issue: {rep['permitted_issue']} | page {n // 36 + 1}",
            10,
        )
        for i, line in enumerate(lines[n : n + 36]):
            c.ptext(110, 126 + i * 14, line, 9)
        _footer(c, job, job.revision(), 'Release state follows the model revision shown above.')
        pages.append(sh)
    return pages
