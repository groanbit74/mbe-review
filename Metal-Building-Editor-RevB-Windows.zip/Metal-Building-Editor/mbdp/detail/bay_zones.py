"""Explicit longitudinal bays and enclosure; no inferred structural adequacy.
Initial supported topology: gable, one enclosed block reaching the right end,
with an optional roof-only extension at the left. All bays retain roof coverage.
"""

import copy

from .model import D

STATES = ('sheeted', 'open', 'future')


def active(p):
    return bool(getattr(p, 'bay_zones', {}).get('enabled'))


def stations(p):
    if not active(p):
        return []
    out = [0.0]
    for b in p.bay_zones['bays']:
        out.append(out[-1] + float(D(b['length']).inches))
    return out


def apply(p):
    raw = p.bay_zones
    if not isinstance(raw, dict):
        raise ValueError('Bay enclosure settings must be an object')
    if not isinstance(raw.get('enabled', False), bool):
        raise ValueError('Bay enclosure enabled must be boolean')
    if not raw.get('enabled'):
        p.bay_zones = {}
        return
    if p.frame_type != 'gable':
        raise ValueError(
            'Bay enclosure currently requires a gable building (Building settings > step 1 - Building & bays > Shape)'
        )
    if not p.endwalls.get('enabled'):
        raise ValueError(
            'Bay enclosure requires separate endwall framing: it is switched on automatically with bay enclosure in the editor; for API jobs send endwalls.enabled=true (Building settings > step 3 - Endwalls & openings)'
        )
    # Bay enclosure frames both ends as end walls (posts + end rafter).  A roof-only start
    # (rigid frames at both ends) is converted rather than rejected: the end becomes a
    # standard bearing end wall and the owner can set its enclosure open / sheeted in step 3.
    converted = []
    for end in ('front_end', 'rear_end'):
        ref = p.bay_layout.get(end) if isinstance(p.bay_layout, dict) else None
        rec = p.endwalls.get(end)
        if (isinstance(ref, dict) and ref.get('type') == 'rigid_frame') or (
            isinstance(rec, dict) and rec.get('type') == 'rigid_frame'
        ):
            if isinstance(ref, dict):
                ref.update(type='bearing_endwall', column_section='', rafter_section='', roof_mode='bypass')
            if isinstance(rec, dict):
                rec['type'] = 'bearing_endwall'
                rec.setdefault('enclosure', 'open')
            converted.append(end)
    rows = raw.get('bays', [])
    if not 2 <= len(rows) <= 100:
        raise ValueError('Enter 2–100 longitudinal bays')
    clean = []
    for i, b in enumerate(rows):
        L = D(b['length'])
        if not 0 < L.inches <= 1200:
            raise ValueError('Each bay must be positive and at most100ft; capacity is not inferred')
        c = {'id': 'B' + str(i + 1), 'length': L.fmt()}
        for side in ('left', 'right'):
            c[side] = b.get(side, 'sheeted')
            if c[side] not in STATES:
                raise ValueError('Bay sides must be sheeted, open or future')
        for side in ('left', 'right'):
            k = side + '_girts_now'
            v = b.get(k, False)
            if not isinstance(v, bool) or (v and c[side] != 'future'):
                raise ValueError('Install-now wall framing must be an explicit boolean on a future wall')
            c[k] = v
        clean.append(c)
    line = int(raw.get('enclosed_start_line', 0))
    if line != float(raw.get('enclosed_start_line', 0)) or not 0 <= line < len(rows):
        raise ValueError('Choose an enclosed-left wall on an existing frame line')
    if line and 'outer_front_end' not in p.endwalls:
        raise ValueError(
            'Roof-only extension requires its own outer end framing, separate from the enclosed junction wall'
        )
    if any(b[k] == 'sheeted' for b in clean[:line] for k in ('left', 'right')):
        raise ValueError('Left extension bays are roof-only; use open or future sides')
    state = raw.get('outer_front_state', 'future')
    if state not in STATES:
        raise ValueError('Invalid outer end enclosure state')
    now = raw.get('outer_girts_now', False)
    if not isinstance(now, bool) or (now and (state != 'future' or not line)):
        raise ValueError('Outer install-now framing requires a future outer end')
    p.bay_zones = dict(enabled=True, bays=clean, enclosed_start_line=line, outer_front_state=state, outer_girts_now=now)
    if converted:
        p.bay_zones['converted_ends'] = converted
    lengths = [D(b['length']).inches for b in clean]
    total = sum(lengths)
    if p.length is not None and abs(float(p.length.inches - total)) > 1e-7:
        raise ValueError('Bay lengths must total the master building length')
    p.length = D(total)
    p.bay_layout.update(
        enabled=True,
        layout_mode='explicit',
        bays=len(clean),
        bay_lengths=[b['length'] for b in clean],
        spacing=D(min(lengths)).fmt(),
    )
    if not p.cladding.get('enabled') or not p.cladding.get('walls') or not p.cladding.get('roof'):
        raise ValueError(
            'Bay enclosure requires the roof and wall sheet takeoff (cladding.enabled, walls and roof); individual wall coverage is controlled by the bay states (Building settings > step 5 - Sheets & trim)'
        )
    p.frames = len(clean) - 1 - (1 if line else 0)
    if p.frames < 1:
        raise ValueError(
            'This topology needs at least one interior main-frame line in addition to its channel junction wall'
        )
    if line:
        if state == 'sheeted':
            # Sheeted outer end (owner): the end wall past the roof-only bays takes sheets
            # like any sheeted end - girts included (sheets never without girts)
            p.endwalls['outer_front_end']['include_girts'] = True
            p.endwalls['outer_front_end']['enclosure'] = 'sheeted'
        else:
            p.endwalls['outer_front_end']['include_girts'] = now
    # The inside (junction) wall and the right end are sheeted in this topology: girts by default.
    # An explicit include_girts=false (editor checkbox / API) is respected.
    for end in ('front_end', 'rear_end'):
        rec = p.endwalls.get(end)
        if rec is None:
            p.endwalls[end] = {'include_girts': True}
        elif isinstance(rec, dict):
            rec.setdefault('include_girts', True)


def wall_station(p, key):
    L = float(p.length.inches) if p.length else 0
    if key in ('rear', 'rear_end'):
        return L
    if key in ('outer_front', 'outer_front_end'):
        return 0.0
    return stations(p)[p.bay_zones['enclosed_start_line']] if active(p) else 0.0


def intervals(p, side):
    if not active(p):
        from .enclosure import is_open

        if is_open(p, side):
            return []
        return [(0, float(p.length.inches))]
    ss = stations(p)
    L = ss[-1]
    runs = []
    for i, b in enumerate(p.bay_zones['bays']):
        if b[side] != 'sheeted':
            continue
        lo, hi = (L - ss[i + 1], L - ss[i]) if side == 'left' else (ss[i], ss[i + 1])
        runs.append((lo, hi))
    merged = []
    for lo, hi in sorted(runs):
        if merged and abs(merged[-1][1] - lo) < 1e-7:
            merged[-1] = (merged[-1][0], hi)
        else:
            merged.append((lo, hi))
    return merged


def framing_key(p, station):
    if not active(p):
        return (
            'front_end'
            if station == 0
            else 'rear_end'
            if abs(station - (float(p.length.inches) if p.length else 0)) < 1e-7
            else None
        )
    if abs(station - wall_station(p, 'front_end')) < 1e-7:
        return 'front_end'
    if station == 0:
        return 'outer_front_end'
    if abs(station - float(p.length.inches)) < 1e-7:
        return 'rear_end'
    return None


def finish(job, p):
    if not active(p):
        return
    owner = job.assemblies[p.column_mark]
    layout = job.settings['frame_layouts'][p.column_mark]
    ss = stations(p)
    plan = copy.deepcopy(p.bay_zones)
    plan.update(
        stations_in=ss,
        enclosed_left_station_in=wall_station(p, 'front_end'),
        primary_frame_stations_in=[x for x in ss[1:-1] if framing_key(p, x) is None],
        future_scope='Future panels and trim excluded; only explicitly selected install-now girts/base angles and their clips enter current demand; future connection/foundation/load design is NOT approved',
    )
    owner.derivation['bay_zones'] = plan
    layout['bay_zones'] = plan
    for key, w in owner.derivation.get('endwalls', {}).items():
        w['station_in'] = wall_station(p, key)
        w['endwall_name'] = (
            'Outer left end (roof-only)'
            if key == 'outer_front_end'
            else 'Inside wall (enclosed junction)'
            if key == 'front_end' and p.bay_zones['enclosed_start_line']
            else 'Right enclosed endwall'
            if key == 'rear_end'
            else 'Left endwall'
        )
        w['enclosure_state'] = (
            p.bay_zones['outer_front_state']
            if key == 'outer_front_end'
            else 'open'
            if w.get('enclosure') == 'open'
            else 'sheeted'
        )
        for r in w['members']:
            r['longitudinal_station_in'] = w['station_in']
            r['endwall_name'] = w['endwall_name']
    for line in owner.derivation.get('secondary_runs', {}).get('support_lines', []):
        key = framing_key(p, line['station_in'])
        line['wall_key'] = key
        if key:
            line.update(
                type='bearing_endwall', reference={'wall_key': key}, design_status='SEPARATE CROSS-WALL / counted once'
            )
    # The run model already counts interior rigid-frame lines with the
    # junction wall excluded (secondary_runs.interior_frame_count), so its
    # PRIMARY QUANTITY MISMATCH warning is authoritative here too.
    owner.derivation['secondary_runs']['interior_frame_lines'] = len(plan['primary_frame_stations_in'])
    if plan.get('converted_ends'):
        names = ' and '.join('left' if e == 'front_end' else 'right' for e in plan['converted_ends'])
        note = (
            f'END TYPE CHANGED: bay enclosure frames the {names} end as a post-supported end wall '
            '(the roof-only rigid end frame was replaced). Set its enclosure open / sheeted and the '
            'post layout in step 3 - Endwalls & openings.'
        )
        ws = owner.derivation['secondary_runs'].setdefault('warnings', [])
        if note not in ws:  # finish runs twice per generation
            ws.append(note)


def framed(p, index, side):
    if not active(p):
        from .enclosure import is_open

        return not is_open(p, side)
    b = p.bay_zones['bays'][index]
    return b[side] == 'sheeted' or (b[side] == 'future' and b.get(side + '_girts_now', False))
