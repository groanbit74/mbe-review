"""Welded frame, ridge and eave details, sharing the managed global setout."""

import math

from ..connections import connection_bom, f, q
from .canvas import S_CL, S_HID, S_NOTE, S_OBJ, Canvas, Sheet, View
from .sheet import _bom_table, _border, _footer, _mark_header, _title_block


def ridge_geometry(job, p, beam=True, clips=True):
    s = p.symbol
    polys = [(x['role'], x['points'], S_OBJ) for x in s['welded_profiles']]
    lines = []
    theta = math.radians(s['pitch_deg'])
    co = math.cos(theta)
    sn = math.sin(theta)
    d = s['rafter_depth']
    if beam:
        for x, y in s['beam_starts']:
            sign = 1 if x >= 0 else -1
            for z in (0, -d):
                plumb = s.get('ridge_type') == 'fully_welded'
                dx = 0 if plumb else sign * sn * z
                dy = z / co if plumb else co * z
                L = s.get('beam_preview_length', 8)
                lines.append(('rafter', (x + dx, y + dy), (x + dx + sign * L * co, y + dy - L * sn), S_OBJ))
    if clips:
        polys += [('peak clip', c['corners'], S_NOTE) for c in s['roof_clips']]
    return polys, lines


def header(job, name, kind, qty, fid):
    sh = Sheet(name, kind)
    c = Canvas(sh)
    _border(c)
    _mark_header(c, name, 'WELDED FRAME DETAIL')
    _title_block(c, job, qty, name, fid, job.date)
    return sh, c


def frame_sheet(job, fid, line=None):
    l = job.settings['frame_layouts'][fid]
    p = job.settings['frames'][fid]
    W = l['width_in']
    H = max(l['low_eave_in'], l['high_eave_in'], l['ridge_top_in'] or 0) + 12
    sh, c = header(
        job, ('FL%d-' % line['index'] if line else 'FRAME-') + fid, 'frameline' if line else 'frame', l['frames'], fid
    )
    sh.meta['setout'] = l
    sh.meta['frame_line'] = line
    if line:
        from .frameline_sheets import banner

        banner(c, line, job=job, fid=fid)
    c.ptext(
        110,
        73,
        (
            'A — FULLY WELDED / ONE-PIECE CUT-AND-FOLD RAFTER (NO RIDGE PLATE)'
            if l.get('ridge_joint') == 'cut_and_fold'
            else 'A — FULLY WELDED / SINGLE SHARED RIDGE PLATE'
            if l['connection_style'] == 'fully_welded'
            else 'B — WELDED APEX BOX / NO CONNECTION BOLTS'
        ),
        11,
        bold=True,
    )
    c.ptext(
        110,
        94,
        'SHOP STANDARD inside-flange knee: rafter welded to the inside flange, column run to the rafter top line; '
        + (
            'FLUSH mount purlins (top flush with the rafter top) - column at EAVE HEIGHT and the eave purlin welded flush to the outside of the column flange'
            if float(l.get('strut_depth_in') or 0) <= 0
            else 'BYPASS purlins - the eave purlin bears on the COLUMN SEAT, so the column is cut to EAVE HEIGHT less the purlin depth ('
            + q(l['strut_depth_in']).fmt()
            + ')'
        )
        + (
            ', column top and rafter top support the underside of the bearing plate.'
            if l.get('welded_knee_cap', True)
            else ', column cut to the pitch, no cap.'
        )
        if l.get('welded_knee') == 'inside_flange'
        else 'OPTION outside seat (rafter ON the column seat): column low side = roof line at that face less the ACTUAL PLUMB rafter depth'
        + (
            ''
            if float(l.get('strut_depth_in') or 0) <= 0
            else ' less the purlin depth (BYPASS: the eave purlin bears on the rafter top flange)'
        )
        + '.',
        10,
    )
    c.ptext(
        110,
        114,
        'Fixed outside wall width '
        + q(W).fmt()
        + '; column inset each side '
        + q(l['inset_in']).fmt()
        + ' (bypass GIRT depth). Pitch '
        + l['slope_rise']
        + ':12.',
        10,
    )
    from .. import frame_lines as FL
    from .coordination_views import extents, girt_clip, leans

    lean_layout = FL.layout_for_station(job, fid, line['station_in'] if line else None)
    xmin, xmax, H = extents(lean_layout, W, H)
    fnd = l.get('foundation') or {}
    below = fnd.get('embed_in', 0) + 6 if fnd.get('type') == 'post_footing' else 0  # post footings below the floor
    scale = min(800 / (xmax - xmin), 300 / (H + below))
    v = View(290 - xmin * scale, 480 - below * scale, scale, scale)
    a = Canvas(sh, v)
    leans(a, lean_layout)
    a.line(-10, 0, W + 10, 0, S_CL)
    if below:
        a.text(W / 2, 3, 'FLOOR DATUM', 8, 0, 'middle')
    for x in (0, W):
        a.line(x, 0, x, H, S_HID)
    for col in l['columns']:
        x0, x1, y0 = col['x0'], col['x1'], col['y0']
        a.poly([(x0, y0), (x1, y0), (x1, col['top_y1']), (x0, col['top_y0'])])
        a.text((x0 + x1) / 2, (y0 + col['y1']) / 2, col['mark'], 9, 90, 'middle')
        asm = job.assemblies[col['mark']]
        bp = job.parts.get(asm.derivation['resolved_base_plate'])
        xc = (x0 + x1) / 2
        if bp:
            a.rect(xc - f(bp.length) / 2, l['base_elevation_in'], xc + f(bp.length) / 2, y0)
        elif below:
            from .frame_sheet import post_footing

            post_footing(a, xc, fnd, label=col is l['columns'][-1])
        else:
            a.text(xc, y0 - 3, 'WELD TO FLOOR PLATE', 7, 0, 'middle')
        for att in asm.attachments:
            if att.station is not None and att.part == p['girt_clip']:
                girt_clip(a, job, p, col, att)
    for roof in l['rafters']:
        s, e = roof['top_start'], roof['top_end']
        u, n = roof['direction'], roof['normal']
        sec = job.assemblies[roof['mark']].main.sec
        co = abs(u[0])
        d = sec.d
        bottom_s = (s[0], s[1] - d / co)
        bottom_e = (e[0], e[1] - d / co) if roof['far_plumb'] else (e[0] - n[0] * d, e[1] - n[1] * d)
        a.poly([s, e, bottom_e, bottom_s])
        a.text((s[0] + e[0]) / 2, (s[1] + e[1]) / 2 + 8, roof['mark'], 9, 0, 'middle')
        for r in l['clip_records']:
            if r['owner'] != roof['mark']:
                continue
            st = r['station_top_in']
            if r.get('in_channel'):
                # purlin inside the open-face channel: mark the station, no clip
                pd = f(p['purlin_depth'])
                a.poly(
                    [
                        (s[0] + u[0] * (st + dd) + n[0] * z, s[1] + u[1] * (st + dd) + n[1] * z)
                        for dd, z in [(-0.5, 0), (0.5, 0), (0.5, -pd), (-0.5, -pd)]
                    ]
                )
                continue
            part = job.part(r['part'])
            z0 = 0 if p['purlin_mode'] == 'bypass' else -f(p['purlin_web_y']) - f(part.width) / 2
            z1 = f(part.length) if p['purlin_mode'] == 'bypass' else z0 + f(part.width)
            a.poly(
                [
                    (s[0] + u[0] * st + (dd if u[0] > 0 else -dd), s[1] + u[1] * st + z)
                    if r.get('orientation') == 'PLUMB'
                    else (s[0] + u[0] * (st + dd) + n[0] * z, s[1] + u[1] * (st + dd) + n[1] * z)
                    for dd, z in [
                        (-f(part.thk) / 2, z0),
                        (f(part.thk) / 2, z0),
                        (f(part.thk) / 2, z1),
                        (-f(part.thk) / 2, z1),
                    ]
                ],
                style=S_NOTE,
            )
        # Eave cover top flush with roof top and plumb at outside column face.
        if l.get('eave_plate'):
            ep = job.part(l['eave_plate'])
            sign = 1 if u[0] > 0 else -1
            a.poly(
                [
                    (s[0], s[1]),
                    (s[0] - sign * f(ep.thk), s[1]),
                    (s[0] - sign * f(ep.thk), s[1] - f(ep.length)),
                    (s[0], s[1] - f(ep.length)),
                ],
                style=S_NOTE,
            )
            if l['frame_type'] == 'monoslope':
                a.rect(e[0], e[1] - f(ep.length), e[0] + f(ep.thk), e[1], S_NOTE)
    for rec in l.get('knee_records', []):
        geo = rec['geometry']
        x, y, mirror = rec['x'], rec['y'], rec['mirror']
        a.poly([(x + mirror * px, y + py) for px, py in geo['side_contour_in']], style=S_NOTE)
        kp = job.part(rec['part'])
        if kp.symbol.get('starting_clip'):
            cp = job.part(kp.symbol['starting_clip'])
            yy = y + geo['thickness_in'] / geo['co']
            t = f(cp.thk)
            h = f(cp.length)
            a.poly([(x + mirror * px, py) for px, py in [(0, yy), (t, yy), (t, yy + h), (0, yy + h)]], style=S_NOTE)
    from .connection_views import draw_side

    for e in l['connections']:
        draw_side(a, job, job.part(e['mark']), False, False, lambda x, y: (e['x'] + x, e['y'] + y))
    if l.get('ridge_joint') == 'cut_and_fold' and l.get('ridge_top_in') is not None:
        rd = job.assemblies[l['rafters'][0]['mark']].main.sec.d
        rco = math.cos(math.radians(l['ridge_fold']['pitch_deg']))
        a.line(W / 2, l['ridge_top_in'], W / 2, l['ridge_top_in'] - rd / rco, S_OBJ)
        tip = v.p(W / 2, l['ridge_top_in'] - rd / rco / 2)
        c.leader(
            (tip[0] + 2, tip[1]),
            [(tip[0] + 40, tip[1] - 30)],
            'ONE-PIECE RAFTER: CUT & FOLD, NO PLATE - see RIDGE-' + fid,
            9,
        )
    m = float(l['slope_rise']) / 12
    roof0 = l['low_eave_in']
    mid = W if l['frame_type'] == 'monoslope' else W / 2
    a.line(0, roof0, mid, roof0 + mid * m, S_HID)
    if mid != W:
        a.line(mid, roof0 + mid * m, W, roof0, S_HID)
    if line:
        from .frameline_sheets import roof_line_overlay

        roof_line_overlay(a, c, v, job, fid, line)
    col = l['columns'][0]
    d = job.assemblies[l['rafters'][0]['mark']].main.sec.d
    low = min(col['top_y0'], col['top_y1'])
    rtop = low + (
        0 if l.get("welded_knee") == "inside_flange" else d * math.sqrt(1 + (float(l["slope_rise"]) / 12) ** 2)
    )
    for x, height, label in [
        (130, l['low_eave_in'], 'EAVE / TOP PURLIN'),
        (182, rtop, 'TOP RAFTER AT COLUMN'),
        (234, low, 'LOW SIDE COLUMN'),
    ]:
        c.dim_v(v.py(0), v.py(height), v.px(col['x0']), v.px(col['x0']), x, q(height).fmt() + ' ' + label, size=8)
    c.dim_h(v.px(0), v.px(W), v.py(0), v.py(0), v.py(-below) + 42, q(W).fmt() + ' OUTSIDE WALL LINES', size=10)
    c.ptext(
        110,
        552,
        'Inside-flange knee: rafter end welded to INSIDE building-facing column face; top plate bears on pitch-cut column.'
        if l.get('welded_knee') == 'inside_flange' and l.get('welded_knee_cap', True)
        else 'Rafter end PLUMB, welded to the INSIDE building-facing column face; column top cut to the pitch at the rafter top line.'
        if l.get('welded_knee') == 'inside_flange'
        else 'Column cut to pitch; rafter eave end PLUMB at outside column face. Keep eave clip; no knee bracket.',
        10,
    )
    c.ptext(
        110,
        573,
        'Top bearing plate:3/16 x rafter width x (column bearing along pitch +3in rafter overlap).'
        if l.get('welded_knee') == 'inside_flange' and l.get('welded_knee_cap', True)
        else 'NO cap plate (open-face rafter); eave member / first purlin inside the rafter channel.'
        if l.get('welded_knee') == 'inside_flange'
        else 'Column-end cover: 3/16 thick x rafter flange width x (plumb rafter depth + '
        + p['eave_plate_extension']
        + '); TOP FLUSH.',
        10,
    )
    c.ptext(
        110,
        595,
        f'COLUMN CUT CORRECTION: {l.get("nominal_depth_correction_in", 0):.6f}in deducted for plumb depth; seat overlap ZERO.',
        9,
    )
    for i, row in enumerate(l['schedule']):
        c.ptext(
            110,
            625 + i * 19,
            row['mark']
            + ' | '
            + row['section']
            + ' | qty '
            + str(row['total'])
            + ' | '
            + (
                'low-point cut '
                if row['role'] == 'column'
                else 'long-point blank '
                if row['role'] == 'rafter'
                else 'detail '
            )
            + row['cut'],
            10,
        )
    c.ptext(
        110,
        733,
        (
            'Post footings '
            + fnd.get('hole_diameter', '')
            + ' DIA x '
            + fnd.get('hole_depth', '')
            + ' DEEP: column cuts include the embedment below the floor datum; no base plates.'
        )
        if below
        else 'Base elevation and base plate are deducted separately from the steel cut length.',
        8,
    )
    if l['clip_warnings']:
        c.ptext(
            110,
            750,
            str(len(l['clip_warnings']))
            + ' clip clearance warning(s) under 3 in: see the clearance schedule on the ridge detail.',
            8,
            style=S_NOTE,
        )
    from ..layout_options import draw_starting

    draw_starting(c, a, l)
    _footer(c, job, job.revision(), 'direct-depth datum; pitch cuts are NOT weld-preparation bevels')
    return sh


def connection_sheet(job, p, qty, peak_detail=False):
    if peak_detail:
        import copy

        p = copy.deepcopy(p)
        fid = p.symbol['config']['frame_id']
        layout = job.settings['frame_layouts'][fid]
        peak = layout.get('peak_clip')
        if peak:
            theta = math.radians(p.symbol['pitch_deg'])
            co = math.cos(theta)
            sn = math.sin(theta)
            edge = peak['actual_edge_in']
            t = peak['thickness_in']
            p.symbol['beam_preview_length'] = max(8, edge + 6)
            if peak['support'] != 'apex':
                z0 = 0 if peak['mode'] == 'bypass' else -peak['web_center_in'] - peak['web_height_in'] / 2
                z1 = peak['height_in'] if peak['mode'] == 'bypass' else z0 + peak['web_height_in']
                for sign in (-1, 1):
                    p.symbol['roof_clips'].append(
                        dict(
                            role='peak',
                            part=peak['part'],
                            quantity=1,
                            corners=[
                                (
                                    sign * (s * co + z * sn),
                                    p.symbol['h'] - p.symbol.get('top_extension_in', 0) - s * sn + z * co,
                                )
                                for s, z in [(edge, z0), (edge + t, z0), (edge + t, z1), (edge, z1)]
                            ],
                        )
                    )
    fid = p.symbol['config']['frame_id']
    sh, c = header(job, p.mark, 'connection', qty, fid)
    c.ptext(
        110,
        92,
        (
            'Finished apex bottom: '
            + q(p.symbol['bottom_length_in']).fmt()
            + ' HALF / '
            + q(2 * p.symbol['bottom_length_in']).fmt()
            + ' TOTAL.'
            if p.symbol['ridge_type'] == 'welded_box'
            else 'BUTT JOINT: rafters meet on the centre line; 3/16 x 5 x 7 splice plate welded to the channel face EACH SIDE.'
            if p.symbol.get('ridge_joint') == 'face_splice'
            else 'Single SHARED ridge plate: actual plumb pitch-cut depth +1in; extends1/2in ABOVE and1/2in BELOW cut.'
        ),
        9,
    )
    c.ptext(
        110,
        73,
        'Welded ridge: face splice plates, one each side of the open-face rafters; plumb cuts both rafters. NO BOLT HOLES.'
        if p.symbol.get('ridge_joint') == 'face_splice'
        else 'Welded ridge:1/2in plate(s), flange width; shared plate extends beyond actual plumb rafter cut. NO BOLT HOLES.',
        10,
    )
    from .connection_views import bounds, draw_side, side_geometry

    b = bounds(side_geometry(job, p, True))
    scale = min(15, 880 / (b[2] - b[0]), 330 / (b[3] - b[1] + 3))
    v = View(612 - (b[0] + b[2]) / 2 * scale, 475 + b[1] * scale, scale, scale)
    draw_side(Canvas(sh, v), job, p, True)
    if p.symbol.get('ridge_joint') == 'face_splice':
        H = p.symbol['h']
        c.dim_v(v.py(0), v.py(H), v.px(3.5), v.px(3.5), v.px(3.5) + 235, f'{H:.3f} IN PLATE HEIGHT', size=9)
        c.ptext(735, 505, '7 in long plate centred on the joint; centred on the plumb rafter depth', 9)
    elif p.symbol['ridge_type'] == 'fully_welded':
        H = p.symbol['h']
        c.dim_v(v.py(0), v.py(H), v.px(0.25), v.px(0.25), v.px(0.25) + 235, f'{H:.6f} IN CALCULATED LENGTH', size=9)
        c.ptext(735, 505, 'Actual plumb cut ' + f'{H - 1:.6f}' + 'in + .500in ABOVE + .500in BELOW', 9)
    _bom_table(c, connection_bom(job, p.mark))
    if peak_detail and job.settings['frame_layouts'][fid].get('peak_clip'):
        peak = job.settings['frame_layouts'][fid]['peak_clip']
        c.ptext(
            110,
            108,
            'PEAK near edge '
            + q(peak['input_edge_in']).fmt()
            + ' ALONG SLOPE; support: '
            + peak['support']
            + '. Rafter-owned clips excluded from ridge BOM.',
            9,
        )
    c.ptext(
        110,
        535,
        'Plates weld directly to rafter. Welding procedure, effective lengths and capacity require approval.',
        9,
        style=S_NOTE,
    )
    for i, w in enumerate(job.settings['frame_layouts'][fid].get('clip_warnings', [])[:2]):
        c.ptext(110, 557 + i * 14, 'WARNING: ' + w, 8, style=S_NOTE)
    _footer(c, job, job.revision(), 'welded ridge; same model drives BOM and hole-free plate contours')
    return sh


def ridge_sheet(job, fid):
    if job.settings['frame_layouts'][fid].get('ridge_joint') == 'cut_and_fold':
        return fold_ridge_sheet(job, fid)
    sh = connection_sheet(job, job.part('AP-' + fid), job.settings['frames'][fid]['frames'], True)
    sh.name = 'RIDGE-' + fid
    sh.kind = 'ridge'
    return sh


def _break(c, x, y0, y1, half=3.0):
    """Zig-zag break symbol on a vertical edge (model coordinates)."""
    ym = (y0 + y1) / 2
    c.poly(
        [(x, y0), (x, ym - half), (x - half, ym - half / 2), (x + half, ym + half / 2), (x, ym + half), (x, y1)], False
    )


def fold_ridge_sheet(job, fid):
    """One-piece cut-and-fold W rafter: folded ridge, the wedge on the flat blank and the shop numbers."""
    l = job.settings['frame_layouts'][fid]
    fr = l['ridge_fold']
    raf = job.assemblies[l['rafters'][0]['mark']]
    sec = raf.main.sec
    d = sec.d
    tf = sec.tf or 0.0
    theta = math.radians(fr['pitch_deg'])
    co, sn = math.cos(theta), math.sin(theta)
    h = fr['wedge_half_in']
    Hw = fr['wedge_depth_in']
    overall = f(raf.main.cut_length)
    leg = q(fr['leg_bottom_in']).fmt()
    sh, c = header(job, 'RIDGE-' + fid, 'ridge', l['frames'], fid)
    sh.meta['ridge_fold'] = fr
    c.ptext(110, 73, 'A — FULLY WELDED / ONE-PIECE CUT-AND-FOLD RAFTER (NO RIDGE PLATE)', 11, bold=True)
    c.ptext(
        110,
        94,
        'Rafter '
        + raf.mark
        + ' '
        + sec.name
        + ' is ONE shop piece per frame: blank '
        + raf.main.cut_length.fmt()
        + ' long point to long point, both knee cuts plumb (long point at the bottom flange).',
        10,
    )
    c.ptext(
        110,
        114,
        'Cut a wedge '
        + q(2 * h).fmt()
        + ' wide at the bottom flange (2 x '
        + q(d).fmt()
        + ' depth x tan of '
        + l['slope_rise']
        + ':12), apex at the underside of the top flange, out of the bottom flange and the web; fold the rafter on the'
        ' top flange to the pitch and weld the seam full depth both sides.',
        10,
    )
    # ---- folded ridge, local coordinates: ridge top point at (0, 0)
    Lp = 30.0
    scale = min(420 / (2 * Lp * co), 120 / (Lp * sn + d / co))
    v = View(330, 290, scale, scale)
    a = Canvas(sh, v)
    c.ptext(110, 180, 'FOLDED RIDGE  (pitch ' + l['slope_rise'] + ':12)', 10, bold=True)
    for sign in (-1, 1):
        a.poly([(sign * -Lp * co, -Lp * sn), (0, 0), (0, -d / co), (sign * -Lp * co, -Lp * sn - d / co)])
        a.line(sign * -Lp * co, -Lp * sn - tf / co, 0, -tf / co, S_OBJ)
        a.line(sign * -Lp * co, -Lp * sn - d / co + tf / co, 0, -d / co + tf / co, S_OBJ)
    a.line(0, -tf / co, 0, -d / co, S_OBJ)
    for k in range(1, 5):
        a.weld_tick(0, -tf / co - k * (d / co - tf / co) / 5, vertical=False)
    tip = v.p(0, -d / 2 / co)
    c.leader(
        (tip[0] + 3, tip[1]), [(tip[0] + 60, tip[1] + 40)], 'SEAM: WEB + BOTTOM FLANGE WELDED FULL DEPTH, BOTH SIDES', 9
    )
    tip = v.p(0, 0)
    c.leader(
        (tip[0], tip[1] - 2),
        [(tip[0] - 40, tip[1] - 36)],
        'TOP FLANGE CONTINUOUS - FOLDED TO PITCH, NOT CUT',
        9,
        anchor='end',
    )
    a.line(0, -d / co - 6, 0, 8, S_CL)
    a.text(0, 10, 'RIDGE C.L.', 8, 0, 'middle')
    # ---- flat blank at the wedge, local coordinates: wedge apex x = 0, bottom of blank y = 0
    Lb = 30.0
    scale2 = min(420 / (2 * Lb), 90 / d)
    v2 = View(330, 560, scale2, scale2)
    b = Canvas(sh, v2)
    c.ptext(
        110, 450, 'FLAT BLANK AT THE RIDGE  (before the fold; break lines, see the full blank below)', 10, bold=True
    )
    b.poly([(-Lb, 0), (-h, 0), (0, Hw), (h, 0), (Lb, 0), (Lb, d), (-Lb, d)], False)
    _break(b, -Lb, 0, d)
    _break(b, Lb, 0, d)
    b.line(-Lb, d - tf, Lb, d - tf, S_OBJ)
    xt = -h + h * tf / Hw if Hw > 0 else -h
    b.line(-Lb, tf, xt, tf, S_OBJ)
    b.line(-xt, tf, Lb, tf, S_OBJ)
    n = 8
    for i in range(1, n):
        y = Hw * i / n
        xr = h * (1 - y / Hw)
        b.line(-xr, y, xr, y, S_HID)
    b.line(0, -6, 0, d + 6, S_CL)
    c.dim_h(
        v2.px(-h),
        v2.px(h),
        v2.py(0),
        v2.py(0),
        v2.py(0) + 22,
        'WEDGE ' + q(2 * h).fmt() + ' AT BOTTOM FLANGE',
        text_above=False,
    )
    c.dim_h(v2.px(-Lb), v2.px(-h), v2.py(d), v2.py(d), v2.py(d) - 12, 'KNEE CUT (BOTTOM) TO WEDGE ' + leg, 8)
    c.dim_h(v2.px(h), v2.px(Lb), v2.py(d), v2.py(d), v2.py(d) - 12, 'WEDGE TO KNEE CUT (BOTTOM) ' + leg, 8)
    tip = v2.p(0, Hw / 2)
    c.leader(
        (tip[0], tip[1]), [(tip[0] + 50, tip[1] - 24)], 'CUT OUT: BOTTOM FLANGE + WEB - DO NOT CUT THE TOP FLANGE', 9
    )
    c.ptext(
        tip[0] + 50,
        tip[1] - 12,
        'APEX AT THE UNDERSIDE OF THE TOP FLANGE, ' + q(Hw).fmt() + ' FROM THE BOTTOM FLANGE FACE',
        9,
    )
    # ---- whole blank, small
    scale3 = 760 / overall
    v3 = View(120, 700, scale3, scale3)
    g = Canvas(sh, v3)
    kx = fr['knee_long_point_in']
    cx = overall / 2
    g.poly([(0, 0), (cx - h, 0), (cx, Hw), (cx + h, 0), (overall, 0), (overall - kx, d), (kx, d)])
    c.dim_h(
        v3.px(0),
        v3.px(overall),
        v3.py(0),
        v3.py(0),
        v3.py(0) + 20,
        'BLANK ' + raf.main.cut_length.fmt() + ' LONG POINT TO LONG POINT',
        text_above=False,
    )
    c.dim_h(v3.px(0), v3.px(cx - h), v3.py(d), v3.py(d), v3.py(d) - 12, leg)
    c.dim_h(v3.px(cx + h), v3.px(overall), v3.py(d), v3.py(d), v3.py(d) - 12, leg)
    g.text(cx, d + 14, 'WEDGE ' + q(2 * h).fmt() + ' (included in the blank)', 8, 0, 'middle')
    g.text(0, d + 14, raf.mark + ' x ' + str(raf.qty) + '  ' + sec.name, 8, 0, 'start')
    # ---- numbers
    x0 = 790
    rows = [
        ('Blank, long point to long point', raf.main.cut_length.fmt()),
        ('Each leg, bottom of knee cut to bottom of wedge', leg),
        ('Wedge at the bottom flange (2 x depth x tan pitch)', q(2 * h).fmt()),
        ('Wedge depth to the underside of the top flange', q(Hw).fmt()),
        ('Top flange, continuous (2 x top line)', q(2 * fr['leg_top_in']).fmt()),
        ('Knee cut: plumb, top corner inside the long point', q(kx).fmt()),
        ('Rafter plumb depth', q(d / co).fmt()),
        ('Pieces', str(raf.qty) + ' (one per frame)'),
    ]
    c.ptext(x0, 150, 'SHOP NUMBERS', 10, bold=True)
    for i, (k, val) in enumerate(rows):
        c.ptext(x0, 170 + i * 16, k, 9)
        c.ptext(x0 + 330, 170 + i * 16, val, 9, anchor='end', bold=True)
    c.ptext(
        x0, 320, 'Purlin clips on both legs are stationed from the LEFT long point on the ' + raf.mark + ' sheet;', 9
    )
    c.ptext(x0, 334, 'the right leg carries the mirror image of the left leg.', 9)
    c.ptext(x0, 360, 'The wedge is the cut loss: it is already included in the blank length. No ridge plate,', 9)
    c.ptext(
        x0, 374, 'no ridge bolts. Grind the weld flush under the peak purlin clips only if a clip lands on the seam.', 9
    )
    _footer(c, job, job.revision(), 'one-piece cut-and-fold rafter; wedge included in the blank length')
    return sh


def eave_sheet(job, fid):
    if job.settings['frame_layouts'][fid].get('welded_knee') == 'inside_flange':
        from .inside_knee_sheet import sheet, side_welded_sheet

        if job.settings['frame_layouts'][fid].get('knee_records'):
            return sheet(job, fid)
        return side_welded_sheet(job, fid)
    l = job.settings['frame_layouts'][fid]
    p = job.settings['frames'][fid]
    col = l['columns'][0]
    roof = l['rafters'][0]
    sec = job.assemblies[roof['mark']].main.sec
    d = sec.d
    sh, c = header(job, 'EAVE-' + fid, 'welded_eave', l['frames'] * (1 if l['frame_type'] == 'monoslope' else 2), fid)
    c.ptext(
        110, 73, 'WELDED EAVE — rafter plumb at outside column face; column top cut to pitch; eave clip retained.', 10
    )
    c.ptext(
        110,
        94,
        '3/16 cover plate TOP FLUSH with rafter; width '
        + q(sec.bf).fmt()
        + '; extension '
        + p['eave_plate_extension']
        + ' below rafter.',
        10,
    )
    m = float(l['slope_rise']) / 12
    co = roof['direction'][0]
    cd = col['x1'] - col['x0']
    v = View(320, 270, 12, 12)
    a = Canvas(sh, v)
    # Local origin = rafter top at the outside column face.
    a.poly([(0, -d / co - 14), (cd, -d / co - 14), (cd, -d / co + cd * m), (0, -d / co)])
    a.poly([(0, 0), (cd + 8, (cd + 8) * m), (cd + 8, (cd + 8) * m - d / co), (0, -d / co)])
    for z in (sec.tf, sec.d - sec.tf) if sec.tf is not None else ():
        a.line(0, -z / co, cd + 8, (cd + 8) * m - z / co)
    csec = job.assemblies[col['mark']].main.sec
    for x in (csec.tf, cd - csec.tf) if csec.tf is not None else ():
        a.line(x, -d / co - 14, x, -d / co + x * m)
    ep = job.part(l['eave_plate'])
    a.rect(-f(ep.thk), -f(ep.length), 0, 0, S_NOTE)
    if p['eave_start_clip']:
        cp = job.part(p.get('eave_clip') or p['purlin_clip'])
        t = f(cp.thk)
        h = f(cp.length)
        z0 = 0 if p['purlin_mode'] == 'bypass' else -f(p['purlin_web_y']) - f(cp.width) / 2
        z1 = h if p['purlin_mode'] == 'bypass' else z0 + f(cp.width)
        a.poly([(s, s * m + z) for s, z in [(0, z0), (t, z0), (t, z1), (0, z1)]], style=S_NOTE)
        a.text(0, z1 + 2, 'EAVE ' + cp.mark, 9)
    c.dim_v(v.py(-d / co), v.py(0), v.px(0), v.px(0), 230, q(d / co).fmt() + ' PLUMB RAFTER', size=9)
    c.dim_v(v.py(-f(ep.length)), v.py(-d / co), v.px(0), v.px(0), 180, p['eave_plate_extension'] + ' EXTENSION', size=9)
    c.ptext(735, 168, 'FLOOR-REFERENCED DATUMS', 11, bold=True)
    low = col['y1']
    for i, (label, value) in enumerate(
        [
            ('Column LOW side', low),
            ('Rafter top at column', low + d / co),
            ('Top purlin at column', low + d / co + l['strut_depth_in']),
            ('Eave at outside wall', l['low_eave_in']),
        ]
    ):
        c.ptext(735, 197 + i * 24, label + ': ' + q(value).fmt(), 10)
    c.ptext(735, 311, 'Inset from fixed outside wall: ' + q(l['inset_in']).fmt(), 10)
    c.ptext(
        110,
        660,
        'Column cut height includes actual PLUMB rafter depth. Rafter and retained top clip are PLUMB; eave datum unchanged.',
        9,
        style=S_NOTE,
    )
    c.ptext(
        110,
        679,
        f'Applied column correction d(sec(pitch)-1) = {l.get("nominal_depth_correction_in", 0):.6f}in. Theoretical contact closes; cut rounding listed separately.',
        9,
        style=S_NOTE,
    )
    c.ptext(
        110,
        698,
        'Plate extension is below the ACTUAL plumb rafter underside. No connection bolts; base anchorage remains as specified separately.',
        9,
    )
    _footer(c, job, job.revision(), 'welded eave detail; no automatic projected-depth substitution')
    return sh
