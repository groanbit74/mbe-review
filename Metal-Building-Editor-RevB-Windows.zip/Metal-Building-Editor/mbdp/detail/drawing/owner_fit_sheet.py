"""Owner fit rules: lean roof run plan and slip-in door interface review."""

from ..cladding import fmt
from .canvas import S_HID, S_NOTE, S_TABLE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _title_block

BLUE = Style(width=1.0)  # black, set style (owner 0.8.55: no blue/red abstract sheets)
RED = Style(width=0.7, dash=(4, 2))


def sheet(job, fid, kind, index, page=1):
    model = job.assemblies[fid].derivation['framing_additions']
    sh = Sheet(fid + '~' + kind + '~' + str(index) + '~' + str(page), 'additions')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, 1, kind.upper(), fid, job.date)
    if kind == 'lean_purlins':
        z = model['lean_tos'][index]
        m = z['roof_purlin_layout']
        L = z['length_in']
        P = z['projection_in']
        start = z['start_in']
        c.ptext(110, 60, z['id'] + ' / LEAN ROOF PURLINS — PLAN + CUT LIST', 17, bold=True)
        c.ptext(110, 88, m['end_rule'], 10, style=S_NOTE)
        c.ptext(
            110,
            109,
            'ONE lean only; shared main-eave row counted in main building. Spacing along slope '
            + fmt(m['spacing_along_in'])
            + ' (planning, not capacity).',
            9,
        )
        v = View(270, 356, 650 / L, 198 / P)
        a = Canvas(sh, v)
        for st in z['stations']:
            x = st['x_in'] - start
            a.line(x, 0, x, P, S_HID)
            a.text(x, -12, fmt(st['x_in']), 8, anchor='middle')
        for row in m['rows']:
            y = row['horizontal_out_in']
            a.line(0, y, L, y, BLUE if not row['shared_main_eave'] else S_HID)
            a.text(-8, y, ('SHARED' if row['shared_main_eave'] else row['mark']), 8, anchor='end')
            a.text(L + 8, y, fmt(row['along_slope_in']) + ' ALONG', 8)
        for rc in z.get('roof_clip_schedule', []):
            row = next(r for r in m['rows'] if r['mark'] == rc['row'])
            px = v.px(rc['station_in'] - start)
            py = v.py(row['horizontal_out_in'])
            for off in [-4, 4] if rc['quantity'] == 2 else [0]:
                c.prect(
                    px + off - 2, py - 3, px + off + 2, py + 3, S_HID if rc.get('shared_low_connection') else S_NOTE
                )
        c.ptext(270, 382, 'MAIN EAVE = SHARED ROW0; rows progress outward to LOW EAVE.', 8)
        _mixed_fit = m.get('mixed_support_fit')
        _all_channel = m.get('in_channel')
        _purlin_end_rule = (
            'At special open-C end lines: purlins are flush in the channel, 1/4 in from the web and welded to the flanges. W supports use their per-line bypass/flush rule; no lap is inferred.'
            if _mixed_fit
            else 'At channel supports: purlins are 1/4 in from the channel web and welded to the flanges; no lap is inferred.'
            if _all_channel
            else 'At ends: flush to end-rafter OUTSIDE edge. At interior supports: butt at CENTER, zero end gap. No overlap/lap inferred.'
        )
        c.ptext(110, 395, _purlin_end_rule, 9)
        heads = ['MARK', 'SECTION', 'START / END', 'CUT', 'QTY']
        xs = [110, 340, 610, 830, 960, 1120]
        top = 422
        rows = [heads] + [
            [
                r['mark'],
                r['profile_id'],
                fmt(r['start_in']) + ' / ' + fmt(r['end_in']),
                r['cut_length'],
                str(r['quantity']),
            ]
            for r in m['pieces'][(page - 1) * 12 : page * 12]
        ]
        for i, row in enumerate(rows):
            y = top + i * 19
            c.pline(xs[0], y, xs[-1], y, S_TABLE)
            for x, t in zip(xs, row):
                c.ptext(x + 4, y + 13, t, 8, bold=i == 0)
        if z.get('roof_clip_schedule'):
            c.ptext(
                110,
                648,
                'Roof clips:1 end /2 interior per new RAFTER row. Added '
                + str(sum(r['quantity'] for r in z['roof_clip_schedule']))
                + ' solid clips; LOW row references3 retained start clips; high row shared.',
                9,
            )
            c.ptext(
                110,
                671,
                'Low row mounts at column/cap, others at rafters. Blank/mount schedule: lean_roof_clips.csv. Account for actual top-plate stack-up when fitting.',
                9,
                style=S_NOTE,
            )
        c.ptext(
            110,
            701,
            'Full purlin piece data: lean_roof_purlins.csv. Weld procedure, clip contact fit and lateral stability require field/design review.',
            9,
            style=S_NOTE,
        )
    else:
        o = model['openings'][index]
        d = o['walk_slip_fit']
        pr = o['section']
        depth = pr['depth']
        flange = pr['width']
        c.ptext(110, 60, o['id'] + ' / WALK-DOOR SLIP-IN FRAME', 17, bold=True)
        c.ptext(
            110,
            89,
            'DOWNWARD-FACING GIRT; frame outside TOP is1/2in below WEB UNDERSIDE — INSIDE the girt',
            11,
            bold=True,
        )
        c.ptext(
            110,
            115,
            'Clear opening remains '
            + fmt(o['width_in'])
            + ' x '
            + fmt(o['height_in'])
            + '. Door frame is a complete assembly, not extra shop jamb pieces.',
            10,
        )
        v = View(250, 255, 38, 38)
        a = Canvas(sh, v)
        a.poly([(0, -flange), (0, 0), (depth, 0), (depth, -flange)], closed=False, style=BLUE)
        a.poly([(1, -4), (1, -0.5), (depth - 1, -0.5), (depth - 1, -4)], closed=False, style=RED)
        a.line(depth, 0, depth + 2, 0, S_HID)
        a.line(depth - 1, -0.5, depth + 2, -0.5, S_HID)
        c.dim_v(v.py(-0.5), v.py(0), v.px(depth), v.px(depth), v.px(depth + 2), '1/2" INSIDE GAP', size=10)
        c.ptext(680, 215, 'SOLID: girt web + DOWN flanges', 10)
        c.ptext(680, 242, 'DASHED: door-frame outline (SCHEMATIC)', 10)
        c.ptext(
            680,
            271,
            ('Frame outside: ' + fmt(d['door_frame_outside_width_in']) + ' x ' + fmt(d['door_frame_outside_height_in']))
            if d.get('door_frame_outside_width_in') is not None
            else 'Frame sections / outer dimensions not inferred.',
            9,
            style=S_NOTE,
        )
        c.ptext(680, 300, 'Not a gap beneath the flange tips.', 10, bold=True)
        c.ptext(110, 439, 'Shared girt: ' + (d['girt_member_ref'] or 'NOT FOUND / HOLD'), 11, bold=True)
        c.ptext(
            110,
            465,
            'Girt web setout / reference station: '
            + (fmt(d['girt_station_in']) if d['girt_station_in'] is not None else 'PENDING')
            + '; this is NOT automatically the physical web underside.',
            9,
        )
        c.ptext(
            110,
            491,
            'Girt WEB UNDERSIDE above floor: '
            + (
                fmt(d['girt_web_underside_in'])
                if d['girt_web_underside_in'] is not None
                else 'NOT SUPPLIED / ABSOLUTE VERTICAL FIT HELD'
            ),
            10,
            style=S_NOTE,
        )
        c.ptext(
            110,
            517,
            'Frame OUTSIDE TOP above floor: '
            + (
                fmt(d['door_frame_outside_top_in'])
                if d['door_frame_outside_top_in'] is not None
                else 'underside datum minus1/2in; exact elevation held'
            ),
            10,
        )
        entry = job.settings['frames'][fid]['additions']['opening_members'][o['id']].get('girt_insertion', '0')
        if d.get('girt_flange_tip_in') is not None:
            c.ptext(680, 325, 'Girt lower flange tips: ' + fmt(d['girt_flange_tip_in']) + ' above floor', 10)
        c.ptext(
            110,
            558,
            'Lower girts: selected insertion '
            + fmt(float(entry))
            + ' INTO jamb, not stand-off. Entry orientation/thickness fit remains checked separately.',
            9,
        )
        c.ptext(
            110,
            589,
            'Column-web weld clips: LONG edge parallel to column web; SHORT edge projects. Roof clips are not rotated by this rule.',
            9,
        )
        c.ptext(
            110,
            624,
            'No second header counted: the wall girt is shared. Door-frame fabrication / procurement details remain separately identified.',
            9,
        )
        c.ptext(
            110,
            689,
            (
                'Owner head / jamb faces supplied; no gauge-to-steel-thickness conversion or capacity inferred.'
                if d.get('frame_head_face_in') is not None
                else 'Dimensional relationship is confirmed. Do not infer frame head thickness, gauge-to-thickness, or support elevation from this schematic.'
            ),
            9,
            style=S_NOTE,
        )
    _footer(
        c,
        job,
        job.revision(),
        'owner fit rules / coordinated lengths and quantities; NOT a fabrication or capacity release',
    )
    return sh
