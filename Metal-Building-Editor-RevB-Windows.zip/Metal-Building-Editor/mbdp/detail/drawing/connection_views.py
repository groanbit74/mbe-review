"""Shared, uniformly scaled installed geometry and aligned plate/beam face views."""

import math

from ..connections import f
from .canvas import S_CL, S_HID, S_HOLE, S_NOTE, S_OBJ, S_PLATE


def side_geometry(job, p, beam=True, column=False, clips=True):
    if p.symbol.get('welded'):
        from .welded_sheet import ridge_geometry

        return ridge_geometry(job, p, beam, clips)
    s = p.symbol
    cfg = s['config']
    theta = math.radians(s['pitch_deg'])
    co, sn = math.cos(theta), math.sin(theta)
    sg = 1 if cfg['kind'] == 'low' else -1
    u = (co, sg * sn)
    n = (-sg * sn, co)
    B = s['bottom_length_in']
    t = f(cfg['flange_thk'])
    P = s['plate_bottom_xy']
    E = s['rafter_top_xy']
    h = s['h']
    ep = job.part(p.mark + '-END')
    et = f(ep.thk)
    L = f(ep.length)
    poly = []
    lines = []

    def add(role, pts, style=S_OBJ):
        poly.append((role, pts, style))

    def translated(pt, along=0, normal=0):
        return (pt[0] + along * u[0] + normal * n[0], pt[1] + along * u[1] + normal * n[1])

    apex = cfg['kind'] == 'apex'
    ext = f(cfg['top_extension']) if cfg['kind'] == 'low' else 0
    T = (-ext * co, h - ext * sg * sn)
    top = [T, E, translated(E, normal=-t), translated(T, normal=-t)]
    by = s.get('bottom_y_in', 0)
    add('bottom', [(-B if apex else 0, by), (B, by), (B, by + t), (-B if apex else 0, by + t)])
    add('web', s['web_outline'])
    add('top', top)
    if apex:
        add('top-left', [(-x, y) for x, y in top])
    else:
        add('back', [(0, t), (t, t), (t, t + s['back_height_in']), (0, t + s['back_height_in'])])
    for offset, name in [(0, 'END'), (et, 'MATE')]:
        points = [
            translated(P, offset),
            translated(P, offset, L),
            translated(P, offset + et, L),
            translated(P, offset + et),
        ]
        add(name, points, S_PLATE)
        if apex:
            add(name + '-left', [(-x, y) for x, y in points], S_PLATE)
    for row in sorted({f(h.x) for h in ep.holes}):
        a = translated(P, -0.35, row)
        b = translated(P, 2 * et + 0.35, row)
        lines.append(('hole-row', a, b, S_CL))
        if apex:
            lines.append(('hole-row-left', (-a[0], a[1]), (-b[0], b[1]), S_CL))
    if beam:
        sec = job.assemblies[cfg['rafter']].main.sec
        for normal in (0, -sec.tf, -sec.d + sec.tf, -sec.d):
            a = translated(E, 2 * et, normal)
            b = translated(E, 2 * et + 8, normal)
            lines.append(('beam', a, b, S_OBJ))
            if apex:
                lines.append(('beam-left', (-a[0], a[1]), (-b[0], b[1]), S_OBJ))
    if column and not apex:
        d = s['column_depth']
        tf = job.assemblies[cfg['column']].main.sec.tf
        add('column', [(0, -4), (d, -4), (d, 0), (0, 0)])
        for x in (tf, d - tf) if tf is not None else ():
            lines.append(('column-flange', (x, -4), (x, 0), S_OBJ))
    if clips:
        for rec in s.get('roof_clips', []):
            add(rec['role'] + ' clip', rec['corners'], S_NOTE)
    return poly, lines


def bounds(geometry):
    poly, lines = geometry
    points = [pt for _, pts, _ in poly for pt in pts] + [pt for _, a, b, _ in lines for pt in (a, b)]
    return min(x for x, y in points), min(y for x, y in points), max(x for x, y in points), max(y for x, y in points)


def draw_side(c, job, p, beam=True, column=False, transform=lambda x, y: (x, y), clips=True):
    geometry = side_geometry(job, p, beam, column, clips)
    for role, pts, style in geometry[0]:
        c.poly([transform(x, y) for x, y in pts], style=style)
    for role, a, b, style in geometry[1]:
        c.line(*transform(*a), *transform(*b), style)
    if clips:
        for rec in p.symbol.get('roof_clips', []):
            pts = rec['corners']
            x = (pts[2][0] + pts[3][0]) / 2
            y = max(pt[1] for pt in pts) + 1.5
            c.text(
                *transform(x, y),
                rec['role'].upper() + ' ' + rec['part'] + (' (2)' if rec['quantity'] == 2 else ''),
                7,
                0,
                'middle',
            )
    return geometry


def draw_aligned_face(c, job, p):
    """Looking normal to END/MATE: true hole centers and rafter I-section overlay."""
    ep = job.part(p.mark + '-END')
    L, W = f(ep.length), f(ep.width)
    c.rect(0, 0, W, L, S_PLATE)
    sec = job.assemblies[p.symbol['config']['rafter']].main.sec
    y = (L - sec.d) / 2
    x = (W - sec.bf) / 2
    # dashed beam outline behind the plate; coordinates share its physical datum.
    for box in [
        (x, y, x + sec.bf, y + sec.tf),
        (x, y + sec.d - sec.tf, x + sec.bf, y + sec.d),
        ((W - sec.tw) / 2, y + sec.tf, (W + sec.tw) / 2, y + sec.d - sec.tf),
    ]:
        c.rect(*box, S_HID)
    for hole in ep.holes:
        X, Y = f(hole.y), f(hole.x)
        c.circle(X, Y, f(hole.dia) / 2, S_HOLE)
        c.line(X - 0.3, Y, X + 0.3, Y, S_CL)
        c.line(X, Y - 0.3, X, Y + 0.3, S_CL)
    return W, L
