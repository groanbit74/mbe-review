"""One dimensioned building datum plan, not a foundation or framing design."""

from ..cladding import fmt
from .canvas import S_HID, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _mark_header, _title_block


def building_sheet(job, fid):
    l = job.settings['frame_layouts'][fid]
    g = l['building_geometry']
    W = g['width_in']
    L = g['length_in']
    sh = Sheet('BUILDING-' + fid, 'building')
    c = Canvas(sh)
    _border(c)
    _mark_header(c, 'BUILDING-' + fid, 'MASTER GEOMETRY')
    _title_block(c, job, 1, 'BUILDING', fid, job.date)
    c.ptext(110, 75, 'ONE BUILDING / MASTER GEOMETRY AND ORIENTATION', 12, bold=True)
    c.ptext(
        110,
        98,
        'WIDTH '
        + fmt(W)
        + ' | LENGTH '
        + fmt(L)
        + ' | LOW EAVE '
        + fmt(g['low_eave_height_in'])
        + ' | PITCH '
        + str(g['pitch_rise'])
        + ':12 | '
        + g['shape'].upper(),
        10,
    )
    footprints = []
    for lean in l.get('framing_additions', {}).get('lean_tos', []):
        u = lean['start_in']
        end = u + lean['length_in']
        P = lean['projection_in']
        side = lean['face']
        box = (
            (u, -P, end, 0)
            if side == 'right'
            else (L - end, W, L - u, W + P)
            if side == 'left'
            else (-P, W - end, 0, W - u)
            if side == 'front'
            else (L, u, L + P, end)
        )
        footprints.append((lean, box))
    xmin = min([0] + [b[0] for _, b in footprints])
    xmax = max([L] + [b[2] for _, b in footprints])
    ymin = min([0] + [b[1] for _, b in footprints])
    ymax = max([W] + [b[3] for _, b in footprints])
    scale = min(980 / (xmax - xmin), 470 / (ymax - ymin))
    v = View(100 + (980 - (xmax - xmin) * scale) / 2 - xmin * scale, 600 + ymin * scale, scale, scale)
    a = Canvas(sh, v)
    a.rect(0, 0, L, W)
    for lean, b in footprints:
        a.rect(*b, Style(fill=(0.93, 0.97, 1), color=(0.15, 0.35, 0.6), width=1))
        a.text(
            (b[0] + b[2]) / 2,
            (b[1] + b[3]) / 2,
            lean['id'] + ' LEAN-TO',
            8,
            90 if lean['face'] in ('front', 'rear') else 0,
            'middle',
        )
        for station in lean['stations']:
            u = station['x_in']
            side = lean['face']
            if side == 'right':
                a.line(u, 0, u, b[1], S_HID)
            elif side == 'left':
                a.line(L - u, W, L - u, b[3], S_HID)
            elif side == 'front':
                a.line(0, W - u, b[0], W - u, S_HID)
            else:
                a.line(L, u, b[2], u, S_HID)
    zones = l.get('bay_zones', {})
    junction = zones.get('enclosed_left_station_in', 0)
    if zones:
        ss = zones['stations_in']
        for i, bay in enumerate(zones['bays']):
            a.text((ss[i] + ss[i + 1]) / 2, W * 0.7, bay['id'] + ' / ' + fmt(ss[i + 1] - ss[i]), 8, anchor='middle')
            a.text(
                (ss[i] + ss[i + 1]) / 2,
                W * 0.25,
                ('ENCLOSED' if bay['left'] == bay['right'] == 'sheeted' else 'ROOF / ' + bay['right'].upper()),
                8,
                anchor='middle',
            )
        a.line(junction, 0, junction, W, Style(width=2, color=(0.2, 0.45, 0.3)))
        a.text(junction, W + 10, 'ENCLOSED JUNCTION', 8, anchor='middle')
    runs = l.get('secondary_runs', {})
    for line in runs.get('support_lines', []):
        x = line['station_in']
        a.line(x, 0, x, W, S_HID)
        if len(runs['support_lines']) <= 20:
            a.text(x, W / 2, str(line['line']), 8, anchor='middle')
    if g['shape'] == 'gable':
        a.line(0, W / 2, L, W / 2, S_HID)
    c.ptext(
        v.px(L / 2),
        v.py(W) + (15 if any(z['face'] == 'left' for z, b in footprints) else -24),
        'BACK SIDEWALL / EAVE' + (' - LOW' if g['shape'] == 'monoslope' else ''),
        10,
        anchor='middle',
        bold=True,
    )
    c.ptext(
        v.px(L / 2),
        v.py(0) + (-15 if any(z['face'] == 'right' for z, b in footprints) else 25),
        'FRONT SIDEWALL / EAVE' + (' - HIGH' if g['shape'] == 'monoslope' else ''),
        10,
        anchor='middle',
        bold=True,
    )
    c.ptext(
        v.px(0) + (15 if any(z['face'] == 'front' for z, b in footprints) else -25),
        v.py(W / 2),
        'OUTER ROOF-ONLY END' if zones and junction else 'LEFT ENDWALL',
        10,
        rot=90,
        anchor='middle',
        bold=True,
    )
    c.ptext(
        v.px(L) + (-15 if any(z['face'] == 'rear' for z, b in footprints) else 25),
        v.py(W / 2),
        'RIGHT ENDWALL',
        10,
        rot=90,
        anchor='middle',
        bold=True,
    )
    # Project openings to wall edges. Stable IDs retain the v080 physical locations.
    for o in l.get('cladding', {}).get('config', {}).get('openings', []):
        u = o['x_in']
        w = o['width_in']
        side = o['surface']
        st = Style(layer='OPENING_PLAN', width=3, color=(0.7, 0.15, 0.1))
        if side == 'right':
            a.line(u, 0, u + w, 0, st)
        elif side == 'left':
            a.line(L - u - w, W, L - u, W, st)
        elif side == 'front':
            a.line(junction, W - u - w, junction, W - u, st)
        elif side == 'rear':
            a.line(L, u, L, u + w, st)
    c.dim_h(v.px(0), v.px(L), v.py(0), v.py(0), 545, fmt(L) + ' MASTER LENGTH / LEFT TO RIGHT', size=10)
    c.dim_v(v.py(0), v.py(W), v.px(L), v.px(L), v.px(L) + 65, fmt(W) + ' WIDTH', size=10)
    _footer(c, job, job.revision(), 'master datum plan; foundation and anchor rods are issued separately')
    return sh
