"""Shared main knee/base rules, displayed for each lean low end."""

from ..framing_additions import profile
from ..model import Job
from .canvas import S_HID, S_NOTE, Canvas, Sheet, View
from .sheet import _border, _footer, _title_block


def sheet(job, fid, index):
    z = job.assemblies[fid].derivation['framing_additions']['lean_tos'][index]
    d = z['low_connection_detail']
    sh = Sheet(fid + '~low_detail~' + str(index) + '~1', 'additions')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, len(z['stations']), 'LEAN LOW', z['id'], job.date)
    c.ptext(110, 63, z['id'] + ' / SHARED MAIN KNEE + BASE RULES', 16, bold=True)
    c.ptext(110, 91, 'Q04: reuse main builders. Geometry review, not a new independent lean connection design.', 11)
    c.ptext(
        110,
        113,
        'Style ' + d['style'] + ' | ' + str(d['quantity']) + ' physical stations | outer column ' + z['column'],
        10,
    )
    if d.get('template_job'):
        from .connection_views import bounds, draw_side, side_geometry

        tmp = Job.loads(d['template_job'])
        k = tmp.part(d['knee'])
        b = bounds(side_geometry(tmp, k, True))
        sc = min(13, 570 / max(b[2] - b[0], 1), 290 / max(b[3] - b[1], 1))
        v = View(420 - (b[0] + b[2]) / 2 * sc, 440 + b[1] * sc, sc, sc)
        draw_side(Canvas(sh, v), tmp, k, True)
    elif 'column_low_cut_in' in d and d.get('mixed_seats'):
        c.ptext(165, 479, 'MIXED SUPPORT CONNECTION MODES — SEE PHYSICAL SUPPORT SCHEDULE BELOW', 9, style=S_NOTE)
    elif 'column_low_cut_in' in d:
        cp = profile(z['column'])
        m = z['pitch'] / 12
        depth = d['plumb_rafter_depth_in']
        v = View(270, 257, 9, 9)
        a = Canvas(sh, v)
        cd = cp['depth']
        if d.get('welded_knee') == 'inside_flange':
            # post to the rafter top line (pitch-cut top), rafter welded to the post inside face
            a.poly([(0, -depth - 18), (cd, -depth - 18), (cd, cd * m), (0, 0)])
            a.poly([(cd, cd * m), (34, 34 * m), (34, 34 * m - depth), (cd, cd * m - depth)])
            if d.get('knee_geometry'):
                a.poly(d['knee_geometry']['side_contour_in'], style=S_NOTE)
        else:
            a.poly([(0, -depth - 18), (cd, -depth - 18), (cd, -depth + cd * m), (0, -depth)])
            a.poly([(0, 0), (34, 34 * m), (34, 34 * m - depth), (0, -depth)])
        a.line(0, 0, 0, 7, S_NOTE)
        a.line(0, 2, 34, 34 * m + 2, S_HID)
        c.ptext(165, 479, d.get('seat', 'LOCAL LOW-EAVE CONTACT') + ' / post continues to the shared base', 9)
    c.ptext(760, 167, 'DERIVED GEOMETRY', 12, bold=True)
    rows = [
        (
            'Base plate',
            d.get('base_plate')
            or (
                'FLOOR WELD PLATE'
                if d.get('base_connection') == 'floor_weld'
                else 'NONE - POST EMBEDDED (POST FOOTING)'
                if (d.get('foundation') or {}).get('type') == 'post_footing'
                else 'NONE'
            ),
        ),
        ('Base thickness', d.get('base_thickness_in', 'HOLD')),
        ('Column LOW above floor', d.get('column_low_floor_in', 'HOLD')),
        ('Column LOW cut', d.get('column_low_cut_in', 'HOLD')),
        ('Column LONG blank', d.get('column_long_blank_in', 'HOLD')),
    ]
    for i, (label, value) in enumerate(rows):
        c.ptext(
            760, 199 + i * 37, label + ': ' + (f'{value:.6f}in' if isinstance(value, (float, int)) else str(value)), 10
        )
    support_lines = d.get('lines', [])
    if support_lines:
        c.ptext(500, 390, 'PHYSICAL SUPPORT SCHEDULE', 11, bold=True)
        c.ptext(500, 409, 'FRAME LINE / POST | RAFTER SEAT | LOW CUT', 8, bold=True)
        for i, row in enumerate(support_lines[:12]):
            seat = row.get('rafter_seat_mode', 'INHERITED')
            c.ptext(
                500,
                427 + i * 16,
                f"{row.get('frame_line', row.get('station'))} / {row.get('main_mark', '')} | {seat} | {row.get('column_low_cut_in', 0):.3f} in",
                8,
            )
        if len(support_lines) > 12:
            c.ptext(
                500, 427 + 12 * 16, f"+ {len(support_lines) - 12} more; see lean_low_connections.csv", 8, style=S_NOTE
            )
    c.ptext(110, 545, 'Generated low-end parts (also exported as actual contour review DXFs):', 11, bold=True)
    for i, r in enumerate(z.get('low_connection_parts', [])[:9]):
        c.ptext(110, 570 + i * 16, f'{r["quantity"]} x {r["part"]["mark"]} / {r["role"]}', 9)
    for i, msg in enumerate(d.get('issues', [])[:3]):
        c.ptext(110, 710 - i * 16, 'HOLD: ' + msg, 9, style=S_NOTE)
    c.ptext(
        110,
        730,
        'Rafter end planes: LEAN RAFTER CUTS sheet. Roof purlin rows and bay pieces: lean purlin schedule.',
        8,
        style=S_NOTE,
    )
    _footer(
        c,
        job,
        job.revision(),
        'dimensions in inches; actual shared geometry, retained original base/anchor/weld checks',
    )
    return sh
