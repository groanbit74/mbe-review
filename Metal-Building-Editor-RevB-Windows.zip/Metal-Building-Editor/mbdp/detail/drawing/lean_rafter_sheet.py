"""Actual theoretical high/low plumb cut planes, separate from fit approval."""

from ..cladding import fmt
from ..framing_additions import profile
from ..grades import fmt_grade
from . import coordination_views as CV
from .canvas import S_DIM, S_HID, S_NOTE, Canvas, Sheet, View
from .erection_views import _schedule
from .sheet import _border, _footer, _title_block


def sheet(job, fid, index):
    z = job.assemblies[fid].derivation['framing_additions']['lean_tos'][index]
    r = z['rafter_cut_detail']
    low = z['low_connection_detail']
    lines = r.get('lines') or []

    def _physical_line(line):
        station = next(
            (st for st in z.get('stations') or [] if st.get('index') == line.get('station')),
            {},
        )
        return int(line.get('frame_line') or station.get('frame_line') or line.get('station') or 0)

    special_lines = sorted((line for line in lines if line.get('special_open_c')), key=_physical_line)
    representative = special_lines[0] if special_lines else (min(lines, key=_physical_line) if lines else None)
    display = dict(r)
    if representative:
        for key in (
            'high_cut_x_in',
            'low_cut_x_in',
            'high_top_in',
            'low_top_in',
            'high_bottom_in',
            'low_bottom_in',
            'top_line_length_in',
            'long_blank_in',
            'plumb_depth_in',
            'high_gap_in',
            'high_cut_angle_deg',
            'low_cut_angle_deg',
        ):
            if key in representative:
                display[key] = representative[key]
    representative_station = next(
        (st for st in z.get('stations') or [] if representative and st.get('index') == representative.get('station')),
        None,
    )
    display_low = dict(low)
    low_line = next(
        (
            row
            for row in low.get('lines') or []
            if representative and row.get('station') == representative.get('station')
        ),
        None,
    )
    if low_line:
        display_low.update(low_line)
    col = profile(z['column'])
    rafter_section = representative.get('profile_id') if representative else z['rafter']
    P = z['projection_in']
    H = z['high_eave_in']
    m = z['pitch'] / 12
    sh = Sheet(fid + '~rafter_cuts~' + str(index) + '~1', 'additions')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, len(z['stations']), 'LEAN RAFTER CUTS', z['id'], job.date)
    mixed_high = bool(z.get('high_connection_overrides'))
    mixed_low = bool(z.get('rafter_seat_overrides'))
    direct = (representative or {}).get('high_connection', r.get('high_connection', 'clip')) == 'welded_direct'
    inside = (representative or {}).get('low_connection', r.get('low_seat')) == 'inside_flange'
    c.ptext(110, 65, z['id'] + ' / WELDED RAFTER END PLANES', 16, bold=True)
    c.ptext(
        110,
        92,
        (
            'HIGH END connection varies by physical support; see the frame-line schedule below'
            if mixed_high
            else (
                (
                    'HIGH END on the main column seat, welded to the seat (no gap)'
                    if r.get('high_fits') == ['seat']
                    else 'HIGH END on the main column seat per station where the main rafter sits on it, welded to the column face elsewhere (no gap)'
                    if 'seat' in (r.get('high_fits') or [])
                    else 'HIGH END welded directly at the main column line (plumb end, no gap)'
                )
                if direct
                else 'HIGH END %.3g in clear of the main column face, welded clip' % r.get('high_gap_in', 0)
            )
        )
        + (
            ' / LOW END rafter seat varies by physical support; see frame-line schedule'
            if mixed_low
            else ' / LOW END at the post INSIDE face, post to the rafter top line'
            if inside
            else ' / LOW END over the post, plumb cut at the post outside face'
        ),
        11,
    )
    c.ptext(110, 115, r['datum'], 8)
    _frame_line = (representative_station or {}).get('frame_line')
    _fit_label = (
        'FLUSH IN OPEN-FACE CHANNEL'
        if representative and representative.get('purlin_fit') == 'channel'
        else str((representative or {}).get('purlin_fit') or z.get('purlin_mode', '')).upper()
    )
    c.ptext(
        110,
        133,
        'CUT VIEW: FRAME LINE %s — %s — %s' % (_frame_line or '-', rafter_section, _fit_label),
        9,
        bold=True,
    )
    sc = min(880 / (P + 40), 295 / (H + 10))
    v = View(200 - r['high_face_x_in'] * sc, 455, sc, sc)
    a = Canvas(sh, v)
    a.poly(
        [
            (display['high_cut_x_in'], display['high_top_in']),
            (display['low_cut_x_in'], display['low_top_in']),
            (display['low_cut_x_in'], display['low_bottom_in']),
            (display['high_cut_x_in'], display['high_bottom_in']),
        ]
    )
    cd = col['depth']
    y0 = display_low.get('column_bottom_in', low['base_elevation_in'] + low['base_thickness_in'])
    ly = display_low['column_low_floor_in']
    a.poly([(P - cd, y0), (P, y0), (P, ly), (P - cd, ly + cd * m)])
    # Main attachment FACE datum, not an invented new main-column profile.
    a.line(r['high_face_x_in'], 0, r['high_face_x_in'], H + 5, S_HID)
    a.line(0, 0, P + 8, 0, S_HID)
    _clip = next(
        (
            q
            for q in z.get('flush_clips') or []
            if representative_station and q.get('main_mark') == representative_station.get('main_mark')
        ),
        None,
    )
    if _clip:
        a.poly([(r['high_face_x_in'] + x, y) for x, y in _clip['installed_contour_in']], style=S_NOTE)
    _knee = low.get('knee_geometry')
    if representative and low.get('knee_geometry_by_seat'):
        _seat = representative.get('low_connection') or low.get('rafter_seat_resolved')
        _knee = low['knee_geometry_by_seat'].get(str(_seat) + ':' + str(rafter_section), _knee)
    if _knee:
        a.poly([(P - x, ly + y) for x, y in _knee['side_contour_in']], style=S_NOTE)
    a.line(0, H, P, z['low_eave_in'], S_HID)
    purlin_rows = (z.get('roof_purlin_layout') or {}).get('rows') or []
    if purlin_rows:
        from ..secondary_catalog import get as get_purlin

        low_row = max(purlin_rows, key=lambda row: float(row.get('horizontal_out_in') or 0))
        for row in purlin_rows:
            _x = float(row.get('horizontal_out_in') or 0)
            _y = float(row.get('roof_top_in') or 0)
            _section = get_purlin(row['profile_id'])
            _depth = float(_section.get('nominal_depth_in') or 6)
            _flange = max(_section.get('flanges_in') or [3.0])
            _hand = -1 if row is low_row else 1
            a.line(_x, _y, _x, _y - _depth)
            a.line(_x, _y, _x + _hand * _flange, _y)
            a.line(_x, _y - _depth, _x + _hand * _flange, _y - _depth)
            _mark_rise = 8 + (int(row.get('row') or 0) % 2) * 8
            a.text(
                _x + _hand * (_flange + 3),
                _y + _mark_rise,
                str(row.get('mark') or row['profile_id']),
                7,
                anchor='start' if _hand > 0 else 'end',
            )
        _chain_points = [
            (float(row['horizontal_out_in']), float(row['roof_top_in']))
            for row in sorted(purlin_rows, key=lambda row: float(row.get('horizontal_out_in') or 0), reverse=True)
        ]
        CV.slope_dimension_chain(a, _chain_points, 18 + 12 / max(sc, 0.1))
        _low_p = v.p(float(low_row['horizontal_out_in']), float(low_row['roof_top_in']))
        c.pline(_low_p[0] + 2, _low_p[1] - 4, _low_p[0] + 18, _low_p[1] - 18, S_DIM)
        c.ptext(_low_p[0] + 20, _low_p[1] - 20, 'LOW EAVE — DIMENSION ORIGIN', 8)
    CV.slope_dimension_chain(
        a,
        [
            (float(display['high_cut_x_in']), float(display['high_top_in'])),
            (float(display['low_cut_x_in']), float(display['low_top_in'])),
        ],
        -12,
        text_size=8.5,
        label_prefix='RAFTER TOP LINE ',
    )
    _special = [q for q in (r.get('lines') or []) if q.get('special_open_c')]
    if _special:
        # open-face Cee below the C purlin line, stopping 1/2 in from the main wall sheet
        a.line(
            r['high_face_x_in'] + 0.5,
            display['high_top_in'] - 0.5 * m - 4,
            display['low_cut_x_in'],
            display['low_top_in'] - 4,
            S_HID,
        )
        c.ptext(
            110,
            442,
            'END LINES - SPECIAL OPEN-C RAFTER: C purlin '
            + fmt(_special[0]['special_open_c']['c_purlin_blank_in'])
            + ' (full slope, into the main end rafter) + open-face Cee '
            + fmt(_special[0]['special_open_c']['open_face_blank_in'])
            + ' stopping 1/2 in from the sheet (dashed).',
            9,
        )
    _fit_groups = {}
    for _line in lines:
        _station = next(
            (st for st in z.get('stations') or [] if st.get('index') == _line.get('station')),
            {},
        )
        _line_number = _line.get('frame_line') or _station.get('frame_line') or _line.get('station')
        _physical_line_number = str(_line_number)
        _fit = _line.get('purlin_fit') or _station.get('purlin_fit') or z.get('purlin_mode', '')
        if _fit == 'channel':
            _fit_label = str(_line.get('profile_id') or '') + ' FLUSH IN OPEN-FACE CHANNEL'
        elif _fit == 'flush':
            _fit_label = str(_line.get('profile_id') or '') + ' FLUSH / WEB-WELD'
        else:
            _fit_label = str(_line.get('profile_id') or '') + ' BYPASS'
        _fit_groups.setdefault(_fit_label, []).append(_physical_line_number)
    _fit_note = 'PURLIN FIT BY FRAME LINE: ' + '; '.join(
        'lines ' + ', '.join(sorted(nums, key=int)) + ': ' + label
        for label, nums in sorted(_fit_groups.items(), key=lambda item: min(map(int, item[1])))
    )
    c.ptext(
        110,
        460,
        (
            'Main-column attachment is per support; see the high connection schedule. '
            if mixed_high
            else 'Main column face to rafter end: 0 (welded direct). '
            if direct
            else 'Main column face to rafter end: %.4g in horizontal; welded clip overlaps 6 in into the rafter web. '
            % r.get('high_gap_in', 0)
        )
        + _fit_note,
        10,
    )
    _pair_lines = [q for q in (r.get('lines') or []) if q.get('pair') == 2]
    if _pair_lines:
        _prof = profile(_pair_lines[0].get('profile_id') or z['rafter']) or {}
        _dep = float(_prof.get('depth') or 6)
        _fw = float(_prof.get('width') or 2)
        _spacer = z.get('doubled_rafter') == 'spacer'
        # section detail, top right of the sheet: two open-face channels, open sides out
        _cx, _cy, _sc = 940.0, 330.0, 13.0
        _hd, _hf = _dep * _sc / 2, _fw * _sc
        c.ptext(_cx, _cy - _hd - 34, 'DOUBLED OPEN-FACE RAFTER (I) - SECTION', 10, bold=True, anchor='middle')
        for _sgn in (-1, 1):
            _wx = _cx + (_sgn * (0.9 if _spacer else 0.0))
            _fx = _wx + _sgn * _hf
            c.pline(_fx, _cy - _hd, _wx, _cy - _hd)
            c.pline(_wx, _cy - _hd, _wx, _cy + _hd)
            c.pline(_wx, _cy + _hd, _fx, _cy + _hd)
            c.pline(_fx, _cy - _hd, _fx + 4 * _sgn, _cy - _hd)
            c.pline(_fx, _cy + _hd, _fx + 4 * _sgn, _cy + _hd)
        if _spacer:
            # 1/8 in plate, the width of the open face, sandwiched FULL LENGTH
            c.prect(_cx - 0.9, _cy - _hf / 2, _cx + 0.9, _cy + _hf / 2)
            c.ptext(
                _cx,
                _cy + _hd + 14,
                '(b) 1/8 in PLATE x ' + fmt(_fw) + ' (OPEN-FACE WIDTH) BETWEEN THE CHANNELS, FULL LENGTH',
                8.5,
                anchor='middle',
            )
        else:
            c.ptext(_cx, _cy + _hd + 14, '(a) CHANNELS WELDED BACK TO BACK', 8.5, anchor='middle')
        c.ptext(
            _cx,
            _cy + _hd + 28,
            _pair_lines[0].get('profile_id', z['rafter'])
            + ' x2 - depth '
            + fmt(_dep)
            + ', open face '
            + fmt(_fw)
            + ' wide',
            8.5,
            anchor='middle',
        )
    data = [
        ('Top line between PLUMB cut planes', display['top_line_length_in']),
        ('Physical LONG blank', display['long_blank_in']),
        ('High rafter top above floor', display['high_top_in']),
        ('Low rafter top above floor', display['low_top_in']),
        ('Lean post LOW cut', display_low['column_low_cut_in']),
        ('Lean post LONG blank', display_low['column_long_blank_in']),
    ]
    for i, (label, value) in enumerate(data):
        c.ptext(110 + (i // 3) * 530, 490 + (i % 3) * 22, label + ': ' + fmt(value), 10)
    c.ptext(
        110,
        556,
        'PLUMB END angle %.2f deg from square. Section %s; no weld-preparation bevel inferred. '
        'Long blank = top line + section depth x slope. Stock plan rounds UP separately.'
        % (display['high_cut_angle_deg'], rafter_section),
        9,
    )
    if z.get('open_face_rafter') and inside:
        _support_lines = r.get('lines') or []
        _channel_lines = [
            line for line in _support_lines if line.get('profile_id', '').startswith(('SSS-SS', 'MBCI-Channel-'))
        ]
        _other_lines = [line for line in _support_lines if line not in _channel_lines]
        _head_note = (
            'Shop rule: special open-C end supports side-weld to the lean posts without caps; W support heads remain per line schedule.'
            if _channel_lines and _other_lines
            else 'Shop rule: open-face channel rafter side-welded to the main column and to the lean post; no cap on the post.'
        )
        c.ptext(110, 578, _head_note, 9)
    # rafter and post by frame line (round 11: a different section / purlin fit on any line)
    lines = sorted(r.get('lines') or [], key=_physical_line)
    posts = {q['station']: q for q in (low.get('lines') or [])}
    if lines:
        cols = (
            ('LINE', 40),
            ('STATION', 64),
            ('RAFTER', 118),
            ('QTY', 34),
            ('HIGH', 68),
            ('LOW', 68),
            ('LONG BLANK', 78),
            ('PLUMB DEPTH', 78),
            ('TOP AT COLUMN', 86),
            ('PURLINS', 150),
            ('GRADE', 52),
            ('POST CUT', 76),
        )
        rows = []
        for q in lines:
            st = next((x for x in z['stations'] if x['index'] == q['station']), {})
            post = posts.get(q['station'], {})
            fit = st.get('purlin_fit') or ('channel' if z.get('purlins_in_channel') else z.get('purlin_mode', ''))
            rows.append(
                [
                    str(st.get('frame_line') or q['station']),
                    fmt(st.get('x_in', 0)),
                    q['profile_id'] + (' x2 (I)' if q['pair'] == 2 else ''),
                    str(q['pair']),
                    q.get('high_connection', z.get('high_connection', '')),
                    q.get('low_connection', low.get('rafter_seat_resolved', '')),
                    fmt(q['long_blank_in']),
                    fmt(q['plumb_depth_in']),
                    fmt(q['high_top_in']),
                    'OPEN-C END / FLUSH IN CHANNEL'
                    if q.get('special_open_c')
                    else 'FLUSH IN OPEN-FACE CHANNEL'
                    if fit == 'channel'
                    else 'FLUSH / web weld'
                    if fit == 'flush'
                    else 'BYPASS (top = roofline - purlin)',
                    fmt_grade(post.get('grade_in') or 0.0) if post else '-',
                    fmt(post['column_low_cut_in']) if post else '-',
                ]
            )
        _table_bottom = _schedule(c, 110 + sum(w for _, w in cols), 590, rows, 'RAFTER AND POST BY FRAME LINE', cols)
        lf = low.get('foundation') or {}
        if lf.get('type') == 'post_footing':
            c.ptext(
                110,
                _table_bottom + 8,
                'POSTS IN %s DIA x %s DEEP HOLES: grade = ground level at the post (set level 0); post cut = top - ground + hole depth.'
                % (lf.get('hole_diameter', ''), lf.get('hole_depth', '')),
                8,
            )
    c.ptext(
        110,
        770,
        'Full per-member quantities: lean_to_members.csv. End planes: lean_rafter_cut_planes.csv. Roof panels are separate.',
        9,
    )
    _footer(c, job, job.revision(), 'plumb end planes from the roof line; dimensions in inches')
    return sh
