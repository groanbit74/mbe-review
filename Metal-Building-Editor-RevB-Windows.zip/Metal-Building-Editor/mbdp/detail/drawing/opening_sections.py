"""Opening Cee cross sections and physical column/wall datum, not vendor punching."""

from ..cladding import fmt
from ..framing_additions import profile
from .canvas import S_HID, S_NOTE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _title_block

BLUE = Style(layer='OPENING_CEE', width=1.0)  # black, set style (owner 0.8.55)


def opening_sections(job, fid, index):
    model = job.assemblies[fid].derivation['framing_additions']
    r = model['openings'][index]
    pr = r['section']
    p = job.settings['frames'][fid]
    layout = job.settings['frame_layouts'][fid]
    sh = Sheet(fid + '~opening_sections~' + str(index) + '~1', 'additions')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, 1, 'OPENING SECTIONS', fid, job.date)
    c.ptext(110, 55, r['id'] + ' / CEE ORIENTATION + INSET WALL DATUM', 16, bold=True)
    c.ptext(
        110, 80, 'COORDINATION DETAIL — NO SECTION SUBSTITUTION, VENDOR PUNCHING OR CAPACITY APPROVAL', 10, style=S_NOTE
    )
    if not pr:
        c.ptext(110, 150, 'No matching Cee section available; framing held.', 12, style=S_NOTE)
        return sh
    d = pr['depth']
    b = pr['width']
    lip = 0 if pr['open_face'] else min(0.5, b / 3)  # symbolic lip ONLY, explicitly not dimensioned
    c.ptext(
        110,
        111,
        pr['id']
        + ' | '
        + str(d)
        + 'in web depth / '
        + str(b)
        + 'in flanges | '
        + ('HEADER UNLIPPED' if pr['open_face'] else 'HEADER LIPPED'),
        11,
    )
    c.ptext(
        110,
        132,
        'BLUE lines = nominal section envelopes. Line weight is NOT material thickness; any return lips are SYMBOLIC, NOT sized.',
        9,
    )
    # Side cut through the horizontal header: wall normal x; vertical y.
    v = View(240, 300, 18, 18)
    a = Canvas(sh, v)
    up = r.get('header_direction', 'down') == 'up'
    tip = b if up else -b
    a.poly([(0, tip), (0, 0), (d, 0), (d, tip)], closed=False, style=BLUE)
    if lip:
        a.line(0, tip, lip, tip, BLUE)
        a.line(d, tip, d - lip, tip, BLUE)
    a.line(0, -b - 1, 0, b + 2, S_HID)
    a.text(d / 2, b + 2, 'HEADER / FLANGES ' + ('UP' if up else 'DOWN'), 10, anchor='middle')
    c.dim_h(v.px(0), v.px(d), v.py(0), v.py(0), 370, fmt(d) + ' WALL-NORMAL DEPTH', size=9)
    c.ptext(220, 397, 'OUTSIDE WALL at left; clear aperture BELOW header.', 9)
    # Horizontal cut through left jamb: web vertical in plan, opens toward aperture.
    jp = r.get('jamb_section') or pr
    d = jp['depth']
    b = jp['width']
    lip = 0 if jp['open_face'] else min(0.5, b / 3)
    v = View(760, 317, 18, 18)
    a = Canvas(sh, v)
    outward = 'GIRT RECEIVER' in r.get('jamb_orientation', '')
    pts = [(0, 0), (b, 0), (b, d), (0, d)] if outward else [(b, 0), (0, 0), (0, d), (b, d)]
    a.poly(pts, closed=False, style=BLUE)
    if lip:
        tip = 0 if outward else b
        a.line(tip, 0, tip, lip, BLUE)
        a.line(tip, d, tip, d - lip, BLUE)
    a.text(b + 1, d / 2, 'OPENS TO GIRT RECEIVER' if outward else 'OPEN TO APERTURE', 9)
    c.ptext(704, 156, 'LEFT JAMB / PLAN CUT', 11, bold=True)
    c.ptext(704, 370, 'Right jamb MIRRORS this section.', 9)
    c.ptext(704, 392, 'JAMB: ' + jp['id'], 9)
    if outward:
        c.ptext(704, 414, 'Selected insertion from entry; actual web/lip fit held.', 8, style=S_NOTE)
    # Enlarged datum: actual primary column near the opening, plus wall girt depth.
    u = min(r['uprights'], key=lambda u: abs(u['x'] - r['x_in'])) if r['uprights'] else None
    c.ptext(110, 445, 'COLUMN / WALL-NORMAL DATUM (ENLARGED PLAN)', 11, bold=True)
    if u:
        cp = profile(u['profile'])
        rotated_corner = r['face'] in ('left', 'right') and u['mark'].startswith('EW-')
        normal = cp['width'] if rotated_corner else cp['depth']
        wide = cp['depth'] if rotated_corner else cp['width']
        inset = layout.get('inset_in', 0)
        v = View(380, 660, 8, 8)
        a = Canvas(sh, v)
        # x is wall-normal (outside -> inside); y runs along wall in this enlarged cut.
        a.line(0, -4, 0, 13, Style(layer='WALL_PLANE', color=(0.65, 0.1, 0.1), width=1.2))
        if cp['family'] == 'W':
            tf = cp['flange']
            tw = cp['web']
            if not rotated_corner:
                a.rect(inset, 0, inset + tf, wide)
                a.rect(inset + normal - tf, 0, inset + normal, wide)
                a.rect(inset + tf, wide / 2 - tw / 2, inset + normal - tf, wide / 2 + tw / 2)
            else:
                a.rect(inset, 0, inset + normal, tf)
                a.rect(inset, wide - tf, inset + normal, wide)
                a.rect(inset + normal / 2 - tw / 2, tf, inset + normal / 2 + tw / 2, wide - tf)
        else:
            a.rect(inset, 0, inset + normal, wide)
        from ..model import D

        gd = float(D(p['girt_depth']).inches)
        near = inset - gd if p['girt_mode'] == 'bypass' else inset
        a.line(near, wide + 3, near + gd, wide + 3, BLUE)
        a.line(near, wide + 3, near, wide + 8, BLUE)
        a.line(near + gd, wide + 3, near + gd, wide + 8, BLUE)
        a.text(inset + normal / 2, -2, u['profile'], 9, anchor='middle')
        c.ptext(650, 480, 'RED: fixed outside wall plane', 10)
        c.ptext(650, 505, 'Column outside face: ' + fmt(inset) + ' inward from wall', 10)
        c.ptext(650, 530, 'Girt / Cee outside face: ' + fmt(near) + ' from wall', 10)
        c.ptext(
            650,
            555,
            'BYPASS: girt outside column'
            if p['girt_mode'] == 'bypass'
            else 'FLUSH: girt outside face = column outside face',
            10,
            bold=True,
        )
        c.ptext(
            650,
            580,
            'DIRECT welded girt receiver / no separate clip counted'
            if r.get('bearing_jambs') and u.get('opening_id') == r['id']
            else 'Girts welded directly to the column web (coped at the flanges); no clip'
            if p['girt_clip'] == 'GIRT-WELD'
            else 'Clip: '
            + p['girt_clip']
            + ' / '
            + ('outside flange' if p['girt_mode'] == 'bypass' else 'web; inward ends / both interior sides'),
            9,
        )
        c.ptext(650, 605, 'Connection positions/counts: wall_girt_connections.csv', 9)
        c.ptext(650, 630, 'Vendor clip contour, bolt fit and weld access remain held.', 9, style=S_NOTE)
    c.ptext(
        110,
        706,
        'Both source erection sets use inset steel. This view uses THIS job\'s actual inset; no source-job geometry is silently copied.',
        9,
    )
    _footer(c, job, job.revision(), 'physical Cee orientation; lip/thickness/radii and connection fit are not inferred')
    return sh
