"""Master purchasing order, department schedules, holds and stock patterns."""

import math
import textwrap
from collections import Counter

from ..ordering import DEPARTMENTS, build, fmt
from .canvas import S_NOTE, S_TABLE, Canvas, Sheet, Style, text_width
from .sheet import _border, _footer, _title_block


def descriptors(plan):
    yield 'summary', 1
    for key in ('frame', 'secondaries', 'sheets_trim', 'patterns', 'trace', 'holds'):
        rows = rows_for(plan, key)
        for page in range(1, math.ceil(len(rows) / 16) + 1):
            yield key, page


def rows_for(plan, key):
    if key == 'trace':
        return plan.get('piece_trace', [])
    if key == 'patterns':
        return plan['patterns']
    if key == 'holds':
        return plan['pending']
    dep = {'frame': 'Frame', 'secondaries': 'Secondaries', 'sheets_trim': 'Sheets / Trim'}[key]
    return [r for r in plan['items'] if r['department'] == dep]


def order_sheet(job, key='summary', page=1, plan=None):
    plan = plan or build(job)
    name = 'MASTER-ORDER' if key == 'summary' else 'ORDER-' + key.upper() + '-' + str(page)
    sh = Sheet(name, 'order')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, 1, name, 'ORDER', job.date)
    c.ptext(968, 53, name, min(15, 170 / max(text_width(name, 1, True), 1)), bold=True)
    c.ptext(968, 73, 'MATERIAL ORDER', 12, bold=True)
    c.ptext(615, 31, 'PURCHASE / CUT PLAN', 11, anchor='middle', bold=True)
    _footer(
        c, job, job.revision(), 'job-scoped quantities; stock assumptions and unresolved items require confirmation'
    )
    if key == 'summary':
        c.ptext(110, 77, 'MASTER ORDER LIST - ' + job.job_no, 15, bold=True)
        c.ptext(110, 104, 'FRAME  /  SECONDARIES  /  SHEETS & TRIM', 11, bold=True)
        y = 145
        for dep in DEPARTMENTS:
            s = plan['summary'][dep]
            c.prect(110, y, 1110, y + 72, Style(fill=(0.95, 0.96, 0.98), width=0.5))
            c.ptext(125, y + 23, dep.upper(), 12, bold=True)
            c.ptext(
                125,
                y + 47,
                str(s['order_lines'])
                + ' proposed order lines | '
                + str(s['proposed_pieces'])
                + ' proposed pieces (includes fabricated parts) | '
                + str(s['pending_entries'])
                + ' HOLD entries',
                10,
            )
            y += 90
        cfg = plan['config']
        c.ptext(
            110,
            435,
            'USER STOCK LENGTHS (feet): beams '
            + ', '.join(f'{x:g}' for x in cfg['beam_stock_ft'])
            + '; C/Z '
            + ', '.join(f'{x:g}' for x in cfg['purlin_stock_ft'])
            + '; HSS '
            + ', '.join(f'{x:g}' for x in cfg['hss_stock_ft']),
            10,
        )
        c.ptext(
            110,
            458,
            'Kerf '
            + fmt(cfg['kerf_in'])
            + '; end allowance EACH stock end '
            + fmt(cfg['end_allowance_in'])
            + '; trim max '
            + fmt(cfg['trim_max_in'])
            + '. Exact/custom is selectable.',
            10,
        )
        c.ptext(
            110,
            484,
            'Planned linear stock: '
            + f"{plan['ordered_linear_stock_in'] / 12:,.2f}"
            + ' LF; one-piece-per-stock baseline '
            + f"{plan['baseline_linear_stock_in'] / 12:,.2f}"
            + ' LF.',
            10,
        )
        c.ptext(
            110,
            506,
            'Material reduction vs baseline: '
            + f"{(plan['baseline_linear_stock_in'] - plan['ordered_linear_stock_in']) / 12:,.2f}"
            + ' LF. Applies only to planned linear items; not prices or excluded HOLD items.',
            9,
        )
        c.ptext(
            110,
            528,
            'Finished blank footage '
            + f"{plan['blank_linear_stock_in'] / 12:,.2f}"
            + ' LF; kerf loss '
            + f"{plan['kerf_loss_in'] / 12:,.2f}"
            + ' LF; end loss '
            + f"{plan['end_loss_in'] / 12:,.2f}"
            + ' LF; remnant '
            + f"{plan['remnant_in'] / 12:,.2f}"
            + ' LF.',
            9,
        )
        notes = [
            'Stock packing compares several deterministic plans; not a guarantee of global optimum or cheapest supplier price.',
            'Long physical blanks are used for columns, not low-point dimensions. No stock-length member splice is invented.',
            'Short trim ordered exact; long trim segmented to selected maximum plus entered lap. Custom lengths need supplier confirmation.',
            'Plate/clip rows are fabricated-piece requirements: raw plate stock is NOT nested. Gutters require explicit additional trim runs.',
            'Endwall references, eave cuts, missing quantities, supplier limits and accessories remain on Holds / release notes.',
            'Workbook: Master Order, department tabs, Stock Patterns, Cutting Plan, Cut Demands, Holds and Settings.',
        ]
        for i, t in enumerate(notes):
            c.ptext(110, 565 + i * 20, t, 8, style=S_NOTE if i in (1, 4) else S_TABLE)
        return sh
    rows = rows_for(plan, key)
    selected = rows[(page - 1) * 16 : page * 16]
    if not selected:
        raise ValueError('Order page outside schedule')
    c.ptext(
        110,
        77,
        key.upper().replace('_', ' ') + ' - PAGE ' + str(page) + ' / ' + str(math.ceil(len(rows) / 16)),
        12,
        bold=True,
    )
    if key == 'trace':
        heads = ['SUPPLIER / STOCK', 'CUT MARK / INSTANCE', 'CUT LENGTH', 'PHYSICAL LOCATION']
        xs = [110, 310, 565, 690, 1110]
        values = [
            [
                r['supplier_id'] + ' / ' + r['stock_id'],
                r['cut_mark'] + ' #' + str(r['instance']),
                fmt(r['blank_length_in']),
                r['location'],
            ]
            for r in selected
        ]
    elif key == 'patterns':
        heads = ['PATTERN / MATERIAL', 'STOCK / QTY', 'BLANK CUT PATTERN (PER STOCK)', 'REMNANT EACH']
        xs = [110, 400, 555, 975, 1110]
        values = []
        for r in selected:
            counts = Counter(r['cut_lengths_in'])
            pattern = ' + '.join(str(q) + ' x ' + fmt(L) for L, q in sorted(counts.items(), reverse=True))
            values.append(
                [
                    r['pattern_id'] + ' ' + r['profile'],
                    fmt(r['stock_length_in']) + ' / ' + str(r['quantity']),
                    pattern,
                    fmt(r['remnant_each_in']),
                ]
            )
    elif key == 'holds':
        heads = ['DEPARTMENT / MATERIAL', 'QTY', 'REFERENCE / LENGTH', 'REASON']
        xs = [110, 415, 475, 745, 1110]
        values = [
            [
                r['department'] + ' / ' + r['material'],
                str(r['quantity']) if r['quantity'] is not None else 'PENDING',
                r['reference'] + ' / ' + r['required_length'],
                r['reason'],
            ]
            for r in selected
        ]
    else:
        heads = ['ORDER / MATERIAL', 'FINISH / GRADE', 'LENGTH / QTY', 'BASIS / STATUS']
        xs = [110, 420, 650, 785, 1110]
        values = [
            [
                r.get('supplier_id', '') + ' / ' + r['order_id'] + ' / ' + r.get('display_material', r['material']),
                r['finish'] + ' / ' + r['grade'],
                (r['order_length'] or 'PART') + ' / ' + str(r['quantity']),
                r['basis'] + ' / ' + r['status'] + ' / ' + r.get('supplier_status', ''),
            ]
            for r in selected
        ]
    top = 119
    rh = 30
    for i, row in enumerate([heads] + values):
        y = top + i * rh
        c.pline(xs[0], y, xs[-1], y, S_TABLE)
        for j, t in enumerate(row):
            width = xs[j + 1] - xs[j] - 8
            chars = max(10, int(width / 3.6))
            lines = textwrap.wrap(str(t), chars) or ['']
            for z, line in enumerate(lines[:3]):
                c.ptext(
                    xs[j] + 4, y + 9 + z * 9, line if z < 2 or len(lines) <= 3 else line[:-3] + '...', 6.7, bold=i == 0
                )
    end = top + (len(values) + 1) * rh
    c.pline(xs[0], end, xs[-1], end, S_TABLE)
    for x in xs:
        c.pline(x, top, x, end, S_TABLE)
    c.ptext(
        110,
        650,
        'Full specifications, source marks and every allocation are retained in master_order.xlsx and JSON/CSV. Long cells may be abbreviated here.',
        8,
    )
    c.ptext(
        110,
        673,
        'Stock assumptions only. Verify material/finish/grade, fabrication geometry and supplier availability before purchase or cutting.',
        8,
        style=S_NOTE,
    )
    c.ptext(
        110,
        696,
        'Patterns use rounded-up long blanks; Cutting Plan maps stock IDs to actual marks. No automatic splice; Holds not silently counted as zero.',
        8,
    )
    return sh


def all_order_sheets(job, plan=None):
    plan = plan or build(job)
    return [order_sheet(job, k, p, plan) for k, p in descriptors(plan)]
