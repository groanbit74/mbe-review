"""Dimensioned local view of the optional inside-flange welded knee."""

from ..connections import f
from .canvas import S_HID, S_NOTE, Canvas, View
from .sheet import _footer
from .welded_sheet import header


def sheet(job, fid):
    l = job.settings['frame_layouts'][fid]
    p = job.settings['frames'][fid]
    r = l['knee_records'][0]
    g = r['geometry']
    col = l['columns'][0]
    sh, c = header(job, 'EAVE-' + fid, 'welded_eave', l['frames'] * (1 if l['frame_type'] == 'monoslope' else 2), fid)
    c.ptext(110, 74, 'OPTIONAL WELDED KNEE / RAFTER AT INSIDE COLUMN FLANGE', 13, bold=True)
    c.ptext(110, 98, '3/16in TOP bearing plate / rafter flange width /3in ALONG-pitch overlap; NO BOLTS.', 10)
    cd = g['column_depth_in']
    m = g['pitch_rise'] / 12
    co = g['co']
    raf = job.assemblies[l['rafters'][0]['mark']].main.sec
    dep = raf.d / co
    sc = min(13, 340 / (dep + 16), 490 / (cd + 10))
    v = View(270, 235, sc, sc)
    a = Canvas(sh, v)
    a.poly([(0, -dep - 14), (cd, -dep - 14), (cd, cd * m), (0, 0)])
    a.poly([(cd, cd * m), (cd + 10, (cd + 10) * m), (cd + 10, (cd + 10) * m - dep), (cd, cd * m - dep)])
    a.poly(g['side_contour_in'], style=S_NOTE)
    a.line(0, 0, cd + 10, (cd + 10) * m, S_HID)
    if p['eave_start_clip']:
        cp = job.part(p.get('eave_clip') or p['purlin_clip'])
        t = f(cp.thk)
        if p['purlin_mode'] == 'flush':
            xx = cd
            y = cd * m - f(p['purlin_web_y']) - f(cp.width) / 2
            h = f(cp.width)
        else:
            xx = 0
            y = g['thickness_in'] / co
            h = f(cp.length)
        a.poly([(xx, y), (xx + t, y), (xx + t, y + h), (xx, y + h)], style=S_NOTE)
        a.text(xx, y + h + 1, 'PLUMB ' + cp.mark, 9)
    c.dim_h(v.px(0), v.px(cd), v.py(-dep - 14), v.py(-dep - 14), 520, f'{cd:.6f}in COLUMN DEPTH', size=9)
    c.ptext(720, 165, 'PLATE / CUT DATUMS', 12, bold=True)
    lines = [
        f'Plate:3/16 x {g["width_in"]:.6f} x {g["length_along_in"]:.6f}in',
        f'Bearing along pitch: {g["column_bearing_along_in"]:.6f}in',
        'Rafter overlap:3.000000in ALONG pitch',
        f'Column LOW above floor: {min(col["top_y0"], col["top_y1"]):.6f}in',
        f'Column LONG blank: {col["design_length"]:.6f}in',
        f'Rafter top at inside flange: {l["rafters"][0]["top_start"][1]:.6f}in',
    ]
    for i, text in enumerate(lines):
        c.ptext(720, 197 + i * 27, text, 10)
    c.ptext(
        110, 573, 'Column top and rafter top meet the UNDERSIDE of the pitched bearing plate. Rafter end is PLUMB.', 10
    )
    c.ptext(
        110,
        599,
        'Starting eave clip: bypass at column top plate; flush at rafter web inside the column face. No negative rafter station.',
        9,
    )
    for i, text in enumerate(g['fit_notes']):
        c.ptext(110, 627 + i * 22, text, 9)
    _footer(
        c,
        job,
        job.revision(),
        'inside-flange knee; flush outer material edge; square-cut thickness bearing offset shown',
    )
    return sh


def side_welded_sheet(job, fid):
    """Rafter welded to the inside column face, column run to the rafter top line, no cap plate
    (open-face channel rafters - carports)."""
    import math

    l = job.settings['frame_layouts'][fid]
    p = job.settings['frames'][fid]
    col = l['columns'][0]
    csec = job.assemblies[col['mark']].main.sec
    raf = job.assemblies[l['rafters'][0]['mark']].main.sec
    m = float(l['slope_rise']) / 12
    co = 1 / math.hypot(1, m)
    cd = csec.d
    dep = raf.d / co
    sh, c = header(job, 'EAVE-' + fid, 'welded_eave', l['frames'] * (1 if l['frame_type'] == 'monoslope' else 2), fid)
    c.ptext(110, 74, 'RAFTER WELDED TO THE INSIDE COLUMN FACE / COLUMN TO THE RAFTER TOP LINE / NO CAP', 13, bold=True)
    c.ptext(
        110, 98, 'Column top cut to the pitch at the rafter top line; rafter end PLUMB against the inside face.', 10
    )
    sc = min(13, 340 / (dep + 16), 490 / (cd + 10))
    v = View(270, 235, sc, sc)
    a = Canvas(sh, v)
    a.poly([(0, -dep - 14), (cd, -dep - 14), (cd, cd * m), (0, 0)])
    a.poly([(cd, cd * m), (cd + 10, (cd + 10) * m), (cd + 10, (cd + 10) * m - dep), (cd, cd * m - dep)])
    a.line(0, 0, cd + 10, (cd + 10) * m, S_HID)
    if p['eave_start_clip'] and p['purlin_mode'] == 'flush':
        cp = job.part(p.get('eave_clip') or p['purlin_clip'])
        t = f(cp.thk)
        y = cd * m - f(p['purlin_web_y']) - f(cp.width) / 2
        a.poly([(cd, y), (cd + t, y), (cd + t, y + f(cp.width)), (cd, y + f(cp.width))], style=S_NOTE)
    c.dim_h(v.px(0), v.px(cd), v.py(-dep - 14), v.py(-dep - 14), 520, f'{cd:.4f}in COLUMN DEPTH', size=9)
    c.ptext(720, 165, 'CUT DATUMS', 12, bold=True)
    lines = [
        f'Column LOW (outside face) above floor: {min(col["top_y0"], col["top_y1"]):.4f}in',
        f'Column LONG (inside face): {max(col["top_y0"], col["top_y1"]):.4f}in',
        f'Column blank: {col["design_length"]:.4f}in',
        f'Rafter top at the inside face: {l["rafters"][0]["top_start"][1]:.4f}in',
        f'Rafter plumb depth: {dep:.4f}in ({raf.name})',
        'Rafter eave end: PLUMB cut, welded to the inside column face',
    ]
    for i, text in enumerate(lines):
        c.ptext(720, 197 + i * 27, text, 10)
    c.ptext(110, 573, 'No cap / cover plate: open-face rafter. The eave member sits inside the rafter channel.', 10)
    c.ptext(110, 599, 'Weld all round at the contact; weld sizes per the shop standard.', 9)
    _footer(c, job, job.revision(), 'side-welded rafter; column to the rafter top line; no cap')
    return sh
