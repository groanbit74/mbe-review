"""DXF renderer (ezdxf, AC1027 / R2013).

* Sheet coordinates are paper inches (1 unit = 1 inch on the 17x11 sheet), y up.
* Layers: BORDER, TABLE, OBJECT, HIDDEN, CENTER, HOLE, WELD, DIM, TEXT, NOTE.
* Linear dimensions are emitted as real DIMENSION entities with the exact
  fraction string as text override (the measured paper distance is not the value);
  exploded dimension geometry created for PDF/SVG is skipped.
"""

from __future__ import annotations

import ezdxf
from ezdxf.enums import TextEntityAlignment

from .canvas import Circle, Line, Poly, Sheet, Text

PT = 1.0 / 72.0  # points -> inches

LAYERS = {
    "BORDER": 7,
    "TABLE": 7,
    "OBJECT": 7,
    "HIDDEN": 8,
    "CENTER": 8,
    "HOLE": 7,
    "WELD": 7,
    "DIM": 3,
    "TEXT": 7,
    "NOTE": 1,
}
LINETYPES = {"HIDDEN": "HIDDEN", "CENTER": "CENTER"}


def _xy(sh: Sheet, x: float, y: float) -> tuple[float, float]:
    return (x * PT, (sh.height - y) * PT)


def render_dxf(sh: Sheet, path: str) -> str:
    doc = ezdxf.new("R2013", setup=True)
    doc.header["$INSUNITS"] = 1  # inches
    doc.header["$MEASUREMENT"] = 0
    for name, color in LAYERS.items():
        lay = doc.layers.add(name, color=color)
        if name in LINETYPES:
            lay.dxf.linetype = LINETYPES[name]
    if "ARIAL" not in doc.styles:
        doc.styles.add("ARIAL", font="arial.ttf")
    if "ARIALB" not in doc.styles:
        doc.styles.add("ARIALB", font="arialbd.ttf")
    doc.dimstyles.new(
        "MBDP",
        dxfattribs={
            "dimtxt": 12.4 * PT,
            "dimasz": 0.08,
            "dimexo": 0.02,
            "dimexe": 0.04,
            "dimgap": 0.03,
            "dimtad": 1,
            "dimtxsty": "ARIAL",
            "dimclrd": 3,
            "dimclre": 3,
            "dimclrt": 7,
            "dimdec": 4,
        },
    )
    msp = doc.modelspace()
    for it in sh.items:
        if it.style.tag == "dim":
            continue  # replaced by DIMENSION entities
        attribs = {"layer": it.style.layer}
        if isinstance(it, Line):
            msp.add_line(_xy(sh, it.x1, it.y1), _xy(sh, it.x2, it.y2), dxfattribs=attribs)
        elif isinstance(it, Poly):
            pts = [_xy(sh, x, y) for x, y in it.pts]
            if it.style.fill is not None:
                h = msp.add_hatch(
                    color=254 if it.style.fill != (0.0, 0.0, 0.0) else 7, dxfattribs={"layer": it.style.layer}
                )
                h.paths.add_polyline_path(pts, is_closed=True)
                if it.style.width > 0:
                    msp.add_lwpolyline(pts, close=True, dxfattribs=attribs)
            else:
                msp.add_lwpolyline(pts, close=it.closed, dxfattribs=attribs)
        elif isinstance(it, Circle):
            msp.add_circle(_xy(sh, it.cx, it.cy), it.r * PT, dxfattribs=attribs)
        elif isinstance(it, Text):
            h = it.size * PT * 0.72
            align = {
                ("start", "baseline"): TextEntityAlignment.LEFT,
                ("middle", "baseline"): TextEntityAlignment.CENTER,
                ("end", "baseline"): TextEntityAlignment.RIGHT,
                ("start", "middle"): TextEntityAlignment.MIDDLE_LEFT,
                ("middle", "middle"): TextEntityAlignment.MIDDLE_CENTER,
                ("end", "middle"): TextEntityAlignment.MIDDLE_RIGHT,
                ("start", "top"): TextEntityAlignment.TOP_LEFT,
                ("middle", "top"): TextEntityAlignment.TOP_CENTER,
                ("end", "top"): TextEntityAlignment.TOP_RIGHT,
            }[(it.anchor, it.valign)]
            t = msp.add_text(
                it.text,
                height=h,
                rotation=it.rot,
                dxfattribs={"layer": it.style.layer, "style": "ARIALB" if it.bold else "ARIAL"},
            )
            t.set_placement(_xy(sh, it.x, it.y), align=align)
    for d in sh.dims:
        p1, p2 = _xy(sh, *d.p1), _xy(sh, *d.p2)
        base = _xy(sh, *d.line_pt)
        dim = msp.add_linear_dim(
            base=base, p1=p1, p2=p2, angle=d.angle, text=d.text, dimstyle="MBDP", dxfattribs={"layer": "DIM"}
        )
        dim.render()
    # paper outline for reference
    msp.add_lwpolyline(
        [(0, 0), (sh.width * PT, 0), (sh.width * PT, sh.height * PT), (0, sh.height * PT)],
        close=True,
        dxfattribs={"layer": "BORDER", "color": 8},
    )
    doc.saveas(path)
    return path
