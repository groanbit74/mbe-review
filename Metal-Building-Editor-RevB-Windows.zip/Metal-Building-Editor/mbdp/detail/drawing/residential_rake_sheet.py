"""Source-based formed residential rake order section; no guessed bend allowances."""

from .canvas import S_NOTE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _title_block


def sheet(job, fid):
    p = job.settings['frames'][fid]
    sh = Sheet(fid + '~rakeprofile~1', 'cladding_schedule')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, 1, 'FL1010-A4', fid, job.date)
    c.ptext(110, 62, 'RESIDENTIAL RAKE / FL-1010 REFERENCE / OWNER A = 4"', 17, bold=True)
    c.ptext(
        110,
        94,
        'CUSTOM FORMED PROFILE — order by length, color/gauge and this section; NOT unmodified catalog FL-1010.',
        10,
        style=S_NOTE,
    )
    v = View(290, 245, 48, 48)
    a = Canvas(sh, v)
    blue = Style(color=(0.12, 0.3, 0.6), width=2)
    # Profile routing follows the source pictogram. Bend angles are not dimensioned
    # in that source, so the sketch is NOT a scale flat-development / tool path.
    a.poly([(-0.39, -4.39), (0, -4), (0, 0), (3, 0), (4.24, -1.24), (4.99, -1.24)], closed=False, style=blue)
    a.line(-0.39, -4.39, -0.1, -4.1, blue)
    a.line(4.99, -1.24, 4.49, -1.24, blue)
    c.dim_v(v.py(-4), v.py(0), v.px(0), v.px(0), v.px(-1.2), 'A = 4"', size=12)
    c.dim_h(v.px(0), v.px(3), v.py(0), v.py(0), v.py(1), '3" TOP LEG', size=11)
    c.ptext(560, 285, '1-3/4" roof-side leg', 11)
    c.ptext(560, 310, '3/4" toe + 1/2" hem', 11)
    c.ptext(145, 485, '5/8" bottom return + 1/2" hem', 11)
    c.ptext(740, 192, 'FORMED ORDER SPECIFICATION', 12, bold=True)
    for i, t in enumerate(
        [
            'Owner face A: 4"',
            'Actual roof pitch: ' + str(p['slope_rise']) + ':12',
            p['cladding']['trim_finish']['color'] + ' / ' + str(p['cladding']['trim_finish']['gauge']) + ' ga',
            'All remaining legs: source FL-1010',
            'Source stock A: 3-11/16" (NOT used)',
            'Source standard pitch range: 3-4:12',
            'This job is a CUSTOM modification',
            'Lengths: trim_pieces.csv / order workbook',
        ]
    ):
        c.ptext(740, 225 + i * 26, t, 10)
    c.ptext(110, 543, 'Reference material girth: source10-13/16" + (4" minus3-11/16") =11-1/8".', 11)
    c.ptext(
        110,
        568,
        'This is a source-based girth adjustment, NOT a machine-ready developed blank. Supplier controls tooling/bend allowances.',
        9,
        style=S_NOTE,
    )
    c.ptext(
        110,
        594,
        'Lengths ordered exact; previous maximum20ft6in and entered laps retained. No extra duplicate lean rake on a continuous roof.',
        9,
    )
    c.ptext(
        110,
        621,
        'Source: MBCI Commercial / Industrial, effective March4,2026, printed54; local PBR trim extract page5.',
        9,
    )
    c.ptext(
        110,
        648,
        'Diagram shows source routing and labeled legs; unprinted bend angles are not invented. No FL-16 substitution.',
        9,
    )
    _footer(c, job, job.revision(), 'custom formed trim procurement section; not a plate CNC contour')
    return sh
