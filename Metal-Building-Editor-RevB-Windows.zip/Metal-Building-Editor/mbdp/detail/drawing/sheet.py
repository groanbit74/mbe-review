"""Sheet composition: border, mark header, title block, BOM table and view placement.

Geometry of the fixed elements was measured from the sample shop drawings
(17x11 landscape, border 74.4/14.6 - 1150.6/778.0 pt, title block 260.4 x 81 pt at
bottom-right, BOM table 504 pt wide at bottom-left, Arial 12.4 / 14.1 / 13.4 / 4.2 pt).
"""

from __future__ import annotations

from decimal import Decimal
from fractions import Fraction
from typing import Optional

import pymupdf

from ...dims import Dim
from .. import model as M
from .. import sections as _sections
from . import views as V
from .canvas import (
    BORDER,
    S_BORDER,
    S_CL,
    S_DIM,
    S_LEADER_FILL,
    S_NOTE,
    S_TABLE,
    TXT_BOM,
    TXT_DIM,
    TXT_KIND,
    TXT_MARK,
    TXT_TITLE_LBL,
    TXT_TITLE_VAL,
    Canvas,
    Sheet,
    View,
    text_width,
)

SY_ELEV = 6.12  # pt per inch, member depth in elevations (sample value)
S_DETAIL = 12.0  # 1:6 for sections and part details
S_PLATE_MAX = 36.0  # up to 1:2 for piece sheets

TB_X0, TB_X1 = 890.2, 1150.6
TB_ROWS = (697.1, 724.1, 751.1, 778.0)
BOM_X = (74.4, 281.7, 322.3, 497.7, 578.7)
BOM_HDR_H, BOM_ROW_H, BOM_TOT_H = 25.3, 15.2, 21.5


# --------------------------------------------------------------------------- fixed furniture
class _furniture:
    """Records the item range a furniture helper adds, so print packages can re-compose the
    drawing content (everything that is not border / title block / footer / mark header)."""

    def __init__(self, c: Canvas):
        self.c = c

    def __enter__(self):
        self.i0 = len(self.c.sheet.items)
        return self

    def __exit__(self, *exc):
        self.c.sheet.meta.setdefault("furniture", []).append((self.i0, len(self.c.sheet.items)))
        return False


def _border(c: Canvas) -> None:
    with _furniture(c):
        x0, y0, x1, y1 = BORDER
        c.prect(x0, y0, x1, y1, S_BORDER)


def _mark_header(c: Canvas, mark: str, kind: str) -> None:
    with _furniture(c):
        c.ptext(970.9, 54.0, mark, TXT_MARK, 0, "start", "baseline", True)
        c.pline(967.4, 57.5, TB_X1, 57.5, S_TABLE)
        c.ptext(970.9, 72.0, kind, TXT_KIND, 0, "start", "baseline", True)
    c.sheet.meta.setdefault("mark_header", (mark, kind))


def _view_for_sections(c: Canvas) -> None:
    c.pline(132.9, 59.7, 210.7, 59.7, S_DIM)
    c.arrow((132.9, 59.7), (-1, 0), length=7, half=2.2, style=S_LEADER_FILL)
    c.ptext(146.0, 56.0, "View for", TXT_DIM)
    c.ptext(146.0, 71.5, "Sections", TXT_DIM)


def _title_block(c: Canvas, job: M.Job, qty: int | str, part: str, drawing: str, date: str) -> None:
    c.sheet.meta.setdefault("title", {"qty": qty, "part": part, "drawing": drawing, "date": date or job.date})
    with _furniture(c):
        r = TB_ROWS
        c.prect(TB_X0, r[0], TB_X1, r[3], S_TABLE)
        for y in r[1:3]:
            c.pline(TB_X0, y, TB_X1, y, S_TABLE)
        cw = (TB_X1 - TB_X0) / 3
        for k in (1, 2):
            c.pline(TB_X0 + cw * k, r[1], TB_X0 + cw * k, r[3], S_TABLE)

        def cell(x0: float, x1: float, y0: float, label: str, value: str) -> None:
            c.ptext(x0 + 3, y0 + 5.5, label, TXT_TITLE_LBL)
            size = min(TXT_TITLE_VAL, TXT_TITLE_VAL * (x1 - x0 - 8) / max(1, text_width(value, TXT_TITLE_VAL)))
            c.ptext((x0 + x1) / 2, y0 + 20.5, value, size, 0, "middle")

        cell(TB_X0, TB_X1, r[0], "CUSTOMER", job.customer)
        cell(TB_X0, TB_X0 + cw, r[1], "JOB", job.job_no)
        cell(TB_X0 + cw, TB_X0 + 2 * cw, r[1], "CHECKED BY", job.checked_by)
        cell(TB_X0 + 2 * cw, TB_X1, r[1], "DATE", date or job.date)
        cell(TB_X0, TB_X0 + cw, r[2], "QUANTITY", str(qty))
        cell(TB_X0 + cw, TB_X0 + 2 * cw, r[2], "PART", part)
        cell(TB_X0 + 2 * cw, TB_X1, r[2], "DRAWING", drawing)


def _bom_table(c: Canvas, lines: list[M.BOMLine]) -> float:
    """Draw the BOM anchored to the bottom border; returns the table's top y."""
    n = len(lines)
    y_bot = BORDER[3]
    y_tot = y_bot - BOM_TOT_H
    y_hdr_bot = y_tot - n * BOM_ROW_H
    y_top = y_hdr_bot - BOM_HDR_H
    x = BOM_X
    c.prect(x[0], y_top, x[4], y_bot, S_TABLE)
    c.pline(x[0], y_hdr_bot, x[4], y_hdr_bot, S_TABLE)
    for k in range(1, 4):
        c.pline(x[k], y_top, x[k], y_tot, S_TABLE)
    c.pline(x[0], y_tot, x[4], y_tot, S_TABLE)
    c.pline(x[0], y_tot + 1.3, x[4], y_tot + 1.3, S_TABLE)
    hb = y_top + BOM_HDR_H - 6
    c.ptext(x[0] + 3, hb, "PART", TXT_BOM)
    c.ptext((x[1] + x[2]) / 2, hb, "QNT", TXT_BOM, 0, "middle")
    c.ptext((x[2] + x[3]) / 2, hb, "DESCRIPTION", TXT_BOM, 0, "middle")
    c.ptext((x[3] + x[4]) / 2, hb, "WEIGHT", TXT_BOM, 0, "middle")
    for i, l in enumerate(lines):
        yb = y_hdr_bot + (i + 1) * BOM_ROW_H - 3
        c.pline(
            x[0], y_hdr_bot + (i + 1) * BOM_ROW_H, x[4], y_hdr_bot + (i + 1) * BOM_ROW_H, S_TABLE
        ) if i < n - 1 else None
        c.ptext(x[0] + 8, yb, l.part, TXT_BOM)
        c.ptext((x[1] + x[2]) / 2, yb, str(l.qty), TXT_BOM, 0, "middle")
        c.ptext(
            x[2] + 6,
            yb,
            l.description,
            min(TXT_BOM, (x[3] - x[2] - 12) / max(pymupdf.get_text_length(l.description, fontsize=1), 1)),
        )
        c.ptext(x[3] + 8, yb, M.fmt_weight(l.total, l.kind), TXT_BOM)
    c.ptext(x[3] - 12, y_bot - 6, "TOTAL WEIGHT =", TXT_BOM, 0, "end")
    c.ptext(x[3] + 8, y_bot - 6, M.fmt_weight(M.total_weight(lines), "main"), TXT_BOM)
    return y_top


def _issues_banner(c: Canvas, issues: list[M.ModelIssue]) -> None:
    errs = [i for i in issues if i.severity == "error"]
    if not errs:
        return
    c.ptext(612, 30, "MODEL ERRORS - NOT FOR FABRICATION", 12, 0, "middle", "baseline", True, S_NOTE)
    for k, e in enumerate(errs[:3]):
        c.ptext(612, 42 + k * 10, e.text, 7.5, 0, "middle", "baseline", False, S_NOTE)


def _footer(c: Canvas, job: M.Job, rev: str, extra: str = "") -> None:
    with _furniture(c):
        c.ptext(BORDER[0] + 2, BORDER[3] + 9, f"Generated from model {rev}  |  job {job.job_no}  |  {extra}", 6.0)


# --------------------------------------------------------------------------- section extents (for placement)
def _section_extents(job: M.Job, a: M.Assembly, station: Optional[float]) -> tuple[float, float, float]:
    sec = a.main.sec
    top, bottom, half = sec.d, 0.0, sec.bf / 2
    for att in a.attachments:
        if att.face in ("left_end", "right_end"):
            continue
        if station is not None and att.station is not None and abs(V.f(att.station) - station) > 1 / 16:
            continue
        p = job.part(att.part)
        if p.kind not in ("clip", "plate"):
            continue
        if att.face == "top":
            top = max(top, sec.d + V.f(p.length))
            half = max(half, V.f(p.width) / 2)
        elif att.face == "bottom":
            bottom = min(bottom, -V.f(p.length))
            half = max(half, V.f(p.width) / 2)
        elif att.face == "web":
            half = max(half, (sec.bf / 2 if sec.kind in ('Channel', 'HSS') else (sec.tw or 0) / 2) + V.f(p.length))
            yh = sec.d - V.f(att.y_from_top) if att.y_from_top is not None else sec.d / 2
            bottom = min(bottom, yh - V.f(p.width) / 2)
    return top, bottom, half


def _section_station(job: M.Job, a: M.Assembly) -> Optional[float]:
    for face in ("top", "bottom", "web"):
        for att in sorted(a.attachments, key=lambda t: V.f(t.station)):
            if att.face == face and att.station is not None and job.part(att.part).kind in ("clip", "plate"):
                return V.f(att.station)
    return None


# --------------------------------------------------------------------------- assembly sheet
def assembly_sheet(job: M.Job, a: M.Assembly, issues: Optional[list[M.ModelIssue]] = None) -> Sheet:
    sh = Sheet(a.mark, "assembly", meta={"mark": a.mark, "kind": a.kind})
    c = Canvas(sh)
    lines = M.bom(job, a)
    _border(c)
    _mark_header(c, a.mark, a.kind)
    _view_for_sections(c)
    weld = a.derivation.get("params", {}).get("weld_size") or job.settings.get("weld_default")
    if weld:
        c.ptext(
            110, 97, "Fillet weld leg: " + weld + " (job default unless overridden on the connection)", 9, bold=True
        )
    if a.derivation.get("first_purlin_formula"):
        c.ptext(110, 78, a.derivation["first_purlin_formula"], 8)
    _title_block(c, job, a.qty, a.mark, a.mark, a.date)
    table_top = _bom_table(c, lines)
    if issues:
        _issues_banner(c, [i for i in issues if i.assembly == a.mark])

    # ---- elevation -------------------------------------------------------
    ext = V.elevation_extents(job, a)
    L = V.f(a.main.cut_length)
    d = a.main.sec.d
    sy = SY_ELEV
    x_left = BORDER[0] + 34 + ext.left_in * sy
    x_right = BORDER[2] - 34 - ext.right_in * sy
    sx = min(sy, (x_right - x_left) / L)
    if sx < (x_right - x_left) / L:  # true scale fits: centre
        slack = (x_right - x_left) - sx * L
        x_left += slack / 2
    y_row_top = 120.0
    y_top = y_row_top + 16 + ext.up_in * sy
    view = View(x_left, y_top + d * sy, sx, sy)
    y_row_bottom = view.py(0) + ext.down_in * sy + 18
    V.draw_elevation(Canvas(sh, view), job, a, y_row_top, y_row_bottom)
    embed = float(a.derivation.get("embed_in") or 0)
    if embed > 0 and a.kind == "COLUMN":  # post footing: the floor line is a shop mark on the post
        fl = Canvas(sh, view)
        fl.line(embed, -d * 0.35, embed, d * 1.35, S_CL)
        fl.text(embed, d * 1.35 + 4, "FLOOR LINE", 7, 0, "middle")
        fl.text(embed, -d * 0.35 - 2, Dim(Fraction(embed)).fmt() + " EMBED (POST FOOTING)", 7, 0, "middle")

    # ---- details region ----------------------------------------------------
    y_det_top = max(y_row_bottom + 34, 430.0)
    y_det_bot = table_top - 14
    h_avail = max(60.0, y_det_bot - y_det_top)
    x_cursor = BORDER[0] + 40
    for att in a.attachments:
        p = job.part(att.part)
        if p.kind != "stub":
            continue
        ssec = _sections.get_section(p.section)
        Ls = V.f(p.cut_length)
        clip_h = max([V.f(job.part(s.part).length) for s in p.attachments if s.face == "top"] + [0.0])
        plate_w = sum(
            V.f(job.part(s.part).width) + V.GAP_END + 4 for s in p.attachments if s.face in ("left_end", "right_end")
        )
        need_h = (ssec.d + clip_h) * S_DETAIL + 60
        s = S_DETAIL if need_h <= h_avail else max(4.0, (h_avail - 60) / (ssec.d + clip_h))
        left_pad = sum(V.f(job.part(t.part).width) + V.GAP_END + 4 for t in p.attachments if t.face == "left_end") * s
        vw = View(x_cursor + left_pad, y_det_bot - 22, s, s)
        V.draw_stub_detail(Canvas(sh, vw), job, p)
        label = p.mark
        cx = vw.px(Ls / 2)
        c.ptext(cx, y_det_bot - 4, label, TXT_DIM, 0, "middle")
        w = text_width(label, TXT_DIM)
        c.pline(cx - w / 2, y_det_bot - 2, cx + w / 2, y_det_bot - 2, S_DIM)
        x_cursor += left_pad + (Ls + plate_w) * s + 70

    # ---- section -----------------------------------------------------------
    station = _section_station(job, a)
    top, bottom, half = _section_extents(job, a, station)
    s = S_DETAIL
    if (top - bottom) * s + 40 > h_avail:
        s = max(4.0, (h_avail - 40) / (top - bottom))
    sec_cx = max(x_cursor + 110, 700.0)
    oy = y_det_top + 28 + top * s
    V.draw_section(Canvas(sh, View(sec_cx, oy, s, s)), job, a, station)
    sh.meta["section_station"] = None if station is None else Dim(Fraction(station).limit_denominator(64)).fmt()
    _footer(c, job, job.revision(), f"scale elev x 1:{72 / sx:.1f} y 1:{72 / sy:.1f}, details 1:{72 / s:.0f}")
    return sh


# --------------------------------------------------------------------------- cut sheet
def cut_sheet(job: M.Job, a: M.Assembly, qty: int) -> Sheet:
    mm = a.main
    sh = Sheet(mm.mark, "cut", meta={"mark": mm.mark, "kind": a.kind})
    c = Canvas(sh)
    _border(c)
    _mark_header(c, mm.mark, a.kind)
    if a.derivation.get("frame_id"):
        c.ptext(750, 32, "PARAMETRIC FRAME", 12, 0, "middle", bold=True)
    _title_block(c, job, qty, mm.mark, mm.mark, a.date)
    # header table
    xs = (74.4, 198.7, 250.0, 465.0, 545.0)
    y0, rh = BORDER[1], 20.0
    c.prect(xs[0], y0, xs[4], y0 + 2 * rh, S_TABLE)
    c.pline(xs[0], y0 + rh, xs[4], y0 + rh, S_TABLE)
    for x in xs[1:4]:
        c.pline(x, y0, x, y0 + 2 * rh, S_TABLE)
    hdr = ("COL/RAF", "QNT", "LOW POINT LENGTH" if "column_low_cut_in" in a.derivation else "BEAM LENGTH", "WEIGHT")
    w = M.WeightPolicy(member_decimals=1, member_mode="round").member(mm.sec.plf, mm.cut_length)
    vals = (
        mm.section,
        str(qty),
        M.D(a.derivation["column_low_cut_in"]).fmt() if "column_low_cut_in" in a.derivation else mm.cut_length.fmt(),
        f"{w:.1f}" if w is not None else "UNKNOWN",
    )
    for k in range(4):
        cx = (xs[k] + xs[k + 1]) / 2
        c.ptext(cx, y0 + rh - 5.5, hdr[k], TXT_BOM, 0, "middle")
        c.ptext(cx, y0 + 2 * rh - 5.5, vals[k], TXT_BOM, 0, "middle")
    # views
    L = V.f(mm.cut_length)
    sy = SY_ELEV
    x0, x1 = 253.0, 907.0
    sx = min(sy, (x1 - x0) / L)
    x0 += ((x1 - x0) - sx * L) / 2
    view = View(x0, 420.0, sx, sy)
    V.draw_cut_member(Canvas(sh, view), a)
    _footer(c, job, job.revision(), f"cut sheet, scale x 1:{72 / sx:.1f} y 1:{72 / sy:.1f}")
    return sh


# --------------------------------------------------------------------------- plate / piece sheet
def plate_sheet(job: M.Job, p: M.Part, qty: int) -> Sheet:
    if p.symbol.get("cut_contour"):
        from .fabrication_sheet import fabrication_sheet

        return fabrication_sheet(job, p, qty)
    sh = Sheet(p.mark, "plate", meta={"mark": p.mark, "kind": p.kind})
    c = Canvas(sh)
    _border(c)
    _mark_header(c, p.mark, "PART")
    _title_block(c, job, qty, p.mark, p.mark, "")
    # piece table (HPC style) top-right
    xs = (700.0, 740.0, 780.0, 850.0, 930.0, 1010.0, 1070.0, 1150.6)
    y0, rh = BORDER[1] + 84, 20.0
    c.prect(xs[0], y0, xs[7], y0 + 3 * rh, S_TABLE)
    for k in (1, 2):
        c.pline(xs[0], y0 + k * rh, xs[7], y0 + k * rh, S_TABLE)
    for x in xs[1:7]:
        c.pline(x, y0, x, y0 + 2 * rh, S_TABLE)
    hdr = ("ITEM", "QTY.", "MARK", "WIDTH", "LENGTH", "THICK", "WEIGHT")
    wt = p.weight(job.weights)
    vals = ("1", str(qty), p.mark, p.width.fmt(), p.length.fmt(), p.thk.fmt(), M.fmt_weight(wt, p.kind))
    for k in range(7):
        cx = (xs[k] + xs[k + 1]) / 2
        c.ptext(cx, y0 + rh - 6, hdr[k], TXT_DIM, 0, "middle")
        c.ptext(cx, y0 + 2 * rh - 6, vals[k], TXT_DIM, 0, "middle")
    c.ptext(xs[6] - 6, y0 + 3 * rh - 6, "TOTAL WT.", TXT_DIM, 0, "end")
    c.ptext(
        (xs[6] + xs[7]) / 2,
        y0 + 3 * rh - 6,
        M.fmt_weight((wt * qty).quantize(Decimal("0.01")), p.kind),
        TXT_DIM,
        0,
        "middle",
    )
    # face view
    pl, pw = V.f(p.length), V.f(p.width)
    avail_w, avail_h = 560.0, 480.0
    s = min(S_PLATE_MAX, (avail_w - 90) / pl, (avail_h - 110) / max(pw, 1.0))
    ox = 150.0 + ((avail_w - 90) - pl * s) / 2
    oy = 150.0 + 70 + pw * s
    V.draw_plate_face(Canvas(sh, View(ox, oy, s, s)), p, True, p.mark)
    c.ptext(
        110.0,
        680.0,
        f"PL {p.thk.fmt()} x {p.width.fmt()} x {p.length.fmt()}   ({p.kind.upper()})   unit weight {M.fmt_weight(wt, p.kind)} lb",
        TXT_DIM,
    )
    c.ptext(110.0, 696.0, f"source: {p.source}", TXT_DIM * 0.8)
    if p.notes:
        c.ptext(110.0, 710.0, p.notes, TXT_DIM * 0.8)
    if p.symbol.get("draft_connection"):
        if p.symbol.get("contour"):
            c.ptext(110, 612, "CUT CONTOUR VERTICES (inches): datum = lower-left blank corner; connect in order", 10)
            pts = p.symbol["contour"]
            for i, (x, y) in enumerate(pts):
                c.ptext(110 + (i % 3) * 260, 630 + (i // 3) * 16, f"P{i + 1}: x={x}  y={y}", 10)
    _footer(c, job, job.revision(), f"piece sheet, scale 1:{72 / s:.1f}")
    return sh


# --------------------------------------------------------------------------- job level
def usage(job: M.Job) -> tuple[dict[str, int], dict[str, int]]:
    """Total quantities per cut mark and per part mark across the job (assembly qty applied)."""
    mains: dict[str, int] = {}
    parts: dict[str, int] = {}
    for a in job.assemblies.values():
        mains[a.main.mark] = mains.get(a.main.mark, 0) + a.qty
        for l in M.bom(job, a)[1:]:
            parts[l.part] = parts.get(l.part, 0) + l.qty * a.qty
    from ..connections import quantities

    return mains, quantities(job, parts)


def drawing_part_quantities(job, primary=None):
    """Drawing totals include separate physical ends/leans, without changing BOM ownership."""
    parts = dict(usage(job)[1] if primary is None else primary)
    for a in job.assemblies.values():
        for mark, q in a.derivation.get('end_girt_clip_counts', {}).items():
            if mark in job.parts:
                parts[mark] = parts.get(mark, 0) + q
        for wall in a.derivation.get('endwalls', {}).values():
            r = wall.get('ridge_face_clip')
            if r:
                parts[r['mark']] = parts.get(r['mark'], 0) + r['quantity']
        for z in a.derivation.get('framing_additions', {}).get('lean_tos', []):
            for low in z.get('low_connection_parts', []):
                mark = low['part']['mark']
                if mark in job.parts:
                    parts[mark] = parts.get(mark, 0) + low['quantity']
            for r in z.get('roof_clip_schedule', []):
                parts[r['part_mark']] = parts.get(r['part_mark'], 0) + r['quantity']
    return parts


def all_sheets(job: M.Job, issues: Optional[list[M.ModelIssue]] = None) -> list[Sheet]:
    if issues is None:
        issues = M.validate(job)
    from .order_sheet import all_order_sheets

    out: list[Sheet] = []
    mains, parts = usage(job)
    from .frame_sheet import frame_sheet

    for frame_id, layout in job.settings.get('frame_layouts', {}).items():
        if layout.get('building_geometry'):
            from .building_sheet import building_sheet

            out.append(building_sheet(job, frame_id))
        out.append(frame_sheet(job, frame_id))
        from .. import frame_lines as FL
        from .frameline_sheets import frameline_sheet, roof_plan_sheet, sidewall_sheet

        for rec in FL.lines(job, frame_id):
            if rec['framed']:
                out.append(frameline_sheet(job, frame_id, rec['index']))
        out.append(sidewall_sheet(job, frame_id, 'front'))
        out.append(sidewall_sheet(job, frame_id, 'back'))
        out.append(roof_plan_sheet(job, frame_id))
        if frame_id in job.assemblies and (job.assemblies[frame_id].derivation.get('column_grades') or {}).get(
            'enabled'
        ):
            from .grade_sheet import grade_sheet

            out.append(grade_sheet(job, frame_id))  # column grade schedule (v0.8.43), only when entered
        if layout.get('welded'):
            from .welded_sheet import eave_sheet

            out.append(eave_sheet(job, frame_id))
        if layout.get('peak_clip'):
            from .ridge_sheet import ridge_sheet

            out.append(ridge_sheet(job, frame_id))
    for a in job.assemblies.values():
        if a.derivation.get('framing_additions'):
            from .additions_sheet import all_addition_sheets

            out.extend(all_addition_sheets(job, a.mark))
        if a.derivation.get('cladding'):
            from .cladding_sheet import all_cladding_sheets

            out.extend(all_cladding_sheets(job, a.mark))
        if a.derivation.get('endwalls'):
            import math

            from .endwall_sheet import cut_sheet as end_cut_sheet
            from .endwall_sheet import endwall_sheet

            for end, data in a.derivation['endwalls'].items():
                out.append(endwall_sheet(job, a.mark, end))
                if data.get('ridge_face_clip') or any(
                    r.get('head_connection') and r['role'] != 'outer column' for r in data.get('members', [])
                ):
                    from .endwall_joint_sheet import sheet as joint_sheet

                    out.append(joint_sheet(job, a.mark, end))
                out.extend(
                    end_cut_sheet(job, a.mark, end, page) for page in range(1, math.ceil(len(data['cuts']) / 18) + 1)
                )
        if a.derivation.get("secondary_runs"):
            from .run_sheet import cut_sheet as run_cut_sheet
            from .run_sheet import run_sheet

            out.extend([run_sheet(job, a.mark), run_cut_sheet(job, a.mark)])
        if a.derivation.get("secondary_catalog"):
            from .secondary_sheet import secondary_sheet

            out.append(secondary_sheet(job, a.mark))
        out.append(assembly_sheet(job, a, issues))
    seen: set[str] = set()
    for a in job.assemblies.values():
        if a.main.mark in seen:
            continue
        seen.add(a.main.mark)
        out.append(cut_sheet(job, a, mains[a.main.mark]))
    for mark, q in drawing_part_quantities(job, parts).items():
        p = job.part(mark)
        if p.symbol.get("connection"):
            from .connection_sheet import connection_sheet

            out.append(connection_sheet(job, p, q))
        if p.kind in ("plate", "clip") and None not in (p.thk, p.width, p.length):
            out.append(plate_sheet(job, p, q))
    out.extend(all_order_sheets(job))
    return out
