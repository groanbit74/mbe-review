"""Task-specific print sets. Legacy reference archive remains available separately.
Conservative grouping: no unequal geometry is silently treated as identical.
"""

import copy
import json

from ..ordering import DEPARTMENTS, build, fmt
from ..purchasing import supplier_plan
from .canvas import S_NOTE, S_TABLE, Canvas, Sheet, text_width
from .sheet import _border, _footer, _title_block, all_sheets, drawing_part_quantities, plate_sheet


def wrap(text, width, size=9):
    lines = []
    for paragraph in str(text).split('\n'):
        line = ''
        for word in paragraph.split():
            candidate = (line + ' ' + word).strip()
            if text_width(candidate, size) > width and line:
                lines.append(line)
                line = word
            else:
                line = candidate
            while text_width(line, size) > width and len(line) > 1:
                n = len(line) - 1
                while n > 1 and text_width(line[:n], size) > width:
                    n -= 1
                lines.append(line[:n])
                line = line[n:]
        lines.append(line)
    return lines or ['']


def tables(job, title, headers, widths, rows, notes=(), kind='packet'):
    """Variable-height rows, no clipped cells or dropped records."""
    widths = [w * 1000 / sum(widths) for w in widths]
    out = []
    page = 0

    def newpage():
        nonlocal page
        page += 1
        s = Sheet(title.replace(' ', '-') + '-' + str(page), kind)
        c = Canvas(s)
        _border(c)
        _title_block(c, job, 1, title[:28], 'PRINT', job.date)
        c.ptext(110, 66, title + ' / ' + str(page), 17, bold=True)
        from .packages import STATUS_REVIEW, drawing_status

        state = 'PROPOSED / REVIEW REQUIRED' if drawing_status(job) == STATUS_REVIEW else 'ISSUED FOR CONSTRUCTION'
        c.ptext(110, 88, 'Job ' + job.job_no + ' | ' + job.revision() + ' | ' + state, 10, style=S_NOTE)
        y = 115
        for note in notes:
            for line in wrap(note, 1000, 8):
                c.ptext(110, y, line, 8)
                y += 11
        y += 12
        x = 110
        for head, w in zip(headers, widths):
            c.ptext(x + 4, y, head, 9, bold=True)
            x += w
        _footer(
            c,
            job,
            job.revision(),
            'supplier totals and internal cutting are separate documents',
        )
        out.append(s)
        return c, y + 10

    c, y = newpage()
    fresh_capacity = int((681 - y - 12) / 12)
    for row in rows:
        if len(row) == 1:  # group heading spanning the table width
            if y + 30 > 681:
                c, y = newpage()
            c.pline(110, y, 1110, y, S_TABLE)
            c.ptext(114, y + 15, str(row[0]), 9.5, bold=True)
            y += 22
            continue
        cells = [wrap(t, w - 10, 9) for t, w in zip(row, widths)]
        count = max(map(len, cells))
        offset = 0
        while offset < count:
            available = int((681 - y - 12) / 12)
            if available < 1 or (offset == 0 and count <= fresh_capacity and count > available):
                c, y = newpage()
                continue
            take = min(available, count - offset)
            height = take * 12 + 12
            x = 110
            c.pline(110, y, 1110, y, S_TABLE)
            for lines, w in zip(cells, widths):
                shown = lines[offset : offset + take]
                if offset and not shown:
                    shown = [lines[0]]  # repeat stock/material identity on an unusually long continued row
                for i, line in enumerate(shown):
                    c.ptext(x + 4, y + 14 + i * 12, line, 9)
                x += w
            y += height
            offset += take
            if offset < count:
                c, y = newpage()
    return out


def supplier_sheets(job, plan=None):
    p = plan or build(job)
    s = supplier_plan(job, p)
    out = []
    for dep in DEPARTMENTS:
        rows = [
            [
                r['supplier_id'],
                str(x['quantity']) + ' ' + r['unit'],
                fmt(x['length_in']) if x['length_in'] is not None else '',
                r['supplier_code'],
                r['material'],
                r['finish'] + ' / ' + r['grade'],
            ]
            for r in s['rows']
            if r['department'] == dep
            for x in r['lengths']
        ]
        if rows:
            out += tables(
                job,
                'SUPPLIER - ' + dep.upper(),
                ['ITEM', 'QTY', 'LENGTH', 'SUPPLIER PART NO.', 'MATERIAL / GAUGE / SIZE', 'COLOR / FINISH / GRADE'],
                [60, 55, 115, 165, 345, 260],
                rows,
                [
                    'Purchasing list. Blank part number means no supplier code is recorded for the item. Internal cutting is on the shop set.'
                ],
                kind='supplier',
            )
    # A custom formed profile cannot be ordered by a stock SKU alone.
    from .residential_rake_sheet import sheet as rake

    seen = set()
    for fid, cfg in job.settings.get('frames', {}).items():
        if cfg.get('cladding', {}).get('trim_stock', {}).get('rake') == 'OWNER-FL1010-A4':
            key = (cfg.get('slope_rise'), json.dumps(cfg.get('cladding', {}).get('roof_finish', {}), sort_keys=True))
            if key not in seen:
                out.append(rake(job, fid))
                seen.add(key)
    return out


def stock_sheets(job, p):
    rows = []
    for b in sorted(
        p['bars'],
        key=lambda b: (
            DEPARTMENTS.index(b['department']),
            0 if b['profile'].startswith('W') else 1,
            b['profile'],
            b['finish'],
            b['stock_length_in'],
            b['stock_id'],
        ),
    ):
        cuts = '\n'.join(
            str(r['cut_sequence'])
            + '. '
            + r['cut_mark']
            + ' #'
            + str(r['instance'])
            + ' / '
            + fmt(r['blank_length_in'])
            + ' / start '
            + fmt(r['start_in'])
            + ' / '
            + r.get('location', 'Location review')
            for r in b['cuts']
        )
        rows.append(
            [
                b.get('supplier_id', '') + ' / ' + b['stock_id'],
                b['profile'] + ' / ' + b['finish'] + ' / ' + b['grade'],
                fmt(b['stock_length_in']),
                cuts,
                fmt(b['remnant_in']),
            ]
        )
    out = (
        tables(
            job,
            'SHOP - STOCK CUTTING',
            ['STOCK ID', 'MATERIAL', 'PURCHASE LENGTH', 'CUT MARK / BLANK / START', 'REMNANT'],
            [100, 230, 130, 440, 100],
            rows,
            [
                'Compatible main, end and lean members share material pools; no mixing of section, grade or finish.',
                'Kerf '
                + fmt(p['config']['kerf_in'])
                + ' between blanks; end allowance '
                + fmt(p['config']['end_allowance_in'])
                + ' EACH stock end. Final offcut separation is included in remnant. Long blanks, not low-point cuts.',
            ],
        )
        if rows
        else []
    )
    exact = [
        d
        for d in p['demands']
        if any(g['id'] == d['material_group'] and g['mode'] == 'exact' and g['planned_quantity'] for g in p['groups'])
    ]
    if exact:
        out += tables(
            job,
            'SHOP - EXACT CUTS',
            ['MARK', 'MATERIAL', 'QTY', 'BLANK', 'FIT / STATUS'],
            [210, 260, 60, 140, 330],
            [[r['mark'], r['profile'], r['quantity'], r['blank_length'], r['status']] for r in exact],
            ['Custom pieces use calculated order blanks and piece marks. Stock-end allowances are NOT added.'],
        )
    return out


def _group_details(job, source):
    """Merge only identical plate specs; retain alias marks and combined quantity."""
    counts = drawing_part_quantities(job)
    groups = {}
    replacement = {}
    omitted = {}
    for s in source:
        if s.kind != 'plate' or s.name not in job.parts:
            continue
        p = job.part(s.name)
        record = p.to_json()
        record.pop('mark', None)
        key = json.dumps(record, sort_keys=True)
        groups.setdefault(key, []).append(s)
    for same in groups.values():
        if len(same) < 2:
            continue
        alias = ', '.join(s.name for s in same)
        if text_width('SAME PIECE: ' + alias, 9) > 1000:
            continue
        first = same[0]
        rep = plate_sheet(job, job.part(first.name), sum(counts[s.name] for s in same))
        # Plain (not NOTE-layer) text: the alias line must survive the package composer.
        Canvas(rep).ptext(110, 715, 'SAME PIECE: ' + alias + ' (quantity above is combined)', 9, bold=True)
        replacement[id(first)] = rep
        for s in same[1:]:
            omitted[id(s)] = (
                first.name,
                'identical plate specification; aliases and combined quantity on representative',
            )
    # Identical walk section, with actual receiver aliases (not mirrored elevations).
    walk_groups = {}
    for s in source:
        if s.kind != 'additions' or '~walk_fit~' not in s.name:
            continue
        fid, _, index, _ = s.name.split('~')
        o = job.assemblies[fid].derivation['framing_additions']['openings'][int(index)]
        d = dict(o['walk_slip_fit'])
        for key in ('girt_member_ref', 'original_girt_station_in'):
            d.pop(key, None)
        key = json.dumps([d, o['section'], o.get('y_in')], sort_keys=True)
        walk_groups.setdefault(key, []).append((s, o))
    for same in walk_groups.values():
        if len(same) < 2:
            continue
        aliases = 'ALSO: ' + '; '.join(
            o['id'] + ' / ' + o['face'] + ' / ' + o['walk_slip_fit']['girt_member_ref'] for s, o in same[1:]
        )
        if text_width(aliases, 8) > 1000:
            continue
        first = copy.deepcopy(same[0][0])
        Canvas(first).ptext(110, 660, aliases + '; same frame / vertical fit.', 8, style=S_NOTE)
        replacement[id(same[0][0])] = first
        for s, o in same[1:]:
            omitted[id(s)] = (first.name, 'identical walk section; actual opening/receiver aliases retained')
    # End joint installation geometry can be common; retain EVERY head-cut row.
    for fid, a in job.assemblies.items():
        walls = a.derivation.get('endwalls', {})
        ends = [k for k, w in walls.items() if w.get('ridge_face_clip')]
        if len(ends) != 2:
            continue

        def jointkey(w):
            clip = dict(w['ridge_face_clip'])
            clip.pop('mark', None)
            return json.dumps(
                [clip, w['roof_left_in'], w['pitch_rise'], w['config']['resolved_rafter']], sort_keys=True
            )

        if jointkey(walls[ends[0]]) != jointkey(walls[ends[1]]):
            continue
        heads = [r for e in ends for r in walls[e]['members'] if r.get('head_connection')]
        if len(heads) > 6:
            continue  # existing detail has room for six complete rows
        originals = [s for s in source if s.kind == 'endjoint' and s.name in [fid + '~' + e + '~joints' for e in ends]]
        if len(originals) != 2:
            continue
        clone = copy.deepcopy(job)
        clone.assemblies[fid].derivation['endwalls'][ends[0]]['members'] = [
            r for r in walls[ends[0]]['members'] if r['role'] == 'endwall rafter'
        ] + heads
        from .endwall_joint_sheet import sheet as endjoint

        rep = endjoint(clone, fid, ends[0], quantity=2)
        rep.name = fid + '~common-end-joints'
        for item in rep.items:
            if hasattr(item, 'text'):
                item.text = item.text.replace(clone.revision(), job.revision())
                if 'ENDWALL / OWNER WELDED JOINTS' in item.text:
                    item.text = 'BOTH ENDWALLS / COMMON PEAK DETAIL + ALL HEAD CUTS'
                if '/ QTY1 THIS END' in item.text:
                    item.text = 'PEAK FACE CLIPS: QTY 2 / ONE EACH END'
        replacement[id(originals[0])] = rep
        omitted[id(originals[1])] = (rep.name, 'common peak geometry; ALL post/head cuts from BOTH ends included')
    return replacement, omitted


def packet(job, kind, plan=None, details_dir=None):
    """``(sheets, routing)`` for one print package.

    * ``'supplier'``  purchasing tables (unchanged)
    * ``'erection'``  the composed 22x17 erection set (``packages.erection_sheets``)
    * ``'shop'``      shipping list + assembly / cut / weldment / fabricated plate sheets
      (``packages.shop_sheets``); identical plates and common end joints are merged first
      (``_group_details``) so aliases and combined quantities stay on the representative sheet.

    ``routing`` lists where every archive sheet went (``print_manifest.json``).  The archive itself
    (every sheet, 11x17) stays available through ``/api/drawings.pdf``.
    """
    p = plan or build(job)
    if kind == 'supplier':
        return supplier_sheets(job, p), []
    from .packages import erection_sheets, routing, shop_sheets

    source = all_sheets(job)
    if kind == 'erection':
        out = erection_sheets(job, source, details_dir)
        return out, routing(source, out, kind)
    if kind == 'shop':
        replace, merged = _group_details(job, source)
        compact = [replace.get(id(s), s) for s in source if id(s) not in merged]
        out = shop_sheets(job, compact)
        aliases = {s.name: merged[id(s)][0] for s in source if id(s) in merged}
        return out, routing(source, out, kind, aliases)
    raise KeyError(f'unknown print package {kind!r}')


def export_packets(job, folder, plan=None, details_dir=None):
    from pathlib import Path

    from ..order_workbook import write_workbook
    from ..purchasing import write_supplier_workbook
    from .render_pdf import render_pdf

    root = Path(folder)
    root.mkdir(parents=True, exist_ok=True)
    p = plan or build(job)
    files = []
    manifest = {}
    from .packages import append_details, cover_rows_for_manifest, drawing_status

    for kind in ('supplier', 'shop', 'erection'):
        sheets, index = packet(job, kind, p, details_dir)
        path = root / (kind + '.pdf')
        render_pdf(sheets, str(path))
        files.append(str(path))
        manifest[kind] = dict(
            pages=len(sheets),
            sheets=[s.name for s in sheets],
            index=cover_rows_for_manifest(sheets),
            archive_sheet_routing=index,
        )
        if kind == 'erection':
            manifest[kind]['appended_details'] = append_details(path, details_dir)
    manifest['drawing_status'] = drawing_status(job)
    files.append(write_supplier_workbook(job, root / 'supplier_order.xlsx', p))
    files.append(write_workbook(job, root / 'internal_shop.xlsx', p))
    from ..material_reports import export_reports

    if p['config']['material_engine']['enabled'] or p['material_comparisons']:
        files += export_reports(p, root)
    cladding = {a.mark: a.derivation['cladding'] for a in job.assemblies.values() if a.derivation.get('cladding')}
    if cladding:
        path = root / 'cladding_layouts.json'
        path.write_text(json.dumps(cladding, indent=2))
        files.append(str(path))
    s = supplier_plan(job, p)
    for name, data in [('supplier_order.json', s), ('print_manifest.json', manifest)]:
        path = root / name
        path.write_text(json.dumps(data, indent=2))
        files.append(str(path))
    return files
