"""Frame-line drawing family.

* ``frameline_sheet``  – one elevation per frame line (interior rigid frame or end wall) with the
  roof line (TOP OF PURLIN) drawn dotted through the eave height at the frame pitch, labelled
  BYPASS (rafter top + purlin depth: interior frames and the standard W end rafters) or FLUSH
  (channel end walls / explicit override: rafter top = roof line).
* ``sidewall_sheet``   – front / back sidewall framing elevation (outside view): columns and end
  posts at every frame line, eave struts, girts, openings, bay enclosure states.
* ``roof_plan_sheet``  – roof framing plan: rafters at every frame line, purlin lanes per bay with
  the flush/bypass support condition at each line, lean-to roofs.

All three read the same frame-line index (``mbdp.detail.frame_lines``) so the station, the
line type and the roof datum rule are identical on every sheet.
"""

import math

from .. import frame_lines as FL
from ..connections import q
from ..purlin_lay import bays_text
from .canvas import LW_THIN, S_CL, S_NOTE, S_OBJ, S_TABLE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _mark_header, _title_block

S_ROOF = Style(layer='ROOF_LINE', width=LW_THIN, dash=(2, 2))
S_BUBBLE = Style(layer='DIM', width=LW_THIN)
S_LEAN = Style(layer='LEAN_ENVELOPE', width=0.8)
S_FUTURE = Style(layer='NOTE', width=LW_THIN, dash=(6, 3), color=(0.55, 0, 0))

SIDE_FACE = {'front': 'right', 'back': 'left'}  # sidewall name -> legacy face / piece side key
SIDE_TITLE = {'front': 'FRONT SIDEWALL', 'back': 'BACK SIDEWALL'}


def _fmt(x):
    try:
        return q(x).fmt()
    except Exception:
        return f'{x:.2f}"'


def _profile_depth(pid, default):
    try:
        from ..secondary_catalog import get

        return float(get(pid)['nominal_depth_in'])
    except Exception:
        return default


# ----------------------------------------------------------------------------- shared overlays
def roof_line_overlay(a, c, v, job, fid, rec, label_x=None):
    """Dotted roof line (top of purlin) + flush/bypass annotation on a frame elevation.

    ``a`` draws in frame coordinates (x across the width from the left/back wall, y above floor).
    """
    layout = job.settings['frame_layouts'][fid]
    W = float(layout['width_in'])
    roof = FL.roof_line(job, fid)
    mono = layout['frame_type'] == 'monoslope'
    mid = W if mono else W / 2
    ext = 6.0
    m = float(layout['slope_rise']) / 12
    a.line(-ext, roof(0) - ext * m, mid, roof(mid), S_ROOF)
    if not mono:
        a.line(mid, roof(mid), W + ext, roof(W) - ext * m, S_ROOF)
    off = rec['roof_offset_in']
    mode = rec['roof_mode'].upper()
    lx = label_x if label_x is not None else mid * 0.45
    if mode == 'BYPASS':
        text = 'ROOF LINE = TOP OF PURLIN = RAFTER TOP + ' + _fmt(rec['purlin_depth_in']) + ' PURLIN (BYPASS)'
    else:
        text = 'ROOF LINE = TOP OF PURLIN = RAFTER TOP (FLUSH MOUNT)'
    a.text(
        lx,
        roof(lx) + 7,
        text,
        8,
        math.degrees(math.atan(m)),
        'middle',
        style=Style(layer='ROOF_LINE'),
    )
    # Offset ticks at the left wall line: rafter top vs roof line (bypass only).
    if off > 1e-6:
        x = -ext - 2
        a.line(x - 3, roof(0) - off, x + 3, roof(0) - off, S_ROOF)
        a.line(x - 3, roof(0), x + 3, roof(0), S_ROOF)
        a.line(x, roof(0) - off, x, roof(0), S_ROOF)
        a.text(x - 4, roof(0) - off / 2 - 2, _fmt(off), 6.5, 0, 'end')


def banner(c, rec, y=50, job=None, fid=None):
    title, rule = FL.banner(rec)
    c.ptext(612, y, title, 11, 0, 'middle', bold=True)
    c.ptext(612, y + 13, rule, 8.5, 0, 'middle')
    if job is not None and fid is not None:
        c.ptext(612, y + 25, FL.heights(job, fid, rec), 8, 0, 'middle')


def frame_line_bubbles(c, v, job, fid, x_of, y_paper, size=10):
    """Numbered frame-line bubbles along a paper row; ``x_of`` maps a station to paper x."""
    for rec in FL.lines(job, fid):
        px = x_of(rec['station_in'])
        c.pcircle(px, y_paper, size, S_BUBBLE)
        c.ptext(px, y_paper + 3.5, str(rec['index']), 9, 0, 'middle', bold=True)
        c.ptext(px, y_paper + size + 9, _fmt(rec['station_in']), 6.5, 0, 'middle')


def line_schedule(c, job, fid, top=617, xs=(110, 150, 215, 400, 490, 770, 880)):
    """Frame-line table: line, station, what sits on it, rafter, roof mode, lean-tos."""
    headers = ['LINE', 'STATION', 'FRAME / WALL', 'RAFTER', 'ROOF PURLINS', 'LEAN-TOS']
    rows = []
    for rec in FL.lines(job, fid):
        rows.append(
            [
                str(rec['index']),
                _fmt(rec['station_in']),
                rec['label'],
                rec['rafter'] or '—',
                (
                    'BYPASS — ROOF LINE = TOP OF PURLIN = RAFTER TOP + '
                    + _fmt(rec['purlin_depth_in'])
                    + ' (rafter a purlin lower)'
                )
                if rec['roof_mode'] == 'bypass'
                else 'FLUSH MOUNT — PURLIN TOP FLUSH WITH THE RAFTER TOP (= ROOF LINE)',
                ', '.join(rec['lean_tos']) or '—',
            ]
        )
    row = 16
    for i, values in enumerate([headers] + rows):
        y = top + i * row
        c.pline(xs[0], y, xs[-1], y, S_TABLE)
        for k, value in enumerate(values):
            c.ptext(xs[k] + 4, y + 11.5, value, 7.5 if i else 7, bold=not i)
    bottom = top + (len(rows) + 1) * row
    c.pline(xs[0], bottom, xs[-1], bottom, S_TABLE)
    for x in xs:
        c.pline(x, top, x, bottom, S_TABLE)
    return bottom


# ----------------------------------------------------------------------------- per-line sheet
ARCHIVE_BOX = (82.0, 58.0, 1142.0, 688.0)  # drawing area of an 11x17 archive sheet above the title block


def frameline_sheet(job, fid, index):
    """Frame line ``index`` on an 11x17 archive sheet, drawn by ``erection_views`` - the same view the
    22x17 erection set prints (rigid frame cross section or end wall framing)."""
    from .erection_views import frame_line

    rec = FL.line(job, fid, index)
    if rec['kind'] == 'end' and not rec['framed']:
        raise KeyError(f'end wall {rec["wall_key"]} is not generated for {fid}')
    layout = job.settings['frame_layouts'][fid]
    name = 'FL%d-%s' % (rec['index'], fid)
    sh = Sheet(
        name,
        'frameline',
        meta={'frame_id': fid, 'frame_type': layout['frame_type'], 'setout': layout, 'frame_line': rec},
    )
    c = Canvas(sh)
    _border(c)
    _mark_header(c, name, 'FRAME LINE %d' % rec['index'])
    _title_block(c, job, layout['frames'] if rec['kind'] != 'end' else 1, name, fid, job.date)
    frame_line(sh, job, fid, rec, ARCHIVE_BOX)
    _footer(c, job, job.revision(), 'frame line %d of %d; %s' % (rec['index'], rec['count'], rec['label'].lower()))
    return sh


# ----------------------------------------------------------------------------- sidewall framing
def _pieces(job, fid):
    sr = job.assemblies[fid].derivation.get('secondary_runs') or {}
    return sr.get('pieces') or []


def _bays(job, fid):
    """[(bay_no, start_station, end_station, zone_record_or_None)]"""
    recs = FL.lines(job, fid)
    bz = job.settings['frame_layouts'][fid].get('bay_zones') or {}
    zones = bz.get('bays') or []
    out = []
    for i in range(len(recs) - 1):
        out.append((i + 1, recs[i]['station_in'], recs[i + 1]['station_in'], zones[i] if i < len(zones) else None))
    return out


def _bay_state(zone, face):
    if not zone:
        return 'sheeted', True
    state = zone.get(face) or 'sheeted'
    girts_now = state == 'sheeted' or bool(zone.get(face + '_girts_now'))
    return state, girts_now


def sidewall_sheet(job, fid, side):
    """Side wall framing elevation on an 11x17 archive sheet (``erection_views.sidewall``) with the
    frame-line schedule below it."""
    from .erection_views import sidewall

    if side not in SIDE_FACE:
        raise KeyError(side)
    name = 'SIDEWALL-' + ('F' if side == 'front' else 'B') + '-' + fid
    sh = Sheet(name, 'sidewall', meta={'frame_id': fid, 'side': side})
    c = Canvas(sh)
    _border(c)
    _mark_header(c, name, SIDE_TITLE[side] + ' FRAMING')
    _title_block(c, job, 1, name, fid, job.date)
    bottom = sidewall(sh, job, fid, side, (82.0, 58.0, 1142.0, 500.0))
    c.ptext(
        110,
        bottom + 12,
        'Frame-line bubbles are numbered from the LEFT END (station 0). RED dashed bays are open / future per the '
        'wall and bay settings; girts and sheets appear only where they are ordered now (secondary runs).',
        8,
    )
    line_schedule(c, job, fid, top=bottom + 24)
    _footer(c, job, job.revision(), 'sidewall framing elevation; outside view; floor and outside-wall datums')
    return sh


# ----------------------------------------------------------------------------- roof framing plan
def roof_plan_sheet(job, fid):
    layout = job.settings['frame_layouts'][fid]
    L = FL.length_in(job, fid)
    W = float(layout['width_in'])
    mono = layout['frame_type'] == 'monoslope'
    recs = FL.lines(job, fid)
    name = 'ROOF-PLAN-' + fid
    sh = Sheet(name, 'roofplan', meta={'frame_id': fid})
    c = Canvas(sh)
    _border(c)
    _mark_header(c, name, 'ROOF FRAMING PLAN')
    _title_block(c, job, 1, name, fid, job.date)
    if L <= 0:
        c.ptext(110, 140, 'Master building length is not set — no longitudinal layout to draw.', 10, style=S_NOTE)
        _footer(c, job, job.revision(), 'roof framing plan; no length')
        return sh
    # Plan mapping: x = station, y = W - frame_x (back wall at the top of the sheet).
    py_of = lambda frame_x: W - frame_x
    leans = [z for z in (layout.get('framing_additions') or {}).get('lean_tos', [])]
    ymin = min([0] + [-float(z.get('projection_in') or 0) for z in leans if z.get('face') == 'right'])
    ymax = max([W] + [W + float(z.get('projection_in') or 0) for z in leans if z.get('face') == 'left'])
    xmin = min([0] + [-float(z.get('projection_in') or 0) for z in leans if z.get('face') == 'front'])
    xmax = max([L] + [L + float(z.get('projection_in') or 0) for z in leans if z.get('face') == 'rear'])
    # Owner: no chart on this sheet - the plan itself fills the page (the line
    # schedule lives on the frame-line member schedule sheet)
    scale = min(1020 / (xmax - xmin + 30), 520 / (ymax - ymin + 20))
    v = View(130 + (1020 - (xmax - xmin) * scale) / 2 - xmin * scale, 600 + ymin * scale, scale, scale)
    a = Canvas(sh, v)
    a.rect(0, 0, L, W)
    if not mono:
        a.line(-8, py_of(W / 2), L + 8, py_of(W / 2), S_CL)
        a.text(L * 0.12, py_of(W / 2) + 3, 'RIDGE', 7, 0, 'middle')
    # wall captions sit in the middle of the longest bay, never on a frame-line rafter
    widest = max(_bays(job, fid), key=lambda b: b[2] - b[1], default=None)
    cap_x = (widest[1] + widest[2]) / 2 if widest else L / 2
    a.text(cap_x, W - 7, 'BACK SIDEWALL (EAVE)' + (' — LOW SIDE' if mono else ''), 7, 0, 'middle')
    a.text(cap_x, 3, 'FRONT SIDEWALL (EAVE)' + (' — HIGH SIDE' if mono else ''), 7, 0, 'middle')
    # Rafters at every frame line.
    ends = job.assemblies[fid].derivation.get('endwalls') or {}
    for rec in recs:
        x = rec['station_in']
        if rec['kind'] == 'end':
            a.line(x, 0, x, W, S_OBJ)
            a.line(x, 0, x, W, Style(layer='OBJECT', width=2.2))
            for post in (ends.get(rec['wall_key']) or {}).get('posts', []):
                w = float(post['width'])
                d = float(post['profile'].get('depth') or w)
                a.rect(x - d / 2, py_of(float(post['x'])) - w / 2, x + d / 2, py_of(float(post['x'])) + w / 2)
            tag = (
                'END RAFTER ' + (rec['rafter'] or '') + ' — FLUSH'
                if rec['roof_mode'] == 'flush'
                else 'END RAFTER ' + (rec['rafter'] or '') + ' — BYPASS (W PRESET, RAKE ANGLE)'
            )
        else:
            bf = 4.0
            try:
                bf = float(job.assemblies[fid].main.sec.bf)
            except Exception:
                pass
            for roof in layout['rafters']:
                x0 = min(roof['top_start'][0], roof['top_end'][0])
                x1 = max(roof['top_start'][0], roof['top_end'][0])
                a.rect(x - bf / 2, py_of(x1), x + bf / 2, py_of(x0))
            tag = (
                'RF ' + (rec['rafter'] or '') + ' — BYPASS'
                if rec['roof_mode'] == 'bypass'
                else 'RF ' + (rec['rafter'] or '') + ' — FLUSH'
            )
        a.text(x + 4, W * 0.28, tag, 6.5, 90, 'middle')
    # Purlin lanes and eave struts.
    pieces = [z for z in _pieces(job, fid) if z.get('role') in ('purlin', 'eave')]
    lanes = {}
    drawn = 0
    first_purlin_lane = {}  # one purlin lane per side carries the piece lengths (round 16: see where a stick spans)
    for z in pieces:
        s0 = z.get('start_in')
        s1 = z.get('end_in')
        if s0 is None or s1 is None:
            s0, s1 = z.get('support_start_in'), z.get('support_end_in')
        if s0 is None or s1 is None:
            continue
        fx = float(z.get('frame_x_in') if z.get('frame_x_in') is not None else (0 if z.get('side') == 'left' else W))
        y = py_of(fx)
        a.line(
            float(s0),
            y,
            float(s1),
            y,
            Style(layer='OBJECT', width=1.4) if z['role'] == 'purlin' else Style(layer='OBJECT', width=1.8),
        )
        a.line(float(s0), y - 1.2, float(s0), y + 1.2, S_OBJ)
        a.line(float(s1), y - 1.2, float(s1), y + 1.2, S_OBJ)
        key = (z['role'], z.get('side'), round(fx, 3))
        lanes.setdefault(key, z)
        if z['role'] == 'purlin' and z.get('cut_length') and first_purlin_lane.setdefault(z.get('side'), key) == key:
            label = z['cut_length'] + (' · 1 STICK, B' + bays_text(z) if z.get('span_bays', 1) > 1 else '')
            # centred in the FIRST bay of the piece, so the label never sits on an interior rafter it spans
            inside = sorted(r['station_in'] for r in recs if float(s0) + 1 < r['station_in'] < float(s1) - 1)
            mid = (float(s0) + (inside[0] if inside else float(s1))) / 2
            a.text(mid, y + 4, label, 6, 0, 'middle')
        drawn += 1
    for (role, side, fx), z in sorted(lanes.items(), key=lambda kv: -kv[0][2]):
        y = py_of(fx)
        label = ('EAVE STRUT ' if role == 'eave' else 'PURLIN ') + str(z.get('profile_id') or '')
        # measured from the EAVE to the peak, each side (owner 0.8.53)
        dist, wall = (fx, 'BACK') if fx <= W - fx else (W - fx, 'FRONT')
        a.text(L + 6, y - 1.5, label + ' — ' + _fmt(dist) + ' FROM ' + wall + ' EAVE', 6, 0, 'start')
    if not drawn:
        a.text(
            L / 2,
            W / 2 + 10,
            'PURLINS: generate secondary runs (products + bay layout) to show lanes and cut pieces',
            8,
            0,
            'middle',
            style=S_NOTE,
        )

    # Lean-to roofs.
    def lean_rafter_caption(z):
        lines = z.get('rafter_lines_resolved') or []
        if not lines:
            return 'rafter ' + str(z.get('rafter') or '(select)')
        if not z.get('mixed_rafter_lines'):
            rec = lines[0]
            fit = (
                'purlins IN the channel'
                if rec['in_channel']
                else 'purlins FLUSH, web-welded'
                if rec['fit'] == 'flush'
                else 'purlins BYPASS over the rafter'
            )
            pairs = sorted({q['pair'] for q in lines})
            sec = rec['profile_id'] + (' (single at the ends, doubled back to back inside)' if pairs == [1, 2] else '')
            return 'rafters ' + sec + ' - ' + fit
        return 'rafters by line: ' + ' / '.join(
            'L%d %s%s %s'
            % (
                q['station'],
                q['profile_id'],
                ' x2' if q['pair'] == 2 else '',
                'flush in channel' if q['in_channel'] else q['fit'],
            )
            for q in lines
        )

    for z in leans:
        P = float(z.get('projection_in') or 0)
        face = z.get('face')
        s0 = float(z.get('start_in') or 0)
        s1 = s0 + float(z.get('length_in') or 0)
        if face == 'left':
            # lean coordinates are the outside view of the back wall: mirror into the plan datum
            s0, s1 = L - s1, L - s0
        if face == 'right':
            a.rect(s0, -P, s1, 0, S_LEAN)
            cy = -P / 2
        elif face == 'left':
            a.rect(s0, W, s1, W + P, S_LEAN)
            cy = W + P / 2
        elif face == 'front':
            a.rect(-P, 0, 0, W, S_LEAN)
            cy = W / 2
        else:
            a.rect(L, 0, L + P, W, S_LEAN)
            cy = W / 2
        a.text(
            (s0 + s1) / 2 if face in ('left', 'right') else (-P / 2 if face == 'front' else L + P / 2),
            cy,
            z['id'] + ' LEAN-TO ROOF — ' + lean_rafter_caption(z),
            6.5,
            0,
            'middle',
            style=S_LEAN,
        )
        if face in ('left', 'right'):
            for rec in recs:
                if s0 - 1e-6 <= rec['station_in'] <= s1 + 1e-6:
                    y0, y1 = (0, -P) if face == 'right' else (W, W + P)
                    a.line(rec['station_in'], y0, rec['station_in'], y1, S_LEAN)
            # lean purlin rows (horizontal distance out from the main wall), each labelled
            rows = (z.get('roof_purlin_layout') or {}).get('rows') or []
            own_rows = [r for r in rows if not r.get('shared_main_eave')]
            for row in own_rows:
                x_out = float(row.get('horizontal_out_in') or 0)
                y = -x_out if face == 'right' else W + x_out
                a.line(s0, y, s1, y, S_LEAN)
                a.text(
                    s0 + 6 / scale,
                    y - 8 / scale,
                    str(row.get('profile_id') or '') + ' ' + _fmt(x_out) + ' OUT FROM MAIN WALL',
                    6,
                    0,
                    'start',
                    style=S_LEAN,
                )
            if rows:
                a.text(
                    (s0 + s1) / 2,
                    cy + 10 / scale,  # clear of the lean-to caption printed at cy
                    '%d purlin rows %s%s'
                    % (
                        len(own_rows),
                        rows[-1].get('profile_id', ''),
                        ' + MAIN EAVE SHARED AS THE TOP ROW' if len(own_rows) != len(rows) else '',
                    ),
                    6,
                    0,
                    'middle',
                    style=S_LEAN,
                )
    # Per-bay support condition.
    for bay_no, s0, s1, zone in _bays(job, fid):
        left = recs[bay_no - 1]
        right = recs[bay_no]
        label = ((zone or {}).get('id') or ('B%d' % bay_no)) + ' ' + _fmt(s1 - s0)
        a.text((s0 + s1) / 2, W + 11, label, 7.5, 0, 'middle', bold=True)
        a.text(
            (s0 + s1) / 2,
            W + 11 + 11 / scale,  # a text line below the bay caption whatever the plan scale (they overprinted)
            'L%d %s  <->  L%d %s'
            % (left['index'], left['roof_mode'].upper(), right['index'], right['roof_mode'].upper()),
            6.5,
            0,
            'middle',
        )
        c.dim_h(v.px(s0), v.px(s1), v.py(0), v.py(0), 618, _fmt(s1 - s0), size=8)
    c.dim_h(v.px(0), v.px(L), v.py(0), v.py(0), 640, _fmt(L) + ' OUTSIDE WALLS', size=10)
    c.dim_v(v.py(0), v.py(W), v.px(0), v.px(0), v.px(xmin) - 40, _fmt(W) + ' OUTSIDE WALLS', size=9, text_left=True)
    frame_line_bubbles(c, v, job, fid, lambda s: v.px(s), 664)
    _footer(c, job, job.revision(), f'roof framing plan 1:{72 / scale:.1f}; outside-wall datums')
    return sh
