"""Column grade schedule (v0.8.43): every column and post with the grade entered at its base, the
resulting bottom, cut length and shop mark; the wall base steps that follow; the main-column
variants (COL-1A ...).  One archive sheet per frame set, only when a grade is entered; placed in
the erection set (after the rigid frame sections) and in the shop set (after the shipping list)."""

from ..cladding import fmt
from ..grades import fmt_grade
from .canvas import Canvas, Sheet
from .erection_views import _schedule
from .sheet import _border, _footer, _title_block

COLS = (
    ('LINE', 36),
    ('WHERE', 232),
    ('MARK', 112),
    ('SECTION', 96),
    ('GRADE', 52),
    ('BOTTOM', 58),
    ('STD CUT', 66),
    ('CUT', 66),
    ('FOUNDATION', 150),
)
STEP_COLS = (('WALL', 150), ('FROM', 64), ('TO', 64), ('BASE / SHEETS', 90))
VARIANT_COLS = (('SHOP MARK', 80), ('OF', 60), ('GRADE', 52), ('QTY', 36), ('CUT', 70), ('FRAME LINES / SIDE', 160))
WALL_WORDS = {
    'left': 'BACK SIDEWALL (outside view)',
    'right': 'FRONT SIDEWALL (outside view)',
    'front': 'LEFT END WALL (outside view)',
    'rear': 'RIGHT END WALL (outside view)',
}


def name(fid):
    return 'GRADES-' + fid


def grade_sheet(job, fid):
    a = job.assemblies[fid]
    cg = a.derivation.get('column_grades') or {}
    sh = Sheet(name(fid), 'grades', meta={'frame_id': fid})
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, 1, 'COLUMN GRADES', fid, job.date)
    c.ptext(110, 62, 'COLUMN GRADE SCHEDULE - ' + fid, 16, bold=True)
    c.ptext(110, 80, 'SET LEVEL 0 = ' + str(cg.get('datum', '')).replace('SET LEVEL (0) = ', '') + '. ', 9)
    c.ptext(
        110,
        93,
        'Grade = top of slab (slab column) or ground level (post in a hole) AT THE COLUMN, relative to the set level; '
        '+ above, - below.  Eave, roof line and girt lines stay level: a column at a lower grade is cut longer by that amount.',
        8,
    )
    rows = []
    order = {'main': 0, 'post': 1, 'lean': 2}
    for r in sorted(
        cg.get('rows') or [],
        key=lambda r: (r.get('line') or 99, order.get(r['kind'], 9), r.get('x_in', r.get('station_in', 0.0))),
    ):
        rows.append(
            [
                str(r.get('line') or '-'),
                r['where'],
                r['shop_mark'] or r['mark'],
                r['section'],
                r['grade'],
                fmt_grade(r['bottom_in']) if abs(r['bottom_in']) > 1e-9 else '0"',
                fmt(r['standard_cut_in']),
                r['cut'] + (' *' if abs(r['grade_in']) > 1e-9 else ''),
                r['foundation'],
            ]
        )
    bottom = _schedule(c, 110 + sum(w for _, w in COLS), 104, rows, 'COLUMNS AND POSTS (* cut to its grade)', COLS)
    y = bottom + 10
    variants = cg.get('variants') or []
    if variants:
        vrows = [
            [
                v['mark'],
                v['of'],
                v['grade'],
                str(v['quantity']),
                v['cut'],
                ', '.join('%d %s' % (ln, side) for ln, side in v['lines']),
            ]
            for v in variants
        ]
        y = _schedule(
            c,
            110 + sum(w for _, w in VARIANT_COLS),
            y,
            vrows,
            'MAIN COLUMN MARKS BY LENGTH (the set-level group keeps the plain mark)',
            VARIANT_COLS,
        )
        y += 10
    steps = cg.get('base_steps') or {}
    srows = []
    for sid in sorted(steps):
        for x0, x1, g in steps[sid]:
            srows.append([WALL_WORDS.get(sid, sid.replace('_', ' ').upper()), fmt(x0), fmt(x1), fmt_grade(g)])
    if srows:
        y = _schedule(
            c,
            110 + sum(w for _, w in STEP_COLS),
            y,
            srows,
            'WALL SHEETS AND BASE ANGLE: BASE OFFSET BY BAY (' + str(cg.get('mixed_bay_rule', '')) + ')',
            STEP_COLS,
        )
        y += 10
    notes = [
        'Post in a hole: post length = top - ground level + hole depth; the ground line is a shop mark on the post.',
        'Slab column: the base plate sits on the slab at the grade shown; anchor rods by others at that elevation.',
    ] + [n for n in (cg.get('notes') or []) if 'ignored' in n]
    for i, n in enumerate(notes):
        c.ptext(110, min(y + 4 + 12 * i, 772), n, 8)
    _footer(c, job, job.revision(), 'column grades relative to the set level; dimensions in inches')
    return sh
