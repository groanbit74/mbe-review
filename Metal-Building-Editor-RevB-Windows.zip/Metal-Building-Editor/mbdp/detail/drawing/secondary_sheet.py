"""Source-controlled secondary nominal sections and explicit material takeoff."""

from ..connections import f, q
from .canvas import S_HID, S_NOTE, Canvas, Sheet, View
from .sheet import _border, _footer, _mark_header, _title_block


def secondary_sheet(job, fid):
    data = job.assemblies[fid].derivation
    selected = data['secondary_catalog']
    rows = data['secondary_material_rows']
    auto = data.get('secondary_runs')
    sh = Sheet('SECONDARIES-' + fid, 'secondaries')
    c = Canvas(sh)
    _border(c)
    _mark_header(c, sh.name, 'SUPPLIER PROFILES')
    _title_block(c, job, 1, sh.name, fid, job.date)
    c.ptext(612, 30, 'SUPPLIER PROFILES — NOMINAL CATALOG DIMENSIONS', 11, 0, 'middle', bold=True)
    c.ptext(
        110,
        74,
        'Selected supplier product envelopes | supplier-specific gauge/flange dimensions | unknown weights and fits remain held',
        10,
    )
    c.ptext(
        110,
        94,
        'Published envelope dimensions only. Gauge is NOT converted to thickness; lips/radii and installed orientation are unverified.',
        9,
        style=S_NOTE,
    )
    regular = [(role, x) for role, x in selected.items() if role not in ('high_eave_companion', 'base_angle')]
    if 'base_angle' in selected:
        base = selected['base_angle']
        c.ptext(
            110,
            113,
            'SLAB BASE: '
            + base['profile']['designation']
            + ' | '
            + base['selection']['finish']
            + ' | 2 vertical / 4 on slab | source p.20; quantities in run/endwall schedules when enabled.',
            8,
            style=S_NOTE,
        )
    for i, (role, item) in enumerate(regular):
        p = dict(item['profile'])
        p['designation'] = p['designation'].translate(
            str.maketrans({'½': '1/2', '⅛': '1/8', '⅜': '3/8', '⅝': '5/8', '⅞': '7/8', '¼': '1/4', '¾': '3/4'})
        )
        spec = item['selection']
        x = 110 + (i % 3) * 370
        y = 132 + (i // 3) * 205
        c.ptext(x, y, role.replace('_', ' ').upper() + ' — ' + p['designation'], 8, bold=True)
        c.ptext(
            x,
            y + 17,
            spec['finish']
            + ' | source p.'
            + str(p['pdf_page'])
            + ' | '
            + (str(p['weight_lb_ft']) + ' lb/ft' if p['weight_lb_ft'] is not None else 'published stock piece weight'),
            9,
        )
        depth = p['nominal_depth_in']
        fl = p['flanges_in']
        scale = min(11, 116 / depth)
        v = View(x + 70, y + 160, scale, scale)
        a = Canvas(sh, v)
        if p['family'] == 'Eave' or fl is None:
            w = max(fl) if fl else 3
            a.rect(0, 0, w, depth, S_HID)
            c.ptext(x + 175, y + 67, 'NOMINAL ENVELOPE ONLY', 9, style=S_NOTE)
            c.ptext(x + 175, y + 84, 'Pitch-dependent height / formed shape held.', 8, style=S_NOTE)
        else:
            left, right = fl[0], fl[-1]
            if p['family'] == 'Z':
                pts = [(-left, 0), (0, 0), (0, depth), (right, depth)]
            elif p['family'] == 'Angle':
                pts = [(right, 0), (0, 0), (0, depth)]
            else:
                pts = [(left, 0), (0, 0), (0, depth), (right, depth)]
            for aa, bb in zip(pts, pts[1:]):
                a.line(*aa, *bb)
            c.ptext(x + 175, y + 67, 'Flanges: ' + ' / '.join(q(z).fmt() for z in fl), 9)
            c.ptext(x + 175, y + 84, 'Lips / bend radii NOT drawn or assumed.', 8, style=S_NOTE)
        c.dim_v(v.py(0), v.py(depth), v.px(0), v.px(0), v.px(0) - 42, q(depth).fmt() + ' NOMINAL', size=8)
        if role == 'purlin':
            cfg = job.settings['frames'][fid]
            clip = job.part(cfg['purlin_clip'])
            c.ptext(x + 175, y + 105, 'Selected clip ' + clip.mark + ' | plate height ' + clip.length.fmt(), 8)
            c.ptext(x + 175, y + 121, 'Clip shown separately; no assumed web contact.', 8, style=S_NOTE)
            a.rect(8, 0, 8 + f(clip.thk), f(clip.length), S_NOTE)
        if auto and role != 'accessory':
            c.ptext(
                x, y + 185, 'AUTO RUNS: see RUN-CUTS-' + fid + ' for quantities and lengths (eave lengths pending).', 8
            )
        else:
            c.ptext(
                x,
                y + 185,
                'Ordered pieces: '
                + (
                    str(spec['quantity']) + ' x ' + spec['piece_length']
                    if spec.get('quantity')
                    else 'NOT PROVIDED — no inferred bay/lap quantities'
                ),
                8,
            )
    c.ptext(110, 563, 'SECONDARY MATERIAL TAKEOFF — separate from primary frame/connection BOM', 10, bold=True)
    for i, row in enumerate(rows[:4] if auto else rows):
        c.ptext(
            110,
            586 + i * 19,
            row['role'].replace('_', ' ').upper()
            + ': '
            + str(row['total_lot_pieces'] or '—')
            + ' pieces; '
            + str(row['ordered_piece_length'] or 'length pending')
            + '; estimated lot weight '
            + str(row['estimated_lot_weight_lb'] or 'NOT TOTALLED')
            + (' lb' if row['estimated_lot_weight_lb'] else ''),
            9,
        )
    if auto:
        c.ptext(
            110,
            672,
            'Preview only: FULL automatic schedule on RUN-CUTS-' + fid + ' and secondary_run_cut_list.csv.',
            9,
            style=S_NOTE,
        )
    if 'high_eave_companion' in selected and not auto:
        c.ptext(
            110,
            677,
            'Mono high-eave companion: '
            + selected['high_eave_companion']['profile']['designation']
            + ' / '
            + selected['high_eave_companion']['profile']['eave_kind']
            + '; quantity pending.',
            8,
        )
    c.ptext(
        110,
        701,
        (
            'Project length/fit rules applied; supplier lap applicability and formed eave fit remain held. No punching/capacity approval.'
            if auto
            else 'No bay lengths, laps, end deductions, punching, capacities or prices inferred. Enter TOTAL lot pieces, not pieces per frame.'
        ),
        9,
        style=S_NOTE,
    )
    c.ptext(
        110,
        720,
        'Eave nominal height varies with pitch. Linked manual eave sizes conflict with current catalog; no silent substitution.',
        9,
        style=S_NOTE,
    )
    _footer(
        c,
        job,
        job.revision(),
        'Source URLs, revision, page numbers and SHA256 retained in secondary_catalog_snapshot.json',
    )
    return sh
