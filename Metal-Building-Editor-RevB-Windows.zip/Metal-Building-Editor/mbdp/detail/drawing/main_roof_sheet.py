"""Main-building roof setout and complete marked piece list; lean boundary not double-counted."""

from ..ordering import fmt
from ..purlin_lay import bays_text
from .canvas import S_HID, Canvas, Sheet, Style, View
from .print_packets import tables


def rows(job, fid):
    r = job.assemblies[fid].derivation.get('secondary_runs', {})
    return [dict(p, quantity=1) for p in r.get('pieces', []) if p['role'] in ('purlin', 'eave', 'high_eave')]


def sheets(job, fid):
    run = job.assemblies[fid].derivation.get('secondary_runs', {})
    pieces = rows(job, fid)
    if not pieces or 'building_geometry' not in job.settings.get('frame_layouts', {}).get(fid, {}):
        return []
    lanes = [r for r in run['lanes'] if r['role'] in ('purlin', 'eave', 'high_eave')]
    g = job.settings['frame_layouts'][fid]['building_geometry']
    W = g['width_in']
    L = g['length_in']
    sh = Sheet('MAIN-ROOF-' + fid, 'roof_plan')
    c = Canvas(sh)
    c.ptext(64, 57, 'MAIN BUILDING / ROOF PURLIN PLAN', 22, bold=True)
    c.ptext(64, 84, 'TOP VIEW / positions from saved secondary runs / ' + job.revision(), 10)
    c.ptext(
        64,
        108,
        'Main roof only. Lean-to rows have their own schedule. Shared main eave remains counted HERE, not twice.',
        10,
    )
    sc = min(790 / L, 380 / W)
    v = View(290, 555, sc, sc)
    a = Canvas(sh, v)
    a.rect(0, 0, L, W, Style(width=0.7, color=(0.4, 0.4, 0.4)))
    if g['shape'] == 'gable':
        a.line(0, W / 2, L, W / 2, S_HID)
        c.ptext(v.px(L) + 15, v.py(W / 2), 'RIDGE', 9)
    for s in run['support_lines']:
        x = s['station_in']
        a.line(x, 0, x, W, S_HID)
        c.ptext(v.px(x), v.py(W) - 25, 'SUPPORT ' + str(s['line']), 9, anchor='middle')
    for row in lanes:
        y = row['frame_x_in']
        own = [p for p in pieces if p['run_id'] == row['run_id']]
        color = (0.12, 0.34, 0.54) if row['role'] == 'purlin' else (0.28, 0.47, 0.35)
        c.ptext(65, v.py(y) + 3, row['run_id'].replace(fid + '-', '') + ' / ' + row['role'].upper(), 9)
        for p in own:
            lo = p['start_in'] if p['cut_length_in'] is not None else p['support_start_in']
            hi = p['end_in'] if p['cut_length_in'] is not None else p['support_end_in']
            a.line(lo, y, hi, y, Style(width=1.5, color=color))
            a.line(lo, y - 2, lo, y + 2, Style(width=0.6, color=color))
            a.line(hi, y - 2, hi, y + 2, Style(width=0.6, color=color))
            c.ptext(
                v.px((lo + hi) / 2),
                v.py(y) - 7,
                'B' + bays_text(p) + ' / ' + (p['cut_length'] or 'HELD'),
                8,
                anchor='middle',
            )
    c.dim_h(v.px(0), v.px(L), 555, 555, 594, fmt(L) + ' MAIN BUILDING LENGTH', size=10)
    c.ptext(
        64,
        637,
        'BACK SIDEWALL: X=0 in across the frame. FRONT SIDEWALL: X=' + fmt(W) + '. Longitudinal origin: LEFT ENDWALL.',
        10,
    )
    c.ptext(
        64,
        662,
        'Piece marks, sections, bay endpoints and cut lengths follow on the schedule. Row setout is the model datum, not a new flange offset.',
        10,
    )
    c.ptext(
        64,
        704,
        'SHOP / ERECTION REVIEW: modeled zero-gap cuts retained. No capacity, punching or connection approval implied.',
        9,
    )
    vals = [
        [
            p['piece_id'],
            p['cut_mark'],
            p['profile_id'],
            bays_text(p) + ' / ' + fmt(p['start_in']) + ' to ' + fmt(p['end_in'])
            if p['cut_length_in'] is not None
            else 'HELD',
            fmt(p['frame_x_in']),
            p['cut_length'] or 'HELD',
            1,
        ]
        for p in pieces
    ]
    out = [sh] + tables(
        job,
        'MAIN ROOF - PURLIN AND EAVE PIECES',
        ['PIECE MARK', 'CUT GROUP', 'SECTION', 'BAY / LENGTH STATIONS', 'FRAME X', 'CUT LENGTH', 'QTY'],
        [240, 145, 190, 175, 85, 110, 55],
        vals,
        [
            'Every main-roof piece listed once, including the eaves. Shared lean high row is a reference to the main eave, not extra material.',
            'FRAME X is horizontal across the main frame from the BACK wall. Bay stations run from LEFT endwall. Connection fit is separate.',
        ],
    )
    return out
