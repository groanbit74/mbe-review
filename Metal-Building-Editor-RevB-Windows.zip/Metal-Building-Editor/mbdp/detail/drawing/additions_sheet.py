"""Lean-to / selected opening / rake-angle coordinate review sheets."""

import math
import textwrap

from ..cladding import fmt
from ..frame import FrameParams
from ..framing_additions import profile, roof_height
from .canvas import S_HID, S_NOTE, S_TABLE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _title_block


def descriptors(m):
    for i, z in enumerate(m.get('lean_tos', [])):
        yield 'lean', i, 1
        if z.get('roof_purlin_layout'):
            for page in range(1, math.ceil(len(z['roof_purlin_layout']['pieces']) / 12) + 1):
                yield 'lean_purlins', i, page
        if z.get('low_connection_detail'):
            yield 'low_detail', i, 1
        if z.get('rafter_cut_detail'):
            yield 'rafter_cuts', i, 1
        if z.get('wall_framing') and (z['wall_framing'].get('framed') or z['wall_framing'].get('status')):
            yield 'lean_walls', i, 1
        yield 'connection', i, 1
        if z.get('transition_detail'):
            yield 'transition_detail', i, 1
        if z.get('end_plate_geometry', {}) and z['end_plate_geometry']['geometry_valid']:
            yield 'end_plate', i, 1
        for page in range(1, math.ceil(len(z.get('flush_clips', [])) / 10) + 1):
            yield 'flush_clip', i, page
        for page in range(1, math.ceil(len(z['members']) / 14) + 1):
            yield 'members', i, page
    for i, r in enumerate(m.get('openings', [])):
        # No separate door-opening sheets (owner 0.8.55): openings are folded into
        # the wall / frame-line framing sheets, drawn and dimensioned there in the
        # same style as the rest of the set.  Only connection details remain.
        if r.get('connection_detail'):
            yield 'opening_detail', i, 1
            for page in range(1, math.ceil(len(r['connection_detail']['girt_segments']) / 16) + 1):
                yield 'opening_girts', i, page
    if m.get('rake_angles'):
        yield 'rake', 0, 1


def additions_sheet(job, fid, kind, index=0, page=1):
    if kind in ('lean_purlins', 'walk_fit'):
        from .owner_fit_sheet import sheet

        return sheet(job, fid, kind, index, page)
    if kind == 'rafter_cuts':
        from .lean_rafter_sheet import sheet

        return sheet(job, fid, index)
    if kind == 'low_detail':
        from .lean_low_sheet import sheet

        return sheet(job, fid, index)
    if kind == 'lean_walls':
        from .lean_walls_sheet import sheet

        return sheet(job, fid, index)
    if kind == 'opening_sections':
        from .opening_sections import opening_sections

        return opening_sections(job, fid, index)
    if kind in ('opening_detail', 'opening_girts', 'transition_detail'):
        from .template_sheet import template_sheet

        return template_sheet(job, fid, kind, index, page)
    if kind == 'end_plate':
        from ..lean_connections import end_plate_part
        from .fabrication_sheet import fabrication_sheet

        rec = job.assemblies[fid].derivation['framing_additions']['lean_tos'][index]['end_plate_geometry']
        return fabrication_sheet(job, end_plate_part(rec), rec['quantity'])
    if kind == 'flush_clip':
        from .flush_clip_sheet import flush_clip_sheet

        return flush_clip_sheet(job, fid, index, page)
    model = job.assemblies[fid].derivation['framing_additions']
    p = FrameParams.from_json(job.settings['frames'][fid])
    name = 'ADD-' + fid + '-' + kind.upper() + '-' + str(index + 1) + '-' + str(page)
    sh = Sheet(name, 'additions')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, 1, name, fid, job.date)
    c.ptext(970, 52, 'FRAMING ADDITIONS', 13, bold=True)
    c.ptext(970, 73, kind.upper(), 11)
    _footer(
        c,
        job,
        job.revision(),
        'primary uprights unchanged; openings and lean-tos framed per the project default details',
    )

    def lines(text, y=605, size=8):
        for line in textwrap.wrap(text, 145):
            c.ptext(110, y, line, size, style=S_NOTE)
            y += 14

    def table(heads, rows, top=160, widths=(110, 350, 570, 790, 1110), rh=31):
        for i, row in enumerate([heads] + rows):
            y = top + i * rh
            c.pline(widths[0], y, widths[-1], y, S_TABLE)
            for j, text in enumerate(row):
                for k, line in enumerate(
                    textwrap.wrap(str(text), max(8, int((widths[j + 1] - widths[j] - 10) / 4)))[:3]
                ):
                    c.ptext(widths[j] + 4, y + 10 + k * 9, line, 7.5, bold=i == 0)
        end = top + (len(rows) + 1) * rh
        c.pline(widths[0], end, widths[-1], end, S_TABLE)
        for x in widths:
            c.pline(x, top, x, end, S_TABLE)

    if kind in ('lean', 'connection', 'members'):
        z = model['lean_tos'][index]
        rf = profile(z.get('rafter', ''))
        _resolved_lines = z.get('rafter_lines_resolved') or []

        def _line_order(line):
            station = next(
                (q for q in z.get('stations') or [] if q.get('index') == line.get('station')),
                {},
            )
            return int(station.get('frame_line') or line.get('station') or 0)

        _special_lines = [q for q in _resolved_lines if q.get('special_open_c')]
        _display_line = (
            min(_special_lines, key=_line_order)
            if _special_lines
            else min(_resolved_lines, key=_line_order)
            if _resolved_lines
            else {}
        )
        _display_profile = profile(_display_line.get('profile_id')) if _display_line.get('profile_id') else rf
        rd = _display_profile['depth'] if _display_profile else 8
        _rafter_deduction = float(
            _display_line.get('purlin_deduction_in', z.get('purlin_deduction_in', z.get('purlin_depth_in', 0)))
        )
        _purlin_depth = float(z.get('purlin_depth_in') or 0)
        _display_fit = _display_line.get('fit') or z.get('purlin_mode', '')
        c.ptext(110, 76, z['id'] + ' - ' + z['elevation'].upper(), 13, bold=True)
        c.ptext(
            110,
            100,
            'Low eave '
            + fmt(z['low_eave_in'])
            + ' | pitch '
            + str(z['pitch'])
            + ':12 | projection '
            + fmt(z['projection_in'])
            + ' | high eave '
            + fmt(z['high_eave_in']),
            10,
        )
        if kind == 'lean':
            P = z['projection_in']
            H = z['low_eave_in']
            hi = z['high_eave_in']
            top = max(hi, roof_height(p, z['face'], z['start_in'])) + 24
            sc = min(550 / max(P, 1), 270 / top)
            v = View(265, 437, sc, sc)
            a = Canvas(sh, v)
            inside = z.get('rafter_seat_resolved') == 'inside_flange' and z['low_connection'] != 'bolted'
            cd = profile(z['column'])['depth'] if z.get('column') and profile(z['column']) else 0
            a.line(-12, 0, P + 12, 0)
            a.line(0, 0, 0, top - 12, Style(width=1.2))
            if inside and cd:
                # Post to the selected line's rafter top datum; rafter stops at the post inside face.
                a.poly(
                    [
                        (P - cd, 0),
                        (P, 0),
                        (P, H - _rafter_deduction),
                        (P - cd, H - _rafter_deduction + cd * z['pitch'] / 12),
                    ]
                )
                a.line(
                    P - cd,
                    H - _rafter_deduction + cd * z['pitch'] / 12,
                    P - cd,
                    H - _rafter_deduction + cd * z['pitch'] / 12 - rd,
                )
            else:
                a.line(P, 0, P, max(1, H - _rafter_deduction - rd), Style(width=1.2))
            a.line(0, hi, P, H, Style(width=1.2))  # roof line black, set style (owner 0.8.55)
            a.line(0, hi - _purlin_depth, P, H - _purlin_depth, S_HID)
            a.line(0, hi - _rafter_deduction - rd, P, H - _rafter_deduction - rd, S_HID)
            _line_station = _display_line.get('station')
            _station_record = next(
                (q for q in z.get('stations') or [] if q.get('index') == _line_station),
                {},
            )
            _line_name = _station_record.get('frame_line') or _line_station or '-'
            _profile_name = _display_line.get('profile_id') or z.get('rafter', '')
            _fit_name = 'FLUSH IN CHANNEL' if _display_line.get('in_channel') else str(_display_fit).upper()
            c.ptext(
                110,
                130,
                'CROSS SECTION — FRAME LINE %s: %s — %s; high/low are TOP-OF-PURLIN datums'
                % (_line_name, _profile_name, _fit_name),
                10,
                bold=True,
            )
            high_text = {
                'welded_direct': (z.get('high_connection_detail') or {}).get('summary')
                or 'welded directly to the main column outside face (plumb end, no gap)',
                'clip': 'welded clip at the main column outside face, rafter end %g in clear'
                % float(z.get('high_gap_in', 0)),
                'end_plate': 'bolted end plate at the outside column face',
            }.get(z['high_connection'], z['high_connection'] + ' at outside column face')
            c.ptext(110, 155, 'High: ' + high_text, 9)
            low = z.get('low_connection_detail') or {}
            c.ptext(
                110,
                173,
                'Low: ' + (low.get('seat') or z['low_connection'] + ' monoslope style'),
                9,
            )
            c.dim_h(v.px(0), v.px(P), v.py(0), v.py(0), 465, fmt(P) + ' PROJECTION', size=9)
            c.ptext(850, 220, 'Roof fit (Line %s): %s' % (_line_name, _fit_name), 9)
            c.ptext(850, 241, 'Wall secondary: ' + z['girt_mode'], 9)
            c.ptext(850, 262, 'Paired middle Cees:', 9)
            c.ptext(850, 278, 'BACK-TO-BACK / WEBS TOUCH', 8)
            c.ptext(
                110,
                500,
                'ALONG ATTACHMENT FACE: '
                + fmt(z['start_in'])
                + ' to '
                + fmt(z['start_in'] + z['length_in'])
                + ' / '
                + str(len(z['stations']))
                + ' existing upright stations',
                10,
                bold=True,
            )
            length = z['length_in']
            scale = 900 / length
            c.pline(130, 547, 1030, 547)
            for st in z['stations']:
                x = 130 + (st['x_in'] - z['start_in']) * scale
                c.pline(x, 536, x, 558)
                if len(z['stations']) <= 16:
                    c.ptext(x, 575, str(st['index']) + ': ' + fmt(st['x_in']), 7.5, anchor='middle')
            from .. import holds as H

            walls = z.get('walls') or {}
            c.ptext(
                110,
                602,
                'Walls: outer '
                + walls.get('outer', 'open').upper()
                + ' / start end '
                + walls.get('start_end', 'open').upper()
                + ' / finish end '
                + walls.get('finish_end', 'open').upper()
                + ' / main wall below '
                + walls.get('main_below', 'sheeted').upper()
                + (
                    '. Wall-to-roof transition trim ' + fmt(length) + ' (custom formed, 26 ga).'
                    if z.get('roof_continuity') != 'main_plane'
                    else '. Roof follows the main roofline: no transition flashing.'
                ),
                8,
            )
            open_items = H.actionable(z['issues'])
            if open_items:
                lines(' '.join(open_items[:3]), 616)
            if z.get('roof_purlin_layout') and z['roof_purlin_layout'].get('mixed_support_fit'):
                c.ptext(
                    110,
                    671,
                    'Purlin fit is per frame line: special open-C ends are flush in-channel; W supports use the listed bypass/flush fit. The low-eave row is outside-face flush and direct-welded to the post. See lean purlin schedule.',
                    8,
                )
            elif z.get('roof_purlin_layout') and z['roof_purlin_layout'].get('in_channel'):
                c.ptext(
                    110,
                    671,
                    'Roof purlin rows are in the rafter channel (1/4 in from web); the low-eave row is outside-face flush and direct-welded to the post. Eave strut over the plumb end; see lean purlin schedule.',
                    8,
                )
            elif z.get('roof_purlin_layout'):
                c.ptext(110, 671, 'Lean roof purlins over the rafters: see the lean purlin schedule.', 8)
            else:
                lines(
                    'Lean-to roof purlin takeoff not generated: switch on the lean roof purlins (lean-to dialog).',
                    671,
                )
            if z.get('wall_framing'):
                c.ptext(110, 687, (z['wall_framing'].get('status') or '') + ' - see the LEAN WALLS sheet.', 8)
        elif kind == 'connection':
            c.ptext(110, 125, 'HIGH ATTACHMENT / OUTSIDE COLUMN FACE - SELECTED CONNECTION', 10, bold=True)
            face = min((st['main_face_width_in'] for st in z['stations']), default=8)
            g = float(z.get('hole_gauge', '0').rstrip('"')) if z.get('hole_gauge') else None
            t = float(z.get('hole_pitch', '0').rstrip('"')) if z.get('hole_pitch') else None
            diagram_height = max(10, (t or 4) + 2)
            scale = min(26, 240 / max(face, g or 0, 1), 260 / diagram_height)
            v = View(380, 470, scale, scale)
            a = Canvas(sh, v)
            a.rect(-face / 2, 0, face / 2, diagram_height)
            hs = z.get('high_connection_schedule') or []
            modes = {row.get('mode') for row in hs} or {z['high_connection']}
            has_clip = 'clip' in modes
            has_plate = 'end_plate' in modes
            c.ptext(
                110,
                151,
                (
                    'Web CENTERPLANES align; welded clip is offset to contact rafter web. See dimensioned clip sheet.'
                    if has_clip
                    else 'Centered on existing column outside face. No holes applied to its CNC file.'
                ),
                9,
            )
            selected = 'PER-SUPPORT' if z.get('high_connection_overrides') else z['high_connection']
            c.ptext(650, 195, 'Selected: ' + selected, 11, bold=True)
            c.ptext(650, 218, 'Clip: one per station; double angle: two.', 9)
            c.ptext(650, 240, 'Bolted end plate: four holes per applicable station.', 9)
            for i, row in enumerate(hs[:8]):
                c.ptext(
                    650, 355 + i * 15, f"Line {row['station']} {row['main_mark']}: {row['mode']} / {row['source']}", 8
                )
            if len(hs) > 8:
                c.ptext(650, 355 + 8 * 15, f"+ {len(hs) - 8} supports; see lean_low_connections.csv", 8, style=S_NOTE)
            if z.get('bolt_preset'):
                c.ptext(650, 335, 'SP2:4x A325 5/8in x2in; hole/grip/edge review', 9, style=S_NOTE)
            c.ptext(650, 265, 'Gauge: ' + (fmt(float(z['hole_gauge'])) if z.get('hole_gauge') else 'PENDING'), 9)
            c.ptext(
                650, 285, 'Vertical pitch: ' + (fmt(float(z['hole_pitch'])) if z.get('hole_pitch') else 'PENDING'), 9
            )
            c.ptext(
                650,
                305,
                'Hole diameter: ' + (fmt(float(z['hole_diameter'])) if z.get('hole_diameter') else 'PENDING'),
                9,
            )
            for dx, dy in ((-1, -1), (1, -1), (-1, 1), (1, 1)) if has_plate else ():
                x = dx * (g / 2 if g else face * 0.22)
                y = diagram_height / 2 + dy * (t / 2 if t else 2)
                a.circle(x, y, float(z.get('hole_diameter', '0.5"').rstrip('"')) / 2, style=S_HID)
            if has_clip:
                off = (z.get('flush_clips') or [{}])[0].get('clip_center_offset_in') or 0
                a.line(off, 1, off, 9, Style(width=1.2))
            if z['high_connection'] == 'double_angle':
                for side in (-1, 1):
                    a.line(side, 1, side, 9, Style(width=1.2))
                    a.line(side, 1, side * face * 0.4, 1, Style(width=1.2))
            c.ptext(
                110,
                501,
                'Dashed pattern is schematic unless all hole dimensions supplied. X origin = column face center; Y above finished floor.',
                9,
            )
            if z['holes']:
                table(
                    ['STATION 1 / MAIN MARK', 'X FROM FACE CENTER', 'Y ABOVE FLOOR', 'HOLE / STATUS'],
                    [
                        [
                            r['main_mark'],
                            fmt(r['x_from_face_center_in']),
                            fmt(r['y_above_floor_in']),
                            fmt(r['diameter_in']) + ' REVIEW',
                        ]
                        for r in z['holes'][:4]
                    ],
                    520,
                    rh=22,
                )
            lines(
                'Full station-by-station coordinates: lean_to_holes.csv. Plate/angle/clip contours, bolt edge distances, weld fit and capacity are NOT approved. '
                + ' '.join(z['issues'][:2]),
                662,
            )
        else:
            c.ptext(
                110, 125, 'MEMBER REFERENCES / PAGE ' + str(page) + ' - counts are ONE lean-to, not main frame lot', 10
            )
            table(
                ['MARK / ROLE', 'PROFILE', 'QTY / REFERENCE ENVELOPE', 'STATUS'],
                [
                    [
                        r['mark'] + ' / ' + r['role'],
                        r['profile'],
                        str(r['quantity'])
                        + ' / '
                        + (fmt(r['reference_length_in']) if r['reference_length_in'] else 'CUT HOLD'),
                        r['status'] + (' / ' + r.get('paired_webs', '')),
                    ]
                    for r in z['members'][(page - 1) * 14 : page * 14]
                ],
                155,
            )
            lines(
                'Where WELDED PLUMB END PLANES are derived, see the lean rafter cut sheet/CSV for theoretical long blanks. Other rafter envelopes remain reference only. Low-column cuts follow their dedicated detail; no paired-Cee stitch pattern or HSS drilling program is invented.',
                665,
            )
    elif kind == 'opening':
        r = model['openings'][index]
        W = float(p.width.inches) if r['face'] in ('front', 'rear') else float(p.length.inches)
        x = r['x_in']
        w = r['width_in']
        y = r['y_in']
        h = r['height_in']
        hw = r['header_face']
        lo = max(0, x - max(w * 0.35, 36))
        hi = min(W, x + w + max(w * 0.35, 36))
        top = max(y + h + hw + 24, *[m['y1_in'] + 12 for m in r['members']], 1)
        sc = min(800 / max(hi - lo, 1), 280 / top)
        v = View(190 - lo * sc, 450, sc, sc)
        a = Canvas(sh, v)
        c.ptext(110, 76, r['id'] + ' - ' + r['elevation'].upper(), 13, bold=True)
        c.ptext(110, 100, '6in clearance to UNRELATED uprights; shared bearing jambs are the opening boundaries', 10)
        c.ptext(
            110,
            121,
            'Requested / last moved X '
            + fmt(r.get('previous_move', {}).get('from_in', r['requested_x_in']))
            + ' -> actual X '
            + fmt(x)
            + ' | '
            + r['status'],
            10,
            style=S_NOTE,
        )
        for u in r['uprights']:
            if lo <= u['x'] <= hi and not (r.get('bearing_jambs') and u.get('opening_id') == r['id']):
                a.rect(
                    u['x'] - u['width'] / 2, 0, u['x'] + u['width'] / 2, min(top, u['top']), Style(fill=(0.8, 0.8, 0.8))
                )
                a.text(u['x'], min(top, u['top']) + 5, u['mark'], 7, anchor='middle')
        for q in r['members']:
            a.rect(q['x0_in'], q['y0_in'], q['x1_in'], q['y1_in'], Style(fill=(0.7, 0.85, 1), color=(0.1, 0.3, 0.5)))
        a.rect(x, y, x + w, y + h, Style(width=1.5, color=(0.65, 0.1, 0.05)))
        c.dim_h(v.px(x), v.px(x + w), v.py(y), v.py(y), 481, fmt(w) + ' CLEAR BETWEEN JAMB FACES', size=9)
        c.ptext(
            110,
            507,
            'Bottom '
            + fmt(y)
            + ' | clear height '
            + fmt(h)
            + (
                ' | SHARED roof-bearing jambs; counted once as endwall posts'
                if r.get('bearing_jambs')
                else ' | WALK SLIP-IN FRAME / no extra fabricated jambs'
                if r.get('walk_slip_fit')
                else ' | ordinary jambs to header top'
            ),
            9,
        )
        table(
            ['MEMBER', 'PROFILE', 'REFERENCE LENGTH', 'CUT / CONNECTION'],
            [
                [
                    q['mark'],
                    q['profile'],
                    fmt(q['reference_length_in']),
                    'SHARED POST / SEE ENDWALL; NOT EXTRA QTY'
                    if q.get('shared_member_ref')
                    else 'SOURCE-TEMPLATE CUT / FIT REVIEW'
                    if q.get('cut_length_in') is not None
                    else 'REFERENCE ONLY / END FIT PENDING',
                ]
                for q in r['members']
            ],
            526,
            rh=23,
        )
        lines(
            ' / '.join(r['issues'])
            or 'Clearance resolved. Member ends, base/anchors, girt termination, section orientation and structural design still require review.',
            659,
        )
    else:
        c.ptext(110, 76, 'SHEETED ENDWALL RAKE ANGLES - BOTH ENDS', 13, bold=True)
        c.ptext(110, 100, '2in leg ON TOP OF PURLIN / 4in leg DOWN wall; follow roof pitch', 10)
        a = Canvas(sh, View(340, 270, 30, 30))
        a.line(0, 0, 2, 0, Style(width=3))
        a.line(2, 0, 2, -4, Style(width=3))
        a.text(1, 1, '2in TOP', 10, anchor='middle')
        a.text(3, -2, '4in DOWN', 10)
        c.ptext(650, 220, 'Existing selected 2x4 base-angle profile / finish.', 10)
        c.ptext(650, 241, 'Rake orientation is NOT slab orientation.', 10)
        c.ptext(650, 262, '20ft stock segmented for procurement planning.', 10)
        c.ptext(650, 283, 'Butt joints / support / fasteners remain held.', 10)
        groups = {}
        for r in model['rake_angles']:
            key = (r['face'], r['length_in'], r['profile'])
            groups[key] = groups.get(key, 0) + 1
        table(
            ['ENDWALL', 'PROFILE', 'SEGMENT / QTY', 'ORIENTATION'],
            [[k[0], k[2], fmt(k[1]) + ' / ' + str(q), '2in TOP /4in DOWN'] for k, q in groups.items()],
            430,
            rh=29,
        )
        lines(
            'Source: uploaded erection1273522, D1/SD10 and D7/TD35 show rake angle;2x4 orientation is the USER rule. This is not proof of joint design or approval to cut primary members.',
            654,
        )
    return sh


def all_addition_sheets(job, fid):
    return [
        additions_sheet(job, fid, k, i, p)
        for k, i, p in descriptors(job.assemblies[fid].derivation['framing_additions'])
    ]
