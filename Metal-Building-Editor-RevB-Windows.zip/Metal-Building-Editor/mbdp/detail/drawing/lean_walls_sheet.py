"""Lean-to walls sheet (v0.8.35): outer wall and both end walls of one lean-to.

Each wall is drawn as an outside elevation with its state (SHEETED / OPEN), the lean posts
on the main framing lines, the lean end posts, the girt lines and the girt cut lengths; the
right-hand table lists every girt piece with its fit rule.
"""

import textwrap

from ..cladding import fmt
from ..framing_additions import profile
from .canvas import S_HID, S_TABLE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _title_block

BLUE = Style(width=1.2)  # roof line in black like the rest of the set (owner 0.8.53)


def sheet(job, fid, index):
    z = job.assemblies[fid].derivation['framing_additions']['lean_tos'][index]
    fr = z.get('wall_framing') or {}
    walls = z.get('walls') or {}
    sh = Sheet(fid + '~lean_walls~' + str(index) + '~1', 'additions')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, len(z['stations']), 'LEAN WALLS', z['id'], job.date)
    c.ptext(110, 63, z['id'] + ' / LEAN-TO WALLS - ' + z['elevation'].upper(), 16, bold=True)
    state = ', '.join(
        k.replace('_', ' ') + ' ' + walls.get(k, 'open').upper()
        for k in ('outer', 'start_end', 'finish_end', 'main_below')
    )
    c.ptext(110, 86, 'Walls: ' + state, 9.5)
    c.ptext(
        110,
        104,
        'Girts: '
        + (fr.get('girt_profile_id') or 'none')
        + ' / '
        + str(fr.get('girt_mode', 'flush'))
        + ' / '
        + ('web weld' if fr.get('girt_attachment', 'web_weld') == 'web_weld' else 'web clips')
        + ' | lines '
        + (', '.join(fmt(y) for y in fr.get('girt_lines_in', [])) or '-')
        + ' | lean posts '
        + str(z.get('column') or '-')
        + ' | end posts: '
        + str(z.get('end_posts', 'auto')),
        9,
    )
    _datum = (
        'DATUM: slab - lean posts on base plates at the slab'
        if z.get('foundation') == 'slab'
        else 'DATUM: lean posts in post holes '
        + str(z.get('footing_diameter') or '18"')
        + ' dia x '
        + str(z.get('footing_depth') or "3'-0\"")
        + ' deep (ground line is a shop mark on the post; post length = top - ground + hole depth)'
    )
    c.ptext(110, 122, _datum, 9)
    c.ptext(1120, 122, 'ROOF LINE (TOP OF PURLIN)', 9, anchor='end')
    _footer(c, job, job.revision(), fr.get('status') or 'roof only: all lean walls open')
    P = z['projection_in']
    H = z['low_eave_in']
    hi = z['high_eave_in']
    L = z['length_in']
    col = profile(z['column']) if z.get('column') else None
    cw = (col or {}).get('width') or 4
    girts = z.get('wall_girts', [])
    lines = fr.get('girt_lines_in', [])

    def label(x, y, text, size=8, bold=False, anchor='start'):
        c.ptext(x, y, text, size, bold=bold, anchor=anchor)

    # ---- outer wall (top band)
    label(
        110,
        136,
        'OUTER WALL - outside view, X along the main face from the lean start  ('
        + walls.get('outer', 'open').upper()
        + ')',
        9.5,
        True,
    )
    sc = min(560 / max(L, 1), 110 / max(H, 1))
    v = View(130, 290, sc, sc)
    a = Canvas(sh, v)
    a.line(-6, 0, L + 6, 0)
    if z.get('foundation') == 'slab':
        a.rect(-6, -6, L + 6, 0, Style(width=0.6, color=(0.5, 0.5, 0.5)))
        label(v.px(L) + 8, v.py(0) + 4, '6" SLAB - FLOOR = TOP OF SLAB', 7)
    else:
        label(v.px(L) + 8, v.py(0) + 4, 'GROUND LINE AT FLOOR HEIGHT', 7)
    a.line(0, H, L, H, BLUE)
    for st in z['stations']:
        x = st['x_in'] - z['start_in']
        a.rect(x - cw / 2, 0, x + cw / 2, H)
    for g in girts:
        if walls.get('outer') == 'sheeted' and g.get('wall') == 'outer' and g.get('cut_length_in') is not None:
            x0 = g['start_in'] - z['start_in']
            a.line(x0, g['y_in'], x0 + g['cut_length_in'], g['y_in'], S_HID)
    if walls.get('outer') == 'sheeted':
        for i in range(1, int(L // 36) + 1):
            a.line(i * 36, 0, i * 36, H, Style(width=0.4, color=(0.6, 0.6, 0.6)))
    c.dim_h(v.px(0), v.px(L), v.py(0), v.py(0), v.py(0) + 22, fmt(L) + ' LEAN LENGTH', size=8)
    _bay_pts = sorted({0.0, L} | {st['x_in'] - z['start_in'] for st in z['stations']})
    for _a, _b in zip(_bay_pts, _bay_pts[1:]):
        if _b - _a > 1:
            c.dim_h(v.px(_a), v.px(_b), v.py(0), v.py(0), v.py(0) + 42, fmt(_b - _a), size=7.5)
    for st in z['stations']:
        label(
            v.px(st['x_in'] - z['start_in']),
            v.py(0) + 58,
            (st.get('main_mark') or '').replace(fid + '-', ''),
            6.5,
            anchor='middle',
        )
    a.text(L / 2, H + 6, 'ROOF LINE (TOP OF PURLIN)', 7, 0, 'middle')
    c.dim_v(v.py(H), v.py(0), v.px(L), v.px(L), v.px(L) + 24, fmt(H) + ' LOW EAVE', size=8)
    if walls.get('outer') == 'sheeted':
        for y in lines:
            # girt-line callout on the LEFT of the view (the piece table sits to the right)
            label(v.px(0) - 58, v.py(y) + 3, 'G ' + fmt(y), 7)
    # ---- end walls (bottom band)
    for key, x0, title in (
        ('start_end', 110, 'START END - main wall on the LEFT'),
        ('finish_end', 420, 'FINISH END - main wall on the RIGHT'),
    ):
        label(x0, 360, title + '  (' + walls.get(key, 'open').upper() + ')', 9.5, True)
        sc2 = min(260 / max(P, 1), 150 / max(hi, 1))
        v2 = View(x0 + 20, 560, sc2, sc2)
        b = Canvas(sh, v2)
        mirror = key == 'finish_end'

        def X(d, mirror=mirror):
            return P - d if mirror else d

        b.line(X(-6), 0, X(P + 6), 0)
        b.line(X(0), hi, X(P), H, BLUE)
        b.line(X(0), 0, X(0), hi + 6, Style(width=1.2))  # main column line
        b.rect(min(X(P), X(P - cw)), 0, max(X(P), X(P - cw)), H)
        end = fr.get(key) or {}
        for post in end.get('posts', []):
            d = post['station_from_main_wall_in']
            pw = cw
            b.rect(min(X(d - pw / 2), X(d + pw / 2)), 0, max(X(d - pw / 2), X(d + pw / 2)), post['top_in'])
        for g in girts:
            if walls.get(key) == 'sheeted' and g.get('wall') == key and g.get('cut_length_in') is not None:
                b.line(X(g['start_in']), g['y_in'], X(g['end_in']), g['y_in'], S_HID)
        if walls.get(key) == 'sheeted':
            for i in range(1, int(P // 36) + 1):
                d = i * 36
                b.line(X(d), 0, X(d), hi - d * (hi - H) / P, Style(width=0.4, color=(0.6, 0.6, 0.6)))
        c.dim_h(v2.px(X(0)), v2.px(X(P)), v2.py(0), v2.py(0), v2.py(0) + 20, fmt(P) + ' PROJECTION', size=8)
        _pts = sorted({0.0, P} | {post['station_from_main_wall_in'] for post in end.get('posts', [])})
        for _a, _b in zip(_pts, _pts[1:]):
            if _b - _a > 1:
                _xa, _xb = sorted((v2.px(X(_a)), v2.px(X(_b))))
                c.dim_h(_xa, _xb, v2.py(0), v2.py(0), v2.py(0) + 38, fmt(_b - _a), size=7)
        for post in end.get('posts', []):
            label(
                v2.px(X(post['station_from_main_wall_in'])),
                v2.py(post['top_in']) - 4,
                post['mark'].split('-')[-1],
                6.5,
                anchor='middle',
            )
    # ---- girt table (right)
    heads = ['PIECE', 'WALL', 'ELEV', 'CUT', 'FIT']
    widths = (735, 830, 890, 935, 1000, 1120)
    rows = [
        [
            g['mark'].replace(fid + '-' + z['id'] + '-', ''),
            g.get('wall', '').replace('_', ' '),
            fmt(g['y_in']),
            g.get('cut_length', '-'),
            g['status'],
        ]
        for g in girts
    ][:22]
    top = 136
    c.ptext(735, 125, 'LEAN GIRT PIECES (' + str(len(girts)) + ')', 10, bold=True)
    rh = 20
    for i, row in enumerate([heads] + rows):
        y = top + i * rh
        c.pline(widths[0], y, widths[-1], y, S_TABLE)
        for j, text in enumerate(row):
            wrap = textwrap.wrap(str(text), max(6, int((widths[j + 1] - widths[j] - 6) / 3.6)))[:2]
            for k, line in enumerate(wrap):
                c.ptext(widths[j] + 3, y + 8 + k * 8, line, 6.5, bold=i == 0)
    endy = top + (len(rows) + 1) * rh
    c.pline(widths[0], endy, widths[-1], endy, S_TABLE)
    for x in widths:
        c.pline(x, top, x, endy, S_TABLE)
    if len(girts) > 22:
        c.ptext(735, endy + 12, '... %d more pieces on the cut list' % (len(girts) - 22), 7)
    posts = [m for m in z.get('members', []) if m.get('role') == 'lean end post']
    y = endy + 30
    if posts:
        c.ptext(735, y, 'LEAN END POSTS', 10, bold=True)
        for m in posts:
            y += 14
            c.ptext(
                735,
                y,
                m['mark'].replace(fid + '-' + z['id'] + '-', '')
                + '  '
                + m['profile']
                + '  cut '
                + fmt(m['cut_length_in'])
                + ' (blank '
                + fmt(m['blank_length_in'])
                + ')',
                7.5,
            )
    y += 24
    for note in fr.get('notes', []):
        for line in textwrap.wrap(note, 80):
            c.ptext(735, y, line, 7)
            y += 11
    return sh
