"""Orthographic exterior views from saved geometry, with depth-sorted opaque faces.
No image generation, phantom enclosure, or manufacturer substitutions.
Current supported envelope: sheeted gable main + welded lean roofs on any wall (side or end).
Unsupported geometry fails visibly rather than producing a misleading customer view.
"""

import math

from ..building import name
from ..framing_additions import profile
from ..model import D
from ..ordering import fmt
from .canvas import Canvas, Sheet, Style, View


def rgb(h):
    return tuple(int(h[i : i + 2], 16) / 255 for i in (1, 3, 5))


def model(job, fid, lean_rake="model"):
    if lean_rake not in ("model", "exposed", "sss"):
        raise ValueError("Unknown lean rake alternative")
    a = job.assemblies[fid]
    c = a.derivation.get('cladding', {})
    g = job.settings['frame_layouts'][fid]['building_geometry']
    if g['shape'] != 'gable' or not c or not c['config'].get('walls') or not c['config'].get('roof'):
        raise ValueError('Customer exterior renderer currently requires a sheeted gable main building')
    W = g['width_in']
    L = g['length_in']
    H = g['low_eave_height_in']
    s = g['pitch_rise'] / 12
    leans = a.derivation.get('framing_additions', {}).get('lean_tos', [])
    for z in leans:
        if z.get('roof_continuity') == 'main_plane' and abs(z['pitch'] / 12 - s) > 1e-6:
            raise ValueError('A lean roof that continues the main roof plane must carry the main pitch')
        if z['walls']['main_below'] == 'open' or not z.get('rafter_cut_detail') or not z.get('low_connection_detail'):
            raise ValueError(
                'Customer view requires verified lean cut geometry and retained main wall; unsupported geometry is not guessed'
            )
    cfg = c['config']
    faces = []
    zones = job.assemblies[fid].derivation.get('bay_zones', {})
    front_station = zones.get('enclosed_left_station_in', 0)
    from ..cladding import catalog as trim_catalog

    trim_profiles = {r['id']: r for r in trim_catalog('all')['trims']}

    def face_width(role):
        return trim_profiles.get(cfg.get('trim_stock', {}).get(role), {}).get('face_in')

    rib_step = int(c.get('profile', {}).get('rib_spacing_in', 12))

    def add(pts, color, tag='', ribs=(), priority=0):
        faces.append(dict(points=pts, color=color, tag=tag, ribs=list(ribs), priority=priority))

    def prism(poly, y0, y1, color, tag):
        add([(x, y0, z) for x, z in poly], color, tag)
        add([(x, y1, z) for x, z in poly], color, tag)
        for (x, z), (u, v) in zip(poly, poly[1:] + poly[:1]):
            add([(x, y0, z), (u, y0, v), (u, y1, v), (x, y1, z)], color, tag)

    wall = rgb(cfg['wall_finish']['hex'])
    trim = rgb(cfg['trim_finish']['hex'])
    steel = (0.43, 0.46, 0.48)

    # The sheet skin sits OUTSIDE the frame (on the girts), not on the wall line: frame
    # prisms are centred on / flush with the wall line and would otherwise poke half their
    # depth through the sheeting and paint over it (owner: "the frame is sticking out of
    # the walls"). 9 in clears an 8 in girt plus the sheet and every frame face behind it;
    # members in FRONT of the wall (lean posts under an open lean) still show, correctly.
    WALL_SKIN_IN = 9.0

    def surface_map(sid, u, z, offset=0):
        offset += WALL_SKIN_IN
        return {
            'outer_front': (u, -offset, z),
            'front': (u, front_station - offset, z),
            'rear': (W - u, L + offset, z),
            'right': (W + offset, u, z),
            'left': (-offset, L - u, z),
        }[sid]

    # Main wall faces and aperture masks use the saved OUTSIDE-view coordinates.
    for surf in c['surfaces']:
        sid = surf['id']
        if sid not in ('front', 'rear', 'left', 'right', 'outer_front'):
            continue
        width = surf['width_in']
        top = surf['top_profile']
        bottom = surf['bottom_in']
        col = rgb(surf['finish']['hex'])

        def height(u):
            for (x, z), (xx, zz) in zip(top, top[1:]):
                if x - 1e-8 <= u <= xx + 1e-8:
                    return z + (zz - z) * (u - x) / (xx - x)
            return top[-1][1]

        vsid = 'front' if sid == 'outer_front' else sid
        ranges = surf.get('sheeted_intervals', [(0, width)])
        for lo, hi in ranges:
            ribs = [
                (surface_map(sid, u, bottom, 0.015), surface_map(sid, u, height(u), 0.015))
                for u in range(int(lo) + rib_step, int(hi), rib_step)
            ]
            cap = [(lo, height(lo))] + [(x, z) for x, z in top if lo < x < hi] + [(hi, height(hi))]
            add(
                [surface_map(sid, lo, bottom), surface_map(sid, hi, bottom)]
                + [surface_map(sid, x, z) for x, z in reversed(cap)],
                col,
                'wall:' + vsid,
                ribs,
            )
        # Color accents follow actual trim runs; width is a diagrammatic line, not a formed-section dimension.
        for x in sorted({v for r in ranges for v in r}):
            face = face_width('corner')
            if face:
                start_edge = any(abs(x - lo) < 1e-7 for lo, hi in ranges)
                a = x if start_edge else max(0, x - face)
                b = min(width, x + face) if start_edge else x
                add(
                    [
                        surface_map(sid, a, bottom, 0.025),
                        surface_map(sid, b, bottom, 0.025),
                        surface_map(sid, b, height(b), 0.025),
                        surface_map(sid, a, height(a), 0.025),
                    ],
                    trim,
                    'corner-face:' + vsid,
                    priority=1,
                )
            elif cfg['trim_stock'].get('corner'):
                add(
                    [surface_map(sid, x, bottom, 0.025), surface_map(sid, x, height(x), 0.025)],
                    trim,
                    'trim-line:' + vsid,
                    priority=1,
                )
        for o in surf['openings']:
            x = o['x_in']
            y = o['y_in']
            w = o['width_in']
            h = o['height_in']
            pts = [
                surface_map(sid, x, y, 0.05),
                surface_map(sid, x + w, y, 0.05),
                surface_map(sid, x + w, y + h, 0.05),
                surface_map(sid, x, y + h, 0.05),
            ]
            lines = []
            if w >= 80:
                lines = [
                    (surface_map(sid, x, y + v, 0.055), surface_map(sid, x + w, y + v, 0.055))
                    for v in range(12, int(h), 12)
                ]
            add(pts, (0.94, 0.94, 0.92), 'opening:' + vsid + ':' + o['id'], lines, 2)
            for aa, bb in ((pts[0], pts[3]), (pts[3], pts[2]), (pts[2], pts[1])):
                add([aa, bb], trim, 'trim-line:' + vsid, priority=3)
            # shop standard (owner): jamb and head trim faces are 1 1/2 in wide, and the
            # head runs to the OUTSIDE of each jamb so the three pieces square off
            jw = hw = 1.5
            for a, b in ((max(0, x - jw), x), (x + w, min(width, x + w + jw))):
                add(
                    [
                        surface_map(sid, a, y, 0.065),
                        surface_map(sid, b, y, 0.065),
                        surface_map(sid, b, y + h, 0.065),
                        surface_map(sid, a, y + h, 0.065),
                    ],
                    trim,
                    'jamb-face:' + vsid,
                    priority=3,
                )
            add(
                [
                    surface_map(sid, max(0, x - jw), y + h, 0.065),
                    surface_map(sid, min(width, x + w + jw), y + h, 0.065),
                    surface_map(sid, min(width, x + w + jw), y + h + hw, 0.065),
                    surface_map(sid, max(0, x - jw), y + h + hw, 0.065),
                ],
                trim,
                'head-face:' + vsid,
                priority=3,
            )
    # Roof surface mapping retains combined main/lean roof extents and saved overhangs.
    for surf in c['surfaces']:
        if surf['id'] not in ('roof_left', 'roof_right'):
            continue
        side = 1 if surf['id'] == 'roof_right' else -1
        co = 1 / math.sqrt(1 + s * s)
        ridge_z = H + W / 2 * s
        start = surf['bottom_in']
        front_oh = float(D(cfg.get('roof_front_overhang', '0')).inches)
        # the unfolded slope runs from the LEFT end overhang; a lean over SOME bays steps it
        prof = [(x - front_oh, start + run) for x, run in surf['top_profile']]

        def rp(y, t):
            return (W / 2 + side * t * co, y, ridge_z - t * co * s)

        def end_at(y):
            for (xa, ta), (xb, tb) in zip(prof, prof[1:]):
                if xa - 1e-8 <= y <= xb + 1e-8:
                    return ta if abs(xb - xa) < 1e-9 else ta + (tb - ta) * (y - xa) / (xb - xa)
            return prof[-1][1]

        y0 = prof[0][0]
        y1 = prof[-1][0]
        end = prof[0][1]  # slope length at the left end (full-length lean: everywhere)
        ribs = [(rp(y, start), rp(y, end_at(y))) for y in range(rib_step, int(L), rib_step)]
        add(
            [rp(y0, start), rp(y1, start)] + [rp(x, t) for x, t in reversed(prof)],
            rgb(surf['finish']['hex']),
            'roof:' + ('right' if side == 1 else 'left'),
            ribs,
        )
        stepped = len(prof) > 2
        # rakes down the lean's open ends where the sheets step (lean over some bays)
        for (xa, ta), (xb, tb) in zip(prof, prof[1:]):
            if abs(xb - xa) < 1e-9 and abs(tb - ta) > 1e-9:
                add([rp(xa, min(ta, tb)), rp(xa, max(ta, tb))], trim, 'trim-line', priority=1)
        # Existing owner rake has a four-inch vertical face. Other trim sections remain outline-only.
        # rake trim wraps the roof edge at the END wall: its face sits just outside the
        # end-wall sheet plane (the 9 in skin), and it is only seen from that end
        for y, end, end_sid, ysign in (
            (y0 - 0.04 - (WALL_SKIN_IN + 0.1), prof[0][1], 'front', -1),
            (y1 + 0.04 + (WALL_SKIN_IN + 0.1), prof[-1][1], 'rear', 1),
        ):
            aa = rp(y, start)
            bb = rp(y, end)
            relevant = next(
                (
                    z
                    for z in leans
                    if z['face'] == ('right' if side == 1 else 'left') and z['id'] == surf.get('continuous_lean_id')
                ),
                None,
            )
            split = W / 2 / co
            if lean_rake != 'model' and relevant and not stepped:
                mid = rp(y, split)
                if cfg['trim_stock'].get('rake') == 'OWNER-FL1010-A4':
                    add([aa, mid, (mid[0], mid[1], mid[2] - 4), (aa[0], aa[1], aa[2] - 4)], trim, 'rake:' + end_sid)
                else:
                    add([aa, mid], trim, 'trim-line:' + end_sid)
                if lean_rake == 'sss':
                    dep = relevant['purlin_depth_in']
                    if dep not in (4, 6, 8):
                        raise ValueError('SSS purlin rake preview supports catalog 4, 6 or 8 inch purlins only')
                    drop = dep + 1.25
                    add(
                        [mid, bb, (bb[0], bb[1], bb[2] - drop), (mid[0], mid[1], mid[2] - drop)],
                        trim,
                        'rake:' + end_sid,
                    )
            elif face_width('rake'):
                drop = face_width('rake')
                add(
                    [aa, bb, (bb[0], bb[1], bb[2] - drop), (aa[0], aa[1], aa[2] - drop)],
                    trim,
                    'supplier-rake-face:' + end_sid,
                )
            elif cfg['trim_stock'].get('rake') == 'OWNER-FL1010-A4':
                add([aa, bb, (bb[0], bb[1], bb[2] - 4), (aa[0], aa[1], aa[2] - 4)], trim, 'rake:' + end_sid)
            else:
                add([aa, bb], trim, 'trim-line:' + end_sid)
        for (xa, ta), (xb, tb) in zip(prof, prof[1:]):
            if abs(xb - xa) < 1e-9:
                continue  # the vertical step is a rake, drawn above
            if face_width('eave'):
                aa = rp(xa, ta)
                bb = rp(xb, tb)
                drop = face_width('eave')
                add([aa, bb, (bb[0], bb[1], bb[2] - drop), (aa[0], aa[1], aa[2] - drop)], trim, 'supplier-eave-face')
            elif cfg['trim_stock'].get('eave'):
                add([rp(xa, ta), rp(xb, tb)], trim, 'eave-line:' + ('right' if side == 1 else 'left'))
    if zones:
        owner = job.assemblies[fid]
        layout = job.settings['frame_layouts'][fid]
        for ew in owner.derivation.get('endwalls', {}).values():
            y = ew.get('station_in', 0)
            for post in ew['posts']:
                x = post['x']
                w = post['width']
                dep = post['profile']['depth']
                bottom = max(0.0, post['bottom'])  # exterior view: nothing below ground
                prism(
                    [
                        (x - w / 2, bottom),
                        (x + w / 2, bottom),
                        (x + w / 2, post['top_low']),
                        (x - w / 2, post['top_low']),
                    ],
                    y - dep / 2,
                    y + dep / 2,
                    steel,
                    'crosswall-post',
                )
            for row in ew['members']:
                if row['role'] == 'endwall girt':
                    x0, z0, x1, z1 = (row[k] for k in ('x0_in', 'y0_in', 'x1_in', 'y1_in'))
                    if ew.get('enclosure_state') == 'future':
                        add([(x0, y, z0), (x1, y, z1)], steel, 'install-now-girt-reference')
                if row['role'] != 'endwall rafter':
                    continue
                sec = profile(row['profile_id'])
                dep = sec['depth'] * math.hypot(1, s)
                w = sec['width']
                x0, z0, x1, z1 = (row[k] for k in ('x0_in', 'y0_in', 'x1_in', 'y1_in'))
                prism(
                    [(x0, z0), (x1, z1), (x1, z1 - dep), (x0, z0 - dep)],
                    y - w / 2,
                    y + w / 2,
                    steel,
                    'crosswall-rafter',
                )
        for row in owner.derivation['secondary_runs']['pieces']:
            if row['role'] == 'girt' and zones['bays'][row['bay'] - 1][row['side']] == 'future':
                add(
                    [
                        (row['frame_x_in'], yy, row['floor_y_in'])
                        for yy in (row['support_start_in'], row['support_end_in'])
                    ],
                    steel,
                    'install-now-girt-reference',
                )
        for y in zones['primary_frame_stations_in']:
            for col in layout['columns']:
                sec = job.assemblies[col['mark']].main.sec
                y0 = max(0.0, col['y0'])  # exterior view: nothing below ground
                prism(
                    [
                        (col['x0'], y0),
                        (col['x1'], y0),
                        (col['x1'], col.get('top_y1', col['y1'])),
                        (col['x0'], col.get('top_y0', col['y1'])),
                    ],
                    y - sec.bf / 2,
                    y + sec.bf / 2,
                    steel,
                    'main-column',
                )
            for row in layout['rafters']:
                sec = job.assemblies[row['mark']].main.sec
                x0, z0 = row['top_start']
                x1, z1 = row['top_end']
                d = sec.d * math.hypot(1, s)
                prism(
                    [(x0, z0), (x1, z1), (x1, z1 - d), (x0, z0 - d)],
                    y - sec.bf / 2,
                    y + sec.bf / 2,
                    steel,
                    'main-rafter',
                )
    # Visible lean structural envelopes come from actual modeled cuts, never nominal 12-foot columns.
    for z in leans:
        side = 1 if z['face'] == 'right' else -1
        base = W if side == 1 else 0
        face = z['face']
        P = z['projection_in']
        r = z['rafter_cut_detail']
        low = z['low_connection_detail']
        cd = profile(z['column'])['depth']
        cw = profile(z['column'])['width']
        m = z['pitch'] / 12
        # lean coordinates are the OUTSIDE view of the face: the back wall runs from the rear end
        yl = (lambda v: L - v) if z['face'] == 'left' else (lambda v: v)
        v0 = z['start_in']
        v1 = v0 + z['length_in']
        lines = {q['station']: q for q in (r.get('lines') or [])}
        low_lines = {q['station']: q for q in (low.get('lines') or [])}

        def loc(poly):
            return [(base + side * x, y) for x, y in poly]

        def span(a, b):
            return tuple(sorted((yl(a), yl(b))))

        def P3(out, along, zz):
            # lean-local (out from the attachment wall, along the wall in its OUTSIDE
            # view, up) -> building (x across, y along, z up); end walls mirror like
            # their outside views (rear view x runs from the right corner)
            if face == 'right':
                return (W + out, along, zz)
            if face == 'left':
                return (-out, L - along, zz)
            if face == 'rear':
                return (W - along, L + out, zz)
            return (along, -out, zz)  # front

        def slab(poly, a0, a1, color, tag):
            # extrude an (out, up) profile between two along-the-wall stations
            add([P3(o, a0, zz) for o, zz in poly], color, tag)
            add([P3(o, a1, zz) for o, zz in poly], color, tag)
            for (o, zz), (u, v) in zip(poly, poly[1:] + poly[:1]):
                add(
                    [P3(o, a0, zz), P3(u, a0, v), P3(u, a1, v), P3(o, a1, zz)],
                    color,
                    tag,
                )

        for st in z['stations']:
            y = st['x_in']
            line = lines.get(st.get('index'), {})
            low_line = low_lines.get(st.get('index'), {})
            rw = profile(st.get('rafter_profile') or z['rafter'])['width'] * (st.get('rafter_pair') or 1)
            y0 = max(v0, y - cw / 2)
            y1 = min(v1, y + cw / 2)
            if y == v0:
                y1 = y + cw
            if y == v1:
                y0 = y - cw
            cy = low_line.get('column_low_floor_in', low['column_low_floor_in'])
            # the modelled bottom includes the post-hole embedment; outside, the post
            # stops at the ground
            b = max(0.0, low.get('column_bottom_in', low['base_elevation_in'] + low['base_thickness_in']))
            slab([(P - cd, b), (P, b), (P, cy), (P - cd, cy + cd * m)], y0, y1, steel, 'lean-column')
            yy0 = max(v0, y - rw / 2)
            yy1 = min(v1, y + rw / 2)
            if y == v0:
                yy1 = y + rw
            if y == v1:
                yy0 = y - rw
            high_top = line.get('high_top_in', r['high_top_in'])
            plumb = line.get('plumb_depth_in', r['plumb_depth_in'])
            low_top = high_top - (r['high_top_in'] - r['low_top_in'])
            slab(
                [
                    (r['high_cut_x_in'], high_top),
                    (r['low_cut_x_in'], low_top),
                    (r['low_cut_x_in'], low_top - plumb),
                    (r['high_cut_x_in'], high_top - plumb),
                ],
                yy0,
                yy1,
                steel,
                'lean-rafter',
            )
        for row in z.get('roof_purlin_layout', {}).get('rows', []):
            if row['shared_main_eave']:
                continue
            try:
                sec = profile(row['profile_id'])
                dep, pw = sec['depth'], sec['width']
            except ValueError:
                # Z purlins (the SSS standard) are not open-face members: nominal envelope
                from ..framing_additions import secondary

                sec = secondary(row['profile_id'])
                dep, pw = sec['nominal_depth_in'], max(sec['flanges_in'] or [2.5])
            x = row['horizontal_out_in']
            top = row['roof_top_in']
            pc = (0.50, 0.25, 0.19) if z.get('roof_purlins', {}).get('finish') == 'Red Oxide' else steel
            slab(
                [(x - pw / 2, top - dep), (x + pw / 2, top - dep), (x + pw / 2, top), (x - pw / 2, top)],
                v0,
                v1,
                pc,
                'lean-purlin-envelope',
            )
        y0, y1 = v0, v1
        if z.get('roof_continuity') != 'main_plane':
            # separate lean roof plane: one slope from the main wall down to the lean eave
            col = 1 / math.sqrt(1 + m * m)
            oh = float(z.get('roof_overhang_in') or 0)
            hx = P + oh * col
            hz = z['low_eave_in'] - oh * col * m
            top_z = z['high_eave_in']
            roof_col = rgb(
                next(
                    (q['finish']['hex'] for q in c['surfaces'] if q['id'] == 'lean_' + z['id'] + '_roof'),
                    cfg['roof_finish']['hex'],
                )
            )
            ribs = [
                (P3(0, y, top_z + 0.02), P3(hx, y, hz + 0.02)) for y in range(int(y0) + rib_step, int(y1), rib_step)
            ]
            add(
                [P3(0, y0, top_z), P3(0, y1, top_z), P3(hx, y1, hz), P3(hx, y0, hz)],
                roof_col,
                'lean-roof:' + z['id'],
                ribs,
            )
            add([P3(hx, y0, hz), P3(hx, y1, hz)], trim, 'trim-line', priority=1)
            for y in (y0 - 0.04, y1 + 0.04):
                add([P3(0, y, top_z), P3(hx, y, hz)], trim, 'trim-line', priority=1)
        # Enclosed variants are drawn only when explicitly present in the saved design.
        if z['walls']['outer'] == 'sheeted':
            xo = P + 2.5  # lean sheeting on its girts, outside the lean posts
            ribs = [
                (P3(xo, y, 0.02), P3(xo, y, z['low_eave_in'] + 0.02))
                for y in range(int(y0) + rib_step, int(y1), rib_step)
            ]
            add(
                [P3(xo, y0, 0), P3(xo, y1, 0), P3(xo, y1, z['low_eave_in']), P3(xo, y0, z['low_eave_in'])],
                wall,
                'lean-wall:' + z['face'],
                ribs,
            )
            add(
                [P3(xo + 0.03, y0, z['low_eave_in']), P3(xo + 0.03, y1, z['low_eave_in'])],
                trim,
                'trim-line',
                priority=1,
            )
        walls = z.get('walls') or {}
        ends = (('start_end', v0 - 0.08), ('finish_end', v1 + 0.08))
        for key, yv in ends:
            if walls.get(key, 'open') == 'sheeted':
                # the lean end wall is seen from the building side it faces: a side
                # lean's ends face front/rear; an end lean's ends face left/right
                if face in ('left', 'right'):
                    end_sid = 'rear' if (key == 'start_end') == (face == 'left') else 'front'
                else:
                    end_sid = 'right' if (key == 'start_end') == (face == 'rear') else 'left'
                hi_e, lo_e = z['high_eave_in'], z['low_eave_in']
                ribs = [
                    (P3(u, yv, 0.02), P3(u, yv, hi_e - (hi_e - lo_e) * u / P + 0.02))
                    for u in range(rib_step, int(P), rib_step)
                ]
                add(
                    [P3(0, yv, 0), P3(P, yv, 0), P3(P, yv, lo_e), P3(0, yv, hi_e)],
                    wall,
                    'lean-end:' + end_sid,
                    ribs,
                )
                add(
                    [
                        P3(0, yv + (0.03 if yv < (y0 + y1) / 2 else -0.03), hi_e),
                        P3(P, yv + (0.03 if yv < (y0 + y1) / 2 else -0.03), lo_e),
                    ],
                    trim,
                    'trim-line',
                    priority=1,
                )
    return dict(
        faces=faces,
        width=W,
        length=L,
        height=H,
        pitch=s,
        config=cfg,
        leans=leans,
        zones=zones,
        outer_sheeted=any(surf['id'] == 'outer_front' for surf in c['surfaces']),
    )


def projection(face, W, L, pt):
    x, y, z = pt
    return {'right': (y, z, x), 'left': (L - y, z, -x), 'front': (x, z, -y), 'rear': (W - x, z, y)}[face]


def _clip_projected_x(points, low, high):
    """Clip a projected polygon to the main-wall end datums, interpolating depth too."""
    out = list(points)
    for bound, keep_greater in ((low, True), (high, False)):
        if not out:
            break
        result = []
        prev = out[-1]
        prev_in = prev[0] >= bound - 1e-9 if keep_greater else prev[0] <= bound + 1e-9
        for cur in out:
            cur_in = cur[0] >= bound - 1e-9 if keep_greater else cur[0] <= bound + 1e-9
            if cur_in != prev_in:
                dx = cur[0] - prev[0]
                if abs(dx) > 1e-12:
                    t = (bound - prev[0]) / dx
                    result.append(tuple(prev[i] + t * (cur[i] - prev[i]) for i in range(3)))
            if cur_in:
                result.append(cur)
            prev, prev_in = cur, cur_in
        out = result
    return out


def _clip_projected_segment(a, b, low, high):
    """Clip one projected member edge to the length datums."""
    dx = b[0] - a[0]
    if abs(dx) < 1e-12:
        return (a, b) if low - 1e-9 <= a[0] <= high + 1e-9 else None
    t0, t1 = (low - a[0]) / dx, (high - a[0]) / dx
    lo, hi = max(0.0, min(t0, t1)), min(1.0, max(t0, t1))
    if lo > hi:
        return None
    interp = lambda t: tuple(a[i] + t * (b[i] - a[i]) for i in range(3))
    return interp(lo), interp(hi)


def sheets(job, fid, lean_rake="model"):
    m = model(job, fid, lean_rake)
    out = []
    for n, sid in enumerate(('right', 'rear', 'left', 'front'), 1):
        sh = Sheet('CUSTOMER-' + fid + '-' + sid, 'customer')
        c = Canvas(sh)
        c.ptext(64, 58, 'EXTERIOR ELEVATIONS', 25, bold=True)
        c.ptext(64, 88, name(sid).upper() + '  /  OUTSIDE VIEW', 13)
        c.ptext(1160, 57, f'{n:02d} / 04', 14, anchor='end')
        c.pline(64, 110, 1160, 110, Style(color=(0.7, 0.7, 0.7), width=0.6))
        c.ptext(
            64,
            137,
            fmt(m['width'])
            + ' x '
            + fmt(m['length'])
            + ' MAIN BUILDING  |  '
            + fmt(m['height'])
            + ' EAVE  |  '
            + str(m['pitch'] * 12).rstrip('0').rstrip('.')
            + ':12 ROOF',
            11,
        )
        for i, z in enumerate(m['leans']):
            c.ptext(
                64,
                158 + i * 17,
                z['id']
                + ': '
                + fmt(z['length_in'])
                + ' long x '
                + fmt(z['projection_in'])
                + ' projection / '
                + fmt(z['low_eave_in'])
                + ' LOW EAVE / '
                + (
                    'OPEN SIDES AND ENDS'
                    if all(z['walls'][k] == 'open' for k in ('outer', 'start_end', 'finish_end'))
                    else 'ENCLOSURE AS SAVED'
                ),
                10,
            )
        projected = []
        for f in m['faces']:
            tag = f['tag']
            head, _, tail = tag.partition(':')
            if (
                head
                in (
                    'wall',
                    'corner-face',
                    'trim-line',
                    'jamb-face',
                    'head-face',
                    'rake',
                    'supplier-rake-face',
                    'lean-wall',
                    'lean-end',
                )
                and tail
            ):
                # a wall's sheets/trim/openings (and a gable's rake) are only seen from
                # the side that faces that wall - from any other side they used to draw
                # as floating strips a skin-depth away from the building
                face_sid = tail.split(':')[0]
                if face_sid in ('front', 'rear', 'left', 'right') and face_sid != sid:
                    continue
            ps = [projection(sid, m['width'], m['length'], p) for p in f['points']]
            # End-frame column/rafter envelopes are centered on the outside frame
            # stations and can extend half a flange past the 0/L wall datum. On the
            # customer SIDE elevations, trim the displayed steel to those datums;
            # do not change member lengths or the underlying shop model. Roof sheets,
            # wall panels and their intentional overhangs are not clipped.
            steel_tags = {
                'main-column',
                'main-rafter',
                'crosswall-post',
                'crosswall-rafter',
                'lean-column',
                'lean-rafter',
                'lean-purlin-envelope',
                'install-now-girt-reference',
            }
            crop_ends = sid in ('right', 'left') and f['tag'] in steel_tags
            if crop_ends:
                if len(ps) == 2:
                    clipped = _clip_projected_segment(ps[0], ps[1], 0.0, m['length'])
                    if clipped is None:
                        continue
                    ps = list(clipped)
                else:
                    ps = _clip_projected_x(ps, 0.0, m['length'])
                    if len(ps) < 3:
                        continue
            area = abs(sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(ps, ps[1:] + ps[:1]))) / 2 if len(ps) > 2 else 1
            if area < 1e-6:
                continue
            ribs = []
            for rp0, rp1 in f['ribs']:
                aa = projection(sid, m['width'], m['length'], rp0)
                bb = projection(sid, m['width'], m['length'], rp1)
                segment = _clip_projected_segment(aa, bb, 0.0, m['length']) if crop_ends else (aa, bb)
                if segment:
                    ribs.append(segment)
            depth = sum(p[2] for p in ps) / len(ps)
            # The facing sloped roof is the outer visible surface, not its average-depth centroid.
            # Draw it over members below it; the far roof stays behind the opaque main wall.
            if f['tag'] == 'roof:' + sid:
                depth = 1e9
            if f['tag'] == 'eave-line:' + sid:
                depth = 1e9 + 1
            projected.append((depth, f['priority'], f, ps, ribs))
        xs = [p[0] for _, _, f, ps, _ribs in projected for p in ps]
        lo = min(xs)
        hi = max(xs)
        top = max(p[1] for _, _, f, ps, _ribs in projected for p in ps)
        sc = min(1000 / (hi - lo), 335 / top)
        v = View(612 - (lo + hi) / 2 * sc, 555, sc, sc)
        a = Canvas(sh, v)
        for dep, pri, f, ps, ribs in sorted(projected, key=lambda z: (z[0], z[1])):
            if len(ps) == 2:
                a.line(
                    *ps[0][:2],
                    *ps[1][:2],
                    Style(color=f['color'], width=3 if f['tag'].startswith(('trim-line', 'eave-line')) else 0.6),
                )
                continue
            a.poly(
                [(p[0], p[1]) for p in ps],
                style=Style(fill=f['color'], color=tuple(x * 0.65 for x in f['color']), width=0.45),
            )
            for u, w in ribs:
                a.line(*u[:2], *w[:2], Style(color=tuple(x * 0.78 for x in f['color']), width=0.35))
        c.pline(64, 556, 1160, 556, Style(color=(0.55, 0.55, 0.55), width=0.5))
        c.dim_h(
            v.px(0),
            v.px(m['width'] if sid in ('front', 'rear') else m['length']),
            556,
            556,
            590,
            fmt(m['width'] if sid in ('front', 'rear') else m['length']) + ' MAIN WALL DATUM',
            size=10,
        )
        for z in m['leans']:
            if sid not in ('front', 'rear') or z['face'] not in ('left', 'right'):
                continue  # a side lean's projection reads across the end views; an end
                # lean's projection runs toward the viewer there and is not dimmed
            x = m['width'] if z['face'] == 'right' else 0
            xx = x + (1 if z['face'] == 'right' else -1) * z['projection_in']
            u = projection(sid, m['width'], m['length'], (x, 0, 0))[0]
            w = projection(sid, m['width'], m['length'], (xx, 0, 0))[0]
            c.dim_h(v.px(min(u, w)), v.px(max(u, w)), 556, 556, 590, fmt(z['projection_in']) + ' LEAN', size=10)
        if sid == 'front' and m.get('zones', {}).get('enclosed_left_station_in') and not m.get('outer_sheeted'):
            c.ptext(
                64,
                615,
                'View through OPEN outer end; enclosed junction wall and its doors are '
                + fmt(m['zones']['enclosed_left_station_in'])
                + ' behind it.',
                10,
            )
        if sid in ('right', 'left') and any(z['face'] == sid and z['walls']['outer'] != 'sheeted' for z in m['leans']):
            c.ptext(
                64,
                615,
                'The sheeted wall visible between the lean posts is the MAIN building wall behind the open lean-to, not lean-to wall sheeting.',
                10,
            )
        for i, (label, key) in enumerate((('WALLS', 'wall_finish'), ('TRIM', 'trim_finish'), ('ROOF', 'roof_finish'))):
            x = 64 + i * 365
            f = m['config'][key]
            c.prect(x, 635, x + 30, 655, Style(fill=rgb(f['hex']), width=0.4))
            c.ptext(x + 42, 645, label + ' / ' + f['color'], 11, bold=True)
            c.ptext(x + 42, 662, str(f['gauge']) + ' ga / ' + f['coating'], 9)
        c.ptext(
            64,
            703,
            'Model-derived design review. Colors are approximations: approve supplier metal samples. Red-oxide secondaries shown; doors and other unspecified steel finishes shown neutral.',
            9,
        )
        c.ptext(
            64,
            720,
            'Known supplier trim faces use catalog dimensions; other trims are outlines. Bend/hem fit remains unverified. Exposed secondary members use nominal envelopes. No structural approval implied.',
            9,
        )
        if lean_rake != 'model':
            c.ptext(
                64,
                738,
                'ALTERNATE VIEW ONLY: '
                + ('SSS carport purlin rake' if lean_rake == 'sss' else 'exposed lean purlins')
                + ' / no purchase order or structural mode changed; fit and trim junctions require review.',
                9,
            )
        c.ptext(
            64, 755, 'Job ' + job.job_no + '  |  ' + job.revision() + '  |  Saved openings and enclosure retained', 9
        )
        out.append(sh)
    return out
