"""Endwall elevation and separate reference-cut schedules; no invented connections."""

import math

from ..building import name as face_name
from ..model import D
from ..sections import get_section
from .canvas import S_CL, S_HID, S_NOTE, S_OBJ, S_TABLE, Canvas, Sheet, View
from .sheet import _border, _footer, _mark_header, _title_block


def header(job, fid, end, name, kind):
    r = job.assemblies[fid].derivation['endwalls'][end]
    sh = Sheet(name, kind)
    c = Canvas(sh)
    _border(c)
    _mark_header(c, name, 'ENDWALL SETOUT')
    _title_block(c, job, 1, name, fid, job.date)
    c.ptext(
        650,
        30,
        (
            'ENDWALL SETOUT — EDIT INPUTS: BUILDING SETTINGS > END WALLS & OPENINGS | '
            'ADDED POSTS: PITCH-CUT / ZERO-GAP CONTACT | CORNER COLUMN CONNECTIONS: '
            + (
                'PER LOCATION'
                if (r.get('config') or {}).get('post_head_overrides')
                else {
                    'side_welded': 'INSIDE FACE',
                    'legacy': 'COLUMN SEAT',
                    'direct_welded': 'DIRECT CONTACT',
                }.get((r.get('config') or {}).get('post_head'), 'REVIEW')
            )
            + (' | PEAK FACE SPLICE PLATE / ZERO GAP' if r.get('ridge_face_clip') else ' | NO CONNECTION GAP')
        ),
        10,
        0,
        'middle',
        style=S_NOTE,
    )
    return r, sh, c


def endwall_sheet(job, fid, end, line=None):
    """End-wall framing elevation. With ``line`` (a frame_lines record) the sheet becomes the
    FRAME LINE n drawing: banner, dotted roof line (top of purlin = top of the FLUSH end rafter)
    and any lean-to that spans this line."""
    name = (
        ('FL%d-' % line['index'] + fid)
        if line
        else 'ENDWALL-' + fid + ('-O' if end == 'outer_front_end' else '-F' if end == 'front_end' else '-R')
    )
    r, sh, c = header(job, fid, end, name, 'frameline' if line else 'endwall')
    cfg = r['config']
    W = r['width_in']
    from .. import frame_lines as FL

    sh.meta['frame_line'] = line
    layout = FL.layout_for_station(job, fid, line['station_in'] if line else r.get('station_in'))
    if line:
        from .frameline_sheets import banner

        banner(c, line, job=job, fid=fid)
    c.ptext(
        110,
        73,
        r.get('endwall_name', face_name(end)).upper()
        + ' — '
        + (
            'OPEN END - RIGID END FRAME, NO POSTS'
            if cfg.get('rigid_end') and cfg.get('enclosure') == 'open'
            else 'NO INTERIOR POSTS'
            if cfg.get('posts_omitted')
            else cfg['type'].replace('_', ' ').upper()
        ),
        11,
        bold=True,
    )
    c.ptext(
        110,
        94,
        'Rafter '
        + cfg['resolved_rafter']
        + '; outer columns '
        + cfg['resolved_column']
        + '; ordinary-post preset '
        + cfg['post']['id'],
        10,
    )
    c.ptext(
        110,
        114,
        str(len(r['posts']) - 1)
        + ' actual POST bays / '
        + cfg.get('post_layout', 'bays').upper()
        + ' layout; stations measured from OUTSIDE-VIEW left wall. Width '
        + D(W).fmt()
        + '.',
        9,
    )
    shared = [
        r
        for r in job.assemblies[fid].derivation.get('framing_additions', {}).get('openings', [])
        if r.get('bearing_jambs')
        and r['face'] == ('front' if end == 'front_end' else 'rear' if end == 'rear_end' else '__NONE__')
    ]
    for i, o in enumerate(shared[:2]):
        c.ptext(
            110,
            134 + i * 15,
            o['id']
            + ' SHARED JAMB/POST: '
            + o['jamb_section']['id']
            + '; HEADER: '
            + o['section']['id']
            + ' / FLANGES '
            + o.get('header_direction', 'up').upper(),
            9,
        )
    H = max(max(x['y0_in'], x['y1_in']) for x in r['members']) + 20
    from .coordination_views import extents, leans

    xmin, xmax, H = extents(layout, W, H)
    fnd = layout.get('foundation') or {}
    below = fnd.get('embed_in', 0) + 6 if fnd.get('type') == 'post_footing' else 0  # holes below the floor
    sc = min(870 / (xmax - xmin), 300 / (H + below))
    v = View(160 + (870 - (xmax - xmin) * sc) / 2 - xmin * sc, 480 - below * sc, sc, sc)
    a = Canvas(sh, v)
    frame_view = v
    frame_canvas = (
        a  # un-mirrored: paper left = back wall = frame x 0 (lean-tos / roof line are frame-coordinate overlays)
    )
    if end == 'rear_end':
        v = View(v.ox + (xmin + xmax) * sc, v.oy, -sc, sc)  # mirror about the view centre (lean-tos)
        a = Canvas(sh, v)
    leans(frame_canvas, layout)
    if line:
        from .frameline_sheets import roof_line_overlay

        roof_line_overlay(frame_canvas, c, frame_view, job, fid, line)
    a.line(0, 0, W, 0, S_CL)
    for post in r['posts']:
        x = post['x']
        d = post['width']
        detail = next(r for r in r['members'] if r['mark'] == post['mark'])
        if detail.get('top_cut_points'):
            a.poly(
                [(x - d / 2, post['bottom']), (x + d / 2, post['bottom'])] + list(reversed(detail['top_cut_points']))
            )
        else:
            a.rect(x - d / 2, post['bottom'], x + d / 2, post['top_low'])
        if post['profile']['family'] == 'W':
            t = post['profile']['web'] / 2
            a.line(x - t, post['bottom'], x - t, post['top_low'])
            a.line(x + t, post['bottom'], x + t, post['top_low'])
        if below:
            from .frame_sheet import post_footing

            post_footing(a, x, fnd, label=post is r['posts'][-1])
        if len(r['posts']) <= 12:
            a.text(x, post['top_low'] / 2, post['mark'], 8, 90, 'middle')
    for member in r['members']:
        if member['role'] == 'endwall rafter':
            a.line(member['x0_in'], member['y0_in'], member['x1_in'], member['y1_in'], S_OBJ)
            depth = get_section(cfg['resolved_rafter']).d * math.hypot(1, float(r['pitch_rise']) / 12)
            a.line(member['x0_in'], member['y0_in'] - depth, member['x1_in'], member['y1_in'] - depth, S_OBJ)
        elif member['role'] in ('endwall girt', 'base angle'):
            a.line(member['x0_in'], member['y0_in'], member['x1_in'], member['y1_in'], S_HID)
    if r.get('ridge_face_clip'):
        a.poly(r['ridge_face_clip']['outline'], closed=True, style=S_NOTE)
    face = 'front' if end == 'front_end' else 'rear' if end == 'rear_end' else '__NONE__'
    for opening in job.assemblies[fid].derivation.get('framing_additions', {}).get('openings', []):
        if opening['face'] != face:
            continue

        def px(x):
            return W - x if face == 'rear' else x

        x = opening['x_in']
        y = opening['y_in']
        w = opening['width_in']
        h = opening['height_in']
        a.rect(min(px(x), px(x + w)), y, max(px(x), px(x + w)), y + h, S_NOTE)
        a.text(
            px(x + w / 2), y + h / 2, opening['id'] + ' CLEAR ' + D(w).fmt() + ' x ' + D(h).fmt(), 8, anchor='middle'
        )
        for part in opening['members']:
            if part.get('shared_member_ref'):
                continue
            xx0, xx1 = sorted((px(part['x0_in']), px(part['x1_in'])))
            a.rect(xx0, part['y0_in'], xx1, part['y1_in'], S_OBJ)
    for clip in job.assemblies[fid].derivation.get('wall_girt_connections', []):
        if clip['face'] != ('outer_front' if end == 'outer_front_end' else face):
            continue
        x = W - clip['station_in'] if face == 'rear' else clip['station_in']
        y = clip['elevation_in']
        hand = clip['hand'] * (-1 if face == 'rear' else 1)
        if hand:
            a.line(x, y, x + hand * 4, y, S_NOTE)
        else:
            a.circle(x, y, 1.5, S_NOTE)
    c.ptext(
        110,
        530,
        'RED: clear openings / connection references. Bearing jambs are single shared posts; girts stop outside their aperture.',
        8,
    )
    c.dim_h(
        v.px(r['posts'][0]['x']),
        v.px(r['posts'][-1]['x']),
        v.py(0),
        v.py(0),
        v.py(-below) + 13,
        str(len(r['posts']) - 1) + ' ACTUAL POST BAYS; NO FORCED RIDGE POST',
        size=8,
    )
    c.dim_h(v.px(0), v.px(W), v.py(0), v.py(0), v.py(-below) + 32, D(W).fmt() + ' OUTSIDE WALLS', size=10)
    c.ptext(
        110,
        543,
        'Posts are embedded in post footings ('
        + fnd.get('hole_diameter', '')
        + ' DIA x '
        + fnd.get('hole_depth', '')
        + '); post lengths include the embedment; no base plates.'
        if below
        else 'Posts begin at the floor weld-plate TOP datum; post bottom touches plate top (0 gap). Plate is by others.'
        if cfg.get('base_connection') == 'floor_weld'
        else 'Post bottoms directly touch selected base-plate tops; 0 gap. Plate and anchors follow selected shared base rules.',
        9,
    )
    c.ptext(
        110,
        550,
        'END ROOF: '
        + r.get('roof_mode', 'legacy').upper()
        + ' / DEPTH FIT: '
        + r.get('roof_depth_fit', {}).get('status', 'unverified'),
        8,
        style=S_NOTE,
    )
    c.ptext(
        110,
        573,
        'Corner posts '
        + str(2)
        + '; intermediate / shared-jamb posts '
        + str(len(r['posts']) - 2)
        + '; rafters '
        + str(sum(x['role'] == 'endwall rafter' for x in r['members']))
        + '. Counted once for this endwall.',
        9,
    )
    connection_names = {
        'legacy': 'COLUMN SEAT / LEGACY',
        'direct_welded': 'PITCH-CUT DIRECT / ZERO GAP',
        'side_welded': 'INSIDE FACE / COLUMN TO ROOF LINE',
    }
    corner_rows = [x for x in r['members'] if x.get('role') == 'outer column']
    if corner_rows:
        c.ptext(
            110,
            590,
            'CORNER CONNECTIONS: '
            + '; '.join(
                x['mark'] + ' — ' + connection_names.get(x.get('head_connection_mode', ''), 'REVIEW')
                for x in corner_rows
            ),
            8,
        )
    for i, t in enumerate(r['warnings'][:6]):
        c.ptext(110, 608 + i * 17, t, 8, style=S_NOTE)
    c.ptext(
        110,
        718,
        'Member geometry: endwall_members.csv. Head modes: endwall_post_head_schedule.csv. Grouped cuts: endwall_cut_list.csv. No endwall NC.',
        8,
    )
    _footer(c, job, job.revision(), 'left/right endwalls are NOT identical interior-frame quantity multipliers')
    return sh


def cut_sheet(job, fid, end, page=1):
    name = (
        'END-CUTS-' + fid + ('-O-' if end == 'outer_front_end' else '-F-' if end == 'front_end' else '-R-') + str(page)
    )
    r, sh, c = header(job, fid, end, name, 'endcuts')
    rows = r['cuts'][(page - 1) * 18 : page * 18]
    if not rows:
        raise ValueError('End cut sheet page outside schedule')
    c.ptext(
        110,
        74,
        ('ENDWALL CUT GEOMETRY / STOCK BLANKS — ' if r.get('ridge_face_clip') else 'ENDWALL REFERENCE CUTS — ')
        + r.get('endwall_name', face_name(end)).upper()
        + ' — PAGE '
        + str(page)
        + ' / '
        + str(math.ceil(len(r['cuts']) / 18)),
        11,
        bold=True,
    )
    c.ptext(
        110,
        96,
        'Post REF CUT = low point; long blank follows the selected pitch/contact planes. Weld details are by others.',
        9,
    )
    c.ptext(
        110,
        116,
        'Displayed values round to 1/16; exact contact planes and cut lengths are retained in CSV/JSON.',
        8,
    )
    xs = [110, 230, 345, 505, 640, 775, 850, 1080]
    top = 133
    rh = 25
    headers = ['GROUP', 'ROLE', 'SECTION / WALL', 'REF CUT', 'LONG BLANK', 'QTY', 'CUT BASIS']

    def cut_basis(row):
        if row.get('cut_basis'):
            return row['cut_basis']
        status = row.get('status', '').upper()
        if row['role'] == 'endwall rafter':
            if 'EAVE PLUMB / PEAK FIT HELD' in status:
                return 'EAVE PLUMB / PEAK FIT HELD'
            if status.startswith('SIDE WELDED:'):
                return 'EAVE PLUMB / INSIDE FACE; PEAK BUTT'
            if status.startswith('OWNER PEAK FACE CLIP:'):
                return 'PEAK PLUMB BUTT / ZERO GAP'
            return 'TOP-LINE REFERENCE / END FIT HELD'
        if row['role'] in ('bearing post', 'roof-bearing opening jamb', 'wall post (nonbearing)'):
            if status.startswith('PITCH-CUT HEAD'):
                return 'PITCH CUT / RAFTER UNDERSIDE / 0 GAP'
            return 'LOW-POINT REFERENCE / HEAD DATUM'
        if row['role'] == 'outer column':
            if status.startswith('PITCH-CUT HEAD'):
                return 'CORNER PITCH CUT / RAFTER UNDERSIDE / 0 GAP'
            if status.startswith('TOP CUT TO ROOF-LINE CONTACT'):
                return 'ROOF LINE / INSIDE-FACE CONTACT / 0 GAP'
            return 'SELECTED CORNER CONNECTION / SEE SETOUT'
        if '1/4 IN GAP' in status or 'ZERO GAP' in status:
            return 'GIRT CONTACT / CHANNEL 1/4 IN ONLY'
        return 'GEOMETRY BASIS IN CSV'

    values = [headers] + [
        [
            x['cut_group'],
            x['role'],
            x['profile_id'],
            x['reference_cut'] or 'PENDING',
            x['blank_length'] or 'PENDING',
            str(x['quantity']),
            cut_basis(x),
        ]
        for x in rows
    ]
    for i, row in enumerate(values):
        y = top + i * rh
        c.pline(xs[0], y, xs[-1], y, S_TABLE)
        for x, t in zip(xs, row):
            c.ptext(x + 4, y + 17, t, 6 if i else 7, bold=not i)
    bottom = top + len(values) * rh
    c.pline(xs[0], bottom, xs[-1], bottom, S_TABLE)
    for x in xs:
        c.pline(x, top, x, bottom, S_TABLE)
    c.ptext(
        110,
        650,
        (
            'Head and ridge geometry resolved with the peak face clip; blank lengths are the long-point references in the table.'
            if r.get('ridge_face_clip')
            else 'Lengths: posts base to rafter underside; girts stop on the selected contact planes, with 1/4in gap only inside open-face channels.'
        ),
        9,
    )
    c.ptext(
        110,
        673,
        'Tube weights are held; gauge is not silently converted to thickness. Supplier Cee references retain source profile data.',
        9,
    )
    if any(x.get('girt_receiving_interfaces') for x in r['members']):
        c.ptext(
            110,
            695,
            'Opening-jamb girt receiver setout: endwall_girt_receiving_faces.csv; 1/4in gap only inside open-face channel.',
            8,
        )
    c.ptext(
        110,
        714,
        'Individual piece marks map to cut groups in endwall_members.csv. Presets and section provenance in endwall_layouts.json.',
        8,
    )
    _footer(
        c,
        job,
        job.revision(),
        'separate endwall quantities; no automatic capacities, foundation design, anchors or CNC',
    )
    return sh
