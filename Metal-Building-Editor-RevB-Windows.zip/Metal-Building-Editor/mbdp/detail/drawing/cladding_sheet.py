"""PBR envelope elevations/unfolded roofs and paginated purchasing schedules."""

import math
import textwrap

from ..building import code as face_code
from ..building import name as face_name
from ..cladding import fmt
from .canvas import S_NOTE, S_OBJ, S_TABLE, Canvas, Sheet, Style, View, text_width
from .sheet import _border, _footer, _furniture, _title_block


def header(job, fid, name, kind):
    m = job.assemblies[fid].derivation['cladding']
    sh = Sheet(name, kind)
    c = Canvas(sh)
    _border(c)
    with _furniture(c):
        c.ptext(970.9, 54, name, min(16.1, 170 / max(text_width(name, 1, True), 1)), bold=True)
        c.pline(967.4, 57.5, 1150.6, 57.5, S_TABLE)
        c.ptext(970.9, 72, 'PBR / TRIM', 13.9, bold=True)
    sh.meta['mark_header'] = (name, 'PBR / TRIM')
    _title_block(c, job, 1, name, fid, job.date)
    _footer(
        c,
        job,
        job.revision(),
        'panel/trim takeoff separate from structural cuts; no automatic panel splices or offcut reuse',
    )
    return m, sh, c


def rgb(h):
    return tuple(int(h[i : i + 2], 16) / 255 for i in (1, 3, 5))


def surface_sheet(job, fid, sid):
    m, sh, c = header(job, fid, 'PBR-' + fid + '-' + face_code(sid).upper(), 'cladding')
    s = next(x for x in m['surfaces'] if x['id'] == sid)
    finish = s['finish']
    width = s['width_in']
    hi = max(y for x, y in s['top_profile'])
    b = s['bottom_in']
    c.ptext(
        110,
        72,
        s.get('elevation', face_code(sid)).upper().replace('_', ' ')
        + ' - '
        + ('VERTICAL WALL PANELS' if s['kind'] == 'wall' else 'SINGLE-PIECE ROOF / UNFOLDED SLOPE'),
        12,
        bold=True,
    )
    c.ptext(
        110,
        94,
        finish['color'] + ' / ' + finish['coating'] + ' / ' + str(finish['gauge']) + ' ga | ' + finish['availability'],
        9,
    )
    c.ptext(
        110,
        113,
        s['datum'] + (' / CONTINUOUS THROUGH ' + s['continuous_lean_id'] if s.get('continuous_lean_id') else ''),
        9,
    )
    c.ptext(
        110, 131, 'PBR:36 in coverage; ribs12 in OC x1-1/4 in high. Color preview approximate; confirm metal chips.', 8
    )
    scale = min(860 / width, 285 / max(hi, 1))
    v = View(160 + (860 - width * scale) / 2, 450, scale, scale)
    a = Canvas(sh, v)
    fill = Style(layer='PBR', fill=rgb(finish['hex']), width=0.5)
    cut = Style(layer='OPENING', fill=(1, 1, 1), width=0.8)
    own = [r for r in m['panels'] if r['surface'] == sid]
    for r in own:
        a.poly(
            [(r['x0_in'], r['bottom_in']), (r['x1_in'], r['bottom_in'])] + list(reversed(r['top_profile'])), style=fill
        )
        for x in (r['x0_in'] + 12, r['x0_in'] + 24):
            if x < r['x1_in'] - 1e-8:
                pts = r['top_profile']
                yt = next(y + (z - y) * (x - u) / (v - u) for (u, y), (v, z) in zip(pts, pts[1:]) if u <= x <= v)
                a.line(x, r['bottom_in'], x, yt, Style(layer='PBR_RIB_SCHEMATIC', width=0.2, color=(0.45, 0.45, 0.45)))
        if len(own) <= 70:
            a.text(
                (r['x0_in'] + r['x1_in']) / 2,
                (r['bottom_in'] + r['top_in']) / 2,
                r['mark'].rsplit('-', 1)[-1] + '  ' + (r.get('order_length') or fmt(r['exact_blank_length_in'])),
                7,
                90,
                'middle',
            )
    # trim on the elevation itself (owner 0.8.53): corner trim at both ends of a
    # wall, rake trim along a sloped top, eave trim along a flat wall top / roof
    # low edge, ridge along a roof top edge - each labelled with its run
    _trim = Style(layer='TRIM', width=1.4)
    _pts = [(float(x), float(y)) for x, y in s['top_profile']]
    if s['kind'] == 'wall':
        # corner trim is a 4 in wide band at each end of the wall (actual size)
        for _xe, _yt in (_pts[0], _pts[-1]):
            a.line(_xe, b, _xe, _yt, _trim)
            _in = _xe + 4 if _xe < width / 2 else _xe - 4
            a.line(_in, b, _in, _yt, _trim)
            a.text(_xe, b + 4, 'CORNER TRIM 4" WIDE x ' + fmt(_yt - b), 6.5, 90, 'start')
        _sloped = abs(_pts[-1][1] - _pts[0][1]) > 1 or len(_pts) > 2
        # rake trim runs out to the EDGE OF THE ROOF: extended past the wall ends
        # along the slope by the roof eave overhang
        try:
            from ..cladding import inch as _inch

            _oh = float(_inch(m['config'].get('roof_eave_extension') or '0'))
        except Exception:
            _oh = 0.0
        _segs = list(zip(_pts, _pts[1:]))
        for k, ((x0_, y0_), (x1_, y1_)) in enumerate(_segs):
            _dx, _dy = x1_ - x0_, y1_ - y0_
            _L = math.hypot(_dx, _dy) or 1
            _ex, _ey = _dx / _L * _oh, _dy / _L * _oh
            if k == 0:
                x0_, y0_ = x0_ - _ex, y0_ - _ey
            if k == len(_segs) - 1:
                x1_, y1_ = x1_ + _ex, y1_ + _ey
            a.line(x0_, y0_ + 1.5, x1_, y1_ + 1.5, _trim)
        _mid = _pts[len(_pts) // 2]
        a.text(
            _mid[0],
            _mid[1] + 5,
            ('RAKE TRIM TO ROOF EDGE ' if _sloped else 'EAVE TRIM ') + fmt(width) + ' RUN',
            7,
            0,
            'middle',
        )
    else:
        a.line(0, b, width, b, _trim)
        a.text(width / 2, b - 9, 'EAVE TRIM ' + fmt(width) + ' RUN', 7, 0, 'middle')
        for (x0_, y0_), (x1_, y1_) in zip(_pts, _pts[1:]):
            a.line(x0_, y0_ + 1.5, x1_, y1_ + 1.5, _trim)
        _mid = _pts[len(_pts) // 2]
        a.text(_mid[0], _mid[1] + 5, 'RIDGE / RAKE TRIM ' + fmt(width) + ' RUN', 7, 0, 'middle')
    for o in s['openings']:
        x = o['x_in']
        y = o['y_in']
        w = o['width_in']
        h = o['height_in']
        a.rect(x, y, x + w, y + h, cut)
        a.text(x + w / 2, y + h / 2, o['id'], 8, anchor='middle')
    c.dim_h(v.px(0), v.px(width), v.py(b), v.py(b), 480, fmt(width) + ' COVERAGE EXTENT', size=10)
    c.ptext(
        110,
        514,
        str(s['panel_quantity'])
        + ' panel pieces | gross '
        + format(s['gross_area_sqft'], '.2f')
        + ' sf | net installed '
        + format(s['net_area_sqft'], '.2f')
        + ' sf | ordered36-in-coverage blanks '
        + format(s['ordered_coverage_blank_sqft'], '.2f')
        + ' sf',
        10,
    )
    c.ptext(
        110,
        536,
        'Order quantities are COVERAGE STRIPS, not net area divided by sheet area. Last strips still buy a full PBR width.',
        9,
    )
    c.ptext(
        110,
        556,
        'Top slopes use highest point of each strip for rectangular blanks; partial-width aperture cuts retain the blank.',
        9,
    )
    if s['kind'] == 'roof':
        c.ptext(
            110,
            578,
            'Run: '
            + fmt(own[0]['exact_blank_length_in'])
            + ' geometric / '
            + own[0]['order_length']
            + ' rounded-up order length; no automatic splice.',
            10,
        )
    else:
        c.ptext(
            110,
            578,
            'Floor-referenced opening sizes/positions: see opening_schedule.csv and opening sheets. No opening framing generated.',
            9,
        )
    n = sum(r['supply_length_review'] for r in own)
    c.ptext(
        110,
        603,
        str(n) + ' pieces outside published5-50 ft range: supplier review required.'
        if n
        else 'Lengths within published5-50 ft range; gauge/color availability and edge details still require confirmation.',
        9,
        style=S_NOTE,
    )
    for i, t in enumerate(
        textwrap.wrap(
            'Allowances: '
            + ', '.join(
                k.replace('_', ' ') + ' ' + str(m['config'][k])
                for k in ('wall_bottom_clearance', 'wall_top_allowance')
                if s['kind'] == 'wall'
            )
            if s['kind'] == 'wall'
            else 'Roof edge allowances ALONG SLOPE: effective eave extension '
            + (
                fmt(s['effective_eave_overhang_in'])
                if 'effective_eave_overhang_in' in s
                else m['config']['roof_eave_extension']
            )
            + '; ridge cutback '
            + m['config']['roof_ridge_cutback']
            + '; mono high cutback '
            + m['config']['roof_high_cutback']
            + '; left/right end overhang ALONG BUILDING '
            + m['config']['roof_front_overhang']
            + ' / '
            + m['config']['roof_rear_overhang'],
            145,
        )
    ):
        c.ptext(110, 628 + i * 16, t, 8)
    c.ptext(
        110,
        687,
        'Cut groups in panel_order_schedule.csv; individual marks, exact bounds and field cuts in panel_pieces.csv / cladding_layouts.json.',
        8,
    )
    c.ptext(
        110,
        709,
        'Profile geometry schematic. Fastener/sealant/closure layout and trim junction details are per the panel manufacturer.',
        8,
    )
    return sh


def schedule_sheet(job, fid, kind, page=1, sid=None):
    if kind == 'rakeprofile':
        from .residential_rake_sheet import sheet

        return sheet(job, fid)
    prefix = {'panel': 'PBR-CUTS', 'trim': 'TRIM', 'trimcut': 'TRIM-CUTS', 'opening': 'OPENINGS'}[kind]
    m, sh, c = header(
        job,
        fid,
        prefix + '-' + fid + ('-' + face_code(sid).upper() if sid else '') + '-' + str(page),
        'cladding_schedule',
    )
    if kind == 'panel':
        rows = [r for r in m['groups'] if r['surface'] == sid]
        headers = ['GROUP', 'LENGTH / QTY', 'COLOR / GAUGE', 'SUPPLY STATUS']
        values = [
            [
                r['group'],
                r['order_length'] + ' / ' + str(r['quantity']),
                r['color'] + ' / ' + str(r['gauge']),
                'LENGTH REVIEW'
                if r['supply_length_review']
                else ('STANDARD' if r['availability'].startswith('STANDARD') else 'SPECIAL / LEAD TIME'),
            ]
            for r in rows
        ]
    elif kind == 'trimcut':
        rows = m['trim_groups']
        headers = ['GROUP / SURFACE', 'ROLE / PROFILE', 'CUT LENGTH / QTY', 'ORDER LENGTH / COLOR']
        values = [
            [
                r['group'] + ' / ' + face_name(r['surface']),
                r['role'] + ' / ' + r['profile_id'],
                r['cut_length'] + ' / ' + str(r['quantity']),
                fmt(r['stock_length_in']) + ' / ' + r['color'],
            ]
            for r in rows
        ]
    elif kind == 'trim':
        rows = m['trim_runs']
        headers = ['RUN / SURFACE', 'ROLE / LOCATION', 'PROFILE REF / ORDER LIMIT', 'NET / REQUIRED RUN / QTY']
        values = [
            [
                r['mark'] + ' ' + face_name(r['surface']),
                r['role'] + ' / ' + r['location'],
                (r['profile_id'] + ' / ' + fmt(r['stock_length_in']))
                if r['profile_id']
                else 'NOT ORDERED'
                if r.get('not_ordered')
                else 'PROFILE PENDING',
                r['net_run']
                + ' / '
                + fmt(r['required_run_in'])
                + ' / '
                + (str(r['stock_quantity']) if r['stock_quantity'] is not None else 'PENDING'),
            ]
            for r in rows
        ]
    else:
        rows = m['config']['openings']
        headers = ['ID / SURFACE', 'TYPE', 'LEFT X / BOTTOM Y', 'WIDTH / HEIGHT']
        values = [
            [
                r['id'] + ' / ' + face_name(r['surface']),
                r['kind'],
                fmt(r['x_in']) + ' / ' + fmt(r['y_in']),
                fmt(r['width_in']) + ' / ' + fmt(r['height_in']),
            ]
            for r in rows
        ]
    values = values[(page - 1) * 18 : page * 18]
    if not values:
        raise ValueError('Schedule page outside range')
    c.ptext(
        110,
        76,
        prefix + ' ' + face_name(sid or '').upper() + ' - PAGE ' + str(page) + ' / ' + str(math.ceil(len(rows) / 18)),
        12,
        bold=True,
    )
    c.ptext(
        110, 100, 'Planning quantities only. All lengths in feet/inches; cut lengths round UP to1/16 in, not down.', 9
    )
    xs = [110, 335, 605, 865, 1110]
    top = 125
    rh = 25
    for i, row in enumerate([headers] + values):
        y = top + i * rh
        c.pline(xs[0], y, xs[-1], y, S_TABLE)
        for x, t in zip(xs, row):
            # Long location labels wrap within the row instead of crossing another cell.
            chunks = textwrap.wrap(str(t), 42)
            for z, line in enumerate(chunks[:2]):
                c.ptext(x + 4, y + 10 + z * 10, line, 7, bold=i == 0)
    end = top + (len(values) + 1) * rh
    c.pline(xs[0], end, xs[-1], end, S_TABLE)
    for x in xs:
        c.pline(x, top, x, end, S_TABLE)
    notes = {
        'trimcut': [
            'Exact/custom trim pieces unless catalog mode selected. Cut lengths rounded UP to1/16 in; qty equals stock pieces for these cuts.',
            'Project lap '
            + m['config']['trim_lap']
            + '; allowance EACH run end '
            + m['config']['trim_end_allowance']
            + '.',
            'Trim gauge '
            + str(m['config']['trim_finish']['gauge'])
            + '; run and piece marks are mapped in trim_pieces.csv.',
        ],
        'panel': [
            'Groups combine purchase blanks only. Field cutouts and top cuts remain unique per marked piece in panel_pieces.csv.',
            'One physical piece per listed quantity; full PBR width ordered for partial last strips. No credit for scrap or field cutout area.',
            'Panels above 50 ft are ordered full length; they are not split or lapped automatically.',
        ],
        'trim': [
            'NET RUN is not the stock cut: required run = net +2 x end allowance + owner lug/head allowance. Overlaps use project lap. Stock/custom rule comes from order settings.',
            'Project trim lap '
            + m['config']['trim_lap']
            + '; end allowance EACH END '
            + m['config']['trim_end_allowance']
            + ' (order settings).',
            'Trim finish '
            + m['config']['trim_finish']['color']
            + ' / '
            + str(m['config']['trim_finish']['gauge'])
            + ' ga. Exact individual stock cuts: trim_pieces.csv. No cross-run reuse.',
            'Ridge counted once. Four outside corners assigned to left/right endwalls only. Base interrupted at floor-level openings.',
            'Peak boxes / end caps, gutters, closures and fasteners are not in these tables.',
        ],
        'opening': [
            'Coordinates are EXTERIOR-VIEW LEFT and floor height, as drawn. Front sidewall starts at LEFT endwall; back sidewall at RIGHT endwall.',
            'Left endwall starts at BACK sidewall; right endwall starts at FRONT sidewall. Do not mirror positions again.',
            'These are panel cut apertures; rough-frame dimensions are on the wall framing elevations.',
        ],
    }
    if m['config'].get('owner_length_rules') and kind in ('trim', 'trimcut'):
        notes[kind][1] = (
            'Owner lengths: slab-level door jamb +1.5in sheet lug; head +3in TOTAL. General end extras '
            + m['config']['trim_end_allowance']
            + ' each remain additional. Lap '
            + m['config']['trim_lap']
            + '.'
        )
    for i, line in enumerate(notes[kind]):
        c.ptext(110, 628 + i * 18, line, 8, style=S_OBJ)
    return sh


def descriptors(model):
    if model['config'].get('trim_stock', {}).get('rake') == 'OWNER-FL1010-A4':
        yield ('rakeprofile', '', 1)
    for s in model['surfaces']:
        if s.get('open_wall'):
            continue  # an OPEN wall has no panel layout page (v0.8.35: no empty sheets)
        yield ('cladding', s['id'], 0)
        for page in range(1, math.ceil(len(s['groups']) / 18) + 1):
            yield ('panel', s['id'], page)
    for kind, rows in [
        ('trim', model['trim_runs']),
        ('trimcut', model['trim_groups']),
        ('opening', model['config']['openings']),
    ]:
        for page in range(1, math.ceil(len(rows) / 18) + 1):
            yield (kind, '', page)


def all_cladding_sheets(job, fid):
    for kind, sid, page in descriptors(job.assemblies[fid].derivation['cladding']):
        yield surface_sheet(job, fid, sid) if kind == 'cladding' else schedule_sheet(job, fid, kind, page, sid or None)
