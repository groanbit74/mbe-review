"""Finished USER clip geometry, installation elevations and per-instance offsets."""

from ..cladding import fmt
from .canvas import S_NOTE, S_TABLE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _title_block


def flush_clip_sheet(job, fid, index, page=1):
    z = job.assemblies[fid].derivation['framing_additions']['lean_tos'][index]
    clips = z['flush_clips']
    c0 = clips[0]
    chosen = clips[(page - 1) * 10 : page * 10]
    sh = Sheet('FLUSH-CLIP-' + fid + '-' + str(index + 1) + '-' + str(page), 'flush_clip')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, len(clips), sh.name, fid, job.date)
    c.ptext(970, 52, 'FLUSH LEAN-TO CLIP', 13, bold=True)
    c.ptext(970, 74, 'USER WELDED DETAIL', 10)
    c.ptext(610, 32, 'GEOMETRY REVIEW - NOT A CONNECTION CAPACITY OR WELD APPROVAL', 10, anchor='middle', style=S_NOTE)
    c.ptext(110, 76, z['id'] + ' / ' + z['elevation'].upper(), 13, bold=True)
    c.ptext(
        110,
        100,
        'PL1/2in | ' + fmt(c0['projection_in']) + ' horizontal projection | height NOMINAL depth minus2in | NO HOLES',
        10,
    )
    H = c0['exact_bounding_height_in']
    scale = min(36, 250 / H)
    v = View(210, 410, scale, scale)
    a = Canvas(sh, v)
    a.poly(c0['contour_in'], style=Style(fill=(0.91, 0.94, 0.98), width=1))
    for i, (x, y) in enumerate(c0['contour_in']):
        a.text(x + (-0.22 if x == 0 else 0.22), y, 'P' + str(i + 1), 9, anchor='end' if x == 0 else 'start')
    c.dim_h(
        v.px(0),
        v.px(c0['projection_in']),
        v.py(0),
        v.py(0),
        439,
        fmt(c0['projection_in']) + ' HORIZONTAL PROJECTION',
        size=9,
    )
    c.dim_v(
        v.py(c0['drop_in']),
        v.py(H),
        v.px(0),
        v.px(0),
        170,
        fmt(c0['finished_height_in']) + ' FINISHED ROOT HEIGHT',
        size=9,
    )
    c.ptext(
        600,
        148,
        'Pitch ' + str(c0['pitch_rise']) + ':12 / cut angle ' + format(c0['cut_angle_deg'], '.4f') + ' deg',
        10,
        bold=True,
    )
    c.ptext(
        600,
        172,
        'Raw rectangular envelope:' + fmt(c0['projection_in']) + ' x ' + fmt(c0['blank_height_in']) + ' x1/2in',
        10,
    )
    c.ptext(
        600,
        194,
        'Along slope:1.5in CLEAR GAP +6in WEB OVERLAP'
        if c0.get('fit_rule') == 'gap_overlap'
        else 'Root/tip vertical edges; BOTH long edges follow pitch.',
        9,
    )
    c.ptext(600, 216, 'Peak elevation: ' + fmt(c0['peak_height_in']) + ' above floor', 9)
    c.ptext(600, 236, 'Root center (actual plumb section): ' + fmt(c0['center_height_in']) + ' above floor', 9)
    c.ptext(600, 256, 'Root bottom / top: ' + fmt(c0['root_bottom_in']) + ' / ' + fmt(c0['root_top_in']), 9)
    c.ptext(600, 276, 'Tip bottom / top: ' + fmt(c0['tip_bottom_in']) + ' / ' + fmt(c0['tip_top_in']), 9)
    c.ptext(600, 300, 'Weld leg: ' + fmt(c0['weld_size_in']) + '; to column flange AND rafter web.', 9)
    c.ptext(600, 320, 'Weld access, side(s), extent, sequence and design require review.', 8, style=S_NOTE)
    c.ptext(600, 349, 'Contour coordinates INCHES from bounding lower-left:', 9, bold=True)
    for i, (x, y) in enumerate(c0['contour_in']):
        c.ptext(600, 369 + i * 17, 'P' + str(i + 1) + ': X ' + format(x, '.6f') + ' / Y ' + format(y, '.6f'), 9)
    c.ptext(
        110,
        467,
        'TOP-VIEW OFFSET: web centerplane stays on COLUMN WEB centerplane. Clip contacts one web face.',
        9,
        bold=True,
    )
    c.ptext(
        110,
        487,
        'Signed clip center offset = hand x (combined rafter web thickness +1/2in)/2. Mirror changes hand, not alignment.',
        9,
    )
    xs = [110, 400, 565, 760, 1110]
    y = 508
    rh = 16
    heads = ['PHYSICAL STATION / CLIP', 'WEB COUNT / EACH THICKNESS', 'CLIP CENTER OFFSET', 'PEAK BASIS / FIT']
    for i, row in enumerate(
        [heads]
        + [
            [
                r['mark'] + ' @' + fmt(r['station_in']),
                str(r['web_count'])
                + ' / '
                + (format(r['web_thickness_each_in'], '.6f') + 'in' if r['web_thickness_each_in'] else 'PENDING'),
                format(r['clip_center_offset_in'], '.6f') + 'in'
                if r['clip_center_offset_in'] is not None
                else 'PENDING',
                ('USER PEAK' if r['peak_basis'].startswith('USER') else 'DERIVED PEAK / HOLD')
                + '; '
                + ('OFFSET HOLD' if r['clip_center_offset_in'] is None else 'fit/weld review'),
            ]
            for r in chosen
        ]
    ):
        yy = y + i * rh
        c.pline(xs[0], yy, xs[-1], yy, S_TABLE)
        for k, t in enumerate(row):
            c.ptext(xs[k] + 4, yy + 11, t, 7.2, bold=i == 0)
    for x in xs:
        c.pline(x, y, x, y + (len(chosen) + 1) * rh, S_TABLE)
    c.pline(xs[0], y + (len(chosen) + 1) * rh, xs[-1], y + (len(chosen) + 1) * rh, S_TABLE)
    c.ptext(
        110,
        707,
        '1:1 contours in lean_clip_review are unit-explicit, uncompensated REVIEW geometry; no automatic G-code or column drilling.',
        8,
        style=S_NOTE,
    )
    c.ptext(
        110,
        723,
        'Confirm actual high-cut-plane peak, clear web/fillets, flange width and main wall FLUSH system. Cee gauge does not establish thickness.',
        8,
        style=S_NOTE,
    )
    _footer(
        c,
        job,
        job.revision(),
        'finished clip height and bounding stock blank are different; no primary member substitution',
    )
    return sh
