"""Owner direct-bearing heads and the separate endwall peak face clip."""

import math

from ..cladding import fmt
from .canvas import S_DIM, S_HID, S_NOTE, S_TABLE, Canvas, Sheet, Style, View
from .sheet import _border, _footer, _title_block


def _head_view(c, s, m):
    """Draw the selected upright pitch-cut to the actual rafter underside envelope."""
    candidates = [
        r for r in m['members'] if r.get('head_connection') and r.get('top_cut_points') and r['role'] != 'outer column'
    ]
    head = next((r for r in candidates if r['role'] == 'roof-bearing opening jamb'), None) or next(
        iter(candidates), None
    )
    if head is None:
        return
    post = next((p for p in m['posts'] if p['mark'] == head['mark']), None)
    if post is None:
        return
    points = head['top_cut_points']
    cx = head['x0_in']
    cy = sum(y for _, y in points) / len(points)
    slope = math.tan(math.radians(float(head['top_cut_angle_deg'])))
    from ..endwalls import rafter_profile

    depth = rafter_profile(m['config']['resolved_rafter'])['depth'] * math.hypot(1, slope)
    left, right = -10.0, 10.0
    view = View(465, 350, 6.5, 6.5)
    a = Canvas(s, view)
    blue = Style(color=(0.1, 0.3, 0.65), width=1.4)
    fill = Style(color=(0.1, 0.3, 0.65), width=1.0, fill=(0.88, 0.92, 0.98))
    underside_left, underside_right = slope * left, slope * right
    a.poly(
        [
            (left, underside_left),
            (right, underside_right),
            (right, underside_right + depth),
            (left, underside_left + depth),
        ],
        style=fill,
    )
    top_left = (points[0][0] - cx, points[0][1] - cy)
    top_right = (points[-1][0] - cx, points[-1][1] - cy)
    half_width = post['width'] / 2
    a.poly([(-half_width, -5), (half_width, -5), top_right, top_left], style=blue)
    a.line(0, -5, 0, 9, S_HID)


def _geometric_contact_views(c, m, opening_rows):
    """Program-style joint views: exact contact planes, with no weld schedule or invented plate size."""
    c.ptext(110, 251, 'GEOMETRIC CONTACT DETAILS', 12, bold=True)
    c.pline(110, 258, 1115, 258, S_TABLE)

    # Base: the post bottom and embedded-plate top share the same datum. The plate itself is by others.
    c.ptext(125, 278, 'A  BASE / EMBEDDED PLATE', 9, bold=True)
    base = View(210, 370, 6.0, 6.0)
    a = Canvas(c.sheet, base)
    post = next((x for x in m.get('posts', []) if x.get('role') != 'outer column'), None) or next(
        iter(m.get('posts', [])), None
    )
    width = float(post.get('width', 4.0)) if post else 4.0
    half = max(1.0, width / 2)
    steel = Style(color=(0.1, 0.3, 0.65), width=1.2, fill=(0.88, 0.92, 0.98))
    a.rect(-half, 0, half, 12, steel)
    a.line(-half, 0, half, 0, S_TABLE)
    a.line(-half - 4, 0, half + 4, 0, S_HID)
    c.ptext(130, 401, 'POST BOTTOM = PLATE TOP / 0 GAP', 8)
    c.ptext(130, 416, 'Embedded plate by others; no plate size shown.', 7.5)

    # Head: this view is generated from the selected member cut points and actual rafter underside.
    c.ptext(365, 278, 'B  UPRIGHT / RAFTER', 9, bold=True)
    c.ptext(365, 401, 'Pitch-cut to rafter underside / 0 gap', 8)

    # Header: use actual end-setout span where present, with end faces touching both jamb inside faces.
    c.ptext(590, 278, 'C  OPENING HEADER', 9, bold=True)
    header = next((j for row in opening_rows for j in row.get('header_end_joints', [])), None)
    clear = 120.0
    if header:
        joints = next(row['header_end_joints'] for row in opening_rows if row.get('header_end_joints'))
        if len(joints) >= 2:
            clear = abs(joints[1]['header_end_plane_x_in'] - joints[0]['header_end_plane_x_in'])
    span_pt = min(150.0, max(80.0, clear * 0.8))
    x0, x1 = 700.0 - span_pt / 2, 700.0 + span_pt / 2
    c.prect(x0 - 7, 302, x0, 378, steel)
    c.prect(x1, 302, x1 + 7, 378, steel)
    c.prect(x0, 324, x1, 338, steel)
    c.ptext(610, 401, 'Ends cut to jamb inside faces / 0 gap', 8)
    c.ptext(610, 416, 'Clear setout: ' + fmt(clear), 7.5)

    # Girt: direct butt at a column except when entering the open face of a channel, where the
    # explicit 1/4 in web gap is dimensioned. These are section views; no wall thickness is assumed.
    c.ptext(815, 278, 'D  ENDWALL GIRT', 9, bold=True)
    # Direct-to-column view.
    c.prect(835, 305, 850, 380, steel)
    c.prect(780, 338, 835, 350, steel)
    c.ptext(770, 397, 'DIRECT / 0 GAP', 7.5)
    # Open-face channel receiver, shown as a C profile around the member end.
    c.pline(1005, 305, 1055, 305, S_TABLE)
    c.pline(1055, 305, 1055, 380, S_TABLE)
    c.pline(1055, 380, 1005, 380, S_TABLE)
    c.prect(950, 338, 1049, 350, steel)
    c.pline(1049, 330, 1049, 358, S_DIM)
    c.pline(1055, 330, 1055, 358, S_DIM)
    c.pline(1049, 330, 1055, 330, S_DIM)
    c.pline(1049, 358, 1055, 358, S_DIM)
    c.ptext(1052, 326, '1/4"', 7.5, anchor='middle')
    c.ptext(940, 397, 'OPEN CHANNEL / 1/4" TO WEB', 7.5)
    c.ptext(
        110,
        439,
        'Embedded plates / anchors are by others where indicated; only their member contact planes are shown.',
        8,
        style=S_NOTE,
    )


def sheet(job, fid, end, quantity=1):
    m = job.assemblies[fid].derivation['endwalls'][end]
    clip = m.get('ridge_face_clip')
    s = Sheet(fid + '~' + end + '~joints', 'endjoint')
    c = Canvas(s)
    _border(c)
    _title_block(c, job, quantity, 'END JOINTS', fid, job.date)
    c.ptext(110, 62, m.get('endwall_name', end).upper() + ' / ENDWALL JOINT GEOMETRY', 17, bold=True)
    if clip:
        c.ptext(
            110,
            92,
            'End-channel ridge is NOT the main-frame ridge connection. No1/2in interposed plate or associated deduction.',
            10,
            style=S_NOTE,
        )
        cx = clip['center_x_in']
        cy = clip['center_y_in']
        v = View(350, 322, 23, 23)
        a = Canvas(s, v)
        blue = Style(color=(0.1, 0.3, 0.65), width=1.4)
        for r in m['members']:
            if r['role'] != 'endwall rafter':
                continue
            slope = float(m['pitch_rise']) / 12
            end_y = m['roof_left_in'] + slope * cx
            from ..endwalls import rafter_profile

            depth = rafter_profile(m['config']['resolved_rafter'])['depth'] * math.hypot(1, slope)
            for offset in (0, depth):
                a.line(-10, end_y - slope * 10 - cy - offset, 0, end_y - cy - offset)
                a.line(0, end_y - cy - offset, 10, end_y - slope * 10 - cy - offset)
            break
        a.line(0, -5, 0, 5, S_HID)
        a.rect(-3.5, -2.5, 3.5, 2.5, blue)
        c.dim_h(v.px(-3.5), v.px(3.5), v.py(2.5), v.py(2.5), v.py(4), '7" WIDE', size=11)
        c.dim_v(v.py(-2.5), v.py(2.5), v.px(3.5), v.px(3.5), v.px(5), '5" TALL', size=11)
        c.ptext(725, 181, clip['mark'] + ' / QTY1 THIS END', 11, bold=True)
        for i, t in enumerate(
            [
                '3/16in plate; rectangular5x7; NO HOLES',
                'Flat to channel WEB FACE',
                'Centered horizontally at peak joint',
                'Centered vertically in plumb web depth',
                'Rafters BUTT at peak; ZERO plate gap',
                'Center above floor: ' + fmt(cy),
                'Rafters meet at the peak plane with zero plate gap',
            ]
        ):
            c.ptext(725, 213 + i * 25, t, 10)
    else:
        ridge = m['config'].get('ridge_joint', 'legacy').upper()
        c.ptext(
            110,
            92,
            'RIDGE MODE: ' + ridge + ' — no new peak plate or cut deduction is inferred by this sheet.',
            10,
        )
    opening_rows = job.assemblies[fid].derivation.get('framing_additions', {}).get('openings', [])
    header_joints = [j for o in opening_rows for j in o.get('header_end_joints', [])]
    if header_joints:
        c.ptext(110, 126, 'ENDWALL OPENING HEADER ENDS — DIRECT CONTACT / ZERO GAP', 10, bold=True)
        for i, joint in enumerate(header_joints[:4]):
            c.ptext(
                110,
                144 + 15 * i,
                joint['opening_id']
                + ' / '
                + joint['header_end'].upper()
                + ' END / '
                + joint['jamb_mark']
                + ' inside face @ '
                + fmt(joint['header_end_plane_x_in'])
                + ' / '
                + joint['geometry_status'],
                8,
            )
        c.ptext(
            110, 144 + 15 * min(len(header_joints), 4), 'Header ends cut to jamb inside faces; physical gap = 0 in.', 8
        )
        if len(header_joints) > 4:
            c.ptext(110, 144 + 15 * 5, 'Additional interfaces: see endwall_header_end_joints.csv.', 8)
    if not clip:
        _geometric_contact_views(c, m, opening_rows)
        _head_view(c, s, m)
    c.ptext(110, 461, 'ENDWALL POST-HEAD CUT GEOMETRY', 12, bold=True)
    c.ptext(
        110,
        486,
        'Added posts/jambs are pitch-cut to the supporting rafter underside; base and head contact planes are zero-gap. Corners retain selected connections.',
        9,
    )
    headers = ['MARK', 'SELECTED HEAD', 'LOW CUT', 'LONG BLANK', 'HEAD ANGLE']
    xs = [110, 290, 525, 700, 895, 1115]
    rows = [headers]
    for r in m['members']:
        if r.get('head_connection'):
            connection = (
                'ROOF LINE / INSIDE FACE' if 'INSIDE FACE' in r['head_connection'] else 'PITCH CUT / DIRECT CONTACT'
            )
            rows.append(
                [
                    r['mark'],
                    connection,
                    fmt(r['reference_cut_in']),
                    fmt(math.ceil(r['blank_length_in'] * 16 - 1e-8) / 16),
                    f"{r['top_cut_angle_deg']:.4f} deg",
                ]
            )
    for i, row in enumerate(rows[:7]):
        y = 507 + i * 23
        c.pline(110, y, 1115, y, S_TABLE)
        for x, t in zip(xs, row):
            c.ptext(x + 4, y + 15, t, 8 if i else 9, bold=i == 0)
    if len(rows) > 7:
        c.ptext(110, 678, 'Additional head cuts: see endwall_members.csv (all members included).', 9, style=S_NOTE)
    c.ptext(
        110,
        694,
        'Exact head cuts in endwall_post_head_contacts.csv; girt end contacts / 1/4in channel-web gaps in endwall_girt_contacts.csv.',
        9,
        style=S_NOTE,
    )
    _footer(c, job, job.revision(), 'owner-defined joint geometry')
    return s
