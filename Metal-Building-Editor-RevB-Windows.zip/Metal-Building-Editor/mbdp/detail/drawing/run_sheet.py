"""Longitudinal equal-bay setout and scoped secondary cut schedule."""

from ..building import name as face_name
from .canvas import S_HID, S_NOTE, S_OBJ, S_TABLE, Canvas, Sheet
from .sheet import _border, _footer, _mark_header, _title_block


def title(job, fid, name, kind):
    sh = Sheet(name, kind)
    c = Canvas(sh)
    _border(c)
    _mark_header(c, name, 'SECONDARY RUNS')
    _title_block(c, job, 1, name, fid, job.date)
    c.ptext(
        612,
        31,
        'SECONDARY RUN LAYOUT',
        11,
        0,
        'middle',
        bold=True,
    )
    return sh, c


def run_sheet(job, fid):
    r = job.assemblies[fid].derivation['secondary_runs']
    sh, c = title(job, fid, 'RUNS-' + fid, 'runs')
    cfg = r['config']
    L = r['support_length_in']
    N = cfg['bays']
    c.ptext(
        110,
        73,
        str(N)
        + ' EQUAL BAYS @ '
        + cfg['spacing']
        + ' = '
        + r['centerline_length']
        + (' END OUTSIDE-EDGE LENGTH; INTERIOR CL' if cfg.get('welded_zero_gap') else ' END-SUPPORT CENTERLINE LENGTH'),
        11,
        bold=True,
    )
    c.ptext(
        110,
        94,
        (
            'MASTER LENGTH / zero-offset end-support datums. '
            if cfg.get('length_basis')
            else 'LEGACY support-centerline length. '
        )
        + 'LEFT END -> RIGHT END. Interior lines '
        + str(N - 1)
        + '; entered primary lot '
        + str(r['primary_frame_lot_quantity'])
        + '.',
        9,
    )
    c.ptext(
        110,
        114,
        'LEFT END: '
        + cfg['front_end']['type'].replace('_', ' ').upper()
        + ' | RIGHT END: '
        + cfg['rear_end']['type'].replace('_', ' ').upper(),
        10,
    )
    c.ptext(
        110,
        134,
        (
            'Separate ENDWALL sheets/CSVs contain end-member setout and counts; connections/capacities remain pending.'
            if job.assemblies[fid].derivation.get('endwalls')
            else 'End support choices/reference sizes are recorded, NOT automatically sized, framed or counted in the primary BOM.'
        ),
        9,
        style=S_NOTE,
    )
    ox = 190
    sx = 880 / L
    y0 = 196
    # Support lines and longitudinal coordinates.
    for s in r['support_lines']:
        x = ox + sx * s['station_in']
        c.pline(x, y0, x, 450, S_HID)
        if N <= 12 or s['line'] in (1, N + 1):
            c.ptext(x, y0 - 12, str(s['line']), 8, 0, 'middle')
    c.dim_h(
        ox,
        ox + 880,
        y0,
        y0,
        164,
        r['centerline_length'] + (' END EDGES / ' if cfg.get('welded_zero_gap') else ' C.L. / ') + str(N) + ' EQ BAYS',
        size=9,
    )
    for i, role in enumerate(
        ('purlin', 'girt', 'eave', 'base_angle')
        if any(x['role'] == 'base_angle' for x in r['lanes'])
        else ('purlin', 'girt', 'eave')
    ):
        yy = 225 + i * 66
        lanes = [x for x in r['lanes'] if x['role'] == role or role == 'eave' and x['role'] == 'high_eave']
        c.ptext(110, yy - 19, role.upper() + ' ROWS: ' + str(len(lanes)), 9, bold=True)
        if not lanes:
            continue
        sample = lanes[0]['run_id']
        pieces = [x for x in r['pieces'] if x['run_id'] == sample]
        if role in ('purlin', 'girt'):
            c.ptext(
                395,
                yy - 19,
                (
                    'WELDED OUTSIDE EDGE / CL BUTTS; ZERO GAP'
                    if role == 'purlin' and cfg.get('welded_zero_gap')
                    else 'FLUSH / WEB-TO-WEB'
                    if cfg.get(role + '_mode') == 'flush'
                    else cfg[role + '_pattern']
                )
                + ' / '
                + cfg[role + '_direction']
                + ' | repeated at frame section stations',
                8,
            )
        for p in pieces:
            pending = p['cut_length_in'] is None
            a = p['support_start_in'] if pending else p['start_in']
            b = p['support_end_in'] if pending else p['end_in']
            offset = (p['bay'] % 2) * 9
            c.pline(ox + a * sx, yy + offset, ox + b * sx, yy + offset, S_HID if pending else S_OBJ)
            c.pline(ox + a * sx, yy + offset - 3, ox + a * sx, yy + offset + 3)
            c.pline(ox + b * sx, yy + offset - 3, ox + b * sx, yy + offset + 3)
            if N <= 10:
                c.ptext(
                    ox + (a + b) / 2 * sx, yy + offset + 17, 'PENDING' if pending else p['cut_length'], 7, 0, 'middle'
                )
    c.ptext(
        110,
        487,
        'Representative run strips; alternating vertical offsets are diagrammatic, not physical member offsets.',
        9,
    )
    c.ptext(
        110,
        506,
        'All rows/pieces in CSV. Owner welded roof rule uses exact end-edge/CL stations, ZERO gap; girt fit and vertical channel checks remain separate.'
        if cfg.get('welded_zero_gap')
        else 'All rows/pieces in CSV. Flush lengths rounded SHORTER to 1/16; missing end web sizes hold end-bay cuts.',
        9,
    )
    c.ptext(
        110,
        525,
        'Starting eave clips support TWO eave runs; shared lean high-boundary row is NOT counted a second time.',
        9,
    )
    for i, w in enumerate(r['warnings'][:6]):
        c.ptext(110, 551 + i * 20, w, 8, style=S_NOTE)
    c.ptext(
        110,
        692,
        'Saved project length rules; supplier lap applicability must be verified. End clearances: left '
        + cfg['front_clearance']
        + ', right end '
        + cfg['rear_clearance']
        + ' (project inputs).',
        9,
    )
    c.ptext(
        110,
        712,
        'Owner welded purlin standard supersedes legacy end deductions; not a manufacturer punching rule. Formed-strut end fit remains held.'
        if cfg.get('welded_zero_gap')
        else 'Simple support cutback 1/4 = 2 in CL-to-hole minus 1-3/4 in end-to-hole. No punching or connection design generated.',
        8,
    )
    _footer(c, job, job.revision(), 'one longitudinal layout; no multiplication by entered primary-frame lot quantity')
    return sh


def cut_sheet(job, fid):
    r = job.assemblies[fid].derivation['secondary_runs']
    sh, c = title(job, fid, 'RUN-CUTS-' + fid, 'run_cuts')
    c.ptext(110, 73, 'AUTOMATIC SECONDARY LENGTH / QUANTITY SCHEDULE', 11, bold=True)
    c.ptext(
        110,
        94,
        'Welded owner purlins: end OUTSIDE edges / interior CENTER butts, ZERO gaps. Other runs retain their individual fit rules.'
        if r['config'].get('welded_zero_gap')
        else 'Bypass: selected lap length. Flush: web-to-web minus adjustable total clearance. No endwall girts included.',
        9,
    )
    cols = [110, 270, 370, 565, 680, 745, 855, 1080]
    heads = ['CUT MARK', 'ROLE', 'PROFILE (local ID)', 'CUT LENGTH', 'QTY', 'EST. LB', 'PATTERN / STATUS']
    top = 132
    rowh = min(34, 360 / (len(r['cuts']) + 1))
    for i, values in enumerate(
        [heads]
        + [
            [
                z['cut_mark'],
                z['role'],
                z['profile_id'],
                z['cut_length'] or 'PENDING',
                str(z['quantity']),
                z['estimated_lot_weight_lb'] or 'PENDING',
                z['pattern'],
            ]
            for z in r['cuts']
        ]
    ):
        y = top + i * rowh
        c.pline(cols[0], y, cols[-1], y, S_TABLE)
        for x, t in zip(cols, values):
            c.ptext(x + 4, y + 20, t, 7 if i else 8, bold=not i)
    bottom = top + (len(r['cuts']) + 1) * rowh
    c.pline(cols[0], bottom, cols[-1], bottom, S_TABLE)
    for x in cols:
        c.pline(x, top, x, bottom, S_TABLE)
    c.ptext(
        110,
        max(bottom + 26, 532),
        'C/Z eave purlins use the selected welded zero-gap rule.'
        if r['config'].get('welded_zero_gap')
        else 'EAVE / HIGH EAVE struts: simple span per bay, support CL less end clearance each side; weight from catalog lb/ft.',
        9,
    )
    c.ptext(
        110,
        max(bottom + 46, 552),
        'Accessory manual orders remain in secondary_material_schedule.csv; they are not multiplied or duplicated here.',
        9,
    )
    c.ptext(
        110,
        max(bottom + 66, 572),
        'These are secondary members ONLY. End primary members, holes, fasteners, load capacity and installed fit are NOT approved.',
        9,
        style=S_NOTE,
    )
    for j, end in enumerate(('front_end', 'rear_end')):
        e = r['config'][end]
        endmodel = job.assemblies[fid].derivation.get('endwalls', {}).get(end)
        c.ptext(
            110,
            636 + j * 23,
            face_name(end).upper()
            + ': '
            + e['type']
            + ' | column '
            + (e['column_section'] or 'PENDING')
            + ' | rafter '
            + (e['rafter_section'] or 'PENDING')
            + ' | posts '
            + (
                str(endmodel['config']['bays']) + ' bays (see ENDWALL)'
                if endmodel
                else e['post_spacing'] or 'PENDING / N.A.'
            ),
            9,
        )
    c.ptext(
        110,
        704,
        'Traceability: every cut mark maps to run IDs and bay numbers in secondary_run_pieces.csv; lap source in secondary_run_layouts.json.',
        8,
    )
    _footer(
        c,
        job,
        job.revision(),
        'Project length geometry; supplier section envelopes; pending weights are excluded from totals',
    )
    return sh
