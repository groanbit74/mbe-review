"""Erection elevations in ONE drawing language (v0.8.39).

Every elevation of the erection set - the rigid frame cross sections (R), the end wall
framing (E) and the side wall framing (S) - is drawn here with the same primitives, text
sizes and dimension layout, straight into a box on the sheet (the 22x17 erection sheets draw
at full size instead of shrinking an 11x17 archive sheet):

* primary members (columns, rafters, end-wall posts) - grey filled outlines;
* secondary members (girts, purlins, eave struts, base angle) - thin open outlines, drawn at
  their true size: a section (depth x flange) in the cross sections, the visible flange or
  web face in the wall elevations;
* the roof line (TOP OF PURLIN) dotted blue, openings red, open / future bays red dashed;
* floor datum, outside-wall and bay dimensions below the floor, heights at the left,
  frame-line bubbles along the bottom of the side walls; marks 8.5 pt, captions 11 pt bold,
  nothing below 7 pt.

The archive sheets ``FL<n>-<fid>`` (frame lines) and ``SIDEWALL-F/B-<fid>`` draw the same
views through ``frameline_sheets`` so the editor preview and the printed set agree.
"""

from __future__ import annotations

import math

from .. import frame_lines as FL
from .. import grades as GR
from ..connections import f
from ..framing_additions import profile
from . import coordination_views as CV
from .canvas import LW, LW_THIN, S_CL, S_HID, S_NOTE, S_PLATE, S_TEXT, Canvas, Style, View, text_width

S_MEMBER = Style(layer='OBJECT', width=LW, fill=(1, 1, 1))  # white like the whole-frame view (owner 0.8.53)
S_WALL_POST = Style(layer='OBJECT', width=LW, fill=(0.82, 0.82, 0.82))  # a single readable HSS silhouette
S_SECOND = Style(layer='SECONDARY', width=LW_THIN)
S_ROOF = Style(layer='ROOF_LINE', width=LW_THIN, dash=(2, 2))
S_ROOF_TEXT = Style(layer='ROOF_LINE')
S_FUTURE = Style(layer='NOTE', width=LW_THIN, dash=(6, 3), color=(0.55, 0, 0))
S_LEAN = Style(layer='LEAN_ENVELOPE', width=0.8)  # lean-tos draw like the main frame, not blue
S_BUBBLE = Style(layer='DIM', width=LW_THIN)
FLANGE_IN = 2.5  # Z / C flange seen edge-on
STRUT_FLANGE_IN = 3.0
T_CAPTION, T_RULE, T_MARK, T_DIM, T_SMALL = 11.0, 8.5, 8.5, 8.5, 7.0
SIDE_FACE = {'front': 'right', 'back': 'left'}  # side wall name -> frame x side / piece side key
SIDE_TITLE = {'front': 'FRONT SIDEWALL', 'back': 'BACK SIDEWALL'}


def _fmt(x):
    from ..connections import q

    try:
        return q(float(x)).fmt()
    except Exception:
        return f'{float(x):.2f} in'


def _depth(pid, default):
    try:
        from ..secondary_catalog import get

        return float(get(pid)['nominal_depth_in'])
    except Exception:
        try:
            return float((profile(pid) or {}).get('depth') or default)
        except Exception:
            return default


def fit(box, xmin, xmax, ymin, ymax) -> View:
    """Uniform view that puts model window (inches) inside the paper ``box`` (centred)."""
    bx0, by0, bx1, by1 = box
    scale = min((bx1 - bx0) / max(1.0, xmax - xmin), (by1 - by0) / max(1.0, ymax - ymin))
    ox = bx0 + ((bx1 - bx0) - (xmax - xmin) * scale) / 2 - xmin * scale
    oy = by1 - ((by1 - by0) - (ymax - ymin) * scale) / 2 + ymin * scale
    return View(ox, oy, scale, scale)


def _wrap_caption(text, max_width, size, bold=False):
    words = str(text).split()
    lines = []
    current = ''
    for word in words:
        candidate = (current + ' ' + word).strip()
        if current and text_width(candidate, size, bold) > max_width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def _caption(c, box, title, rule, members, heights=None):
    bx0, by0, bx1 = box[0], box[1], box[2]
    x = bx0 + 6
    max_width = bx1 - bx0 - 12
    y = by0 + 14
    title_lines = _wrap_caption(title, max_width, T_CAPTION, True)
    for line in title_lines:
        c.ptext(x, y, line, T_CAPTION, bold=True)
        y += 12
    # Keep independent shop rules and height datums on separate readable lines instead of
    # compressing them into a single pipe-delimited string.
    sections = [part.strip() for part in str(rule).split(' — ') if part.strip()]
    for part in sections:
        for line in _wrap_caption(part, max_width, T_RULE):
            c.ptext(x, y, line, T_RULE)
            y += 11
    if members:
        for part in (p.strip() for p in str(members).split(' | ') if p.strip()):
            for line in _wrap_caption(part, max_width, T_RULE):
                c.ptext(x, y, line, T_RULE)
                y += 11
    if heights:
        for part in (p.strip() for p in str(heights).split(' | ') if p.strip()):
            for line in _wrap_caption(part, max_width, T_RULE):
                c.ptext(x, y, line, T_RULE)
                y += 11
    return y + 7


def _mark(a, x, y, text, rot=0.0, anchor='middle', style=S_TEXT, bold=False):
    a.text(x, y, text, T_MARK, rot, anchor, style=style, bold=bold)


# ----------------------------------------------------------------------------- frame lines (R / E)
def frame_line(sh, job, fid, rec, box, also=(), include_schedule=True):
    """Frame line ``rec`` (``frame_lines.lines``) drawn in ``box`` - rigid frame cross section or
    end wall framing, the same way for every line.  ``also`` lists further identical frame lines
    the view stands for (named in the caption)."""
    # A lean-to is drawn ONLY on the frame lines its run actually spans (owner round 17):
    # it attaches to the main frame at those lines and nowhere else.
    layout = FL.layout_for_station(job, fid, rec['station_in'])
    p = job.settings['frames'][fid]
    c = Canvas(sh)
    W = float(layout['width_in'])
    mono = layout['frame_type'] == 'monoslope'
    fnd = layout.get('foundation') or {}
    below = float(fnd.get('hole_depth_in') or 0) if fnd.get('type') == 'post_footing' else 0.0
    slab_here = fnd.get('type') == 'slab' and rec.get('wall_key') != 'outer_front_end'
    if slab_here:
        below = max(below, 10.0)  # room for the 6 in slab band under the floor
    H = max(float(layout['low_eave_in']), float(layout['high_eave_in'] or 0), float(layout['ridge_top_in'] or 0))
    xmin, xmax, ytop = CV.extents(layout, W, H + 12)
    title, rule = FL.banner(rec)
    _mark = str(rec.get('frame_mark') or '')
    if _mark.startswith('COL-'):
        _disp = 'MF-' + _mark[4:]
        title = title.replace(_mark, _disp)
        rule = rule.replace(_mark, _disp)
    if also:
        title = title.replace(
            'FRAME LINE %d OF' % rec['index'], 'FRAME LINES %s OF' % ', '.join(str(i) for i in (rec['index'], *also)), 1
        )
    end_view = rec['kind'] == 'end' and rec.get('framed')
    if end_view:
        mirrored = rec['wall_key'] == 'rear_end'
        title += ' - OUTSIDE VIEW' + (' (MIRRORED): FRONT SIDEWALL AT LEFT' if mirrored else ': BACK SIDEWALL AT LEFT')
    else:
        title += ' - SECTION LOOKING TOWARD THE RIGHT END: BACK SIDEWALL AT LEFT'
    # Shop-sheet style (owner round 16): the caption is the title, one fit rule and the
    # heights.  The member summary lives in the schedule table, not in a fourth caption line
    # (end walls keep theirs: it carries the foundation wording the crew sets posts by).
    _members = ''
    if rec['kind'] == 'end' and rec.get('framed'):
        _members = _members_line(job, fid, rec, layout, p)
        if _mark.startswith('COL-'):
            _members = _members.replace(_mark, _disp)
    y_top = _caption(c, box, title, rule, _members, FL.heights(job, fid, rec))
    bx0, by0, bx1, by1 = box
    # Owner 0.8.55: the drawing itself carries dimensions and marks only; every
    # descriptive note lives here, in the sheet margin under the caption.
    _notes = []
    if rec.get('primary_connections'):
        _modes = {x.get('side'): str(x.get('mode') or '').replace('_', ' ').upper() for x in rec['primary_connections']}
        _notes.append(
            'PRIMARY COLUMN SEATS: '
            + ' / '.join(f'{side.upper()} {_modes[side]}' for side in ('left', 'right') if side in _modes)
            + '.'
        )
    if xmax - xmin > W + 1e-6:
        _notes.append('Dotted line = ground line flown out to the lean-to - no slab under a lean-to.')
    if slab_here:
        from ..standards import SLAB_THICKNESS_IN as _ST

        _notes.append(_fmt(_ST) + ' slab under the main building only - floor = top of slab.')
    elif fnd.get('type') in ('post_footing', 'slab'):
        _notes.append(
            'Ground line at floor height - no slab'
            + (' under this roof-only end.' if fnd.get('type') == 'slab' else '.')
        )
    if layout.get('peak_height_in') and not mono:
        _notes.append('Peak height given at the ridge = top of peak purlin (the roof line).')
    elif layout.get('ridge_top_in'):
        _notes.append('Ridge height given at the ridge = rafter top (the roof line).')
    if not end_view:
        _notes.append('Eave-purlin outside face flush with the outside face of each main column.')
    _note_y = y_top + 15
    for _n in _notes:
        for _line in _wrap_caption('NOTE: ' + _n, bx1 - bx0 - 12, T_SMALL):
            c.ptext(bx0 + 6, _note_y, _line, T_SMALL)
            _note_y += 10
    y_top = _note_y
    # Owner round 16: no member table on the frame-line drawing.  The view carries marks,
    # cut lengths and dimensions; quantities live on the consolidated member schedule.
    view_top = y_top + 24
    v = fit((bx0 + 96, view_top, bx1 - 30, by1 - 64), xmin - 16, xmax + 16, -below - 4, ytop + 20)
    if end_view and rec['wall_key'] == 'rear_end':
        # mirror about the VIEW centre, not the building centre - with a lean-to on one
        # side the old W-centre mirror pushed the lean clean off the sheet
        v = View(v.ox + (xmin + xmax) * v.sx, v.oy, -v.sx, v.sy)
    a = Canvas(sh, v)
    # floor datum: slab drawn 6 in thick (floor = top of slab); post footings get a
    # ground line AT floor height with the holes below it (holes drawn with the posts)
    # the slab stops at the main building (0..W); beyond the wall line the floor datum
    # is flown out to the lean-to posts as a DOTTED ground line - no slab under a lean-to
    a.line(0, 0, W, 0, S_CL)
    if xmin < -1e-6:
        a.line(xmin - 14, 0, 0, 0, S_HID)
    if xmax > W + 1e-6:
        a.line(W, 0, xmax + 14, 0, S_HID)
    if slab_here:
        from ..standards import SLAB_THICKNESS_IN

        a.rect(0, -SLAB_THICKNESS_IN, W, 0, S_MEMBER)
    if end_view:
        _end_wall(a, c, v, job, fid, rec, layout, p, fnd)
        rafter_edges = _rafter_edge_records(job, fid, rec, layout, p)
    else:
        drawn_rafters = _rigid_frame(a, c, v, job, fid, rec, layout, p, fnd)
        rafter_edges = _rafter_edge_records(job, fid, rec, layout, p, drawn_rafters)
    _roof_line(a, layout, rec)
    # the lean-to (already limited to this line's station above) attaches to the main
    # frame here - on end lines as well as interior lines
    CV.leans(a, layout, rec.get('index'))
    _purlin_station_dims(a, layout, rec)
    if not end_view:
        _column_cut_labels(c, v, layout, rec)
        # the eave purlin itself: OUTSIDE the columns, outside face flush with the
        # outside edge of the frame on both walls (top = eave height) (owner 0.8.54)
        _pd = float(layout.get('nominal_roof_purlin_depth_in') or rec['purlin_depth_in'] or 8)
        _ev = float(layout['low_eave_in'])
        # The purlin web/outside face is on the column outside face; its flange stays inboard.
        a.rect(0, _ev - _pd, FLANGE_IN, _ev, S_SECOND)
        a.rect(W - FLANGE_IN, _ev - _pd, W, _ev, S_SECOND)
        if mono:
            _hev = float(layout['high_eave_in'])
            a.line(W, _hev - _pd, W, _hev, S_SECOND)
    # dimensions: width below the floor, eave height(s) at the side(s), ridge height at the ridge
    base_y = v.py(-below) + 15
    xl, xr = sorted((v.px(0), v.px(W)))
    # Two separate horizontal cut-face-to-cut-face runs sit below the frame. These are
    # deliberately distinct from the sloped cut/blank lengths in the member schedule.
    for mark, side, p0, p1 in rafter_edges:
        x0, y0 = float(p0[0]), float(p0[1])
        x1, y1 = float(p1[0]), float(p1[1])
        if abs(x1 - x0) < 0.05:
            continue
        if v.px(x0) <= v.px(x1):
            xa, ya, xb, yb = v.px(x0), v.py(y0), v.px(x1), v.py(y1)
        else:
            xa, ya, xb, yb = v.px(x1), v.py(y1), v.px(x0), v.py(y0)
        side_name = str(side).upper() if side in ('left', 'right') else 'RAFTER'
        c.dim_h(xa, xb, ya, yb, base_y + 18, side_name + ' LEG ' + _fmt(abs(x1 - x0)), T_DIM, text_above=False)
    c.dim_h(xl, xr, v.py(0), v.py(0), base_y + 44, _fmt(W) + ' OUT-TO-OUT OF CORNER COLUMNS', T_DIM, text_above=False)
    oxl, oxr = v.px(xmin), v.px(xmax)
    if xmax - xmin > W + 1e-6:
        c.dim_h(
            min(oxl, oxr),
            max(oxl, oxr),
            v.py(0),
            v.py(0),
            base_y + 70,
            _fmt(xmax - xmin) + ' OVERALL OUT-TO-OUT (INCL. LEAN-TOS)',
            T_DIM,
            text_above=False,
        )
    _rows = _schedule_rows(job, fid, rec, layout, len(also) + 1, p=p)
    if _rows and include_schedule:
        _right = min(bx1 - 8, 882.0)  # stay left of the fixed title block on archive sheets
        _row_h = 11.0
        _font = 7.0
        _max_top = 773.0 - 13.0 - _row_h * (len(_rows) + 1)
        ly = _max_top
        _schedule_bottom = _schedule(
            c,
            _right,
            ly,
            _rows,
            'LINE MEMBERS + LEAN-TO CUTS',
            SCHEDULE_COLS,
            row_h=_row_h,
            font=_font,
        )
        sh.meta['member_schedule'] = {'top': ly, 'bottom': _schedule_bottom}
    eave = float(layout['low_eave_in'])
    _girt_tops = []
    if end_view:
        _end = (job.assemblies[fid].derivation.get('endwalls') or {}).get(rec['wall_key']) or {}
        _girt_tops = sorted(
            {
                round(float(z['y0_in']) + FLANGE_IN / 2, 3)
                for z in _end.get('members') or []
                if z['role'] == 'endwall girt'
            }
        )
    else:
        for _g in p.get('girt_elevations') or []:
            try:
                _girt_tops.append(round(float(f(_g)) + FLANGE_IN / 2, 3))
            except Exception:
                pass
    x_main_left = min(v.px(0), v.px(W))
    for _i, _gt in enumerate(sorted(set(_girt_tops))):
        if 0 < _gt < eave:
            # Keep each girt-top chain beside the column line it measures, with a small
            # horizontal stagger so adjacent elevation labels do not sit on one another.
            x_dim = x_main_left - 20 - (_i % 4) * 13
            c.dim_v(
                v.py(0),
                v.py(_gt),
                x_main_left,
                x_main_left,
                x_dim,
                _fmt(_gt) + ' GIRT (TO TOP)',
                T_SMALL,
            )
    x_side = x_main_left - 78
    c.dim_v(v.py(0), v.py(eave), x_main_left, x_main_left, x_side, _fmt(eave) + ' EAVE (TOP OF EAVE PURLIN)', T_DIM)
    if mono:
        hi = float(layout['high_eave_in'])
        c.dim_v(v.py(0), v.py(hi), max(xl, xr), max(xl, xr), bx1 - 30, _fmt(hi) + ' HIGH EAVE', T_DIM, False)
    if layout.get('peak_height_in') and not mono:
        peak = float(layout['peak_height_in'])
        a.text(W / 2, peak + 8, _fmt(peak), T_DIM, 0, 'middle')
    elif layout.get('ridge_top_in'):
        ridge = float(layout['ridge_top_in'])
        a.text(W / 2, ridge + 8, _fmt(ridge), T_DIM, 0, 'middle')


SCHEDULE_COLS = (('MARK', 118), ('SECTION', 108), ('PER LINE', 52), ('LINES', 40), ('TOTAL', 44), ('CUT / BLANK', 90), ('CUT-EDGE RUN (HORIZ.)', 118))


def _schedule_cut(layout, mark):
    for row in layout.get('schedule') or []:
        if row.get('mark') == mark:
            return str(row.get('cut') or '')
    return ''


def _column_cut_labels(c, v, layout, rec=None):
    """Column mark + low-point cut under each physical column on this frame line."""
    physical = {x.get('side'): x for x in (rec or {}).get('primary_connections', [])}
    for col in layout.get('columns') or []:
        local = physical.get(col.get('side'))
        if local and local.get('cut_length_in') is not None:
            mark = local.get('mark') or col.get('mark')
            cut = _fmt(local['cut_length_in'])
        else:
            mark = col.get('mark')
            cut = _schedule_cut(layout, mark)
        if not cut:
            continue
        cx = v.px((float(col['x0']) + float(col['x1'])) / 2)
        c.ptext(cx, v.py(float(col.get('y0') or 0)) - 14, str(mark) + ' CUT ' + cut, T_SMALL, anchor='middle')


def frame_member_rows(job, fid, groups, ends):
    """Consolidated frame-line member schedule rows: [APPLIES TO, MARK, SECTION, PER LINE,
    LINES, TOTAL, CUT / BLANK] - the table that used to sit on every frame-line drawing."""
    layout = job.settings['frame_layouts'][fid]
    out = []
    for recs in groups:
        label = _lines_label(recs)
        for row in _schedule_rows(job, fid, recs[0], layout, len(recs)):
            out.append([label] + list(row))
    for rec in ends:
        label = 'FRAME LINE %d' % rec['index']
        for row in _schedule_rows(job, fid, rec, layout, 1):
            out.append([label] + list(row))
    return out


def _lines_label(recs):
    nums = [str(r['index']) for r in recs]
    return ('FRAME LINE ' if len(nums) == 1 else 'FRAME LINES ') + ', '.join(nums)


def _lean_schedule_rows(job, fid, rec, layout, lines):
    rows = []
    additions = (layout.get('framing_additions') or {}).get('lean_tos') or []
    selected = set(rec.get('lean_tos') or [])
    for lean in additions:
        if selected and lean.get('id') not in selected:
            continue
        station = next(
            (st for st in lean.get('stations') or [] if int(st.get('frame_line') or -1) == int(rec['index'])),
            None,
        )
        if not station:
            continue
        station_no = station.get('index')
        for member in lean.get('members') or []:
            if member.get('station') != station_no or member.get('role') not in ('rafter', 'column'):
                continue
            cut = member.get('cut_length_in')
            blank = member.get('blank_length_in')
            if cut is None:
                cut = member.get('reference_length_in')
            cut_text = _fmt(cut) if cut is not None else 'PENDING'
            blank_text = _fmt(blank) if blank is not None else cut_text
            length_text = cut_text if blank_text == cut_text else cut_text + ' / ' + blank_text
            qty = int(member.get('quantity') or 1)
            rows.append(
                [
                    str(member.get('mark') or lean['id']),
                    str(member.get('profile') or ''),
                    str(qty),
                    str(lines),
                    str(qty * lines),
                    length_text,
                ]
            )
    return rows


def _schedule_rows(job, fid, rec, layout, lines, p=None):
    """Compact frame-line rows with cut blanks and horizontal rafter cut-edge runs."""
    p = p or job.settings['frames'][fid]
    rows = []
    if rec['kind'] == 'end' and rec.get('framed'):
        end = (job.assemblies[fid].derivation.get('endwalls') or {}).get(rec['wall_key']) or {}
        groups = {}
        order = {
            'outer column': 0,
            'bearing post': 1,
            'endwall rafter': 2,
            'roof-bearing opening jamb': 3,
            'wall post (nonbearing)': 4,
        }
        keep_roles = set(order)
        for member in end.get('members') or []:
            if member.get('role') not in keep_roles:
                continue
            key = (
                order[member['role']],
                member['role'],
                member.get('profile_id') or '',
                member.get('reference_cut') or member.get('blank_length') or '',
            )
            group = groups.setdefault(key, [0, []])
            group[0] += int(member.get('quantity') or 1)
            group[1].append(member['mark'])
        for key in sorted(groups):
            qty, marks = groups[key]
            mark = marks[0] if len(marks) == 1 else _common_prefix(marks) + '*'
            run = _edge_run_text(job, fid, rec, layout, mark, p)
            rows.append([mark, key[2], str(qty), '1', str(qty), key[3], run])
        rows.extend(_lean_schedule_rows(job, fid, rec, layout, lines))
        return rows

    physical = rec.get('primary_connections') or []
    if physical:
        emitted_rafters = set()
        emitted_columns = set()
        for item in physical:
            mark = item.get('mark')
            asm = job.assemblies.get(mark)
            if asm and mark not in emitted_columns:
                emitted_columns.add(mark)
                rows.append([mark, asm.main.section, '1', str(lines), str(lines), asm.main.cut_length.fmt()])
            rmark = item.get('rafter_mark')
            if rmark and rmark not in emitted_rafters:
                emitted_rafters.add(rmark)
                rasm = job.assemblies.get(rmark)
                if rasm:
                    rows.append([rmark, rasm.main.section, '1', str(lines), str(lines), rasm.main.cut_length.fmt(), _edge_run_text(job, fid, rec, layout, rmark, p)])
    else:
        graded = GR.line_columns(layout, rec['index'])
        primary_source_marks = {
            str(job.settings['frames'][fid].get(key) or '')
            for key in ('column_mark', 'high_column_mark', 'rafter_mark')
        }
        for srow in layout.get('schedule') or []:
            if str(srow.get('mark') or '') not in primary_source_marks:
                continue
            mine = [row for row in graded.values() if row['mark'] == srow['mark']]
            if mine and any(abs(row['grade_in']) > 1e-9 for row in mine):
                by = {}
                for row in sorted(mine, key=lambda row: row['shop_mark']):
                    by.setdefault(row['shop_mark'], []).append(row)
                for shop_mark, members in by.items():
                    asm = job.assemblies.get(shop_mark)
                    low = asm.derivation.get('column_low_cut_in') if asm else None
                    cut = (
                        _fmt(float(low)) + ' LOW'
                        if low is not None
                        else (asm.main.cut_length.fmt() if asm else members[0]['cut'])
                    )
                    rows.append(
                        [shop_mark, srow['section'], str(len(members)), str(lines), str(len(members) * lines), cut,
                         _edge_run_text(job, fid, rec, layout, shop_mark, p)]
                    )
                continue
            rows.append(
                [
                    srow['mark'],
                    srow['section'],
                    str(srow.get('per_frame') or 1),
                    str(lines),
                    str((srow.get('per_frame') or 1) * lines),
                    str(srow.get('cut') or ''),
                    _edge_run_text(job, fid, rec, layout, str(srow.get('mark') or ''), p),
                ]
            )
    rows.extend(_lean_schedule_rows(job, fid, rec, layout, lines))
    return rows


def frame_line_schedule_rows(job, fid, rec, lines=1):
    """Public schedule rows for a single composed erection frame-line sheet."""
    layout = job.settings['frame_layouts'][fid]
    return _schedule_rows(job, fid, rec, layout, lines)


def _common_prefix(marks):
    pre = marks[0]
    for m in marks[1:]:
        while not m.startswith(pre):
            pre = pre[:-1]
    return pre.rstrip('-')


WALL_COLS = (('MARK', 118), ('MEMBER', 150), ('CUT / LENGTH', 84), ('PER BAY', 50), ('BAYS', 40), ('TOTAL', 44))


def _schedule(c, right, top, rows, title='MEMBERS ON THIS FRAME LINE', cols=SCHEDULE_COLS, row_h=13.0, font=T_SMALL):
    """Small member table with its right edge at ``right``; returns the bottom y."""
    from .canvas import S_TABLE

    widths = [w for _, w in cols]
    x0 = right - sum(widths)
    c.ptext(x0, top + 9, title, min(T_RULE, font + 1.5), bold=True)
    y = top + 13
    for i, values in enumerate([[h for h, _ in cols]] + rows):
        c.pline(x0, y, right, y, S_TABLE)
        xx = x0
        for value, w in zip(values, widths):
            c.ptext(xx + 3, y + min(9.5, row_h - 1.5), str(value), font + (0.5 if i == 0 else 0), bold=(i == 0))
            xx += w
        y += row_h
    c.pline(x0, y, right, y, S_TABLE)
    xx = x0
    for w in widths + [0]:
        c.pline(xx, top + 13, xx, y, S_TABLE)
        xx += w
    return y


def _members_line(job, fid, rec, layout, p):
    if rec['kind'] == 'end' and rec.get('framed'):
        end = (job.assemblies[fid].derivation.get('endwalls') or {}).get(rec['wall_key']) or {}
        cfg = end.get('config') or {}
        posts = end.get('posts') or []
        inner = [q for q in posts if q.get('role') != 'outer column']
        parts = ['END RAFTERS ' + str(cfg.get('resolved_rafter') or rec['rafter'] or '-')]
        parts.append('CORNER COLUMNS ' + str(cfg.get('resolved_column') or '-'))
        parts.append(
            ('%d END POST%s ' % (len(inner), '' if len(inner) == 1 else 'S')) + str(cfg.get('post_section') or '')
            if inner
            else 'NO INTERIOR END POSTS'
        )
        if end.get('members'):
            g = [m for m in end['members'] if m['role'] == 'endwall girt']
            if g:
                parts.append('%d GIRTS %s' % (len(g), g[0]['profile_id']))
            if any(m['role'] == 'base angle' for m in end['members']):
                parts.append('BASE ANGLE')
        if rec['roof_mode'] == 'bypass':
            parts.append('RAKE ANGLE ON THE PURLINS (4 IN LEG DOWN)')
        return ' | '.join(parts + _foundation_words(layout))
    sched = layout.get('schedule') or []
    parts = ['%s %s x%d' % (s['mark'], s['section'], s['per_frame']) for s in sched]
    style = {'fully_welded': 'FULLY WELDED', 'welded_box': 'WELDED APEX BOX', 'bolted': 'BOLTED'}.get(
        str(p.get('connection_style')), str(p.get('connection_style', '')).upper()
    )
    joint = layout.get('ridge_joint')
    if joint == 'cut_and_fold':
        style += ' - ONE-PIECE CUT-AND-FOLD RAFTER'
    elif joint == 'shared_plate':
        style += ' - SHARED RIDGE PLATE'
    sec = p.get('secondary') or {}
    purl = (sec.get('purlin') or {}).get('profile_id') or ''
    girt = (sec.get('girt') or {}).get('profile_id') or ''
    tail = [style]
    if purl:
        tail.append('PURLINS ' + purl + ' ' + str(p.get('purlin_mode', 'bypass')).upper())
    if girt and p.get('girt_elevations'):
        tail.append('GIRTS ' + girt + ' ' + str(p.get('girt_mode', 'bypass')).upper())
    tail.extend(_foundation_words(layout))
    return ' | '.join(parts + tail)


def _foundation_words(layout):
    fnd = layout.get('foundation') or {}
    if fnd.get('type') == 'post_footing':
        return [
            'POST FOOTINGS '
            + str(fnd.get('hole_diameter') or '')
            + ' DIA x '
            + str(fnd.get('hole_depth') or '')
            + ' DEEP'
        ]
    if fnd.get('type') == 'slab':
        return ['SLAB - BASE PLATES ON THE FLOOR']
    return []


def _rafter_depth(job, mark, default=8.0):
    try:
        return float(job.assemblies[mark].main.sec.d)
    except Exception:
        return default


def _adjusted_frame_rafters(job, fid, rec, layout, p=None):
    """Return rafter cut-edge endpoints after this frame line's physical seat offsets."""
    p = p or job.settings['frames'][fid]
    W = float(layout['width_in'])
    mono = layout['frame_type'] == 'monoslope'
    m = float(layout['slope_rise']) / 12
    base_outside = p.get('welded_knee', 'inside_flange') != 'inside_flange'
    cols = layout.get('columns') or []
    physical = {x.get('side'): x for x in rec.get('primary_connections', [])}
    rafters = [dict(r, top_start=list(r['top_start']), top_end=list(r['top_end'])) for r in layout.get('rafters') or []]
    cut_by_mark = {}
    for index, r in enumerate(rafters):
        r['side'] = r.get('side') or ('both' if mono and len(rafters) == 1 else ('left' if index == 0 else 'right'))
    for r in rafters:
        side = r.get('side') or 'both'
        if mono:
            left, right = physical.get('left'), physical.get('right')
            local = left or right
            if not local:
                continue
            actual_mark = local.get('rafter_mark') or r['mark']
            r['mark'] = actual_mark
            if local.get('rafter_cut_length_in') is not None:
                cut_by_mark[actual_mark] = _fmt(local['rafter_cut_length_in'])
            for loc, end in ((left, 'start'), (right, 'end')):
                if not loc:
                    continue
                inside_delta = (1 if loc.get('mode') == 'inside_flange' else 0) - (0 if base_outside else 1)
                col = next((x for x in cols if x.get('side') == loc.get('side')), cols[0] if cols else {})
                column_depth = abs(float(col.get('x1') or 0) - float(col.get('x0') or 0))
                dx = column_depth * inside_delta * (1 if end == 'start' else -1)
                point = r['top_start'] if end == 'start' else r['top_end']
                point[0] += dx
                point[1] += m * dx
            continue
        side_name = side if side in ('left', 'right') else ('left' if r is rafters[0] else 'right')
        local = physical.get(side_name)
        if not local:
            continue
        actual_mark = local.get('rafter_mark') or r['mark']
        r['mark'] = actual_mark
        if local.get('rafter_cut_length_in') is not None:
            cut_by_mark[actual_mark] = _fmt(local['rafter_cut_length_in'])
        inside_delta = (1 if local.get('mode') == 'inside_flange' else 0) - (0 if base_outside else 1)
        col = next((x for x in cols if x.get('side') == side_name), cols[0] if cols else {})
        column_depth = abs(float(col.get('x1') or 0) - float(col.get('x0') or 0))
        dx = column_depth * inside_delta * (1 if side_name == 'left' else -1)
        r['top_start'][0] += dx
        r['top_start'][1] += m * dx * (1 if side_name == 'left' else -1)
    for r in rafters:
        dx = float(r['top_end'][0]) - float(r['top_start'][0])
        dy = float(r['top_end'][1]) - float(r['top_start'][1])
        length = math.hypot(dx, dy) or 1.0
        r['direction'] = (dx / length, dy / length)
        old_nx, old_ny = r.get('normal') or (-dy / length, dx / length)
        nx, ny = -dy / length, dx / length
        if nx * old_nx + ny * old_ny < 0:
            nx, ny = -nx, -ny
        r['normal'] = (nx, ny)
    return rafters, cut_by_mark


def _rafter_edge_records(job, fid, rec, layout, p=None, adjusted=None):
    """[mark, side, endpoint0, endpoint1] for each cut-to-cut rafter leg."""
    if rec.get('kind') == 'end':
        end = (job.assemblies[fid].derivation.get('endwalls') or {}).get(rec.get('wall_key')) or {}
        W = float(layout.get('width_in') or 0)
        out = []
        for member in end.get('members') or []:
            if member.get('role') != 'endwall rafter':
                continue
            x0, x1 = float(member.get('x0_in') or 0), float(member.get('x1_in') or 0)
            y0, y1 = float(member.get('y0_in') or 0), float(member.get('y1_in') or 0)
            out.append([str(member.get('mark') or ''), 'left' if (x0 + x1) / 2 <= W / 2 else 'right', (x0, y0), (x1, y1)])
        return out
    rafters = adjusted if adjusted is not None else _adjusted_frame_rafters(job, fid, rec, layout, p)[0]
    return [[str(r.get('mark') or ''), str(r.get('side') or 'rafter'), tuple(r['top_start']), tuple(r['top_end'])] for r in rafters]


def _edge_run_text(job, fid, rec, layout, mark, p=None):
    runs = _rafter_edge_records(job, fid, rec, layout, p)
    matching = [r for r in runs if r[0] == mark or (mark.endswith('*') and r[0].startswith(mark[:-1]))]
    if not matching:
        return ''
    values = []
    for _, side, p0, p1 in matching:
        run = _fmt(abs(float(p1[0]) - float(p0[0])))
        label = {'left': 'L', 'right': 'R', 'both': 'RAFTER'}.get(side, str(side).upper())
        item = f'{label} {run}'
        if item not in values:
            values.append(item)
    return ' / '.join(values)


def _rigid_frame(a, c, v, job, fid, rec, layout, p, fnd):
    from .frame_sheet import post_footing

    W = float(layout['width_in'])
    mono = layout['frame_type'] == 'monoslope'
    m = float(layout['slope_rise']) / 12
    cos = 1 / math.hypot(1, m)
    cols = [dict(col) for col in layout['columns']]
    physical = {x.get('side'): x for x in rec.get('primary_connections', [])}
    rafter_depth = _rafter_depth(job, layout['rafters'][0]['mark']) / cos
    base_outside = p.get('welded_knee', 'inside_flange') != 'inside_flange'
    for col in cols:
        local = physical.get(col.get('side'))
        if not local:
            continue
        top_delta = (0.0 if local.get('mode') == 'inside_flange' else -rafter_depth) - (
            -rafter_depth if base_outside else 0.0
        )
        col['top_y0'] = float(col.get('top_y0') or col['y1']) + top_delta
        col['top_y1'] = float(col.get('top_y1') or col['y1']) + top_delta
        col['y1'] = float(col.get('y1') or 0) + top_delta
        col['mark'] = local.get('mark') or col['mark']
        col['physical_cut_length_in'] = local.get('cut_length_in')
    # Use identical cut-edge endpoints for the drawing and schedule dimensions.
    rafters, cut_by_mark = _adjusted_frame_rafters(job, fid, rec, layout, p)
    graded = GR.line_columns(layout, rec['index'])  # this line's columns: grade, shop mark (v0.8.43)
    # columns (cut to the pitch at the top), base plates, footings
    for i, col in enumerate(cols):
        x0, x1, y0 = float(col['x0']), float(col['x1']), float(col['y0'])
        grow = graded.get(col['side']) or {}
        g = float(grow.get('grade_in') or 0.0)
        y0 += g
        mark = col['mark'] if col.get('physical_cut_length_in') is not None else (grow.get('shop_mark') or col['mark'])
        a.poly(
            [
                (x0, y0),
                (x1, y0),
                (x1, float(col.get('top_y1') or col['y1'])),
                (x0, float(col.get('top_y0') or col['y1'])),
            ],
            style=S_MEMBER,
        )
        bt = float(col.get('base_thickness') or 0)
        if bt > 0 and fnd.get('type') != 'post_footing':
            a.rect(x0 - 1, y0 - bt, x1 + 1, y0, S_PLATE)
        if fnd.get('type') == 'post_footing':
            post_footing(a, (x0 + x1) / 2, fnd, label=(i == 0), ground_in=g)
        if abs(g) > 1e-9:
            a.text(
                (x0 + x1) / 2,
                y0 - 7 - (bt if fnd.get('type') != 'post_footing' else 0),
                GR.base_note(g),
                T_SMALL,
                0,
                'middle',
            )
        top = float(col.get('top_y0') or col['y1'])
        inside = x1 + 3 if col['side'] == 'left' else x0 - 3
        if (x1 - x0) * v.sx >= 11:
            _mark(a, (x0 + x1) / 2, (y0 + top) / 2, mark, 90)
        else:
            _mark(a, inside, (y0 + top) / 2, mark, 90)
    # rafters: parallelogram of the plumb depth; one polygon for a one-piece cut-and-fold rafter
    fold = layout.get('ridge_joint') == 'cut_and_fold' and len(rafters) == 2
    polys = []
    for r in rafters:
        (xs, ys), (xe, ye) = r['top_start'], r['top_end']
        dp = _rafter_depth(job, r['mark']) / cos
        polys.append([(xs, ys), (xe, ye), (xe, ye - dp), (xs, ys - dp)])
    if fold:
        (ls, le, lb, lsb), (rs, re_, rb, rsb) = polys
        a.poly([ls, le, rs, rsb, lb, lsb], style=S_MEMBER)
    else:
        for poly in polys:
            a.poly(poly, style=S_MEMBER)
        if not mono and len(rafters) == 2:
            xr, yr = rafters[0]['top_end']
            dp = _rafter_depth(job, rafters[0]['mark']) / cos
            a.rect(xr - 0.25, yr - dp - 2, xr + 0.25, yr + 0.5, S_PLATE)
    for r in rafters:
        (xs, ys), (xe, ye) = r['top_start'], r['top_end']
        dp = _rafter_depth(job, r['mark']) / cos
        ang = math.degrees(math.atan2(ye - ys, xe - xs))
        if ang > 90 or ang < -90:
            ang += 180
        _cut = cut_by_mark.get(r['mark']) or _schedule_cut(layout, r['mark'])
        _mark(a, (xs + xe) / 2, (ys + ye) / 2 - dp / 2, r['mark'] + (' - ' + _cut if _cut else ''), ang)
    # purlins at the clip stations (bypass: on the rafter top; flush / channel rafter: inside)
    pd = float(layout.get('nominal_roof_purlin_depth_in') or rec['purlin_depth_in'] or 8)
    flush = str(p.get('purlin_mode')) == 'flush' or rec['roof_mode'] == 'flush'
    default_stations = [
        float(z['station_in']) for z in layout.get('clip_records') or [] if z.get('station_in') is not None
    ]
    for r in rafters:
        local = physical.get(r.get('side')) or physical.get('left') or physical.get('right')
        stations = (
            [float(x) for x in local.get('rafter_purlin_stations_in', [])]
            if local and 'rafter_purlin_stations_in' in local
            else default_stations
        )
        (xs, ys) = r['top_start']
        dx, dy = r['direction']
        nx, ny = r['normal']
        for s in stations:
            px, py = xs + dx * s, ys + dy * s
            sgn = -1 if flush else 1
            a.line(px, py, px + sgn * nx * pd, py + sgn * ny * pd, S_SECOND)  # purlin as one line
    # eave struts: plumb section at the outside wall line on the rafter end
    strut = float(layout.get('strut_depth_in') or 0)
    if strut > 0:
        for r in rafters:
            (xs, ys) = r['top_start']
            out = 1 if xs < W / 2 else -1
            # the eave purlin/strut stands at the EDGE OF BUILDING (wall line); the rafter
            # is inset in the column, so the member is drawn at the wall, tied to the rafter
            wall_x = 0.0 if xs < W / 2 else W
            a.line(xs, ys + strut, wall_x, ys + strut, S_SECOND)
            a.rect(
                min(wall_x, wall_x - out * STRUT_FLANGE_IN),
                ys,
                max(wall_x, wall_x - out * STRUT_FLANGE_IN),
                ys + strut,
                S_SECOND,
            )
        if mono and len(rafters) == 1:
            (xe, ye) = rafters[0]['top_end']
            a.rect(xe - STRUT_FLANGE_IN, ye, xe, ye + strut, S_SECOND)
    # girts: section (depth into the building x flange) at each elevation on both columns
    gd = _depth(((p.get('secondary') or {}).get('girt') or {}).get('profile_id'), f(p.get('girt_depth') or '8'))
    bypass = str(p.get('girt_mode', 'bypass')) == 'bypass'
    elevations = []
    for g in p.get('girt_elevations') or []:
        try:
            elevations.append(f(g))
        except Exception:
            pass
    sides = _sheeted_sides(p)
    for col in cols:
        face = col['side']
        if face not in sides:
            continue
        x_wall = float(col['x0']) if face == 'left' else float(col['x1'])
        out = -1 if face == 'left' else 1
        for y in elevations:
            if bypass:
                x0, x1 = sorted((x_wall, x_wall + out * gd))
            else:
                x0, x1 = sorted((x_wall, x_wall - out * gd))
            a.rect(x0, y - FLANGE_IN / 2, x1, y + FLANGE_IN / 2, S_SECOND)
        if layout.get('starting_wall_runs'):
            for run in layout['starting_wall_runs']:
                if run.get('side') == face and run.get('role') == 'base_angle':
                    _base_angle_section(a, x_wall, out, run)
    return rafters


def _sheeted_sides(p):
    from .. import enclosure

    class _P:  # enclosure.states reads attributes
        cladding = p.get('cladding') or {}
        endwalls = p.get('endwalls') or {}

    st = enclosure.states(_P)
    return {k for k in ('left', 'right') if st.get(k) == 'sheeted'}


def _base_angle_section(a, x_wall, out, run):
    vleg = float(run.get('vertical_leg_in') or 2)
    hleg = float(run.get('horizontal_leg_in') or 4)
    y = float(run.get('elevation_in') or 0)
    a.line(x_wall, y, x_wall, y + vleg, S_SECOND)
    a.line(x_wall, y, x_wall - out * hleg, y, S_SECOND)


def _roof_line(a, layout, rec):
    W = float(layout['width_in'])
    mono = layout['frame_type'] == 'monoslope'
    eave = float(layout['low_eave_in'])
    m = float(layout['slope_rise']) / 12
    roof = (lambda x: eave + m * x) if mono else (lambda x: eave + m * min(x, W - x))
    mid = W if mono else W / 2
    ext = 8.0
    a.line(-ext, roof(0) - ext * m, mid, roof(mid), S_ROOF)
    if not mono:
        a.line(mid, roof(mid), W + ext, roof(W) - ext * m, S_ROOF)
    _slope = math.hypot(1, m)
    _leans = (layout.get('framing_additions') or {}).get('lean_tos', [])
    _lean_left = any(z.get('face') == 'left' and z.get('roof_continuity') == 'main_plane' for z in _leans)
    _lean_right = any(z.get('face') == 'right' and z.get('roof_continuity') == 'main_plane' for z in _leans)
    if not _lean_left:
        # ONE overall sheet dimension per slope; the overhang dimensioned apart
        _slope_dim(a, -ext, roof(0) - ext * m, mid, roof(mid), 14, 'ROOF SHEET ' + _fmt((mid + ext) * _slope))
        _slope_dim(a, -ext, roof(0) - ext * m, 0, roof(0), 23, _fmt(ext * _slope) + ' OH')
    if not mono and not _lean_right:
        _slope_dim(a, mid, roof(mid), W + ext, roof(W) - ext * m, 14, 'ROOF SHEET ' + _fmt((mid + ext) * _slope))
        _slope_dim(a, W, roof(W), W + ext, roof(W) - ext * m, 23, _fmt(ext * _slope) + ' OH')
    # roof sheet on the purlins, drawn raised off the rafter/purlin line so it never
    # touches the framing; ridge cap at true scale (7 in of cover each side of the peak)
    soff = 3.0
    norm = math.hypot(1, m)
    ox, oy = -m / norm * soff, 1 / norm * soff
    a.line(-ext + ox, roof(0) - ext * m + oy, mid + ox, roof(mid) + oy, S_ROOF)
    if not mono:
        a.line(mid + ox, roof(mid) + oy, W + ext + ox, roof(W) - ext * m + oy, S_ROOF)
        cap = 7.0
        rise = cap * m
        a.line(mid - cap + ox, roof(mid) - rise + oy, mid + ox, roof(mid) + oy + 1, S_ROOF)
        a.line(mid + ox, roof(mid) + oy + 1, mid + cap + ox, roof(mid) - rise + oy, S_ROOF)
    # a lean roof that CONTINUES the main plane is sheeted ridge-to-lean-eave in
    # ONE piece: the sheet line runs past the wall down the lean slope
    for z in (layout.get('framing_additions') or {}).get('lean_tos', []):
        if z.get('face') not in ('left', 'right') or z.get('roof_continuity') != 'main_plane':
            continue
        sign = -1 if z['face'] == 'left' else 1
        xw = 0 if sign < 0 else W
        P = float(z['projection_in'])
        oh = float(z.get('roof_overhang_in') or 0) / math.hypot(1, m)
        x1 = xw + sign * (P + oh)
        y1 = roof(xw) - m * (P + oh)
        a.line(xw + ox, roof(xw) + oy, x1 + ox, y1 + oy, S_ROOF)
        _slope_dim(a, x1, y1, mid, roof(mid), 14, 'ONE ROOF SHEET RIDGE TO LEAN EAVE ' + _fmt((mid + P + oh) * _slope))


def _end_wall(a, c, v, job, fid, rec, layout, p, fnd):
    from .frame_sheet import post_footing

    W = float(layout['width_in'])
    mono = layout['frame_type'] == 'monoslope'
    end = (job.assemblies[fid].derivation.get('endwalls') or {}).get(rec['wall_key']) or {}
    posts = end.get('posts') or []
    members = end.get('members') or []
    m = float(layout['slope_rise']) / 12
    cos = 1 / math.hypot(1, m)
    # end rafters (top line as modelled, plumb depth from the profile)
    rafters = [z for z in members if z['role'] == 'endwall rafter']
    for z in rafters:
        d = _depth(z.get('profile_id'), 8.0) / cos
        a.poly(
            [
                (z['x0_in'], z['y0_in']),
                (z['x1_in'], z['y1_in']),
                (z['x1_in'], z['y1_in'] - d),
                (z['x0_in'], z['y0_in'] - d),
            ],
            style=S_MEMBER,
        )
        ang = math.degrees(math.atan2(z['y1_in'] - z['y0_in'], (z['x1_in'] - z['x0_in']) * (1 if v.sx > 0 else -1)))
        if ang > 90 or ang < -90:
            ang += 180
        _mark(a, (z['x0_in'] + z['x1_in']) / 2, (z['y0_in'] + z['y1_in']) / 2 - d / 2, z['mark'], ang)
    # posts and corner columns, cut to the roof pitch at the top
    for i, q in enumerate(posts):
        x, w = float(q['x']), float(q['width'])
        bottom = float(q.get('bottom') or 0)
        lo, hi = float(q.get('top_low') or 0), float(q.get('top_high') or q.get('top_low') or 0)
        rising = mono or x < W / 2 - 0.5
        if not mono and abs(x - W / 2) <= 0.5:
            top = [(x - w / 2, lo), (x, hi), (x + w / 2, lo)]
        elif rising:
            top = [(x - w / 2, lo), (x + w / 2, hi)]
        else:
            top = [(x - w / 2, hi), (x + w / 2, lo)]
        a.poly([(x - w / 2, bottom), (x + w / 2, bottom)] + top[::-1], style=S_MEMBER)
        g = float(q.get('grade_in') or 0.0)  # grade at this post (v0.8.43)
        if fnd.get('type') == 'post_footing':
            post_footing(a, x, fnd, label=(i == (0 if v.sx > 0 else len(posts) - 1)), ground_in=g)
        else:
            a.rect(x - w / 2 - 1, bottom - 0.5, x + w / 2 + 1, bottom, S_PLATE)
        if abs(g) > 1e-9:
            a.text(
                x, bottom - 7 - (0.5 if fnd.get('type') != 'post_footing' else 0), GR.base_note(g), T_SMALL, 0, 'middle'
            )
        if w * abs(v.sx) >= 11:
            _mark(a, x, (max(bottom, 0) + lo) / 2, q['mark'], 90)
        else:
            _mark(a, x + w / 2 + 3, (max(bottom, 0) + lo) / 2, q['mark'], 90)
    # girts (visible flange band), base angle, marks at the left margin
    girts = [z for z in members if z['role'] == 'endwall girt']
    _post_at = {round(float(q['x']), 3): float(q['width']) for q in posts}
    for z in girts:
        y = float(z['y0_in'])
        gx0, gx1 = min(z['x0_in'], z['x1_in']), max(z['x0_in'], z['x1_in'])
        # piece endpoints are post centres; the drawn girt starts at the inside face
        if round(gx0, 3) in _post_at:
            gx0 += _post_at[round(gx0, 3)] / 2
        if round(gx1, 3) in _post_at:
            gx1 -= _post_at[round(gx1, 3)] / 2
        a.rect(gx0, y - FLANGE_IN / 2, gx1, y + FLANGE_IN / 2, S_SECOND)
    _face0 = {'front_end': 'front', 'rear_end': 'rear', 'outer_front_end': 'outer_front'}.get(rec['wall_key'], 'rear')
    _walks = [
        o
        for o in (layout.get('framing_additions') or {}).get('openings', [])
        if o.get('face') == _face0 and _is_walk(o)
    ]
    for z in members:
        if z['role'] == 'base angle':
            yb = float(z.get('y0_in') or 0.0)  # on the lower slab of a graded bay (v0.8.43)
            bx0_, bx1_ = min(z['x0_in'], z['x1_in']), max(z['x0_in'], z['x1_in'])
            segs = [(bx0_, bx1_)]
            for o in _walks:
                ox, ow = float(o['x_in']), float(o['width_in'])
                if v.sx < 0:
                    ox = W - ox - ow
                segs = [
                    q
                    for a0, a1 in segs
                    for q in ((a0, min(a1, ox - 0.5)), (max(a0, ox + ow + 0.5), a1))
                    if q[1] - q[0] > 0.25
                ]
            for a0, a1 in segs:
                a.rect(a0, yb, a1, yb + 2, S_SECOND)
    # purlins (through the end wall at the main purlin stations) on / in the end rafter
    pd = float(rec['purlin_depth_in'] or 8)
    main = layout['rafters']
    stations = [float(z['station_in']) for z in layout.get('clip_records') or [] if z.get('station_in') is not None]
    for r in main:
        (xs, ys) = r['top_start']
        dx, dy = r['direction']
        nx, ny = r['normal']
        for s in stations:
            x = xs + dx * s
            top = _end_top(rafters, x)
            if top is None:
                continue
            sgn = 1 if rec['roof_mode'] == 'bypass' else -1
            a.line(x, top, x + sgn * nx * pd, top + sgn * ny * pd, S_SECOND)  # purlin as one line
    # openings on this face (clear opening in red, jambs / headers as members)
    face = {'front_end': 'front', 'rear_end': 'rear', 'outer_front_end': 'outer_front'}.get(rec['wall_key'], 'rear')
    for o in (layout.get('framing_additions') or {}).get('openings', []):
        if o.get('face') != face:
            continue
        x, y, w, h = float(o['x_in']), float(o['y_in']), float(o['width_in']), float(o['height_in'])
        if v.sx < 0:
            x = W - x - w  # outside-view x on a mirrored sheet: plot where the door really is
        a.rect(x, y, x + w, y + h, S_NOTE)
        if _is_walk(o):
            _walk_flange(a, x, y, w, h)
        a.text(x + w / 2, y + h / 2, o['id'], T_MARK, 0, 'middle')
        # set out OUT-TO-OUT: from the outside face of the NEAREST corner column
        # (the wall line, never the column centre) to the inside jamb face.  Where the
        # opening's own jamb posts stand in the post chain below, that chain already
        # measures to the FACE - the setout is not drawn twice (owner 0.8.53).
        _jambed = any(
            'jamb' in str(q.get('role') or '')
            and min(abs(float(q['x']) - float(o['x_in'])), abs(float(q['x']) - (float(o['x_in']) + w))) < 3
            for q in posts
        )
        _j = sorted((v.px(x), v.px(x + w)))
        _oy = v.py(0) + 66  # door dimensions live at the bottom of the drawing
        if x <= W - x - w:
            _corner, _near, _setout = v.px(0), _j[0] if v.sx > 0 else _j[1], x
        else:
            _corner, _near, _setout = v.px(W), _j[1] if v.sx > 0 else _j[0], W - x - w
        if not _jambed and abs(_near - _corner) > 24:
            c.dim_h(
                _corner,
                _near,
                v.py(0),
                v.py(0),
                _oy,
                _fmt(_setout) + ' FROM OUTSIDE FACE OF CORNER',
                T_DIM,
                text_above=True,
            )
        for part in o.get('members', []):
            if part.get('shared_member_ref'):
                continue
            _px0, _px1 = float(part['x0_in']), float(part['x1_in'])
            if v.sx < 0:
                _px0, _px1 = W - _px0, W - _px1
            a.rect(min(_px0, _px1), part['y0_in'], max(_px0, _px1), part['y1_in'])
    # post stations along the bottom
    xs_ = sorted(float(q['x']) for q in posts)
    if len(xs_) >= 2:
        y_row = (v.py(0) if fnd.get('type') != 'post_footing' else v.py(-float(fnd.get('hole_depth_in') or 0))) + 10
        _face_open = [o for o in (layout.get('framing_additions') or {}).get('openings', []) if o.get('face') == face]
        mids = []
        for q in posts:
            if q.get('role') == 'outer column':
                continue
            qx = float(q['x'])
            if 'jamb' in str(q.get('role') or ''):
                # an opening jamb post is measured to the FACE of the opening, not its centre
                for o in _face_open:
                    for fx_ in (float(o['x_in']), float(o['x_in']) + float(o['width_in'])):
                        if abs(qx - fx_) < 3:
                            qx = fx_
            mids.append(qx)
        chain = [0.0] + sorted(set(mids)) + [W]  # OUT to centre of INTERMEDIATE posts only; corners out-to-out
        for x0, x1 in zip(chain, chain[1:]):
            xa, xb = sorted((v.px(x0), v.px(x1)))
            if xb - xa > 8:
                c.dim_h(xa, xb, v.py(0), v.py(0), y_row, _fmt(x1 - x0), T_DIM, text_above=True)
    if not posts:
        a.text(
            W / 2, float(layout['low_eave_in']) / 2, 'OPEN END WALL - NO END POSTS', T_CAPTION, 0, 'middle', bold=True
        )


def _is_walk(o):
    """A walk door (not an overhead / framed opening): 2.5 in flange all around it on the
    framing drawings, and the base angle stops 1/2 in clear of its face (owner 0.8.53)."""
    return float(o.get('width_in') or 0) <= 48 and float(o.get('height_in') or 0) <= 90


def _walk_flange(a, x, y, w, h):
    f = 2.5
    a.rect(x - f, y, x, y + h + f, S_SECOND)
    a.rect(x + w, y, x + w + f, y + h + f, S_SECOND)
    a.rect(x - f, y + h, x + w + f, y + h + f, S_SECOND)


def _purlin_station_dims(a, layout, rec):
    """Dimension main-roof purlin stations from the main-building eave, above the roof-sheet chain."""
    W = float(layout['width_in'])
    rafters = layout.get('rafters') or []
    if not rafters:
        return
    pd = float(layout.get('nominal_roof_purlin_depth_in') or rec.get('purlin_depth_in') or 8)
    flush = str(rec.get('roof_mode') or '').lower() == 'flush'
    scale = max(0.1, min(abs(a.v.sx), abs(a.v.sy)))
    offset = (0.0 if flush else pd) + 14.0 + 32.0 / scale
    local_by_side = {item.get('side'): item for item in rec.get('primary_connections') or []}
    default_stations = sorted(
        {
            round(float(row['station_in']), 3)
            for row in layout.get('clip_records') or []
            if row.get('station_in') is not None
        }
    )
    mono = layout.get('frame_type') == 'monoslope'
    for index, r in enumerate(rafters):
        (xs, ys), (xe, ye) = r['top_start'], r['top_end']
        dx, dy = float(xe) - float(xs), float(ye) - float(ys)
        total = math.hypot(dx, dy)
        if total < 1e-6:
            continue
        ux, uy = dx / total, dy / total
        side = r.get('side') or ('both' if mono and len(rafters) == 1 else ('left' if index == 0 else 'right'))
        local = local_by_side.get(side) or (local_by_side.get('left') if side == 'both' else None)
        stations = sorted(
            {
                round(float(s), 3)
                for s in (local.get('rafter_purlin_stations_in') if local else default_stations)
                if s is not None
            }
        )
        wall_x = 0.0 if abs(float(xs) - 0.0) <= abs(float(xs) - W) else W
        s_eave = (wall_x - float(xs)) / ux if abs(ux) > 1e-9 else 0.0
        at_start = abs(float(xs) - wall_x) <= abs(float(xe) - wall_x)
        if at_start:
            values = [s_eave] + [s for s in stations if s_eave + 0.01 < s < total - 0.01] + [total]
        else:
            values = [s_eave] + [s for s in reversed(stations) if 0.01 < s < s_eave - 0.01] + [0.0]
        values = [value for i, value in enumerate(values) if i == 0 or abs(value - values[i - 1]) > 0.05]
        points = [(float(xs) + ux * s, float(ys) + uy * s) for s in values]
        CV.slope_dimension_chain(a, points, offset)
        eave_point = points[0]
        inboard = 1.0 if wall_x < W / 2 else -1.0
        a.text(
            eave_point[0] + inboard * 18,
            eave_point[1] - 12,
            'MAIN EAVE',
            7,
            anchor='start' if inboard > 0 else 'end',
            style=CV.S_DIM,
        )


def _slope_dim(a, x0, y0, x1, y1, off, label):
    """Dimension line parallel to a slope, ``off`` inches clear of it, with end
    ticks and the measured length lettered on it (owner 0.8.54)."""
    dx, dy = x1 - x0, y1 - y0
    L = math.hypot(dx, dy)
    if L < 1:
        return
    ux, uy = dx / L, dy / L
    nx, ny = -uy, ux
    if ny < 0:
        nx, ny = -nx, -ny
    ax, ay, bx, by = x0 + nx * off, y0 + ny * off, x1 + nx * off, y1 + ny * off
    a.line(ax, ay, bx, by, S_BUBBLE)
    for px, py in ((x0, y0), (x1, y1)):
        a.line(px, py, px + nx * (off + 3), py + ny * (off + 3), S_BUBBLE)
    ang = math.degrees(math.atan2(uy, ux))
    if ang > 90 or ang < -90:
        ang += 180
    a.text((ax + bx) / 2, (ay + by) / 2 + 4, label, T_SMALL, ang, 'middle')


def _end_top(rafters, x):
    for z in rafters:
        x0, x1 = sorted((float(z['x0_in']), float(z['x1_in'])))
        if x0 - 0.01 <= x <= x1 + 0.01:
            if x1 == x0:
                return float(z['y0_in'])
            t = (x - float(z['x0_in'])) / (float(z['x1_in']) - float(z['x0_in']))
            return float(z['y0_in']) + t * (float(z['y1_in']) - float(z['y0_in']))
    return None


# ----------------------------------------------------------------------------- side walls (S)
def _wall_rows(job, fid, face, recs, layout, pieces, p, bays):
    """Member rows for the side-wall table: columns / posts on the wall line, then the eave struts,
    girts and base angle of this wall grouped by product and cut length."""
    rows = []
    ends = job.assemblies[fid].derivation.get('endwalls') or {}
    col = next((k for k in layout['columns'] if k['side'] == face), None)
    sched = {r['mark']: r for r in layout.get('schedule') or []}
    uprights = {}
    for rec in recs:
        mark = sec = cut = None
        if rec['kind'] == 'end':
            end = ends.get(rec['wall_key']) or {}
            posts = end.get('posts') or []
            post = (posts[-1] if face == 'right' else posts[0]) if posts else None
            if post:
                mem = next((m for m in end.get('members') or [] if m.get('mark') == post['mark']), {})
                mark = post['mark']
                sec = str(mem.get('profile_id') or post.get('profile') or '')
                cut = str(mem.get('reference_cut') or mem.get('blank_length') or '')
        if mark is None and col:
            srow = sched.get(col['mark']) or {}
            mark, sec, cut = col['mark'], str(srow.get('section') or ''), str(srow.get('cut') or '')
            grow = GR.line_columns(layout, rec['index']).get(face) or {}
            if grow and abs(float(grow.get('grade_in') or 0.0)) > 1e-9:  # cut to its grade (v0.8.43)
                asm = job.assemblies.get(grow['shop_mark'])
                low = asm.derivation.get('column_low_cut_in') if asm else None
                mark = grow['shop_mark']
                cut = (_fmt(float(low)) + ' LOW' if low is not None else grow['cut']) + ' / ' + grow['grade']
        if mark is None:
            continue
        g = uprights.setdefault(mark, [sec, cut, 0])
        g[2] += 1
    for mark, (sec, cut, n) in uprights.items():
        rows.append([mark, sec, cut, '-', '-', str(n)])
    groups = {}
    order = {'eave': 0, 'girt': 1, 'base_angle': 2}
    for z in pieces:
        key = (order.get(z['role'], 3), z['role'], z.get('profile_id') or '', z.get('cut_length') or '')
        g = groups.setdefault(key, [0, set(), []])
        g[0] += 1
        g[1].add(z.get('bay'))
        if z.get('cut_mark'):
            g[2].append(z['cut_mark'])
    for key in sorted(groups):
        qty, in_bays, marks = groups[key]
        n_b = max(1, len(in_bays))
        mark = (marks[0] if len(set(marks)) == 1 else _common_prefix(marks) + '*') if marks else '-'
        name = {'eave': 'EAVE STRUT ', 'girt': 'GIRT ', 'base_angle': 'BASE ANGLE '}.get(key[1], key[1].upper() + ' ')
        per = qty // n_b if qty % n_b == 0 else '%.1f' % (qty / n_b)
        rows.append([mark, name + key[2], key[3], str(per), str(n_b), str(qty)])
    return rows


def sidewall_member_rows(job, fid, side):
    """Wall-member rows for one outside elevation."""
    from .frameline_sheets import _bays, _pieces

    face = SIDE_FACE[side]
    layout = job.settings['frame_layouts'][fid]
    p = job.settings['frames'][fid]
    recs = FL.lines(job, fid)
    pieces = [z for z in _pieces(job, fid) if z.get('side') == face and z.get('role') in ('eave', 'girt', 'base_angle')]
    return _wall_rows(job, fid, face, recs, layout, pieces, p, list(_bays(job, fid)))


def sidewall_member_schedule(sh, job, fid, side, right, top, row_h=12.0, font=7.0, rows=None):
    """Draw the wall-member schedule in a caller-reserved page margin, never over an elevation."""
    rows = sidewall_member_rows(job, fid, side) if rows is None else rows
    title = ('FRONT' if side == 'front' else 'BACK') + ' SIDEWALL MEMBERS'
    return _schedule(Canvas(sh), right, top, rows, title, WALL_COLS, row_h=row_h, font=font), rows


def sidewall(sh, job, fid, side, box, bubbles=True, member_schedule=True):
    """Side wall framing elevation (outside view) in ``box``; returns the paper y below the view
    where a table may continue."""
    from .frameline_sheets import _bay_state, _bays, _pieces

    if side not in SIDE_FACE:
        raise KeyError(side)
    face = SIDE_FACE[side]
    layout = job.settings['frame_layouts'][fid]
    p = job.settings['frames'][fid]
    L = FL.length_in(job, fid)
    mono = layout['frame_type'] == 'monoslope'
    eave = float(layout['high_eave_in'] if (mono and face == 'right') else layout['low_eave_in'])
    strut = float(layout.get('strut_depth_in') or 0)
    recs = FL.lines(job, fid)
    fnd = layout.get('foundation') or {}
    below = float(fnd.get('hole_depth_in') or 0) if fnd.get('type') == 'post_footing' else 0.0
    c = Canvas(sh)
    title = (
        SIDE_TITLE[side]
        + ' FRAMING - OUTSIDE VIEW ('
        + ('LEFT END AT LEFT' if side == 'front' else 'RIGHT END AT LEFT, MIRRORED')
        + ') - LENGTH '
        + _fmt(L)
        + ' OUTSIDE WALLS'
    )
    sheeted = face in _sheeted_sides(p)
    rule = (
        'Eave height '
        + _fmt(eave)
        + ' = floor to the TOP OF THE EAVE PURLIN (the roof line at the wall); '
        + (
            'FLUSH mount: the purlin top is flush with the rafter top, so the rafter top IS the roof line. '
            if strut <= 0
            else 'BYPASS: the purlin bears on the rafter top flange ('
            + _fmt(strut)
            + ' deep), one purlin below the roof line. '
        )
    ) + (
        'Girts '
        + str(p.get('girt_mode', 'bypass')).upper()
        + ' at '
        + ', '.join(str(g) for g in (p.get('girt_elevations') or []))
        + '.'
        if sheeted and p.get('girt_elevations')
        else 'OPEN WALL - no girts, no sheets.'
    )
    lines = '%d frame lines: ' % len(recs) + '; '.join(
        '%d %s @ %s' % (r['index'], r['label'], _fmt(r['station_in'])) for r in recs
    )
    _states = []
    for _bn, _s0, _s1, _zone in _bays(job, fid):
        _st, _gn = _bay_state(_zone, face)
        if not sheeted:
            _st = 'open'
        _states.append((((_zone or {}).get('id') or ('B%d' % _bn)) + ' ' + _st.upper()))
    if _states:
        lines += ' | BAYS: ' + ', '.join(_states)
    y_top = _caption(c, box, title, rule, lines)
    bx0, by0, bx1, by1 = box
    if L <= 0:
        c.ptext(
            bx0 + 6, y_top + 16, 'Master building length is not set - no longitudinal layout to draw.', 10, style=S_NOTE
        )
        return y_top + 24
    sx = (lambda s: s) if side == 'front' else (lambda s: L - s)
    bays = list(_bays(job, fid))
    pieces = [z for z in _pieces(job, fid) if z.get('side') == face and z.get('role') in ('eave', 'girt', 'base_angle')]
    # Archive sheets keep a compact schedule at the side; composed erection sheets suppress
    # it here and place it in a dedicated bottom-of-page schedule band instead.
    rows = _wall_rows(job, fid, face, recs, layout, pieces, p, bays)
    pieces = [z for z in pieces if z['role'] != 'base_angle']
    table_bottom = _schedule(c, bx1 - 8, y_top + 6, rows, 'MEMBERS ON THIS WALL', WALL_COLS) if rows and member_schedule else y_top
    view_top = max(y_top + 10, table_bottom + 8) if member_schedule else y_top + 10
    H = eave + 22  # room for the marks above the columns and the bay captions
    for z in (layout.get('framing_additions') or {}).get('lean_tos', []):
        if z.get('face') == face:
            H = max(H, float(z.get('high_eave_in') or 0) + 22)
    bottom_room = 78 if bubbles else 46
    v = fit((bx0 + 96, view_top, bx1 - 30, by1 - bottom_room), -12, L + 12, -below - 4, H + 6)
    a = Canvas(sh, v)
    a.line(-10, 0, L + 10, 0, S_CL)
    if fnd.get('type') == 'slab':
        from ..standards import SLAB_THICKNESS_IN

        a.rect(-10, -SLAB_THICKNESS_IN, L + 10, 0, S_MEMBER)
    # bay states behind the framing
    for bay_no, s0, s1, zone in _bays(job, fid):
        state, _girts_now = _bay_state(zone, face)
        if not sheeted:
            state = 'open'
        x0, x1 = sorted((sx(s0), sx(s1)))
        label = (zone or {}).get('id') or ('B%d' % bay_no)
        if state in ('open', 'future'):
            a.rect(x0 + 2, 2, x1 - 2, eave - strut - 2, S_FUTURE)
        a.text((x0 + x1) / 2, eave + 5, label, T_MARK, 0, 'middle', bold=True)
    # columns / end posts at every frame line
    from .frame_sheet import post_footing

    ends = job.assemblies[fid].derivation.get('endwalls') or {}
    col = next((k for k in layout['columns'] if k['side'] == face), None)
    for rec in recs:
        x = sx(rec['station_in'])
        if fnd.get('type') == 'post_footing':
            post_footing(a, x, fnd, label=False)
        if rec['kind'] == 'end':
            end = ends.get(rec['wall_key']) or {}
            posts = end.get('posts') or []
            post = (posts[-1] if face == 'right' else posts[0]) if posts else None
            if post:
                w = float(post['width'])
                top = float(post.get('top_low') or eave - strut)
                bottom = float(post.get('bottom') or 0)
                # corner column: OUTSIDE FACE on the frame line, post inside the
                # building (a junction end line insets toward the enclosed bays)
                _st = float(rec['station_in'])
                if _st <= 0:
                    _dir = 1.0
                elif _st >= L - 1e-6:
                    _dir = -1.0
                else:
                    _zb = {b[0]: b for b in _bays(job, fid)}
                    _after = _zb.get(rec['index'], (0, 0, 0, None))[3]
                    _before = _zb.get(rec['index'] - 1, (0, 0, 0, None))[3]
                    _dir = (
                        1.0
                        if ((_after or {}).get(face) == 'sheeted' or (_before or {}).get(face) != 'sheeted')
                        else -1.0
                    )
                _m0, _m1 = sorted((_st, _st + _dir * w))
                a.poly(
                    [(sx(_m0), bottom), (sx(_m1), bottom), (sx(_m1), top), (sx(_m0), top)],
                    style=S_WALL_POST,
                )
                if eave - strut > top + 0.5:  # end rafter end seen from outside, on the corner column
                    a.poly(
                        [(sx(_m0), top), (sx(_m1), top), (sx(_m1), eave - strut), (sx(_m0), eave - strut)],
                        style=S_WALL_POST,
                    )
                _mark(a, (sx(_m0) + sx(_m1)) / 2, eave + 14, post['mark'], 0, bold=True)
                if abs(float(post.get('grade_in') or 0.0)) > 1e-9:
                    a.text(x, bottom - 7, GR.base_note(float(post['grade_in'])), T_SMALL, 0, 'middle')
                # Keep the frame-line datum visible only beyond the post; a center stroke
                # through the filled HSS profile made one column read as two members.
                a.line(x, -4, x, 0, S_CL)
                a.line(x, top, x, eave + 10, S_CL)
                continue
        if col:
            try:
                w = float(job.assemblies[col['mark']].main.sec.bf)
            except Exception:
                w = float(col['x1'] - col['x0'])
            top = float(col.get('y1') or col.get('top_y0') or eave - strut)
            grow = GR.line_columns(layout, rec['index']).get(face) or {}
            g = float(grow.get('grade_in') or 0.0)
            a.rect(x - w / 2, float(col['y0']) + g, x + w / 2, top, S_WALL_POST)
            if eave - strut > top + 0.5:  # rafter end on the column seat, seen from outside
                a.rect(x - w / 2, top, x + w / 2, eave - strut, S_WALL_POST)
            _mark(a, x, eave + 14, grow.get('shop_mark') or col['mark'], 0, bold=True)
            if abs(g) > 1e-9:
                a.text(x, float(col['y0']) + g - 7, GR.base_note(g), T_SMALL, 0, 'middle')
        else:
            a.line(x, 0, x, eave - strut)
        if col:
            a.line(x, -4, x, float(col['y0']) + g, S_CL)
            a.line(x, top, x, eave + 10, S_CL)
        else:
            a.line(x, -4, x, eave + 10, S_CL)
    # eave strut (web face, full depth) and girts (visible flange) from the secondary runs, each
    # piece named with its cut mark (the mark on the shipping list and the cut sheet)
    drawn = 0
    for z in pieces:
        s0, s1 = z.get('start_in'), z.get('end_in')
        if s0 is None or s1 is None:
            s0, s1 = z.get('support_start_in'), z.get('support_end_in')
        if s0 is None or s1 is None:
            continue
        x0, x1 = sorted((sx(float(s0)), sx(float(s1))))
        if z['role'] == 'eave':
            a.rect(x0, eave - strut, x1, eave, S_SECOND)
            y_label = eave - strut / 2 - 2.5
        else:
            y = float(z['floor_y_in'])
            a.rect(x0, y - FLANGE_IN / 2, x1, y + FLANGE_IN / 2, S_SECOND)
            y_label = y + FLANGE_IN / 2 + 1.5
        if z.get('cut_mark') and (x1 - x0) * v.sx > 70:
            a.text((x0 + x1) / 2, y_label, str(z['cut_mark']), T_SMALL, 0, 'middle')
        drawn += 1
    if not drawn:
        a.line(0, eave, L, eave, S_HID)
    _face_walks = [
        o for o in (layout.get('framing_additions') or {}).get('openings', []) if o.get('face') == face and _is_walk(o)
    ]
    if sheeted:
        for g in p.get('girt_elevations') or []:
            try:
                y = f(g)
            except Exception:
                continue
            a.line(-8, y, 0, y, S_HID)
        for run in layout.get('starting_wall_runs') or []:
            if run.get('side') == face and run.get('role') == 'base_angle':
                _segs = [(0.0, L)]
                for o in _face_walks:
                    ox, ow = float(o['x_in']), float(o['width_in'])
                    _segs = [
                        q
                        for a0, a1 in _segs
                        for q in ((a0, min(a1, ox - 0.5)), (max(a0, ox + ow + 0.5), a1))
                        if q[1] - q[0] > 0.25
                    ]
                for a0, a1 in _segs:
                    a.rect(a0, 0, a1, float(run.get('vertical_leg_in') or 2), S_SECOND)
    # openings on this face (outside-view x)
    for o in (layout.get('framing_additions') or {}).get('openings', []):
        if o.get('face') != face:
            continue
        x, y, w, h = float(o['x_in']), float(o['y_in']), float(o['width_in']), float(o['height_in'])
        a.rect(x, y, x + w, y + h, S_NOTE)
        if _is_walk(o):
            _walk_flange(a, x, y, w, h)
        a.text(x + w / 2, y + h / 2, o['id'], T_MARK, 0, 'middle')
        for part in o.get('members', []):
            if part.get('shared_member_ref'):
                continue
            a.rect(min(part['x0_in'], part['x1_in']), part['y0_in'], max(part['x0_in'], part['x1_in']), part['y1_in'])
    # dimensions: bays, overall, eave height; frame-line bubbles
    y0 = v.py(-below)
    _rec_w = {}
    for rec in recs:
        _w = None
        if rec['kind'] == 'end':
            _end = ends.get(rec['wall_key']) or {}
            _posts = _end.get('posts') or []
            _post = (_posts[-1] if face == 'right' else _posts[0]) if _posts else None
            if _post:
                _w = float(_post['width'])
        elif col:
            try:
                _w = float(job.assemblies[col['mark']].main.sec.bf)
            except Exception:
                _w = float(col['x1'] - col['x0'])
        _rec_w[rec['index']] = _w
    for bay_no, s0, s1, zone in _bays(job, fid):
        x0, x1 = sorted((v.px(sx(s0)), v.px(sx(s1))))
        c.dim_h(x0, x1, v.py(0), v.py(0), y0 + 18, _fmt(s1 - s0), T_DIM)
    xa, xb = sorted((v.px(sx(0)), v.px(sx(L))))
    c.dim_h(xa, xb, v.py(0), v.py(0), y0 + 38, _fmt(L) + ' OUTSIDE WALLS', T_DIM + 1)
    c.dim_v(v.py(0), v.py(eave), v.px(0), v.px(0), v.px(0) - 64, _fmt(eave) + ' EAVE', T_DIM)
    if bubbles:
        y_b = y0 + 60
        for rec in recs:
            px = v.px(sx(rec['station_in']))
            c.pcircle(px, y_b, 9, S_BUBBLE)
            c.ptext(px, y_b + 3, str(rec['index']), T_MARK, 0, 'middle', bold=True)
            c.ptext(px, y_b + 20, _fmt(rec['station_in']), T_SMALL, 0, 'middle')
        return y_b + 26
    return y0 + 46
