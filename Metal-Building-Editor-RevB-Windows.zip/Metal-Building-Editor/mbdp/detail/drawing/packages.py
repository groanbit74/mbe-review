"""Print packages (roadmap #15): the ERECTION set and the SHOP set.

Both packages are *composed* from the drawing content of the archive sheets (``sheet.all_sheets``)
instead of being a filtered copy of them:

* ``content(sheet)`` is every drawn item except the fixed furniture (border, mark header, title
  block, footer; recorded by ``sheet._furniture``) and the red NOTE-layer paragraphs.  One short
  red hold line per source view (the most prominent note) replaces those paragraphs.
* ``place()`` scales that content uniformly (text included) into a box of a new sheet, so one
  22x17 erection sheet can carry two side-wall elevations, an end-wall sheeting elevation with its
  trim table, or three lean-to sections — the way the customer erection sets are organised.

ERECTION set, 22x17 landscape, series numbered (C cover / R rigid frames / E end walls /
S side walls / B roof / D appended standard details):
    C1  cover: job data, sheet index, general notes
    R   one cross section per *distinct* frame line (identical interior lines share a sheet and
        the caption lists every line number), lean-to sections afterwards
    E   end-wall framing (frame line view) per framed end, then sheeting + trim per end wall
    S   both side-wall framing elevations on one sheet, both sheeting elevations + trim on the next
    B   roof framing plan with the purlin / eave piece list, then roof sheeting + trim
    D   any ``details/*.pdf`` found in the workspace is appended page by page (``append_details``)

SHOP set, 11x17 (unchanged sheet format):
    shipping list (assemblies, then loose clips / plates) -> assembly sheets -> cut sheets ->
    weldment / ridge / eave details -> fabricated plates and clips two per sheet.
    Catalog clips (PC8D, CLF…) and all supplier / order tables stay in the purchasing outputs.

Drawing status: ``job.settings['drawing_status']`` is ``'REVIEW'`` (default: grey REVIEW watermark
on every sheet) or ``'FOR CONSTRUCTION'`` (no watermark; issue column of the title block).
"""

from __future__ import annotations

import copy
import re
from collections import OrderedDict
from decimal import Decimal
from pathlib import Path

from .. import model as M
from ..ordering import fmt
from . import erection_views as EV
from .canvas import (
    LW_THIN,
    S_NOTE,
    S_TABLE,
    Canvas,
    Circle,
    Line,
    Poly,
    Sheet,
    Style,
    Text,
    text_width,
)
from .sheet import _border, _footer, _title_block, drawing_part_quantities, usage

# ----------------------------------------------------------------------------- constants
C_W, C_H = 1584.0, 1224.0  # 22 x 17 in at 72 pt
C_MARGIN = 36.0
C_BORDER = (C_MARGIN, C_MARGIN, C_W - C_MARGIN, C_H - C_MARGIN)
TB_H = 118.0  # title block strip (bottom of the sheet)
S_WATER = Style(layer='WATERMARK', width=LW_THIN, color=(0.90, 0.90, 0.90))
S_FRAME = Style(layer='BORDER', width=0.6)
S_CAPTION = Style(layer='TEXT')
STATUS_REVIEW = 'REVIEW'
STATUS_CONSTRUCTION = 'FOR CONSTRUCTION'
STATUSES = (STATUS_REVIEW, STATUS_CONSTRUCTION)
CATALOG_CLIP_SOURCES = ('sample', 'assumed', 'shop-standard', 'catalog')
SERIES_TITLES = OrderedDict(
    [
        ('C', 'COVER / INDEX'),
        ('R', 'RIGID FRAME CROSS SECTIONS'),
        ('E', 'END WALL FRAMING AND SHEETING'),
        ('S', 'SIDE WALL FRAMING AND SHEETING'),
        ('B', 'ROOF FRAMING AND SHEETING'),
        ('D', 'STANDARD DETAILS (APPENDED)'),
    ]
)
GENERAL_NOTES = (
    'Dimensions are to outside of wall steel lines and to top of finished floor unless noted.',
    'Roof line (dotted) is the top of the roof purlin at every rafter; the eave height is the roof line at '
    'the wall. BYPASS rafters (W interior rafters, W end rafters with rake angle): top of rafter = bottom of '
    'purlin. Open-face CHANNEL rafters: purlins sit IN the channel, top of rafter = roof line. Lean-to '
    'rafters follow the same rule, also where the lean roof continues the main roof plane.',
    'Legend: the dotted line is the ROOF LINE (top of purlin); purlins and girts are drawn as single '
    'lines, not profiles; frame marks MF-n are main-frame types (shop marks stay on the shop sheets). '
    'Dimensions on frame lines: overall out-to-out chain first, then the building outside wall lines; '
    'columns are set out out-to-centre, corners out-to-out; openings out to the inside face.',
    'Insulation BY OTHERS - not part of this package; no insulation quantities are listed.',
    'Bracing BY OTHERS - no wall or roof bracing is detailed, listed or ordered in this package.',
    'Frame lines are numbered from the left end wall. Identical interior frame lines share one cross '
    'section; the caption lists every line it applies to.',
    'Openings are located on the wall elevations (jamb and header positions); trim marks and panel '
    'lengths are tabulated beside each sheeting elevation.',
    'Standard connection details, anchor rods and foundation design are issued separately.',
)


def drawing_status(job) -> str:
    s = str(job.settings.get('drawing_status', STATUS_REVIEW)).upper()
    return s if s in STATUSES else STATUS_REVIEW


# ----------------------------------------------------------------------------- composer core
def furniture_ranges(sheet: Sheet) -> set[int]:
    skip: set[int] = set()
    for i0, i1 in sheet.meta.get('furniture', []):
        skip.update(range(i0, i1))
    return skip


def notes(sheet: Sheet) -> list[Text]:
    return [it for it in sheet.items if isinstance(it, Text) and it.style.layer == 'NOTE']


def hold_line(sheet: Sheet) -> str:
    """The most prominent red note of a sheet (largest text, first on ties) — the one line that
    survives on the composed package sheet."""
    best = None
    for t in notes(sheet):
        if best is None or t.size > best.size + 1e-6:
            best = t
    return best.text.strip() if best else ''


HEADER_ZONE = (960.0, 0.0, 1160.0, 80.0)  # mark header corner of the 11x17 sheets (paper units)


def _in_header_zone(it) -> bool:
    x0, y0, x1, y1 = HEADER_ZONE
    if isinstance(it, Text):
        return x0 <= it.x <= x1 and y0 <= it.y <= y1
    if isinstance(it, Line):
        return min(it.x1, it.x2) >= x0 and max(it.y1, it.y2) <= y1
    return False


def content(sheet: Sheet) -> list:
    """Drawn items without furniture (recorded ranges plus anything drawn in the mark-header
    corner) and without NOTE-layer text paragraphs."""
    skip = furniture_ranges(sheet)
    return [
        it
        for i, it in enumerate(sheet.items)
        if i not in skip and not (isinstance(it, Text) and it.style.layer == 'NOTE') and not _in_header_zone(it)
    ]


def _text_box(t: Text):
    w = text_width(t.text, t.size, t.bold)
    h = t.size
    if abs(t.rot) % 180 > 45:  # vertical text
        x0, x1 = t.x - h, t.x
        if t.anchor == 'start':
            y0, y1 = t.y - w, t.y
        elif t.anchor == 'end':
            y0, y1 = t.y, t.y + w
        else:
            y0, y1 = t.y - w / 2, t.y + w / 2
        return x0, y0, x1, y1
    if t.anchor == 'start':
        x0, x1 = t.x, t.x + w
    elif t.anchor == 'end':
        x0, x1 = t.x - w, t.x
    else:
        x0, x1 = t.x - w / 2, t.x + w / 2
    if t.valign == 'middle':
        y0, y1 = t.y - h / 2, t.y + h / 2
    elif t.valign == 'top':
        y0, y1 = t.y, t.y + h
    else:
        y0, y1 = t.y - h, t.y
    return x0, y0, x1, y1


def bbox(items):
    xs, ys = [], []
    for it in items:
        if isinstance(it, Line):
            xs += [it.x1, it.x2]
            ys += [it.y1, it.y2]
        elif isinstance(it, Poly):
            xs += [p[0] for p in it.pts]
            ys += [p[1] for p in it.pts]
        elif isinstance(it, Circle):
            xs += [it.cx - it.r, it.cx + it.r]
            ys += [it.cy - it.r, it.cy + it.r]
        elif isinstance(it, Text):
            x0, y0, x1, y1 = _text_box(it)
            xs += [x0, x1]
            ys += [y0, y1]
    if not xs:
        return None
    return min(xs), min(ys), max(xs), max(ys)


def transformed(items, s: float, dx: float, dy: float) -> list:
    out = []
    for it in items:
        if isinstance(it, Line):
            out.append(Line(dx + s * it.x1, dy + s * it.y1, dx + s * it.x2, dy + s * it.y2, it.style))
        elif isinstance(it, Poly):
            out.append(Poly([(dx + s * x, dy + s * y) for x, y in it.pts], it.closed, it.style))
        elif isinstance(it, Circle):
            out.append(Circle(dx + s * it.cx, dy + s * it.cy, s * it.r, it.style))
        elif isinstance(it, Text):
            t = copy.copy(it)
            t.x, t.y, t.size = dx + s * it.x, dy + s * it.y, s * it.size
            out.append(t)
    return out


def place(
    dst: Sheet,
    src: Sheet,
    box,
    caption: str = '',
    max_scale: float = 1.45,
    caption_size: float = 15.0,
    valign: str = 'middle',
):
    """Scale the content of ``src`` uniformly into ``box`` (x0, y0, x1, y1) of ``dst`` and write a
    caption above it. ``valign`` 'top' keeps tables at the top of the box instead of centring them.
    Returns the scale used (None when the source has no content)."""
    items = content(src)
    bb = bbox(items)
    bx0, by0, bx1, by1 = box
    c = Canvas(dst)
    cap_h = caption_size * 1.5 if caption else 0.0
    if caption:
        c.ptext(bx0 + 4, by0 + caption_size, caption, caption_size, bold=True, style=S_CAPTION)
        c.pline(
            bx0 + 4,
            by0 + caption_size + 4,
            bx0 + 4 + text_width(caption, caption_size) * 1.08,
            by0 + caption_size + 4,
            S_TABLE,
        )
    if bb is None:
        return None
    x0, y0, x1, y1 = bb
    w, h = max(x1 - x0, 1.0), max(y1 - y0, 1.0)
    avail_w, avail_h = (bx1 - bx0) - 8, (by1 - by0 - cap_h) - 8
    s = min(avail_w / w, avail_h / h, max_scale)
    dx = bx0 + 4 + (avail_w - s * w) / 2 - s * x0
    dy = by0 + cap_h + 4 + ((avail_h - s * h) / 2 if valign == 'middle' else 0.0) - s * y0
    dst.items.extend(transformed(items, s, dx, dy))
    dst.meta.setdefault('sources', []).append(src.name)
    return s


def condensed(sheet: Sheet, status: str) -> Sheet:
    """Copy of an 11x17 archive sheet with the red note paragraphs reduced to one hold line and the
    status watermark added (used for the shop set, whose sheet format is unchanged)."""
    out = Sheet(sheet.name, sheet.kind, [], list(sheet.dims), sheet.width, sheet.height, dict(sheet.meta))
    hold = hold_line(sheet)
    first = True
    for it in sheet.items:
        if isinstance(it, Text) and it.style.layer == 'NOTE':
            if first and hold:
                t = copy.copy(it)
                t.text, t.size, t.bold = hold, min(max(it.size, 9.0), 11.0), True
                out.items.append(t)
                first = False
            continue
        out.items.append(it)
    watermark(out, status)
    return out


def watermark(sheet: Sheet, status: str) -> None:
    if status != STATUS_REVIEW:
        return
    size = min(sheet.width, sheet.height) * 0.17
    t = Text(sheet.width / 2, sheet.height * 0.55, 'REVIEW', size, 0.0, 'middle', 'middle', True, S_WATER)
    sheet.items.insert(0, t)


# ----------------------------------------------------------------------------- 22x17 furniture
def _building_size(job, fid):
    layout = job.settings.get('frame_layouts', {}).get(fid, {})
    g = layout.get('building_geometry') or {}
    w = g.get('width_in') or layout.get('width_in')
    length = g.get('length_in')
    eave = layout.get('low_eave_in') or layout.get('high_eave_in')
    rise = layout.get('slope_rise')
    bits = []
    if w:
        bits.append(fmt(w))
    if length:
        bits.append(fmt(length))
    if eave:
        bits.append(fmt(eave) + ' EAVE')
    size = ' x '.join(bits[:2]) + ((' x ' + bits[2]) if len(bits) > 2 else '')
    if rise is not None and size:
        size += '  ' + str(rise) + ':12'
    return size


def _colours(job):
    roof = wall = trim = ''
    for a in job.assemblies.values():
        cl = a.derivation.get('cladding')
        if not cl:
            continue
        for g in cl.get('groups', []):
            if g['surface'].startswith('roof') and not roof:
                roof = g.get('color', '')
            elif not g['surface'].startswith('roof') and not wall:
                wall = g.get('color', '')
        for r in cl.get('trim_runs', []):
            if not trim:
                trim = r.get('color', '')
    return roof or 'T.B.D.', wall or 'T.B.D.', trim or 'T.B.D.'


def _sheet_22x17(
    job, number: str, desc: str, status: str, hold: str = '', kind: str = 'erection'
) -> tuple[Sheet, tuple]:
    """New 22x17 sheet with border, title block, watermark and the hold line.
    Returns (sheet, content box)."""
    sh = Sheet('E-' + number, kind, [], [], C_W, C_H, {'number': number, 'desc': desc, 'series': number[0]})
    c = Canvas(sh)
    watermark(sh, status)
    x0, y0, x1, y1 = C_BORDER
    c.prect(x0, y0, x1, y1, S_FRAME)
    tb_y0 = y1 - TB_H
    c.pline(x0, tb_y0, x1, tb_y0, S_FRAME)
    # revisions block
    rx0, rx1 = x0, x0 + 430
    c.pline(rx1, tb_y0, rx1, y1, S_TABLE)
    c.ptext(rx0 + 6, tb_y0 + 14, 'DRAWING REVISIONS', 9, bold=True)
    cols = [('NO.', 40), ('DATE', 80), ('DESCRIPTION', 230), ('BY', 60)]
    xx = rx0 + 6
    c.pline(rx0, tb_y0 + 20, rx1, tb_y0 + 20, S_TABLE)
    for head, w in cols:
        c.ptext(xx + 2, tb_y0 + 31, head, 7.5, bold=True)
        xx += w
    c.pline(rx0, tb_y0 + 35, rx1, tb_y0 + 35, S_TABLE)
    issue = 'A' if status == STATUS_REVIEW else 'B'
    desc_txt = 'ISSUED FOR REVIEW' if status == STATUS_REVIEW else 'ISSUED FOR CONSTRUCTION'
    xx = rx0 + 6
    for val, (head, w) in zip((issue, job.date, desc_txt, job.checked_by or '-'), cols):
        c.ptext(xx + 2, tb_y0 + 47, val, 8)
        xx += w
    # building colours
    cx0, cx1 = rx1, rx1 + 300
    c.pline(cx1, tb_y0, cx1, y1, S_TABLE)
    roof, wall, trim = _colours(job)
    c.ptext(cx0 + 6, tb_y0 + 14, 'BUILDING COLORS', 9, bold=True)
    for k, (label, val) in enumerate((('ROOF PANEL', roof), ('WALL PANEL', wall), ('TRIM', trim))):
        c.ptext(cx0 + 6, tb_y0 + 34 + k * 16, label, 7.5, bold=True)
        c.ptext(cx0 + 90, tb_y0 + 34 + k * 16, val, 8.5)
    # job cells
    jx0 = cx1
    fid = next(iter(job.settings.get('frame_layouts', {})), '')
    avail = x1 - jx0
    cells = [
        ('DESC', desc, round(avail * 0.41)),
        ('SIZE', _building_size(job, fid) or '-', round(avail * 0.29)),
        ('CUST', job.customer, avail - round(avail * 0.41) - round(avail * 0.29)),
    ]
    xx = jx0
    for label, val, w in cells:
        c.pline(xx, tb_y0, xx, tb_y0 + 59, S_TABLE)
        c.ptext(xx + 5, tb_y0 + 12, label, 7, bold=True)
        size = min(11.0, 11.0 * (w - 14) / max(1.0, text_width(val, 11.0)))
        c.ptext(xx + 7, tb_y0 + 38, val, size)
        xx += w
    c.pline(jx0, tb_y0 + 59, x1, tb_y0 + 59, S_TABLE)
    shares = (0.15, 0.13, 0.22, 0.13, 0.10, 0.10)
    widths = [round(avail * f) for f in shares]
    widths.append(avail - sum(widths))
    cells2 = list(
        zip(
            ('JOB NO', 'SHEET NO', 'ISSUE', 'DATE', 'DRAWN', "CK'D", 'MODEL'),
            (
                job.job_no,
                number,
                issue + ' - ' + status,
                job.date or '-',
                'MBDP',
                job.checked_by or '-',
                job.revision(),
            ),
            widths,
        )
    )
    xx = jx0
    for label, val, w in cells2:
        c.pline(xx, tb_y0 + 59, xx, y1, S_TABLE)
        c.ptext(xx + 5, tb_y0 + 71, label, 7, bold=True)
        size = min(13.0 if label == 'SHEET NO' else 10.0, 10.0 * (w - 14) / max(1.0, text_width(val, 10.0)))
        c.ptext(xx + 7, tb_y0 + 98, val, size, bold=(label == 'SHEET NO'))
        xx += w
    c.ptext(cx0 + 6, tb_y0 + 100, job.building, 7.5)
    if hold:
        c.ptext(x0 + 8, y0 + 13, hold[:160], 8.5, bold=True, style=S_NOTE)
    c.ptext(x1 - 8, y0 + 13, 'SHEET ' + number, 10, 0, 'end', bold=True)
    box = (x0 + 8, y0 + 22, x1 - 8, tb_y0 - 8)
    return sh, box


def _table(
    sheet: Sheet, x: float, y: float, headers, widths, rows, size: float = 8.5, title: str = '', max_h: float = 1e9
):
    """Compact ruled table on a composed sheet; returns the y below the table. Rows that do not fit
    in ``max_h`` are summarised in one closing line."""
    c = Canvas(sheet)
    if title:
        c.ptext(x, y + size + 2, title, size + 2.5, bold=True)
        y += size * 2.2
    lh = size * 1.45
    total_w = sum(widths)
    c.pline(x, y, x + total_w, y, S_TABLE)
    xx = x
    for head, w in zip(headers, widths):
        c.ptext(xx + 3, y + lh - 4, str(head), size, bold=True)
        xx += w
    y += lh
    c.pline(x, y, x + total_w, y, S_TABLE)
    budget = max_h - lh * 2
    shown = 0
    for row in rows:
        if budget < lh * 2 and shown < len(rows) - 1:
            break
        xx = x
        for val, w in zip(row, widths):
            txt = str(val)
            sz = min(size, size * (w - 6) / max(1.0, text_width(txt, size)))
            c.ptext(xx + 3, y + lh - 4, txt, sz)
            xx += w
        y += lh
        budget -= lh
        shown += 1
    if shown < len(rows):
        c.ptext(
            x + 3, y + lh - 4, f'... {len(rows) - shown} more rows: see the purchasing workbook', size, style=S_NOTE
        )
        y += lh
    c.pline(x, y, x + total_w, y, S_TABLE)
    return y + 4


# ----------------------------------------------------------------------------- erection set
def _by_name(sheets):
    return {s.name: s for s in sheets}


def _line_groups(job, fid):
    """Interior frame line records grouped by identical frame; end-line records in station order."""
    from .. import frame_lines as FL

    interior = OrderedDict()
    ends = []
    for rec in FL.lines(job, fid):
        if not rec['framed']:
            continue
        if rec['kind'] == 'end':
            ends.append(rec)
            continue
        from .. import grades as GR

        key = (
            rec['frame_mark'],
            rec['roof_mode'],
            tuple(sorted(map(str, rec.get('lean_tos') or []))),
            GR.line_signature(job.settings['frame_layouts'][fid], rec['index']),  # own sheet per grade (v0.8.43)
            tuple(
                (x.get('side'), x.get('mode'), x.get('mark'), x.get('rafter_mark'))
                for x in rec.get('primary_connections', [])
            ),  # physical takeoff marks must match the depicted line
        )
        interior.setdefault(key, []).append(rec)
    return list(interior.values()), ends


def _lines_caption(recs):
    nums = [str(r['index']) for r in recs]
    return ('FRAME LINE ' if len(nums) == 1 else 'FRAME LINES ') + ', '.join(nums)


def _trim_rows(cl, sid):
    rows = []
    for r in cl.get('trim_runs', []):
        if r.get('surface') != sid:
            continue
        rows.append(
            [
                r['mark'],
                r.get('location') or r.get('role', ''),
                r.get('profile_id', '') or ('NOT ORDERED' if r.get('not_ordered') else ''),
                r.get('color', ''),
                fmt(r['required_run_in']) if r.get('required_run_in') is not None else 'HELD',
                str(r.get('stock_quantity', '')) + ' @ ' + fmt(r['stock_length_in'])
                if r.get('stock_length_in')
                else '-',
            ]
        )
    return rows


def _panel_rows(cl, sid):
    rows = []
    for g in cl.get('groups', []):
        if g.get('surface') != sid:
            continue
        marks = g.get('marks', [])
        label = marks[0] + (f' .. {marks[-1]}' if len(marks) > 1 else '') if marks else g.get('group', '')
        rows.append(
            [
                g.get('group', ''),
                str(g.get('quantity', '')),
                g.get('order_length', ''),
                g.get('profile', ''),
                g.get('color', ''),
                label,
            ]
        )
    return rows


def _sheeting_sheet(job, status, number, desc, surfaces, by, fid):
    """Sheeting elevation(s) on the left with the matching panel groups and trim runs tabulated on
    the right (one panel table and one trim table per wall)."""
    cl = job.assemblies[fid].derivation.get('cladding', {})
    hold = ''
    sh, box = _sheet_22x17(job, number, desc, status)
    x0, y0, x1, y1 = box
    n = max(1, len(surfaces))
    split = x0 + (x1 - x0) * 0.56
    row_h = (y1 - y0) / n
    for k, (sid, caption) in enumerate(surfaces):
        src = by.get('PBR-' + fid + '-' + _face_code(cl, sid))
        if src is None:
            continue
        hold = hold or hold_line(src)
        place(sh, src, (x0, y0 + k * row_h, split - 8, y0 + (k + 1) * row_h), caption)
    tx = split + 8
    col_w = x1 - tx - 4
    block_h = (y1 - y0) / n
    for k, (sid, caption) in enumerate(surfaces):
        top = y0 + k * block_h
        yy = _table(
            sh,
            tx,
            top + 4,
            ['PANEL GROUP', 'QTY', 'LENGTH', 'PROFILE', 'COLOR', 'MARKS'],
            [120, 36, 62, 78, 84, col_w - 380],
            _panel_rows(cl, sid),
            7.5,
            caption + ' - PANELS',
            max_h=block_h * 0.5 - 8,
        )
        _table(
            sh,
            tx,
            yy + 8,
            ['TRIM MARK', 'LOCATION', 'PROFILE', 'COLOR', 'RUN', 'STOCK'],
            [96, col_w - 96 - 60 - 84 - 62 - 86, 60, 84, 62, 86],
            _trim_rows(cl, sid),
            7.5,
            caption + ' - TRIM',
            max_h=top + block_h - yy - 12,
        )
    _set_hold(sh, hold)
    return sh


def _face_code(cl, sid):
    from .cladding_sheet import face_code

    return face_code(sid).upper()


def _set_hold(sh: Sheet, hold: str):
    if hold:
        Canvas(sh).ptext(C_BORDER[0] + 8, C_BORDER[1] + 13, hold[:160], 8.5, bold=True, style=S_NOTE)


def _openings_rows(job, fid):
    rows = []
    cl = job.assemblies[fid].derivation.get('cladding', {})
    for o in cl.get('config', {}).get('openings', []):
        # This table sits on the SIDE WALL framing sheet: end-wall openings listed here
        # read as ghost doors in the side walls (owner round 16), so they stay off it.
        if str(o.get('surface') or '') in ('front', 'rear'):
            continue
        rows.append(
            [
                o['id'],
                o.get('kind', ''),
                o.get('elevation', o.get('surface', '')),
                o.get('x', ''),
                o.get('y', ''),
                o.get('width', ''),
                o.get('height', ''),
            ]
        )
    return rows


def details_index(details_dir) -> list[tuple[str, str]]:
    """[(file name, page count)] of the standard-detail PDFs that ``append_details`` will add."""
    d = Path(details_dir) if details_dir else None
    if not d or not d.is_dir():
        return []
    out = []
    import pymupdf

    for p in sorted(x for x in d.glob('*.pdf') if x.is_file()):
        try:
            with pymupdf.open(p) as doc:
                out.append((p.name, doc.page_count))
        except Exception:
            continue
    return out


def erection_sheets(job, archive=None, details_dir=None):
    """The composed 22x17 erection set (cover first). ``archive`` = all_sheets(job) when already
    built; ``details_dir`` lets the cover index list the appended D-series pages."""
    from .sheet import all_sheets

    archive = archive if archive is not None else all_sheets(job)
    by = _by_name(archive)
    status = drawing_status(job)
    out = []
    counters = {k: 0 for k in SERIES_TITLES}
    index = []

    def number(series):
        counters[series] += 1
        return series + str(counters[series])

    def add(sh, sources):
        out.append(sh)
        known = sh.meta.setdefault('sources', [])
        known.extend(n for n in sources if n not in known)
        index.append((sh.meta['number'], sh.meta['desc'], list(known)))

    layouts = job.settings.get('frame_layouts', {})
    for fid in layouts:
        groups, ends = _line_groups(job, fid)
        # Framing group first, frame lines in station order 1..N (owner round 16): interior
        # rigid-frame sections (R) and framed end walls (E) interleaved by line number, so
        # frame line 1 is the first sheet of the stack.
        frame_sheets = []
        for recs in groups:
            src = by.get('FL' + str(recs[0]['index']) + '-' + fid)
            if src is not None:
                frame_sheets.append((recs[0]['index'], 'R', recs, src))
        for rec in ends:
            src = by.get('FL' + str(rec['index']) + '-' + fid)
            if src is not None:
                frame_sheets.append((rec['index'], 'E', [rec], src))
        for _idx, series, recs, src in sorted(frame_sheets, key=lambda t: t[0]):
            rec = recs[0]
            if series == 'R':
                desc = 'RIGID FRAME CROSS SECTION - ' + _lines_caption(recs)
            else:
                desc = rec['label'] + ' FRAMING - FRAME LINE ' + str(rec['index'])
            sh, box = _sheet_22x17(job, number(series), desc, status, hold_line(src))
            rows = EV.frame_line_schedule_rows(job, fid, rec, len(recs))
            schedule_h = 38 + 14 * (len(rows) + 1) if rows else 0
            schedule_top = box[3] - schedule_h if rows else box[3]
            # Keep member/cut data in a reserved bottom band, not over the cross-section.
            drawing_box = (box[0], box[1], box[2], schedule_top - 58 if rows else box[3])
            EV.frame_line(
                sh, job, fid, rec, drawing_box,
                also=[r['index'] for r in recs[1:]] if series == 'R' else (),
                include_schedule=False,
            )
            if rows:
                _table(
                    sh, box[0] + 4, schedule_top + 4,
                    ['MARK', 'SECTION', 'PER LINE', 'LINES', 'TOTAL', 'CUT / BLANK', 'CUT-EDGE RUN (HORIZONTAL)'],
                    [170, 190, 90, 70, 70, 240, 220], rows, 8.0,
                    'FRAME LINE MEMBERS / CUTS — cut-edge runs are horizontal; CUT / BLANK is the member cut length',
                    max_h=schedule_h - 4,
                )
            add(sh, ['FL' + str(r['index']) + '-' + fid for r in recs])
        # R: one consolidated frame-line member schedule (the table left the drawings,
        # owner round 16 - frame-line views carry marks, cut lengths and dimensions only).
        member_rows = EV.frame_member_rows(job, fid, groups, ends)
        if member_rows:
            sh, box = _sheet_22x17(
                job, number('R'), 'FRAME LINE MEMBER SCHEDULE', status, hold_line(src) if frame_sheets else ''
            )
            bx0, by0, bx1, by1 = box
            _table(
                sh,
                bx0 + 4,
                by0 + 26,
                ['APPLIES TO', 'MARK', 'SECTION', 'PER LINE', 'LINES', 'TOTAL', 'CUT / BLANK', 'CUT-EDGE RUN (HORIZONTAL)'],
                [130, 210, 150, 70, 60, 60, 210, 150],
                member_rows,
                8.5,
                'FRAME LINE MEMBERS - quantities and cuts (dimensions are on the frame-line views; shop cut sheets govern fabrication)',
                max_h=by1 - by0 - 90,
            )
            c = Canvas(sh)
            c.ptext(
                bx0 + 4,
                by1 - 42,
                'Member marks and cut lengths are also lettered on the frame-line views. Purlin station dimensions are along the slope on the sections.',
                8.5,
            )
            add(sh, ['FL' + str(n) + '-' + fid for n in sorted({t[0] for t in frame_sheets})])
        # R: column grade schedule (v0.8.43) - only when a grade is entered
        grades = by.get('GRADES-' + fid)
        if grades is not None:
            sh, box = _sheet_22x17(job, number('R'), 'COLUMN GRADE SCHEDULE', status, hold_line(grades))
            place(sh, grades, box, "COLUMN GRADE SCHEDULE", valign="top")
            add(sh, [grades.name])
        # Lean-to SECTION sheets are not necessary (owner 0.8.53): the frame lines
        # already section every lean.  The lean WALLS sheets stay.
        for lean in [
            s for s in archive if s.kind == 'additions' and re.match(r'ADD-' + re.escape(fid) + r'-LEAN-\d+-1$', s.name)
        ]:
            i = lean.name.split('-LEAN-')[1].split('-')[0]
            wall = by.get(fid + '~lean_walls~' + str(int(i) - 1) + '~1')
            if wall is not None:
                sh2, box2 = _sheet_22x17(job, number('R'), 'LEAN-TO WALLS ' + i, status, hold_line(wall))
                place(sh2, wall, box2, 'LEAN-TO WALLS ' + i)
                add(sh2, [wall.name])
        cl = job.assemblies[fid].derivation.get('cladding') if fid in job.assemblies else None
        surfaces = {
            s['id']: s.get('elevation', s['id']).upper()
            for s in (cl or {}).get('surfaces', [])
            if not s.get('open_wall')
        }
        # S: side wall framing (both elevations) + openings table
        fronts = [by.get('SIDEWALL-F-' + fid), by.get('SIDEWALL-B-' + fid)]
        if any(fronts):
            sh, box = _sheet_22x17(
                job, number('S'), 'SIDE WALL FRAMING ELEVATIONS', status, hold_line(next(s for s in fronts if s))
            )
            bx0, by0, bx1, by1 = box
            rows = _openings_rows(job, fid)
            opening_h = min(240.0, 50 + 14 * len(rows)) if rows else 0.0
            member_rows = [EV.sidewall_member_rows(job, fid, side) for side in ('front', 'back')]
            member_row_h = 11.0
            member_h = 25 + member_row_h * (max((len(r) for r in member_rows), default=0) + 1)
            schedule_gap = 8.0
            schedule_top = by1 - opening_h - member_h - schedule_gap
            view_bottom = schedule_top - 8.0
            view_h = (view_bottom - by0) / 2
            for k, (s, side) in enumerate(zip(fronts, ('front', 'back'))):
                if s is not None:
                    EV.sidewall(
                        sh,
                        job,
                        fid,
                        side,
                        (bx0, by0 + k * view_h, bx1, by0 + (k + 1) * view_h - 6),
                        member_schedule=False,
                    )
            mid_x = (bx0 + bx1) / 2
            EV.sidewall_member_schedule(
                sh, job, fid, 'front', mid_x - 12, schedule_top, row_h=member_row_h, font=7.0, rows=member_rows[0]
            )
            EV.sidewall_member_schedule(
                sh, job, fid, 'back', bx1 - 4, schedule_top, row_h=member_row_h, font=7.0, rows=member_rows[1]
            )
            if rows:
                _table(
                    sh,
                    bx0 + 4,
                    by1 - opening_h + 4,
                    ['OPENING', 'KIND', 'WALL', 'X FROM LEFT', 'SILL', 'WIDTH', 'HEIGHT'],
                    [80, 100, 330, 110, 90, 90, 90],
                    rows,
                    8,
                    'OPENING SETOUT (jamb / header positions on the elevations)',
                    max_h=opening_h,
                )
            add(sh, [s.name for s in fronts if s])
        # B: roof framing plan + purlin / eave piece list
        plan = by.get('ROOF-PLAN-' + fid)
        if plan is not None:
            pieces = by.get('MAIN-ROOF---PURLIN-AND-EAVE-PIECES-1') or by.get('RUN-CUTS-' + fid)
            # Owner round 16: the plan gets the whole sheet (drawing first, information
            # second); the purlin / eave piece list moves to its own following sheet.
            sh, box = _sheet_22x17(job, number('B'), 'ROOF FRAMING PLAN', status, hold_line(plan))
            place(sh, plan, box, 'ROOF FRAMING PLAN')
            add(sh, [plan.name])
            if pieces is not None:
                sh2, box2 = _sheet_22x17(
                    job, number('B'), 'ROOF FRAMING - PURLIN AND EAVE PIECES', status, hold_line(pieces)
                )
                place(sh2, pieces, box2, 'PURLIN / EAVE PIECES', max_scale=1.0, valign='top')
                add(sh2, [pieces.name])
        # E: end wall sheeting + trim, one wall per sheet
        for sid in ('front', 'rear'):
            if sid in surfaces:
                sh = _sheeting_sheet(
                    job, status, number('E'), surfaces[sid] + ' SHEETING AND TRIM', [(sid, surfaces[sid])], by, fid
                )
                add(sh, list(sh.meta.get('sources', [])))
        # S: side wall sheeting + trim (both walls)
        side = [(sid, surfaces[sid]) for sid in ('right', 'left') if sid in surfaces]
        if side:
            sh = _sheeting_sheet(job, status, number('S'), 'SIDE WALL SHEETING AND TRIM', side, by, fid)
            add(sh, list(sh.meta.get('sources', [])))
        roof = [(sid, surfaces[sid]) for sid in ('roof_left', 'roof_right') if sid in surfaces]
        if roof:
            sh = _sheeting_sheet(job, status, number('B'), 'ROOF SHEETING AND TRIM', roof, by, fid)
            add(sh, list(sh.meta.get('sources', [])))
    for name, pages in details_index(details_dir):
        for k in range(pages):
            index.append(
                (number('D'), name.rsplit('.', 1)[0] + (f' (page {k + 1} of {pages})' if pages > 1 else ''), [])
            )
    cover = _cover(job, status, index)
    return [cover] + out


def _cover(job, status, index):
    sh, box = _sheet_22x17(job, 'C1', 'ERECTION DRAWINGS - COVER AND INDEX', status)
    c = Canvas(sh)
    x0, y0, x1, y1 = box
    fid = next(iter(job.settings.get('frame_layouts', {})), '')
    c.ptext(x0 + 10, y0 + 60, 'ERECTION DRAWINGS', 40, bold=True)
    c.ptext(x0 + 10, y0 + 92, job.customer + '  -  ' + job.building, 18)
    size = _building_size(job, fid)
    c.ptext(x0 + 10, y0 + 118, 'JOB ' + job.job_no + ('   BUILDING ' + size if size else '') + '   ' + job.date, 13)
    from ..release_checks import report as release_report

    rel = release_report(job)
    c.ptext(
        x0 + 10,
        y0 + 140,
        'STATUS: ' + status + '   RELEASE CHECK: ' + rel['issue_status'] + '   MODEL ' + job.revision(),
        11,
        bold=True,
        style=S_NOTE if not rel['complete'] else S_CAPTION,
    )
    rows = [[n, d] for n, d, _ in index]
    if not rows:
        rows = [['-', 'No building layout in this job: generate the frame layout to produce the erection views.']]
    _table(sh, x0 + 10, y0 + 170, ['SHEET', 'TITLE'], [90, 640], rows, 10, 'SHEET INDEX', max_h=y1 - y0 - 200)
    ny = y0 + 170
    nx = x0 + 790
    c.ptext(nx, ny + 12.5, 'GENERAL NOTES', 12.5, bold=True)
    ny += 34
    from .print_packets import wrap

    notes = list(GENERAL_NOTES)
    fnd = (job.settings.get('frame_layouts', {}).get(fid) or {}).get('foundation')
    if fnd:
        notes.insert(
            -1,
            (
                'Foundation: POST FOOTINGS - holes '
                + fnd['hole_diameter']
                + ' diameter x '
                + fnd['hole_depth']
                + ' deep at every column and end-wall post; posts embedded the full depth, column lengths include '
                'the embedment, no base plates. Footing design and concrete by others.'
            )
            if fnd.get('type') == 'post_footing'
            else 'Foundation: SLAB - columns on base plates at the top of slab (floor datum); anchor rods by others.',
        )
    for k, note in enumerate(notes, 1):
        lines = wrap(f'{k}. ' + note, x1 - nx - 20, 10)
        for line in lines:
            c.ptext(nx, ny, line, 10)
            ny += 14
        ny += 6
    c.ptext(nx, ny + 10, 'SERIES', 10, bold=True)
    ny += 26
    for k, (series, title) in enumerate(SERIES_TITLES.items()):
        if series == 'D' and not any(n.startswith('D') for n, _, _ in index):
            continue
        c.ptext(nx, ny, series + '  ' + title, 9.5)
        ny += 13
    return sh


def append_details(pdf_path, details_dir) -> list[str]:
    """Append every ``*.pdf`` of ``details_dir`` (sorted by name) to the rendered erection PDF as the
    D series. Returns the appended file names (empty when the folder is absent)."""
    d = Path(details_dir) if details_dir else None
    if not d or not d.is_dir():
        return []
    files = sorted(p for p in d.glob('*.pdf') if p.is_file())
    if not files:
        return []
    import pymupdf

    doc = pymupdf.open(pdf_path)
    added = []
    for p in files:
        try:
            src = pymupdf.open(p)
            doc.insert_pdf(src)
            src.close()
            added.append(p.name)
        except Exception:  # unreadable file: skip, never fail the package
            continue
    doc.saveIncr() if doc.can_save_incrementally() else doc.save(str(pdf_path) + '.tmp')
    doc.close()
    tmp = Path(str(pdf_path) + '.tmp')
    if tmp.exists():
        tmp.replace(pdf_path)
    return added


# ----------------------------------------------------------------------------- shop set
def _fabricated(job, mark) -> bool:
    """Shop-made plate / clip (drawn in the shop set) as opposed to a purchased catalog clip."""
    if mark not in job.parts:
        return False
    p = job.part(mark)
    if p.kind in ('plate', 'stub'):
        return True
    src = (p.source or '').lower()
    return p.kind == 'clip' and src.startswith('user')


def shipping_rows(job):
    """[(group, rows)] for the shipping list: assemblies, then loose clips / plates."""
    paint = str(job.settings.get('paint', 'RO'))
    rows = []
    total = Decimal('0')
    for a in sorted(job.assemblies.values(), key=lambda a: a.mark):
        lines = M.bom(job, a)
        wt = M.total_weight(lines)
        each = M.fmt_weight(wt, 'main') if wt is not None else 'UNKNOWN'
        tot = M.fmt_weight(wt * a.qty, 'main') if wt is not None else 'UNKNOWN'
        if wt is not None:
            total += wt * a.qty
        rows.append(
            [str(a.qty), a.mark, a.kind.title(), a.main.section, 'See Dwg.', a.main.cut_length.fmt(), each, tot, paint]
        )
    attached = usage(job)[1]
    loose = []
    for mark, q in sorted(drawing_part_quantities(job).items()):
        extra = q - attached.get(mark, 0)
        if extra <= 0 or mark not in job.parts:
            continue
        p = job.part(mark)
        desc = p.description or (p.kind.title() + ' ' + mark)
        wt = p.unit_weight
        each = M.fmt_weight(wt, 'plate') if wt is not None else '-'
        tot = M.fmt_weight(wt * extra, 'plate') if wt is not None else '-'
        if wt is not None:
            total += wt * extra
        loose.append(
            [
                str(extra),
                mark,
                desc,
                p.kind.upper(),
                '-',
                p.length.fmt() if p.length else '-',
                each,
                tot,
                '-',
            ]
        )
    groups = [('RIGID FRAMES AND END WALL FRAMES', rows)]
    if loose:
        groups.append(('CLIPS AND PLATES BEYOND THE ASSEMBLY BOMS (end wall, lean-to and roof clips)', loose))
    return groups, total


def shipping_list(job):
    from .print_packets import tables

    groups, total = shipping_rows(job)
    rows = []
    for title, grp in groups:
        rows.append([title])
        rows.extend(grp)
    rows.append(['', 'TOTAL', '', '', '', '', '', M.fmt_weight(total, 'main'), ''])
    rows.append(['END OF ORDER'])
    return tables(
        job,
        'SHIPPING LIST',
        ['NO. REQD', 'MARK', 'DESCRIPTION', 'PART', 'PUNCH', 'SHIPPING LEN', 'WT EACH', 'TOTAL WT', 'PAINT'],
        [55, 90, 130, 150, 70, 100, 70, 80, 55],
        rows,
        ['Shipping length is the main member cut length; end plates are detailed on the assembly sheets.'],
        kind='shipping',
    )


def _two_up(job, status, pair):
    """Two fabricated plate / clip details side by side on one 11x17 sheet."""
    sh = Sheet('PLATES-' + '-'.join(s.name for s in pair), 'plate_pair', [], [], 1224.0, 792.0, {})
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, len(pair), 'FABRICATED PLATES', ' / '.join(s.name for s in pair), job.date)
    _footer(c, job, job.revision(), 'shop set')
    from .canvas import BORDER

    x0, y0, x1, y1 = BORDER
    top = 690
    mid = (x0 + x1) / 2
    for k, s in enumerate(pair):
        box = (x0 + 10, y0 + 10, mid - 6, top) if k == 0 else (mid + 6, y0 + 10, x1 - 10, top)
        mark, kind = s.meta.get('mark_header', (s.name, 'PLATE'))
        qty = s.meta.get('title', {}).get('qty', '')
        place(sh, s, box, f'{mark}  -  QTY {qty}', max_scale=1.0, caption_size=13, valign='top')
    hold = next((hold_line(s) for s in pair if hold_line(s)), '')
    if hold:
        c.ptext(x0 + 10, top + 20, hold[:150], 9, bold=True, style=S_NOTE)
    watermark(sh, status)
    return sh


def shop_sheets(job, archive=None):
    """Shipping list + assembly + cut + weldment + fabricated plate sheets (11x17)."""
    from .sheet import all_sheets

    archive = archive if archive is not None else all_sheets(job)
    status = drawing_status(job)
    out = list(shipping_list(job))
    for s in out:
        watermark(s, status)
    order = {
        'grades': -1,  # column grade schedule: which column goes where (v0.8.43)
        'assembly': 0,
        'cut': 1,
        'endcuts': 2,
        'connection': 3,
        'ridge': 4,
        'welded_eave': 5,
        'endjoint': 6,
        'flush_clip': 7,
    }
    picked = [s for s in archive if s.kind in order]
    picked += [
        s
        for s in archive
        if s.kind == 'additions' and re.search(r'~(low_detail|rafter_cuts|transition_detail|end_plate)~', s.name)
    ]
    picked.sort(key=lambda s: (order.get(s.kind, 9), s.name))
    out.extend(condensed(s, status) for s in picked)
    plates = [s for s in archive if s.kind == 'plate' and _fabricated(job, s.name)]
    for k in range(0, len(plates), 2):
        out.append(_two_up(job, status, plates[k : k + 2]))
    return out


# ----------------------------------------------------------------------------- routing index
def routing(archive, package_sheets, package, aliases=None):
    """[{sheet, kind, included, covered_by, reason}] — where each archive sheet went
    (``print_manifest.json``). ``aliases`` maps merged sheet names to their representative."""
    covered = {}
    for s in package_sheets:
        for src in s.meta.get('sources', [s.name]):
            covered.setdefault(src, s.meta.get('number') or s.name)
    for name, rep in (aliases or {}).items():
        if rep in covered:
            covered.setdefault(name, covered[rep])
    return [
        {
            'sheet': s.name,
            'kind': s.kind,
            'included': s.name in covered,
            'covered_by': covered.get(s.name, ''),
            'reason': ('composed into ' + package + ' sheet ' + covered[s.name])
            if s.name in covered
            else 'reference archive only (drawings.pdf)',
        }
        for s in archive
    ]


def page_size_label(sheet: Sheet) -> str:
    return '%dx%d' % (round(sheet.width / 72), round(sheet.height / 72))


def cover_rows_for_manifest(sheets):
    return [
        {'number': s.meta.get('number', ''), 'title': s.meta.get('desc', s.name), 'size': page_size_label(s)}
        for s in sheets
    ]


__all__ = [
    'append_details',
    'content',
    'drawing_status',
    'erection_sheets',
    'hold_line',
    'place',
    'routing',
    'shipping_rows',
    'shop_sheets',
    'STATUSES',
]
