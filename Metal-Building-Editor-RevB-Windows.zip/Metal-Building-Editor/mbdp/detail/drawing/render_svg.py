"""SVG renderer – used for the live preview in the editor (and as a portable vector export)."""

from __future__ import annotations

from xml.sax.saxutils import escape

from .canvas import Circle, Line, Poly, Sheet, Text


def _rgb(c) -> str:
    return "#%02x%02x%02x" % tuple(int(round(v * 255)) for v in c)


def render_svg(sh: Sheet) -> str:
    out = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {sh.width:g} {sh.height:g}" width="{sh.width:g}" height="{sh.height:g}" '
        f'font-family="Arial, Helvetica, sans-serif">',
        '<rect width="100%" height="100%" fill="white"/>',
    ]
    for it in sh.items:
        if isinstance(it, Line):
            dash = f' stroke-dasharray="{" ".join(f"{x:g}" for x in it.style.dash)}"' if it.style.dash else ""
            out.append(
                f'<line x1="{it.x1:.2f}" y1="{it.y1:.2f}" x2="{it.x2:.2f}" y2="{it.y2:.2f}" stroke="{_rgb(it.style.color)}" '
                f'stroke-width="{max(it.style.width, 0.25):g}"{dash} data-layer="{it.style.layer}"/>'
            )
        elif isinstance(it, Poly):
            pts = " ".join(f"{x:.2f},{y:.2f}" for x, y in it.pts)
            fill = _rgb(it.style.fill) if it.style.fill is not None else "none"
            stroke = _rgb(it.style.color) if it.style.width > 0 else "none"
            dash = f' stroke-dasharray="{" ".join(f"{x:g}" for x in it.style.dash)}"' if it.style.dash else ""
            tag = "polygon" if it.closed else "polyline"
            out.append(
                f'<{tag} points="{pts}" fill="{fill}" stroke="{stroke}" stroke-width="{max(it.style.width, 0.25):g}"{dash} data-layer="{it.style.layer}"/>'
            )
        elif isinstance(it, Circle):
            fill = _rgb(it.style.fill) if it.style.fill is not None else "none"
            out.append(
                f'<circle cx="{it.cx:.2f}" cy="{it.cy:.2f}" r="{it.r:.2f}" fill="{fill}" stroke="{_rgb(it.style.color)}" stroke-width="{max(it.style.width, 0.25):g}"/>'
            )
        elif isinstance(it, Text):
            anchor = {"start": "start", "middle": "middle", "end": "end"}[it.anchor]
            base = {"baseline": "alphabetic", "middle": "central", "top": "hanging"}[it.valign]
            tr = f' transform="rotate({-it.rot:g} {it.x:.2f} {it.y:.2f})"' if it.rot else ""
            weight = ' font-weight="bold"' if it.bold else ""
            out.append(
                f'<text x="{it.x:.2f}" y="{it.y:.2f}" font-size="{it.size:g}" text-anchor="{anchor}" dominant-baseline="{base}" '
                f'fill="{_rgb(it.style.color)}"{weight}{tr}>{escape(it.text)}</text>'
            )
    out.append("</svg>")
    return "\n".join(out)
