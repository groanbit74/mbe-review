"""View generators: elevation, section, part details, plate faces, cut-sheet member.

Every function draws through a ``Canvas`` bound to a ``View``; the sheet module
decides scales and placement.  Model coordinates: x along the member from the
left end (inches), y up from the underside of the bottom flange.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from fractions import Fraction
from typing import Optional

from ...dims import Dim
from .. import sections as _sections
from ..model import Assembly, Attachment, Job, Part
from .canvas import S_CL, S_DIM, S_HID, S_OBJ, S_PLATE, TXT_DIM, Canvas, View, text_width

MIN_T = 3.6  # minimum drawn thickness (pt) for flanges / plates seen edge-on – matches the samples
GAP_END = 6.0  # model inches between member end and an outboard end-plate face view (scaled by sy)


def f(d: Optional[Dim]) -> float:
    return 0.0 if d is None else float(d.inches)


def grid(x: float, den: int = 16) -> Fraction:
    """Round a derived float to the nearest 1/den inch (display of computed values)."""
    return Fraction(round(x * den), den)


def gfmt(x: float, den: int = 16) -> str:
    return Dim(grid(x, den)).fmt()


# --------------------------------------------------------------------------- extents
@dataclass
class ElevExtents:
    """Model-space extents needed to place the elevation (inches; x-extents beyond the member at sy-scale)."""

    left_in: float = 0.0  # inches (at sy scale) needed left of x=0
    right_in: float = 0.0  # inches (at sy scale) needed right of x=L
    up_in: float = 0.0  # inches above top of member
    down_in: float = 0.0  # inches below bottom of member
    top_rows: int = 0  # station dimension rows above
    bottom_rows: int = 0


def elevation_extents(job: Job, a: Assembly) -> ElevExtents:
    e = ElevExtents()
    sec = a.main.sec
    d = sec.d
    for att in a.attachments:
        p = job.part(att.part)
        if att.face in ("left_end", "right_end"):
            if p.kind == "bracket" and p.symbol.get('connection') and a.kind == 'COLUMN' and att.face == 'right_end':
                from .connection_views import bounds, side_geometry

                xmin, ymin, xmax, ymax = bounds(side_geometry(job, p, False, False))
                e.right_in = max(e.right_in, ymax + 3)
                e.up_in = max(e.up_in, max(0, -xmin) + 2)
                e.down_in = max(e.down_in, max(0, xmax - d) + 2)
                continue
            if p.kind == "bracket":
                w = float(p.symbol.get("w", 14.0))
                h = float(p.symbol.get("h", d + 8))
                need = w + GAP_END
                e.up_in = max(e.up_in, max(0.0, (h - d) / 2 + 2))
                e.down_in = max(e.down_in, max(0.0, (h - d) / 2 + 2))
            else:
                need = f(p.width) + GAP_END + 4
                e.up_in = max(e.up_in, max(0.0, (f(p.length) - d) / 2))
                e.down_in = max(e.down_in, max(0.0, (f(p.length) - d) / 2))
            if att.face == "left_end":
                e.left_in = max(e.left_in, need)
            else:
                e.right_in = max(e.right_in, need)
        elif att.face == "top":
            h = (
                f(p.length)
                if p.kind in ("clip", "plate")
                else f(p.cut_length) + 6
                if p.kind == "stub"
                else float(p.symbol.get("h", 4))
            )
            e.up_in = max(e.up_in, h + 1)
            e.top_rows = 1
        elif att.face == "bottom":
            h = (
                f(p.length)
                if p.kind in ("clip", "plate")
                else f(p.cut_length) + 6
                if p.kind == "stub"
                else float(p.symbol.get("h", 4))
            )
            e.down_in = max(e.down_in, h + 1)
            e.bottom_rows = 1
        elif att.face == "web":
            e.bottom_rows = 1
    if a.main.web_holes:
        e.bottom_rows = 1
    return e


# --------------------------------------------------------------------------- elevation
def draw_elevation(c: Canvas, job: Job, a: Assembly, y_row_top: float, y_row_bottom: float, mini: bool = False) -> None:
    """Assembly elevation.  ``y_row_*`` are paper y for the station-dimension rows."""
    v = c.v
    sec = a.main.sec
    L = f(a.main.cut_length)
    d = sec.d
    tf = max(sec.tf or 0, MIN_T / v.sy)
    xw = lambda w: w * v.sy / v.sx  # true-aspect width in model-x units

    # -- member outline (bevel ends supported)
    lx0 = math.tan(math.radians(a.main.left_cut.angle)) * d if a.main.left_cut.type == "bevel" else 0.0
    rx0 = math.tan(math.radians(a.main.right_cut.angle)) * d if a.main.right_cut.type == "bevel" else 0.0
    if a.main.left_cut.type == "bevel":
        pts_left = [(0.0, 0.0), (lx0, d)] if lx0 >= 0 else [(abs(lx0), 0.0), (0.0, d)]
    else:
        pts_left = [(0.0, 0.0), (0.0, d)]
    if a.main.right_cut.type == "bevel":
        pts_right = [(L, d), (L - rx0, 0.0)] if rx0 >= 0 else [(L - abs(rx0), d), (L, 0.0)]
    else:
        pts_right = [(L, d), (L, 0.0)]
    outline = [pts_left[0], pts_left[1], pts_right[0], pts_right[1]]
    c.poly(outline, True, S_OBJ)
    if sec.kind != 'HSS' or sec.tf is not None:
        c.line(
            pts_left[0][0] + (tf * (pts_left[1][0] - pts_left[0][0]) / d),
            tf,
            pts_right[1][0] + (tf * (pts_right[0][0] - pts_right[1][0]) / d),
            tf,
            S_HID if sec.kind == 'HSS' else S_OBJ,
        )
    if sec.kind != 'HSS' or sec.tf is not None:
        c.line(
            pts_left[1][0] - (tf * (pts_left[1][0] - pts_left[0][0]) / d),
            d - tf,
            pts_right[0][0] - (tf * (pts_right[0][0] - pts_right[1][0]) / d),
            d - tf,
            S_HID if sec.kind == 'HSS' else S_OBJ,
        )
    c.text(_label_x(a, L), d / 2, a.main.mark, TXT_DIM, 0, "middle", "middle")
    _fold_wedge(c, a, L, mini)

    if not mini:
        # overall length above everything
        y_len = y_row_top - 22
        from ..model import D

        low = a.derivation.get('column_low_cut_in')
        dimL = L if low is None else low
        c.dim_h(
            v.px(0),
            v.px(dimL),
            v.py(d),
            v.py(d if rx0 <= 0 else 0),
            y_len,
            (D(low).fmt() + ' LOW POINT') if low is not None else a.main.cut_length.fmt(),
        )
        # "Tape (Typ)" datum note
        tx = v.px(0) - 12
        c._free_row(y_row_top, tx - text_width("Tape", TXT_DIM) - 4, tx + 4, False)
        c.ptext(tx, y_row_top - 4, "Tape", TXT_DIM, 0, "end")
        c.ptext(tx, y_row_top + 9, "(Typ)", TXT_DIM, 0, "end")
        c.pline(tx - text_width("Tape", TXT_DIM) - 2, y_row_top - 1.5, tx + 2, y_row_top - 1.5, S_DIM)
        c.pline(v.px(0), v.py(d) - 3, v.px(0), y_row_top - 1.5, S_DIM)

    called: set[tuple] = set()
    top_stations: list[float] = []
    bottom_stations: list[float] = []

    # -- web hole groups
    for wh in a.main.web_holes:
        pos = wh.positions()
        for sx_, sy_ in pos:
            c.circle(f(sx_), d - f(sy_), f(wh.dia) / 2)
        x_first, y_first = f(pos[0][0]), d - f(pos[0][1])
        if not mini:
            c.dim_station(v.px(x_first), v.py(0), y_row_bottom, wh.station.fmt(), below=True)
            bottom_stations.append(f(wh.station))
            xl = v.px(x_first) - 24
            c.dim_v(v.py(d), v.py(y_first), v.px(x_first), v.px(x_first), xl, wh.y_from_top.fmt(), text_left=True)
            if wh.cols > 1 and wh.pitch_x:
                c.dim_h(
                    v.px(x_first),
                    v.px(x_first + f(wh.pitch_x)),
                    v.py(y_first),
                    v.py(y_first),
                    v.py(y_first) - 14,
                    wh.pitch_x.fmt(),
                )
            if wh.rows > 1 and wh.pitch_y:
                c.dim_v(
                    v.py(y_first),
                    v.py(y_first - f(wh.pitch_y)),
                    v.px(x_first),
                    v.px(x_first),
                    xl,
                    wh.pitch_y.fmt(),
                    text_left=True,
                )
            tip = v.p(x_first, y_first - (f(wh.pitch_y) * (wh.rows - 1) if wh.pitch_y else 0))
            note = f"D={wh.dia.fmt()}" + (f"  {wh.note}" if wh.note else "")
            c.leader((tip[0] - 2, tip[1] + 2), [(tip[0] - 30, tip[1] + 22)], note, TXT_DIM, anchor="end", dy=4)

    # -- attachments
    for att in sorted(a.attachments, key=lambda t: (t.face, f(t.station))):
        p = job.part(att.part)
        st = f(att.station) if att.station is not None else 0.0
        label = att.label or p.mark
        if att.face in ("top", "bottom"):
            up = att.face == "top"
            sgn = 1 if up else -1
            base = d if up else 0.0
            if p.kind in ("clip", "plate"):
                h = f(p.length)
                w = xw(max(f(p.thk), MIN_T / v.sy))
                x0 = st - w / 2 if att.ref == "center" else st if att.ref == "left" else st - w
                if att.tilt:
                    theta = math.radians(att.tilt)
                    th = f(p.thk)
                    shift = 0 if att.ref == 'left' else -th if att.ref == 'right' else -th / 2

                    def clippt(px, py):
                        return (
                            st + xw((px + shift) * math.cos(theta) - py * math.sin(theta)),
                            base + sgn * ((px + shift) * math.sin(theta) + py * math.cos(theta)),
                        )

                    c.poly([clippt(px, py) for px, py in [(0, 0), (th, 0), (th, h), (0, h)]], True, S_OBJ)
                else:
                    c.rect(x0, base, x0 + w, base + sgn * h, S_OBJ)
                for hx in sorted({float(hh.x.inches) for hh in p.holes}):
                    c.weld_tick(*clippt(f(p.thk) / 2, hx)) if att.tilt else c.weld_tick(x0 + w / 2, base + sgn * hx)
                if up and not mini:
                    c.dim_station(v.px(x0 + w / 2), v.py(base + h), y_row_top, gfmt(st))
                    top_stations.append(st)
                elif not up and not mini:
                    c.dim_station(v.px(x0 + w / 2), v.py(base - h), y_row_bottom, gfmt(st), below=True)
                    bottom_stations.append(st)
                if ((p.mark, att.face) not in called or att.note.startswith('peak ')) and not mini:
                    called.add((p.mark, att.face))
                    tipx, tipy = v.p(x0 + w, base + sgn * h * 0.55)
                    c.leader((tipx + 1, tipy), [(tipx + 14, tipy)], label, 14.0)
                    if att.angle:
                        c.ptext(tipx + 4, v.py(base) + (11 if up else -4), f"{att.angle:g}°", TXT_DIM, 0, "start")
                if att.show_first_hole_ref and p.holes:
                    hx = min(float(hh.x.inches) for hh in p.holes)
                    xl = v.px(x0) - 9
                    c.dim_v(v.py(base), v.py(base + sgn * hx), v.px(x0), v.px(x0), xl, gfmt(hx), text_left=True)
                    c.ptext(xl - 18, v.py(base) + (-3 if up else 12), "1st hole Ref.", TXT_DIM * 0.85, 0, "end")
            elif p.kind == "stub":
                ssec = _sections.get_section(p.section)
                Ls = f(p.cut_length)
                w = xw(ssec.d)
                x0 = st if att.ref == "left" else st - w / 2 if att.ref == "center" else st - w
                y1 = base + sgn * Ls
                c.rect(x0, base, x0 + w, y1, S_OBJ)
                tfi = xw(max(ssec.tf, MIN_T / v.sy))
                c.line(x0 + tfi, base, x0 + tfi, y1, S_OBJ)
                c.line(x0 + w - tfi, base, x0 + w - tfi, y1, S_OBJ)
                c.text(x0 + w / 2, base + sgn * Ls / 2, p.mark, TXT_DIM, 0, "middle", "middle")
                # stub sub-attachments (drawn schematically on the stub's far/side faces)
                for sub in p.attachments:
                    sp = job.part(sub.part)
                    if sub.face in ("right_end", "left_end") and sp.kind in ("plate", "clip"):
                        t = max(f(sp.thk), MIN_T / v.sy)
                        pl = xw(f(sp.length))
                        cx = x0 + w / 2
                        c.rect(cx - pl / 2, y1, cx + pl / 2, y1 + sgn * t, S_OBJ)
                        for hx in sorted({float(hh.x.inches) for hh in sp.holes}):
                            c.weld_tick(cx - pl / 2 + xw(hx), y1 + sgn * t / 2, vertical=False)
                    elif sub.face in ("top", "bottom") and sp.kind in ("clip", "plate"):
                        s2 = f(sub.station)
                        t = max(f(sp.thk), MIN_T / v.sy)
                        pl = xw(f(sp.length))
                        yy = base + sgn * s2
                        c.rect(x0 + w, yy - t / 2, x0 + w + pl, yy + t / 2, S_OBJ)
                        for hx in sorted({float(hh.x.inches) for hh in sp.holes}):
                            c.weld_tick(x0 + w + xw(hx), yy, vertical=False)
                        if not mini:
                            # station of the clip's first hole from the tape (as the samples do)
                            first = min((float(hh.x.inches) for hh in sp.holes), default=0.0)
                            stx = x0 + w + xw(first)
                            if up:
                                c.dim_station(
                                    v.px(stx), v.py(yy + t / 2), y_row_top, _stub_hole_station(att, w, first, v)
                                )
                            else:
                                c.dim_station(
                                    v.px(stx),
                                    v.py(yy - t / 2),
                                    y_row_bottom,
                                    _stub_hole_station(att, w, first, v),
                                    below=True,
                                )
                if not mini:
                    if up:
                        c.dim_station(v.px(x0), v.py(y1), y_row_top, att.station.fmt())
                        top_stations.append(st)
                    else:
                        c.dim_station(v.px(x0), v.py(y1), y_row_bottom, att.station.fmt(), below=True)
                        bottom_stations.append(st)
            elif p.kind == "bracket":
                w = float(p.symbol.get("w", 10.0))
                h = float(p.symbol.get("h", 3.0))
                ang = math.radians(att.tilt)
                wx, hy = xw(w), h
                x0 = st if att.ref == "left" else st - wx / 2 if att.ref == "center" else st - wx
                # rotate about the near-bottom corner (paper aspect handled by xw)
                pts = [(0, 0), (w, 0), (w, h), (0, h)]
                rot = [
                    (
                        x0 + xw(px * math.cos(ang) - py * math.sin(ang)),
                        base + sgn * (px * math.sin(ang) + py * math.cos(ang)),
                    )
                    for px, py in pts
                ]
                c.poly(rot, True, S_OBJ)
                for k in range(3):
                    c.weld_tick(
                        x0 + xw(w * (k + 0.5) / 3 * math.cos(ang)),
                        base + sgn * (w * (k + 0.5) / 3 * math.sin(ang)) + sgn * 0.3,
                        vertical=False,
                    )
                c.text(x0 + wx / 2, base + sgn * (h + 2.5), label, TXT_DIM, 0, "middle", "middle")
                if not mini:
                    if up:
                        c.dim_station(v.px(x0), v.py(base + h + 1), y_row_top, att.station.fmt())
                    else:
                        c.dim_station(v.px(x0), v.py(base - h - 1), y_row_bottom, att.station.fmt(), below=True)
        elif att.face == "web":
            y_hole = d - f(att.y_from_top) if att.y_from_top is not None else d / 2
            if p.kind == "mark":
                # girt welded directly to the web: tick across the web at the girt centre, station, one callout
                c.line(st, max(0.0, y_hole - 4), st, min(d, y_hole + 4), S_OBJ)
                c.weld_tick(st, y_hole)
                if not mini and not any(abs(s - st) < 1 / 16 for s in top_stations + bottom_stations):
                    c.dim_station(v.px(st), v.py(0), y_row_bottom, att.station.fmt(), below=True)
                    bottom_stations.append(st)
                if (p.mark, "web") not in called and not mini:
                    called.add((p.mark, "web"))
                    tipx, tipy = v.p(st, y_hole - 4)
                    c.leader(
                        (tipx + 1, tipy + 1), [(tipx + 10, tipy + 12)], "GIRT welded to web (coped), no clip", TXT_DIM
                    )
            elif p.kind in ("clip", "plate"):
                h = f(p.width) if att.note.endswith("flush") else f(p.length)
                w = xw(max(f(p.thk), MIN_T / v.sy))
                c.rect(st - w / 2, y_hole - h / 2, st + w / 2, y_hole + h / 2, S_OBJ)
                if att.note.endswith("flush") and p.holes:
                    for hy in sorted({f(hh.y) for hh in p.holes}):
                        c.circle(st, y_hole - h / 2 + hy, f(p.hole_dia()) / 2)
                else:
                    c.circle(st, y_hole, f(p.hole_dia() or Dim(Fraction(9, 16))) / 2)
                at_hole_group = any(abs(f(wh.station) - st) < 1 / 16 for wh in a.main.web_holes)
                if not mini and att.y_from_top is not None and not at_hole_group:
                    c.dim_v(
                        v.py(d), v.py(y_hole), v.px(st), v.px(st), v.px(st) + 10, att.y_from_top.fmt(), text_left=False
                    )
                if not mini and not any(abs(s - st) < 1 / 16 for s in top_stations + bottom_stations):
                    c.dim_station(v.px(st), v.py(0), y_row_bottom, att.station.fmt(), below=True)
                    bottom_stations.append(st)
                if (p.mark, "web") not in called and not mini:
                    called.add((p.mark, "web"))
                    tipx, tipy = v.p(st + w / 2, y_hole - h / 2)
                    txt = label + (f"  {att.note}" if att.note else "")
                    c.leader((tipx + 1, tipy + 1), [(tipx + 10, tipy + 12)], txt, TXT_DIM)
            elif p.kind == "bracket":
                w = float(p.symbol.get("w", 8.0))
                h = float(p.symbol.get("h", 4.0))
                c.rect(st - xw(w) / 2, y_hole - h / 2, st + xw(w) / 2, y_hole + h / 2, S_OBJ)
                c.text(st, y_hole, label, TXT_DIM, 0, "middle", "middle")
        elif att.face in ("left_end", "right_end"):
            left = att.face == "left_end"
            if p.symbol.get('inside_knee_top') and a.kind == 'COLUMN' and not left:
                g = p.symbol['knee_geometry']
                cd = g['column_depth_in']
                slope = g['pitch_rise'] / 12
                xbase = L - max(cd * slope, 0)
                c.poly([(L + xw(xbase - L + y), cd - x) for x, y in g['side_contour_in']], True, S_OBJ)
                c.text(L + xw(4), -4, label + ' / PITCHED TOP PLATE', 9, 0, 'middle')
                if p.symbol.get('starting_clip'):
                    cp = job.part(p.symbol['starting_clip'])
                    h = f(cp.length)
                    t = f(cp.thk)
                    yy = g['thickness_in'] / g['co']
                    c.poly(
                        [(L + xw(xbase - L + y), cd - x) for x, y in [(0, yy), (t, yy), (t, yy + h), (0, yy + h)]],
                        True,
                        S_OBJ,
                    )
                continue
            if p.kind == 'bracket' and p.symbol.get('connection') and a.kind == 'COLUMN' and not left:
                # Column is drawn on its side: global bracket up -> member X,
                # global across-column -> member -Y. Uniform sy keeps the
                # bracket proportional even though the long column is shortened.
                from .connection_views import draw_side

                draw_side(c, job, p, False, False, lambda x, y: (L + y * v.sy / v.sx, d - x))
                c.text(L + xw(p.symbol['h'] / 2), d + 2, label + ' (true proportions)', 9, 0, 'middle')
                continue
            if p.kind == "bracket":
                w = float(p.symbol.get("w", 14.0))
                h = float(p.symbol.get("h", d + 8))
                gap = 1.0
                x0 = -(gap + w) if left else L + gap
                x0m = xw(x0) if left else L + xw(gap)
                wx = xw(w)
                yb = (d - h) / 2
                pts = [(x0m, yb), (x0m + wx, yb), (x0m + wx, yb + h), (x0m, yb + h)]
                if att.tilt:
                    # slanted top edge – roof slope
                    dy = w * math.tan(math.radians(att.tilt))
                    pts = [
                        (x0m, yb),
                        (x0m + wx, yb),
                        (x0m + wx, yb + h + (dy if not left else 0)),
                        (x0m, yb + h + (dy if left else 0)),
                    ]
                c.poly(pts, True, S_OBJ)
                c.text(x0m + wx / 2, d / 2, label, TXT_DIM, 0, "middle", "middle")
                # weld ticks at the member end
                for k in range(3):
                    c.weld_tick(0 if left else L, tf + (d - 2 * tf) * (k + 0.5) / 3)
                for yy in (0.0, d):
                    c.line(0 if left else L, yy, x0m if left else x0m, yy, S_HID)
            else:
                draw_endplate_face(c, job, p, att, L, d, left)


def _fold_wedge(c: Canvas, a: Assembly, L: float, mini: bool) -> None:
    """One-piece cut-and-fold rafter: the ridge wedge on the flat blank (bottom flange + web cut out)."""
    fold = a.derivation.get('ridge_fold')
    if not fold:
        return
    h = fold['wedge_half_in']
    hw = fold['wedge_depth_in']
    cx = L / 2
    c.poly([(cx - h, 0), (cx, hw), (cx + h, 0)], False, S_OBJ)
    c.line(cx, -1.5, cx, a.main.sec.d + 1.5, S_CL)
    if mini:
        return
    v = c.v
    tip = v.p(cx + h / 2, hw / 4)
    c.leader(
        (tip[0], tip[1]),
        [(tip[0] + 30, tip[1] + 34)],
        'CUT & FOLD WEDGE ' + gfmt(2 * h) + ' - see RIDGE-' + str(a.derivation.get('frame_id', '')),
        TXT_DIM,
    )


def _label_x(a: Assembly, L: float) -> float:
    """x of the main-mark label: centre of the widest gap between features along the member."""
    xs = sorted(
        {0.0, L}
        | {f(t.station) for t in a.attachments if t.station is not None}
        | {f(w.station) for w in a.main.web_holes}
    )
    best = max(zip(xs, xs[1:]), key=lambda g: g[1] - g[0])
    return (best[0] + best[1]) / 2


def _stub_hole_station(att: Attachment, w_model: float, first_hole: float, v: View) -> str:
    """Station text of a clip hole on a stub: stub root station + stub depth + hole offset (exact to 1/16)."""
    st = att.station.inches
    val = st + grid(w_model * v.sx / v.sy) + grid(first_hole)
    return Dim(val).fmt()


def draw_endplate_face(c: Canvas, job: Job, p: Part, att: Attachment, L: float, d: float, left: bool) -> None:
    """Outboard face view of an end / base plate (as the sample sheets draw EP12, B-14, K-14)."""
    v = c.v
    xw = lambda w: w * v.sy / v.sx
    pw, pl = f(p.width), f(p.length)
    gap = GAP_END
    x0 = -xw(gap + pw) if left else L + xw(gap)
    y0 = d - pl if p.symbol.get("top_flush") else d / 2 - pl / 2
    c.rect(x0, y0, x0 + xw(pw), y0 + pl, S_PLATE)
    for h in p.holes:
        c.circle(x0 + xw(float(h.y.inches)), y0 + float(h.x.inches), float(h.dia.inches) / 2)
    # label rotated between plate and member
    lx = x0 + xw(pw) + xw(2.2) if left else x0 - xw(2.2)
    c.text(lx, d / 2, att.label or p.mark, TXT_DIM, 90, "middle", "middle")
    if pl >= d - 0.5:
        for yy in (0.0, d):
            c.line(0 if left else L, yy, x0 + xw(pw) if left else x0, yy, S_HID)
    else:
        xa, xb = (x0 - xw(4), 0 + xw(3)) if left else (L - xw(3), x0 + xw(pw) + xw(4))
        c.line(xa, d / 2, xb, d / 2, S_CL)
        c.text(
            xa if left else xb,
            d / 2,
            "C.L",
            TXT_DIM * 0.85,
            0,
            "end" if left else "start",
            "middle",
            dx=-2 if left else 2,
        )
    if att.show_first_hole_ref and p.holes:
        hx = max(float(h.x.inches) for h in p.holes)  # first hole from the plate top edge
        base_datum = p.symbol.get('base_hole_datum') == 'outside_flange_inward'
        top = d if base_datum else y0 + pl
        xl = v.px(x0) - 6 if left else v.px(x0 + xw(pw)) + 6
        c.dim_v(
            v.py(top),
            v.py(y0 + hx),
            v.px(x0),
            v.px(x0),
            xl - 6 if left else xl + 6,
            gfmt(top - y0 - hx),
            text_left=left,
        )
        if base_datum:
            c.ptext(v.px(x0 + xw(pw / 2)), v.py(top) - 12, "OUTSIDE FLANGE", 7, 0, "middle")


# --------------------------------------------------------------------------- section
def draw_section(c: Canvas, job: Job, a: Assembly, station: Optional[float]) -> tuple[float, float]:
    """End view (looking along the member) with the parts present at ``station``.  Returns (height_in, width_in)."""
    v = c.v
    sec = a.main.sec
    d, bf, tf, tw = sec.d, sec.bf, sec.tf or 0, sec.tw or 0
    # I-section outline, centred on x=0
    pts = [
        (-bf / 2, 0),
        (bf / 2, 0),
        (bf / 2, tf),
        (tw / 2, tf),
        (tw / 2, d - tf),
        (bf / 2, d - tf),
        (bf / 2, d),
        (-bf / 2, d),
        (-bf / 2, d - tf),
        (-tw / 2, d - tf),
        (-tw / 2, tf),
        (-bf / 2, tf),
    ]
    if sec.kind == 'HSS':
        c.rect(-bf / 2, 0, bf / 2, d, S_OBJ)
        if tf:
            c.rect(-bf / 2 + tf, tf, bf / 2 - tf, d - tf, S_HID)
        c.text(0, -2, 'HSS CLOSED TUBE / NOMINAL WALL', 7, 0, 'middle')
    elif sec.kind == 'Channel':
        c.poly([(bf / 2, 0), (-bf / 2, 0), (-bf / 2, d), (bf / 2, d)], False, S_OBJ)
        c.text(0, -2, 'UNLIPPED CHANNEL / THICKNESS UNVERIFIED', 7, 0, 'middle')
    else:
        c.poly(pts, True, S_OBJ)
    top = d
    bottom = 0.0
    half_w = bf / 2
    for att in a.attachments:
        if att.face in ("left_end", "right_end"):
            continue
        if station is not None and att.station is not None and abs(f(att.station) - station) > 1 / 16:
            continue
        p = job.part(att.part)
        if p.kind not in ("clip", "plate"):
            continue
        pw, pl = f(p.width), f(p.length)
        if att.face in ("top", "bottom"):
            up = att.face == "top"
            y0 = d if up else -pl
            c.rect(-pw / 2, y0, pw / 2, y0 + pl, S_OBJ)
            xs = sorted({float(h.y.inches) for h in p.holes})
            ys = sorted({float(h.x.inches) for h in p.holes})
            for h in p.holes:
                hy = y0 + float(h.x.inches) if up else -float(h.x.inches)
                c.circle(-pw / 2 + float(h.y.inches), hy, float(h.dia.inches) / 2)
            # dimensions: gauge across (above), pitch + edge (right)
            if len(xs) >= 2:
                yl = v.py(y0 + pl) - 10 if up else v.py(y0) + 10
                c.dim_h(
                    v.px(-pw / 2 + xs[0]),
                    v.px(-pw / 2 + xs[1]),
                    v.py(y0 + pl) if up else v.py(y0),
                    v.py(y0 + pl) if up else v.py(y0),
                    yl,
                    gfmt(xs[1] - xs[0]),
                    text_above=up,
                )
            xr = v.px(pw / 2) + 14
            if ys:
                first = ys[0]
                if up:
                    c.dim_v(v.py(d + first), v.py(d), v.px(pw / 2), v.px(bf / 2), xr, gfmt(first), text_left=False)
                else:
                    c.dim_v(v.py(0), v.py(-first), v.px(bf / 2), v.px(pw / 2), xr, gfmt(first), text_left=False)
                if len(ys) >= 2:
                    if up:
                        c.dim_v(
                            v.py(d + ys[1]),
                            v.py(d + ys[0]),
                            v.px(pw / 2),
                            v.px(pw / 2),
                            xr,
                            gfmt(ys[1] - ys[0]),
                            text_left=False,
                        )
                    else:
                        c.dim_v(
                            v.py(-ys[0]),
                            v.py(-ys[1]),
                            v.px(pw / 2),
                            v.px(pw / 2),
                            xr,
                            gfmt(ys[1] - ys[0]),
                            text_left=False,
                        )
            # callout
            tipx, tipy = v.p(-pw / 2, (y0 + pl * 0.6) if up else (y0 + pl * 0.4))
            dia = p.hole_dia()
            txt = att.label or p.mark
            c.leader((tipx - 1, tipy), [(tipx - 24, tipy - 6)], txt, TXT_DIM, anchor="end")
            if dia is not None:
                c.ptext(tipx - 26, tipy + 8, f"D= {dia.fmt()}", TXT_DIM, 0, "end")
            top = max(top, y0 + pl if up else top)
            bottom = min(bottom, y0 if not up else bottom)
            half_w = max(half_w, pw / 2)
        elif att.face == "web":
            yh = d - f(att.y_from_top) if att.y_from_top is not None else d / 2
            for side in (("NS", -1), ("FS", 1)) if att.side == "both" else ((att.side, -1 if att.side == "NS" else 1),):
                sgn = side[1]
                x0 = sgn * bf / 2 if sec.kind == 'HSS' else (-bf / 2 if sec.kind == 'Channel' else 0) + sgn * tw / 2
                x1 = x0 + sgn * pl
                c.rect(min(x0, x1), yh - pw / 2, max(x0, x1), yh + pw / 2, S_OBJ)
                if att.note.endswith("flush") and p.holes:
                    for hole in p.holes:
                        c.circle(x0 + sgn * f(hole.x), yh - pw / 2 + f(hole.y), f(hole.dia) / 2)
                elif p.holes:
                    c.circle((x0 + x1) / 2, yh, f(p.hole_dia() or Dim(Fraction(9, 16))) / 2)
                if sgn > 0:
                    c.dim_h(v.px(x0), v.px(x1), v.py(yh + pw / 2), v.py(yh + pw / 2), v.py(yh + pw / 2) - 8, gfmt(pl))
            tipx, tipy = v.p((bf / 2 if sec.kind == 'HSS' else -bf / 2 if sec.kind == 'Channel' else tw / 2) + pl, yh)
            dia = p.hole_dia()
            c.leader((tipx + 1, tipy), [(tipx + 16, tipy - 4)], att.label or p.mark, TXT_DIM)
            if dia is not None:
                c.ptext(tipx + 18, tipy + 8, f"D= {dia.fmt()}", TXT_DIM, 0, "start")
            if att.y_from_top is not None:
                c.dim_v(
                    v.py(d),
                    v.py(yh),
                    v.px(bf / 2),
                    v.px(tw / 2 + pl),
                    v.px(bf / 2) + 44,
                    att.y_from_top.fmt(),
                    text_left=False,
                )
            half_w = max(half_w, tw / 2 + pl)
            bottom = min(bottom, yh - pw / 2)
    # NS / FS labels
    c.text(-half_w - 3.5, bottom - 1.5, "NS", TXT_DIM, 0, "end", "middle")
    c.text(half_w + 3.5, bottom - 1.5, "FS", TXT_DIM, 0, "start", "middle")
    return top - bottom, 2 * half_w


# --------------------------------------------------------------------------- stub / part details
def draw_stub_detail(c: Canvas, job: Job, p: Part) -> None:
    """Little elevation of a stub with its own parts (MB-2 / MB-3 style) – view scale is uniform."""
    sec = _sections.get_section(p.section)
    v = c.v
    L = f(p.cut_length)
    d = sec.d
    tf = max(sec.tf or 0, MIN_T / v.sy)
    c.rect(0, 0, L, d, S_OBJ)
    c.line(0, tf, L, tf, S_OBJ)
    c.line(0, d - tf, L, d - tf, S_OBJ)
    c.text(L / 2, d / 2, p.section, TXT_DIM, 0, "middle", "middle")
    y_dim = v.py(d) - 30
    for sub in p.attachments:
        sp = job.part(sub.part)
        if sub.face == "top" and sp.kind in ("clip", "plate"):
            st = f(sub.station)
            t = max(f(sp.thk), MIN_T / v.sy)
            h = f(sp.length)
            c.rect(st - t / 2, d, st + t / 2, d + h, S_OBJ)
            for hx in sorted({float(hh.x.inches) for hh in sp.holes}):
                c.weld_tick(st, d + hx)
            c.dim_h(v.px(0), v.px(st), v.py(d + h), v.py(d + h), v.py(d + h) - 12, sub.station.fmt())
            tipx, tipy = v.p(st + t / 2, d + h * 0.5)
            c.leader((tipx + 1, tipy), [(tipx + 10, tipy)], sub.label or sp.mark, TXT_DIM)
            y_dim = min(y_dim, v.py(d + h) - 28)
        elif sub.face in ("right_end", "left_end") and sp.kind in ("plate", "clip"):
            left = sub.face == "left_end"
            fake = Attachment(part=sp.mark, face=sub.face, label=sub.label)
            draw_endplate_face(c, job, sp, fake, L, d, left)
    c.dim_h(v.px(0), v.px(L), v.py(d), v.py(d), y_dim, p.cut_length.fmt())


def draw_plate_face(c: Canvas, p: Part, with_dims: bool = True, label: Optional[str] = None) -> None:
    """Plan view of a plate: x = length, y = width, holes, outline dims and hole dims."""
    v = c.v
    pl, pw = f(p.length), f(p.width)
    if p.symbol.get("contour"):
        from ..connections import contour

        c.poly(contour(p), style=S_PLATE)
    else:
        c.rect(0, 0, pl, pw, S_PLATE)
    for h in p.holes:
        c.circle(float(h.x.inches), float(h.y.inches), float(h.dia.inches) / 2)
    if with_dims:
        xs = sorted({float(h.x.inches) for h in p.holes})
        ys = sorted({float(h.y.inches) for h in p.holes})
        # running dims along the length (top) : edge, pitches, edge
        y1 = v.py(pw) - 12
        stops = [0.0] + xs + [pl]
        for a_, b_ in zip(stops, stops[1:]):
            if b_ - a_ > 1e-9:
                c.dim_h(v.px(a_), v.px(b_), v.py(pw), v.py(pw), y1, gfmt(b_ - a_))
        c.dim_h(v.px(0), v.px(pl), v.py(pw), v.py(pw), y1 - 16, p.length.fmt())
        x1 = v.px(pl) + 12
        stops = [0.0] + ys + [pw]
        for a_, b_ in zip(stops, stops[1:]):
            if b_ - a_ > 1e-9:
                c.dim_v(v.py(b_), v.py(a_), v.px(pl), v.px(pl), x1, gfmt(b_ - a_), text_left=False)
        c.dim_v(v.py(pw), v.py(0), v.px(pl), v.px(pl), x1 + 16, p.width.fmt(), text_left=False)
        if p.holes:
            dia = p.hole_dia()
            hx, hy = float(p.holes[0].x.inches), float(p.holes[0].y.inches)
            tip = v.p(hx, hy)
            c.leader(
                (tip[0] - 2, tip[1] + 2),
                [(tip[0] - 16, tip[1] + 18)],
                f"{len(p.holes)} HOLES D= {dia.fmt()}",
                TXT_DIM,
                anchor="end",
            )
    if label:
        c.text(pl / 2, -1.5, label, TXT_DIM, 0, "middle", "top")
        w = text_width(label, TXT_DIM)
        px, py = v.p(pl / 2, -1.5)
        c.pline(px - w / 2, py + TXT_DIM + 1, px + w / 2, py + TXT_DIM + 1, S_DIM)


# --------------------------------------------------------------------------- cut sheet member
def draw_cut_member(c: Canvas, a: Assembly) -> None:
    """Cut-sheet view: flange plan above, elevation below, CUT LEN dimension, web holes."""
    v = c.v
    sec = a.main.sec
    L = f(a.main.cut_length)
    d, bf = sec.d, sec.bf
    tf = max(sec.tf or 0, MIN_T / v.sy)
    # elevation
    lx = math.tan(math.radians(a.main.left_cut.angle)) * d if a.main.left_cut.type == 'bevel' else 0
    rx = math.tan(math.radians(a.main.right_cut.angle)) * d if a.main.right_cut.type == 'bevel' else 0
    left = [(0, 0), (lx, d)] if lx >= 0 else [(abs(lx), 0), (0, d)]
    right = [(L, d), (L - rx, 0)] if rx >= 0 else [(L - abs(rx), d), (L, 0)]
    c.poly([left[0], left[1], right[0], right[1]], True, S_OBJ)
    if sec.kind != 'HSS' or sec.tf is not None:
        c.line(
            left[0][0] + tf * (left[1][0] - left[0][0]) / d,
            tf,
            right[1][0] + tf * (right[0][0] - right[1][0]) / d,
            tf,
            S_HID if sec.kind == 'HSS' else S_OBJ,
        )
    if sec.kind != 'HSS' or sec.tf is not None:
        c.line(
            left[1][0] - tf * (left[1][0] - left[0][0]) / d,
            d - tf,
            right[0][0] - tf * (right[0][0] - right[1][0]) / d,
            d - tf,
            S_HID if sec.kind == 'HSS' else S_OBJ,
        )
    c.text(_label_x(a, L), d / 2, f"Member Size {a.main.section}", TXT_DIM, 0, "middle", "middle")
    _fold_wedge(c, a, L, False)
    # flange plan (width bf) above with a gap
    y0 = d + 3
    c.rect(0, y0, L, y0 + bf, S_OBJ)
    from ..model import D

    low = a.derivation.get('column_low_cut_in')
    dimL = L if low is None else low
    c.dim_h(
        v.px(0),
        v.px(dimL),
        v.py(y0 + bf),
        v.py(y0 + bf),
        v.py(y0 + bf) - 10,
        'CUT LEN ' + (D(low).fmt() + ' LOW POINT' if low is not None else a.main.cut_length.fmt()),
    )
    if low is not None:
        c.text(L / 2, -5, 'LONG-POINT BLANK ' + a.main.cut_length.fmt() + ' (profile / NC reference)', 8, 0, 'middle')
    # bevel notes
    for side, cut in (("LEFT", a.main.left_cut), ("RIGHT", a.main.right_cut)):
        if cut.type == "bevel":
            x = 0 if side == "LEFT" else L
            c.text(
                x,
                -2,
                f"{side} END {'PITCH CUT (NOT WELD BEVEL)' if a.derivation.get('connection_style', 'bolted') != 'bolted' else 'BEVEL'} {abs(cut.angle):g}°"
                + (' LONG POINT BOTTOM' if a.derivation.get('ridge_fold') else ''),
                TXT_DIM * 0.85,
                0,
                "start" if side == "LEFT" else "end",
                "top",
            )
    # web holes
    for wh in a.main.web_holes:
        for sx_, sy_ in wh.positions():
            c.circle(f(sx_), d - f(sy_), f(wh.dia) / 2)
        first = wh.positions()[0]
        c.dim_h(
            v.px(0), v.px(f(first[0])), v.py(0), v.py(d - f(first[1])), v.py(0) + 18, wh.station.fmt(), text_above=False
        )
        c.dim_v(
            v.py(d),
            v.py(d - f(first[1])),
            v.px(f(first[0])),
            v.px(f(first[0])),
            v.px(f(first[0])) - 14,
            wh.y_from_top.fmt(),
        )
        tip = v.p(f(first[0]), d - f(first[1]))
        note = f"{wh.rows * wh.cols} HOLES D= {wh.dia.fmt()}" + (f"  {wh.note}" if wh.note else "")
        c.leader((tip[0] + 2, tip[1] - 2), [(tip[0] + 18, tip[1] - 16)], note, TXT_DIM)
