"""Uniform-scale apex / selected peak-clip side elevation from the frame model."""

import math

from ..connections import q
from .canvas import S_CL, S_DIM, S_NOTE, Canvas, Sheet, View
from .connection_views import draw_side, side_geometry
from .sheet import _border, _footer, _mark_header, _title_block


def ridge_sheet(job, frame_id):
    if job.settings['frame_layouts'][frame_id].get('welded'):
        from .welded_sheet import ridge_sheet as welded_sheet

        return welded_sheet(job, frame_id)
    layout = job.settings['frame_layouts'][frame_id]
    peak = layout.get('peak_clip')
    if not peak:
        raise ValueError('No peak clip is defined for this frame')
    root = job.part('AP-' + frame_id)
    s = root.symbol
    theta = math.radians(s['pitch_deg'])
    co, sn = math.cos(theta), math.sin(theta)

    def point(distance, normal, sign=1):
        return (sign * (distance * co + normal * sn), s['h'] - distance * sn + normal * co)

    start = (layout['width_in'] / 2 - layout['rafters'][0]['top_end'][0]) / co
    edge = peak['actual_edge_in']
    end = max(start + 10, edge + 8)
    t = peak['thickness_in']
    normal_low = 0 if peak['mode'] == 'bypass' else -peak['web_center_in'] - peak['web_height_in'] / 2
    normal_high = peak['height_in'] if peak['mode'] == 'bypass' else -peak['web_center_in'] + peak['web_height_in'] / 2
    sec = job.assemblies[layout['rafters'][0]['mark']].main.sec
    sh = Sheet('RIDGE-' + frame_id, 'ridge', meta={'peak_clip': peak, 'frame_id': frame_id})
    c = Canvas(sh)
    _border(c)
    _mark_header(c, sh.name, 'APEX / PEAK CLIPS')
    _title_block(c, job, layout['frames'], sh.name, frame_id, job.date)
    c.ptext(612, 31, 'RIDGE FIT DETAIL', 12, 0, 'middle', bold=True)
    c.ptext(
        110,
        74,
        'Finished apex BOT: '
        + q(2 * s['bottom_length_in']).fmt()
        + ' total; '
        + q(s['bottom_length_in']).fmt()
        + ' each side of ridge C.L.',
        11,
    )
    c.ptext(
        110,
        94,
        'Peak clip '
        + peak['part']
        + ' near edge: '
        + q(peak['input_edge_in']).fmt()
        + ' from ridge ALONG SLOPE (editable).',
        11,
    )
    c.ptext(
        110,
        114,
        f'Actual near edge {edge:.6f} in; rounded toward eave by {peak["rounding_away_from_ridge_in"]:.6f} in. Station from rafter steel cut: '
        + peak['station_from_cut'],
        9,
    )
    pts = [pt for _, poly, _ in side_geometry(job, root, False, False)[0] for pt in poly]
    pts += [point(end, -sec.d), point(end, normal_high + 7), point(end, -sec.d, -1)]
    lo = min(y for x, y in pts)
    hi = max(y for x, y in pts)
    scale = min(22, 920 / (2 * max(abs(x) for x, y in pts)), 350 / (hi - lo))
    v = View(612, 520 + lo * scale, scale, scale)
    a = Canvas(sh, v)
    draw_side(a, job, root, False, False, clips=False)
    a.line(0, lo - 2, 0, hi, S_CL)
    for sign in (-1, 1):
        a.poly([point(start, 0, sign), point(end, 0, sign), point(end, -sec.d, sign), point(start, -sec.d, sign)])
        for depth in (sec.tf, sec.d - sec.tf):
            a.line(*point(start, -depth, sign), *point(end, -depth, sign))
        a.poly(
            [
                point(edge, normal_low, sign),
                point(edge + t, normal_low, sign),
                point(edge + t, normal_high, sign),
                point(edge, normal_high, sign),
            ],
            style=S_NOTE,
        )
        a.text(*point(edge + t / 2, normal_high + 1.5, sign), 'PEAK ' + peak['part'], 9, 0, 'middle')
        # True aligned dimension line parallel to roof, from ridge to near clip edge.
        z = normal_high + 5
        a.line(*point(0, z, sign), *point(edge, z, sign), S_DIM)
        for distance in (0, edge):
            a.line(*point(distance, 0, sign), *point(distance, z + 1, sign), S_DIM)
            a.line(*point(distance - 0.3, z - 0.3, sign), *point(distance + 0.3, z + 0.3, sign), S_DIM)
        a.text(*point(edge / 2, z + 1.0, sign), q(peak['input_edge_in']).fmt() + ' ALONG SLOPE', 9, 0, 'middle')
    y = s['bottom_y_in']
    B = s['bottom_length_in']
    c.dim_h(v.px(-B), v.px(0), v.py(y), v.py(y), 559, q(B).fmt() + ' HALF', size=10)
    c.dim_h(v.px(0), v.px(B), v.py(y), v.py(y), 559, q(B).fmt() + ' HALF', size=10)
    c.ptext(
        110,
        602,
        f'Nearest mating-plate clearance: {peak["clip_clearance_in"]:.3f} in; required 3 in EACH SIDE. Support: '
        + peak.get('support', 'rafter')
        + '.',
        10,
    )
    c.ptext(
        110,
        623,
        'Clip plate shown at actual thickness and '
        + ('height above roof' if peak['mode'] == 'bypass' else 'web position')
        + '. Width across frame follows selected clip; no purlin profile is modeled.',
        9,
    )
    c.ptext(
        110,
        644,
        'Nearest-edge dimension is NOT a hole-center or clip-center dimension. Regular purlin spacing stops before the peak clip.',
        9,
    )
    c.ptext(
        110,
        665,
        'Full purlin profile, bolts/washers, weld access and erection clearance still require review.',
        10,
        style=S_NOTE,
    )
    for i, text in enumerate(peak.get('warnings', [])[:3]):
        c.ptext(110, 686 + i * 13, 'WARNING: ' + text, 8, style=S_NOTE)
    _footer(c, job, job.revision(), 'same managed apex/clip geometry drives frame, member stations, BOM and exports')
    return sh
