"""Uniform-scale whole-frame elevation, derived from managed global setout."""

from ..connections import f, q
from .canvas import S_CL, S_HID, S_NOTE, S_TABLE, Canvas, Sheet, View
from .connection_views import bounds, draw_side, side_geometry
from .sheet import _border, _footer, _mark_header, _title_block


def post_footing(a, xc, fnd, label=True, ground_in=0.0):
    """Augered post footing below the ground at the post (``ground_in`` relative to the set level,
    v0.8.43 column grades): hole outline (diameter x depth), the embedded post is drawn by the
    caller; ``a`` draws in frame coordinates (inches, y up from the floor)."""
    dia = float(fnd.get('hole_diameter_in') or 0)
    depth = float(fnd.get('hole_depth_in') or 0)
    if dia <= 0 or depth <= 0:
        return
    g = float(ground_in or 0.0)
    a.rect(xc - dia / 2, g - depth, xc + dia / 2, g, S_HID)
    a.line(xc - dia / 2, g - depth, xc + dia / 2, g - depth, S_HID)
    if abs(g) > 1e-9:
        a.line(xc - dia / 2 - 4, g, xc + dia / 2 + 4, g, S_HID)
    if label:
        a.text(
            xc + dia / 2 + 3,
            g - depth / 2 + 2,
            fnd.get('hole_diameter', '') + ' DIA x ' + fnd.get('hole_depth', '') + ' DEEP',
            7,
            0,
            'start',
        )
        a.text(xc + dia / 2 + 3, g - depth / 2 - 7, 'POST FOOTING - POST EMBEDDED FULL DEPTH', 7, 0, 'start')


def _eave_line(layout, q):
    """The height datum sentence of the frame sheet (owner, round 15).

    Eave height is the floor to the TOP OF THE EAVE PURLIN (the roof line at the wall); the peak is
    the top of the peak purlin - the actual highest point of the roof line.  On the BYPASS fit the
    purlin bears on the rafter top flange, so the rafter top sits one purlin below the roof line and
    the eave purlin bears on the column seat; on the FLUSH fit the purlin top is flush with the
    rafter top, so the rafter top IS the roof line and the column runs to eave height.
    """
    pd = float(layout.get('strut_depth_in') or 0)
    peak = layout.get('peak_height_in')
    if pd > 0:
        fit = (
            'BYPASS fit: the purlin bears on the rafter top flange, so the rafter top is '
            + q(pd).fmt()
            + ' below the roof line and the eave purlin bears on the column seat (column = eave height less the purlin depth).'
        )
    else:
        fit = 'FLUSH fit: the purlin top is flush with the rafter top, so the rafter top IS the roof line and the column runs to eave height.'
    if peak:
        return (
            'EAVE HEIGHT = floor to the TOP OF THE EAVE PURLIN (the roof line at the wall); PEAK = '
            + q(peak).fmt()
            + ' TOP OF THE PEAK PURLIN (highest point of the roof line). '
            + fit
        )
    return 'Eave height = floor to TOP OF EAVE STRUT. ' + fit


def frame_sheet(job, frame_id, line=None):
    """Whole-frame elevation. With ``line`` (a frame_lines record) the sheet becomes the
    FRAME LINE n drawing: same geometry plus the dotted roof line (top of purlin) and the
    bypass/flush datum rule in the banner."""
    if job.settings['frame_layouts'][frame_id].get('welded'):
        from .welded_sheet import frame_sheet as welded_sheet

        return welded_sheet(job, frame_id, line=line)
    layout = job.settings['frame_layouts'][frame_id]
    p = job.settings['frames'][frame_id]
    mono = layout['frame_type'] == 'monoslope'
    W = layout['width_in']
    H = max(layout['low_eave_in'], layout['high_eave_in'], layout['ridge_top_in'] or 0)
    if line:
        H += line['roof_offset_in'] + 8
    sh = Sheet(
        ('FL%d-' % line['index'] if line else 'FRAME-') + frame_id,
        'frameline' if line else 'frame',
        meta={'frame_id': frame_id, 'frame_type': layout['frame_type'], 'setout': layout, 'frame_line': line},
    )
    c = Canvas(sh)
    _border(c)
    _mark_header(c, sh.name, 'MONO-SLOPE FRAME' if mono else 'GABLE FRAME')
    _title_block(c, job, layout['frames'], sh.name, frame_id, job.date)
    if line:
        from .frameline_sheets import banner

        banner(c, line, job=job, fid=frame_id)
    c.ptext(
        110,
        73,
        'Width: '
        + q(W).fmt()
        + (' outside WALL lines | pitch ' if layout.get('inset_in') else ' outside steel | pitch ')
        + layout['slope_rise']
        + ':12 | '
        + str(layout['frames'])
        + ' identical frame(s)',
        11,
    )
    c.ptext(
        110,
        94,
        _eave_line(layout, q),
        9,
    )
    c.ptext(
        110,
        114,
        (
            'High eave = low eave + FULL width x pitch / 12 = ' + q(layout['high_eave_in']).fmt()
            if mono
            else 'Both eaves equal. Apex BOT underside aligns with rafter underside at inner END planes.'
        ),
        10,
    )
    # Include projecting plate tails in the view envelope without distorting axes.
    for entry in layout['connections']:
        b = bounds(side_geometry(job, job.part(entry['mark']), False, False))
        H = max(H, entry['y'] + b[3])
    from .. import frame_lines as FL
    from .coordination_views import extents, girt_clip, leans

    lean_layout = FL.layout_for_station(job, frame_id, line['station_in'] if line else None)
    xmin, xmax, H = extents(lean_layout, W, H)
    fnd = layout.get('foundation') or {}
    below = fnd.get('embed_in', 0) + 6 if fnd.get('type') == 'post_footing' else 0  # holes below the floor
    scale = min(900 / (xmax - xmin), 330 / (H + 10 + below))
    v = View(160 + (900 - (xmax - xmin) * scale) / 2 - xmin * scale, 490 - below * scale, scale, scale)
    a = Canvas(sh, v)
    leans(a, lean_layout)
    # slab stops at the main building; the datum is flown out to the lean-to posts dotted
    a.line(0, 0, W, 0, S_CL)
    if xmin < -1e-6:
        a.line(xmin, 0, 0, 0, S_HID)
    if xmax > W + 1e-6:
        a.line(W, 0, xmax, 0, S_HID)
    if fnd.get('type') == 'slab':
        a.rect(0, -6, W, 0, S_HID)
        a.text(W / 2, -11, '6" SLAB (MAIN BUILDING ONLY) - FLOOR = TOP OF SLAB; NO SLAB UNDER LEAN-TO', 7, 0, 'middle')
    a.text(
        W / 2,
        -4 if not below else 3,
        'FLOOR DATUM' if fnd.get('type') != 'post_footing' else 'GROUND LINE AT FLOOR HEIGHT - NO SLAB',
        8,
        0,
        'middle',
    )
    # Exact design column envelopes; cut rounding residuals are recorded separately.
    for col in layout['columns']:
        asm = job.assemblies[col['mark']]
        sec = asm.main.sec
        x0, x1, y0, y1 = col['x0'], col['x1'], col['y0'], col['y1']
        a.rect(x0, y0, x1, y1)
        if sec.tf is not None:
            a.line(x0 + sec.tf, y0, x0 + sec.tf, y1)
            a.line(x1 - sec.tf, y0, x1 - sec.tf, y1)
        bp = job.parts.get(asm.derivation['resolved_base_plate'])
        L = f(bp.length) if bp else 0
        xc = (x0 + x1) / 2
        if bp:
            a.rect(xc - L / 2, layout['base_elevation_in'], xc + L / 2, y0)
        elif below:
            post_footing(a, xc, fnd, label=col['side'] == 'left')
        else:
            a.text(xc, y0 - 3, 'WELD TO FLOOR PLATE', 7, 0, 'middle')
        a.text(xc + (-20 if col['side'] == 'left' else 20), (y0 + y1) / 2, col['mark'], 9, 90, 'middle')
        for att in asm.attachments:
            if att.part == p['girt_clip'] and att.station is not None:
                girt_clip(a, job, p, col, att)
    for roof in layout['rafters']:
        asm = job.assemblies[roof['mark']]
        d = asm.main.sec.d
        tf = asm.main.sec.tf
        s, e = roof['top_start'], roof['top_end']
        n = roof['normal']
        u = roof['direction']
        down = lambda pt, depth: (pt[0] - n[0] * depth, pt[1] - n[1] * depth)
        a.poly([s, e, down(e, d), down(s, d)])
        for depth in (tf, d - tf):
            a.line(*down(s, depth), *down(e, depth))
        a.text((s[0] + e[0]) / 2 + n[0] * 10, (s[1] + e[1]) / 2 + n[1] * 10, roof['mark'], 10, 0, 'middle')
        for att in asm.attachments:
            if att.part == p['purlin_clip'] and att.station is not None:
                st = f(att.station)
                point = [s[0] + u[0] * st, s[1] + u[1] * st]
                if att.face == 'web':
                    y = f(att.y_from_top)
                    point = [point[0] - n[0] * y, point[1] - n[1] * y]
                cp = job.part(att.part)
                half = f(cp.thk) / 2
                height = f(cp.length) if att.face != 'web' else f(cp.width)
                offset = 0 if att.face != 'web' else -height / 2
                corners = [
                    (point[0] + u[0] * ds + n[0] * dz, point[1] + u[1] * ds + n[1] * dz)
                    for ds, dz in [(-half, offset), (half, offset), (half, offset + height), (-half, offset + height)]
                ]
                a.poly(corners, style=S_NOTE if att.note.startswith('peak ') else S_CL)
    if line:
        from .frameline_sheets import roof_line_overlay

        roof_line_overlay(a, c, v, job, frame_id, line)
    for entry in layout['connections']:
        ox, oy, mirror = entry['x'], entry['y'], entry['mirror']
        draw_side(
            a,
            job,
            job.part(entry['mark']),
            False,
            False,
            lambda x, y, ox=ox, oy=oy, mirror=mirror: (ox + mirror * x, oy + y),
        )
        a.text(ox, oy + job.part(entry['mark']).symbol['h'] + 18, entry['mark'], 8, 0, 'middle')
    for x, eave, side in [(0, layout['low_eave_in'], 'left'), (W, layout['high_eave_in'], 'right')]:
        a.line(x - 5, eave, x + 5, eave, S_HID)
        c.dim_v(
            v.py(0),
            v.py(eave),
            v.px(x),
            v.px(x),
            v.px(x) + (-48 if side == 'left' else 48),
            q(eave).fmt(),
            size=10,
            text_left=side == 'left',
        )
    c.dim_h(
        v.px(0),
        v.px(W),
        v.py(0),
        v.py(0),
        v.py(-below) + 39,
        q(W).fmt() + (' OUTSIDE WALLS' if layout.get('inset_in') else ' OUTSIDE STEEL'),
        size=11,
    )
    if not mono:
        c.ptext(
            612,
            143,
            'Ridge rigid-frame TOP elevation ' + q(layout['ridge_top_in']).fmt() + ' above floor',
            9,
            0,
            'middle',
        )
    c.ptext(
        110,
        552,
        'Uniform elevation scale. Connection details use actual plate geometry; roof clip plates shown edge-on; full secondary profiles not modeled.',
        9,
    )
    max_res = max(abs(x['rounding_residual_in']) for x in layout['columns'] + layout['rafters'])
    c.ptext(
        110,
        569,
        f'Design endpoints shown; shop cuts rounded to nearest 1/16. Maximum cut rounding residual: {max_res:.6f} in. See frame_layouts.json.',
        9,
    )
    allowances = layout['allowances']
    if any(allowances.values()):
        c.ptext(
            110,
            586,
            'REVIEW: nonzero setbacks/top gaps are explicit setout allowances; physical joint fit at those gaps is not resolved.',
            9,
            style=S_NOTE,
        )
    elif fnd.get('type') == 'post_footing':
        c.ptext(110, 586, fnd.get('column_datum', '').capitalize() + '; column lengths include the embedment.', 9)
    # Frame-scoped schedule: do not aggregate unrelated frames in the same job.
    xs = [110, 245, 355, 410, 465, 565, 755]
    top = 617
    row = 20
    headers = ['ASSEMBLY', 'ROLE', '/ FRAME', 'TOTAL', 'SECTION', 'SHOP CUT']
    rows = [
        [z['mark'], z['role'], str(z['per_frame']), str(z['total']), z['section'], z['cut']] for z in layout['schedule']
    ]
    for i, values in enumerate([headers] + rows):
        y = top + i * row
        c.pline(xs[0], y, xs[-1], y, S_TABLE)
        for k, value in enumerate(values):
            c.ptext(xs[k] + 4, y + 14, value, 8 if i else 7, bold=not i)
    bottom = top + (len(rows) + 1) * row
    c.pline(xs[0], bottom, xs[-1], bottom, S_TABLE)
    for x in xs:
        c.pline(x, top, x, bottom, S_TABLE)
    c.ptext(
        790,
        624,
        (fnd.get('label') or 'Slab').upper()
        + ' FOUNDATION'
        + (
            (' - ' + fnd['hole_diameter'] + ' DIA x ' + fnd['hole_depth'] + ' HOLES')
            if fnd.get('type') == 'post_footing'
            else ' - base plates at top of slab'
        ),
        8,
    )
    c.ptext(790, 642, 'Detail sheets / BOM / contours share this managed model.', 8)
    if layout.get('peak_clip'):
        c.ptext(790, 664, 'PEAK CLIPS SHOWN — see RIDGE-' + frame_id, 9, bold=True)
        c.ptext(790, 680, 'Near edge ' + q(layout['peak_clip']['input_edge_in']).fmt() + ' from ridge along slope.', 9)
    if layout.get('clip_warnings'):
        c.ptext(
            110,
            604,
            str(len(layout['clip_warnings']))
            + ' CLIP FIT WARNING(S): less than 3 in / joint conflict; inputs saved unchanged. See ridge detail and clip clearance schedule.',
            9,
            style=S_NOTE,
        )
    from ..layout_options import draw_starting

    draw_starting(c, a, layout)
    _footer(
        c,
        job,
        job.revision(),
        f'whole-frame elevation 1:{72 / scale:.1f}; floor and outside-steel datums',
    )
    return sh
