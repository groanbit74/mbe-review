"""Sheet-space primitives and the drawing canvas.

* Paper coordinates are PDF points (1/72"), origin top-left, y down – exactly what
  the renderers need.  A ``View`` maps model inches (x right, y up) onto paper with
  independent x/y scales (shop elevations of long members are foreshortened in x,
  as in the sample sheets).
* Text sizes, arrowheads, gaps and line weights are always in paper points so
  they do not change with view scale.
* Linear dimensions are kept twice: expanded into lines/text for PDF/SVG, and as
  a semantic ``DimRecord`` so the DXF renderer can emit real DIMENSION entities.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import pymupdf

# ------------------------------------------------------------------ style constants (from the sample sheets)
SHEET_W, SHEET_H = 1224.0, 792.0  # 17" x 11" landscape
BORDER = (74.4, 14.6, 1150.6, 778.0)  # x0, y0, x1, y1
LW = 0.72  # object / table line weight (pt)
LW_THIN = 0.3
LW_HEAVY = 1.2
TXT_DIM = 12.4  # dimension & callout text
TXT_BOM = 14.1  # table text
TXT_TITLE_VAL = 13.4
TXT_TITLE_LBL = 4.2
TXT_MARK = 16.1
TXT_KIND = 13.9
GRAY = (0.91, 0.91, 0.91)
BLACK = (0.0, 0.0, 0.0)
FONT = "helv"
FONT_BOLD = "hebo"


@dataclass(frozen=True)
class Style:
    layer: str = "OBJECT"
    width: float = LW
    color: tuple = BLACK
    dash: Optional[tuple] = None  # e.g. (4, 2)
    fill: Optional[tuple] = None
    tag: str = ""  # "dim" for exploded dimension geometry (DXF skips it)


S_OBJ = Style()
S_HID = Style(layer="HIDDEN", width=LW_THIN, dash=(4, 2))
S_CL = Style(layer="CENTER", width=LW_THIN, dash=(10, 3, 2, 3))
S_DIM = Style(layer="DIM", width=LW_THIN, tag="dim")
S_DIM_FILL = Style(layer="DIM", width=0, fill=BLACK, tag="dim")
S_LEADER = Style(layer="DIM", width=LW_THIN)
S_LEADER_FILL = Style(layer="DIM", width=0, fill=BLACK)
S_TABLE = Style(layer="TABLE")
S_BORDER = Style(layer="BORDER", width=LW)
S_PLATE = Style(layer="OBJECT", fill=GRAY)
S_WELD = Style(layer="WELD", width=0, fill=BLACK)
S_HOLE = Style(layer="HOLE", width=LW_THIN)
S_TEXT = Style(layer="TEXT")
S_NOTE = Style(layer="NOTE", width=LW_THIN, color=(0.55, 0.0, 0.0))


def _suppressed_note(text, style) -> bool:
    """NOTE-layer texts that are policy / disclaimer wording are not drawn.

    Sheet status is carried by the watermark and the single status line; the
    red note layer is reserved for concrete, actionable items.
    """
    if style is None or getattr(style, "layer", "") != "NOTE":
        return False
    from ..holds import is_disclaimer

    return is_disclaimer(str(text))


# ------------------------------------------------------------------ primitives
@dataclass
class Line:
    x1: float
    y1: float
    x2: float
    y2: float
    style: Style = S_OBJ


@dataclass
class Poly:
    pts: list  # [(x, y), ...] paper coords
    closed: bool = True
    style: Style = S_OBJ


@dataclass
class Circle:
    cx: float
    cy: float
    r: float
    style: Style = S_HOLE


@dataclass
class Text:
    x: float
    y: float
    text: str
    size: float = TXT_DIM
    rot: float = 0.0  # degrees counter-clockwise on paper
    anchor: str = "start"  # start | middle | end
    valign: str = "baseline"  # baseline | middle | top
    bold: bool = False
    style: Style = S_TEXT


@dataclass
class DimRecord:
    """Semantic linear dimension (paper coords) for DXF DIMENSION output."""

    p1: tuple
    p2: tuple
    line_pt: tuple
    text: str
    angle: float  # angle 0 = horizontal, 90 = vertical


def text_width(text: str, size: float, bold: bool = False) -> float:
    return pymupdf.get_text_length(text, fontname=FONT_BOLD if bold else FONT, fontsize=size)


# ------------------------------------------------------------------ view transform
@dataclass
class View:
    ox: float  # paper x of model origin
    oy: float  # paper y of model origin
    sx: float  # paper pt per model inch (x)
    sy: float  # paper pt per model inch (y)

    def p(self, x: float, y: float) -> tuple[float, float]:
        return (self.ox + self.sx * x, self.oy - self.sy * y)

    def px(self, x: float) -> float:
        return self.ox + self.sx * x

    def py(self, y: float) -> float:
        return self.oy - self.sy * y


IDENTITY = View(0.0, 0.0, 1.0, -1.0)  # paper-space pass-through (y already down)


# ------------------------------------------------------------------ sheet + canvas
@dataclass
class Sheet:
    name: str
    kind: str  # assembly | cut | plate
    items: list = field(default_factory=list)
    dims: list = field(default_factory=list)
    width: float = SHEET_W
    height: float = SHEET_H
    meta: dict = field(default_factory=dict)


class Canvas:
    """Draws model-space geometry through a View onto a Sheet."""

    def __init__(self, sheet: Sheet, view: View = IDENTITY):
        self.sheet = sheet
        self.v = view

    def _free_row(self, y_row: float, x0: float, x1: float, below: bool, step: float = 13.5) -> float:
        """Return a row y (starting at ``y_row``) where the label span [x0, x1] does not collide."""
        rows = self.sheet.meta.setdefault("_station_rows", {})
        y = y_row
        for _ in range(6):
            spans = rows.setdefault(round(y, 1), [])
            if all(x1 < a - 2 or x0 > b + 2 for a, b in spans):
                spans.append((x0, x1))
                return y
            y = y + step if below else y - step
        rows.setdefault(round(y, 1), []).append((x0, x1))
        return y

    # ---- raw paper-space -----------------------------------------------
    def add(self, item) -> None:
        self.sheet.items.append(item)

    def pline(self, x1, y1, x2, y2, style: Style = S_OBJ) -> None:
        self.add(Line(x1, y1, x2, y2, style))

    def ppoly(self, pts, closed=True, style: Style = S_OBJ) -> None:
        self.add(Poly(list(pts), closed, style))

    def prect(self, x0, y0, x1, y1, style: Style = S_OBJ) -> None:
        self.add(Poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], True, style))

    def ptext(
        self, x, y, text, size=TXT_DIM, rot=0.0, anchor="start", valign="baseline", bold=False, style=S_TEXT
    ) -> None:
        if _suppressed_note(text, style):
            return
        self.add(Text(x, y, text, size, rot, anchor, valign, bold, style))

    def pcircle(self, cx, cy, r, style: Style = S_HOLE) -> None:
        self.add(Circle(cx, cy, r, style))

    # ---- model-space --------------------------------------------------
    def line(self, x1, y1, x2, y2, style: Style = S_OBJ) -> None:
        a, b = self.v.p(x1, y1), self.v.p(x2, y2)
        self.add(Line(a[0], a[1], b[0], b[1], style))

    def poly(self, pts, closed=True, style: Style = S_OBJ) -> None:
        self.add(Poly([self.v.p(x, y) for x, y in pts], closed, style))

    def rect(self, x0, y0, x1, y1, style: Style = S_OBJ) -> None:
        self.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], True, style)

    def circle(self, cx, cy, r_model, style: Style = S_HOLE, min_r: float = 1.4) -> None:
        c = self.v.p(cx, cy)
        self.add(Circle(c[0], c[1], max(min_r, r_model * min(self.v.sx, self.v.sy)), style))

    def text(
        self,
        x,
        y,
        s,
        size=TXT_DIM,
        rot=0.0,
        anchor="start",
        valign="baseline",
        bold=False,
        dx=0.0,
        dy=0.0,
        style=S_TEXT,
    ) -> None:
        if _suppressed_note(s, style):
            return
        p = self.v.p(x, y)
        self.add(Text(p[0] + dx, p[1] + dy, s, size, rot, anchor, valign, bold, style))

    # ---- symbols ------------------------------------------------------
    def arrow(
        self, tip: tuple, direction: tuple, length: float = 6.0, half: float = 1.6, style: Style = S_DIM_FILL
    ) -> None:
        """Filled arrowhead with the tip at ``tip`` pointing along ``direction`` (paper vector)."""
        dx, dy = direction
        n = math.hypot(dx, dy) or 1.0
        ux, uy = dx / n, dy / n
        bx, by = tip[0] - ux * length, tip[1] - uy * length
        self.add(Poly([tip, (bx - uy * half, by + ux * half), (bx + uy * half, by - ux * half)], True, style))

    def weld_tick(self, x, y, w: float = 5.5, h: float = 4.0, vertical: bool = True, style: Style = S_WELD) -> None:
        """Solid black mark used by the samples for weld / hole positions on clips (model coords)."""
        cx, cy = self.v.p(x, y)
        if vertical:
            self.prect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, style)
        else:
            self.prect(cx - h / 2, cy - w / 2, cx + h / 2, cy + w / 2, style)

    # ---- dimensions (paper space) -------------------------------------
    def dim_h(
        self,
        x1: float,
        x2: float,
        y_feat1: float,
        y_feat2: float,
        y_line: float,
        text: str,
        size: float = TXT_DIM,
        text_above: bool = True,
        ext: bool = True,
    ) -> None:
        """Horizontal linear dimension between paper x1 and x2 with the dimension line at y_line."""
        if x2 < x1:
            x1, x2 = x2, x1
            y_feat1, y_feat2 = y_feat2, y_feat1
        if ext:
            for x, yf in ((x1, y_feat1), (x2, y_feat2)):
                gap = 1.5 if yf > y_line else -1.5
                over = -2.5 if yf > y_line else 2.5
                self.pline(x, yf - gap, x, y_line + over, S_DIM)
        w = text_width(text, size)
        inside = (x2 - x1) > w + 14
        self.pline(x1, y_line, x2, y_line, S_DIM)
        if inside:
            self.arrow((x1, y_line), (-1, 0))
            self.arrow((x2, y_line), (1, 0))
        else:
            self.arrow((x1, y_line), (1, 0))
            self.arrow((x2, y_line), (-1, 0))
            self.pline(x1 - 8, y_line, x1, y_line, S_DIM)
            self.pline(x2, y_line, x2 + 8, y_line, S_DIM)
        ty = y_line - 2.2 if text_above else y_line + size * 0.9
        self.ptext((x1 + x2) / 2, ty, text, size, 0, "middle", "baseline")
        self.sheet.dims.append(DimRecord((x1, y_feat1), (x2, y_feat2), ((x1 + x2) / 2, y_line), text, 0.0))

    def dim_v(
        self,
        y1: float,
        y2: float,
        x_feat1: float,
        x_feat2: float,
        x_line: float,
        text: str,
        size: float = TXT_DIM,
        text_left: bool = True,
        ext: bool = True,
    ) -> None:
        """Vertical linear dimension between paper y1 and y2 with the dimension line at x_line."""
        if y2 < y1:
            y1, y2 = y2, y1
            x_feat1, x_feat2 = x_feat2, x_feat1
        if ext:
            for y, xf in ((y1, x_feat1), (y2, x_feat2)):
                gap = 1.5 if xf < x_line else -1.5
                over = 2.5 if xf < x_line else -2.5
                self.pline(xf + gap, y, x_line + over, y, S_DIM)
        w = text_width(text, size)
        inside = (y2 - y1) > w + 14
        self.pline(x_line, y1, x_line, y2, S_DIM)
        if inside:
            self.arrow((x_line, y1), (0, -1))
            self.arrow((x_line, y2), (0, 1))
        else:
            self.arrow((x_line, y1), (0, 1))
            self.arrow((x_line, y2), (0, -1))
            self.pline(x_line, y1 - 8, x_line, y1, S_DIM)
            self.pline(x_line, y2, x_line, y2 + 8, S_DIM)
        tx = x_line - 2.2 if text_left else x_line + size * 0.9
        self.ptext(tx, (y1 + y2) / 2, text, size, 90, "middle", "baseline")
        self.sheet.dims.append(DimRecord((x_feat1, y1), (x_feat2, y2), (x_line, (y1 + y2) / 2), text, 90.0))

    def dim_station(
        self,
        x: float,
        y_feat: float,
        y_row: float,
        text: str,
        size: float = TXT_DIM,
        side: str = "left",
        below: bool = False,
    ) -> None:
        """Ordinate-style station dimension (measured from the tape datum at the left end).

        Extension line from the feature to the dimension row, text on a shelf; ``below`` mirrors it
        under the member.
        """
        w = text_width(text, size)
        span = (x - w - 3, x) if side == "left" else (x, x + w + 3)
        y_row = self._free_row(y_row, span[0], span[1], below)
        if not below:
            self.pline(x, y_feat - 1.5, x, y_row, S_DIM)
            ty = y_row - 2.0
            self.arrow((x, y_feat - 1.5), (0, 1), length=5, half=1.3)
        else:
            self.pline(x, y_feat + 1.5, x, y_row, S_DIM)
            ty = y_row + size * 0.95
            self.arrow((x, y_feat + 1.5), (0, -1), length=5, half=1.3)
        if side == "left":
            self.pline(x - w - 3, y_row, x, y_row, S_DIM)
            self.ptext(x - 1.5, ty, text, size, 0, "end")
        else:
            self.pline(x, y_row, x + w + 3, y_row, S_DIM)
            self.ptext(x + 1.5, ty, text, size, 0, "start")

    def leader(
        self,
        tip: tuple,
        pts: list,
        text: str,
        size: float = TXT_DIM,
        anchor: str = "start",
        dy: float = -2.0,
        bold=False,
    ) -> None:
        """Leader from ``tip`` through ``pts``; text placed at the last point."""
        prev = tip
        for p in pts:
            self.pline(prev[0], prev[1], p[0], p[1], S_LEADER)
            prev = p
        first = pts[0] if pts else tip
        self.arrow(tip, (tip[0] - first[0], tip[1] - first[1]), length=6, half=1.8, style=S_LEADER_FILL)
        end = pts[-1]
        self.ptext(
            end[0] + (2 if anchor == "start" else -2 if anchor == "end" else 0),
            end[1] + dy,
            text,
            size,
            0,
            anchor,
            "baseline",
            bold,
        )

    def note(self, x: float, y: float, text: str, size: float = TXT_DIM, bold: bool = False, anchor="start") -> None:
        self.ptext(x, y, text, size, 0, anchor, "baseline", bold)
