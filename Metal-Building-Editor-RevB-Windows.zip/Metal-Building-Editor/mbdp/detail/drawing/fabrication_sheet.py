"""Coordinate-controlled plate detail: no undocumented corners or angles."""

import math

from ..connections import f, q
from ..contours import dimensions, validate_contour
from .canvas import S_DIM, S_HID, S_PLATE, Canvas, Sheet, View
from .sheet import _border, _footer, _mark_header, _title_block


def fabrication_sheet(job, p, qty):
    pts = validate_contour(p)
    rows = dimensions(p)
    sh = Sheet(p.mark, 'plate')
    c = Canvas(sh)
    _border(c)
    _mark_header(c, p.mark, 'PLATE DETAIL')
    _title_block(c, job, qty, p.mark, p.mark, job.date)
    c.ptext(110, 72, f'{p.mark} | PL {p.thk.fmt()} | QTY {qty} | unit wt {p.weight(job.weights)} lb', 12, bold=True)
    c.ptext(110, 93, p.symbol.get('role', 'Plate profile')[:120], 10)
    c.ptext(110, 113, 'TIGHT FIT: zero intentional clearance. NO BEVEL: square through thickness.', 10)
    W = max(x for x, y in pts)
    H = max(y for x, y in pts)
    scale = min(29, 460 / W, 300 / H)
    ox = 145 + (460 - W * scale) / 2
    oy = 495
    v = View(ox, oy, scale, scale)
    a = Canvas(sh, v)
    a.poly(pts, style=S_PLATE)
    cx = sum(x for x, y in pts) / len(pts)
    cy = sum(y for x, y in pts) / len(pts)
    for i, (x, y) in enumerate(pts):
        vx, vy = x - cx, y - cy
        dist = max(math.hypot(vx, vy), 1e-6)
        a.text(x, y, f'P{i + 1}', 10, anchor='middle', dx=17 * vx / dist, dy=-17 * vy / dist, bold=True)
    for i, ((x1, y1), (x2, y2)) in enumerate(zip(pts, pts[1:] + pts[:1])):
        a.text((x1 + x2) / 2, (y1 + y2) / 2, f'E{i + 1}', 9, anchor='middle', dx=10, dy=-9)
    for h in p.holes:
        a.circle(f(h.x), f(h.y), f(h.dia) / 2)
    if p.symbol.get('base_hole_datum') == 'outside_flange_inward':
        outside = p.symbol['outside_flange_x_in']
        inside = outside - p.symbol['column_depth_in']
        bf = p.symbol['column_flange_width_in']
        tf = p.symbol['column_flange_thickness_in']
        tw = p.symbol['column_web_thickness_in']
        for x0, y0, x1, y1 in [
            (inside, (H - bf) / 2, inside + tf, (H + bf) / 2),
            (outside - tf, (H - bf) / 2, outside, (H + bf) / 2),
            (inside + tf, (H - tw) / 2, outside - tf, (H + tw) / 2),
        ]:
            a.rect(x0, y0, x1, y1, S_HID)
        hole = outside - p.symbol['base_first_row_in']
        c.dim_h(
            v.px(hole),
            v.px(outside),
            v.py(H),
            v.py(H),
            v.py(H) - 38,
            q(p.symbol['base_first_row_in']).fmt() + ' INWARD FROM OUTSIDE FLANGE',
            size=8,
        )
        c.ptext(
            130,
            625,
            'Dashed column overlay: outside flange at X=' + f'{outside:.6f} in; plate centered on column depth.',
            9,
        )
    c.dim_h(v.px(0), v.px(W), v.py(0), v.py(0), 533, f'{W:.6f} in FINISHED')
    c.dim_v(v.py(0), v.py(H), v.px(0), v.px(0), ox - 38, f'{H:.6f} in FINISHED')
    a.line(0, 0, min(W, 2), 0, S_DIM)
    a.line(0, 0, 0, min(H, 2), S_DIM)
    c.ptext(130, 574, 'DATUM (0,0): lower-left finished bounding box. X right; Y up.', 10)
    c.ptext(130, 590, 'Close profile P1 -> P2 -> ... -> P1. Decimal coordinates govern.', 10)
    c.ptext(130, 606, 'Plan angles are NOT bevel angles. G-code requires a machine postprocessor.', 9)
    # All vertex locations and interior angles.
    c.ptext(740, 149, 'VERTICES / CORNER ANGLES', 11, bold=True)
    xs = [740, 788, 900, 1012]
    for x, t in zip(xs, ['Point', 'X (in)', 'Y (in)', 'Interior deg']):
        c.ptext(x, 173, t, 10, bold=True)
    for i, r in enumerate(rows):
        y = 194 + i * 20
        for x, t in zip(xs, [r['vertex'], f"{r['x_in']:.6f}", f"{r['y_in']:.6f}", f"{r['interior_deg']:.4f}"]):
            c.ptext(x, y, t, 10)
    y0 = 194 + len(rows) * 20 + 26
    c.ptext(740, y0, 'EDGES / OFFSETS / DIRECTION', 11, bold=True)
    xs = [740, 781, 866, 954, 1042]
    for x, t in zip(xs, ['Edge', 'Length in', 'Delta X in', 'Delta Y in', 'Dir. deg']):
        c.ptext(x, y0 + 22, t, 9, bold=True)
    for i, r in enumerate(rows):
        for x, t in zip(
            xs,
            [
                f'E{i + 1}',
                f"{r['length_in']:.6f}",
                f"{r['dx_in']:.6f}",
                f"{r['dy_in']:.6f}",
                f"{r['direction_deg']:.4f}",
            ],
        ):
            c.ptext(x, y0 + 43 + i * 20, t, 9)
    c.ptext(740, y0 + 53 + len(rows) * 20, 'Direction: CCW from +X. E1 = P1 to P2, etc.', 9)
    if p.holes:
        c.ptext(740, 545, 'HOLES: center coordinates from SAME datum (in)', 10, bold=True)
        for i, h in enumerate(p.holes):
            # Pattern table split into two columns for up to 8 holes.
            c.ptext(
                740 + (i // 4) * 198, 564 + (i % 4) * 17, f'{i + 1}: {f(h.x):.4f}, {f(h.y):.4f}, D {f(h.dia):.4f}', 8.5
            )
    c.ptext(
        110,
        650,
        f'STOCK BLANK (rounded UP): {p.thk.fmt()} x {p.width.fmt()} x {p.length.fmt()} — NOT finished edge lengths',
        10,
    )
    c.ptext(
        110,
        671,
        'Cut coordinates: derived at 0.000001 in. No kerf or lead-in applied. Verify scale and process in CAM.',
        10,
    )
    weld = p.symbol.get('weld_size') or 'UNSPECIFIED - supply approved weld schedule'
    c.ptext(110, 694, 'Fillet weld leg: ' + weld, 9, bold=True)
    c.ptext(110, 714, 'DXF/SVG contours are 1:1; no G-code is issued from this sheet.', 9)
    if p.symbol.get('review_hold'):
        c.ptext(
            110,
            735,
            (
                'Hole layout: user hole centers (diameter and bolt specification per the connection).'
                if p.symbol.get('plate_family', '').startswith(('K-', 'R-')) or p.symbol.get('interface_placement')
                else 'Hole layout: per job plate rules (pattern, diameter and bolt specification).'
            ),
            9,
        )
    _footer(c, job, job.revision(), 'same contour drives drawing, 1:1 DXF, true-size SVG and coordinate report')
    return sh
