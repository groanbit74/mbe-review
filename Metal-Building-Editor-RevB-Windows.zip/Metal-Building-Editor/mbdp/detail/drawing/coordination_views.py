"""Physical wall datum and attached lean-to envelopes for whole-frame sheets."""

import math

from ..framing_additions import profile
from .canvas import S_CL, S_DIM_FILL, S_HID, Style

LEAN = Style(layer='LEAN_ENVELOPE', width=0.8)
S_DIM = Style(layer='DIM', width=0.3, tag='dim')


def extents(layout, W, H):
    leans = layout.get('framing_additions', {}).get('lean_tos', [])
    return (
        min([0] + [-z['projection_in'] for z in leans if z['face'] == 'left']),
        max([W] + [W + z['projection_in'] for z in leans if z['face'] == 'right']),
        max([H] + [z['high_eave_in'] + 12 for z in leans]),
    )


def _f(x):
    from ..connections import q

    try:
        return q(float(x)).fmt()
    except Exception:
        return str(x)


def slope_dimension_chain(a, points, offset_in, *, text_size=7.0, origin_label=None, end_label=None, label_prefix=''):
    """Draw readable purlin spacing on the upper side of a sloping member.

    Points are in model coordinates, ordered from the chosen datum outward/up the slope.
    The chain is offset normal to the member and its text stays above the roof sheet dimension.
    """
    points = [(float(x), float(y)) for x, y in points]
    if len(points) < 2:
        return
    scale = max(0.1, min(abs(a.v.sx), abs(a.v.sy)))
    label_gap = 5.0 / scale
    arrow_len = 4.5
    arrow_half = 1.3
    for p0, p1 in zip(points, points[1:]):
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        length = math.hypot(dx, dy)
        if length < 1e-6:
            continue
        ux, uy = dx / length, dy / length
        nx, ny = -uy, ux
        if ny < 0:
            nx, ny = -nx, -ny
        d0 = (p0[0] + nx * offset_in, p0[1] + ny * offset_in)
        d1 = (p1[0] + nx * offset_in, p1[1] + ny * offset_in)
        a.line(d0[0], d0[1], d1[0], d1[1], S_DIM)
        # Witness ticks at each actual purlin station keep the chain tied to geometry
        # without long extension lines crossing the roof-sheet dimension and its label.
        for x, y in (d0, d1):
            tx, ty = (ux + nx) * (2.2 / scale), (uy + ny) * (2.2 / scale)
            a.line(x - tx, y - ty, x + tx, y + ty, S_DIM)
        p0_paper, p1_paper = a.v.p(*d0), a.v.p(*d1)
        paper_tangent = (ux * a.v.sx, -uy * a.v.sy)
        a.arrow(p0_paper, (-paper_tangent[0], -paper_tangent[1]), arrow_len, arrow_half, S_DIM_FILL)
        a.arrow(p1_paper, paper_tangent, arrow_len, arrow_half, S_DIM_FILL)
        tx, ty = ux, uy
        angle = math.degrees(math.atan2(ty, tx))
        if angle > 90:
            angle -= 180
        elif angle < -90:
            angle += 180
        mx, my = (d0[0] + d1[0]) / 2 + nx * label_gap, (d0[1] + d1[1]) / 2 + ny * label_gap
        from ..connections import q

        a.text(mx, my, label_prefix + q(length).fmt(), text_size, angle, 'middle', style=S_DIM)
    if origin_label:
        p0, p1 = points[0], points[1]
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        length = math.hypot(dx, dy) or 1.0
        ux, uy = dx / length, dy / length
        nx, ny = -uy, ux
        if ny < 0:
            nx, ny = -nx, -ny
        angle = math.degrees(math.atan2(uy, ux))
        if angle > 90:
            angle -= 180
        elif angle < -90:
            angle += 180
        x = p0[0] + nx * (offset_in + label_gap * 2)
        y = p0[1] + ny * (offset_in + label_gap * 2)
        a.text(x, y, origin_label, text_size, angle, 'middle', style=S_DIM)
    if end_label:
        p0, p1 = points[-2], points[-1]
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        length = math.hypot(dx, dy) or 1.0
        ux, uy = dx / length, dy / length
        nx, ny = -uy, ux
        if ny < 0:
            nx, ny = -nx, -ny
        angle = math.degrees(math.atan2(uy, ux))
        if angle > 90:
            angle -= 180
        elif angle < -90:
            angle += 180
        x = points[-1][0] + nx * (offset_in + label_gap * 2)
        y = points[-1][1] + ny * (offset_in + label_gap * 2)
        a.text(x, y, end_label, text_size, angle, 'middle', style=S_DIM)


def leans(a, layout, frame_line=None):
    W = layout['width_in']
    for z in layout.get('framing_additions', {}).get('lean_tos', []):
        if z['face'] not in ('left', 'right'):
            continue  # end-attached members run OUT OF this section plane
        sign = -1 if z['face'] == 'left' else 1
        x = 0 if sign < 0 else W
        out = x + sign * z['projection_in']
        hi = z['high_eave_in']
        lo = z['low_eave_in']
        pd = z['purlin_depth_in']
        station = next(
            (s for s in z.get('stations') or [] if frame_line is not None and s.get('frame_line') == frame_line),
            None,
        )
        station_cut = next(
            (
                line
                for line in (z.get('rafter_cut_detail') or {}).get('lines') or []
                if station and line.get('station') == station.get('index')
            ),
            None,
        )
        rafter_id = (station or {}).get('rafter_profile') or z['rafter']
        rf = profile(rafter_id)
        co = profile(z['column'])
        rd = (rf or {}).get('depth', 0) * math.hypot(1, z['pitch'] / 12)
        cd = (co or {}).get('depth', 0)
        a.line(x, hi, out, lo, LEAN)
        cuts = dict(z.get('rafter_cut_detail') or {})
        if station_cut:
            cuts.update(station_cut)
        low = dict(z.get('low_connection_detail') or {})
        low_line = next(
            (line for line in low.get('lines') or [] if station and line.get('station') == station.get('index')),
            None,
        )
        if low_line:
            low.update(low_line)
        if cuts:
            xx = lambda u: x + sign * u
            a.poly(
                [
                    (xx(cuts['high_cut_x_in']), cuts['high_top_in']),
                    (xx(cuts['low_cut_x_in']), cuts['low_top_in']),
                    (xx(cuts['low_cut_x_in']), cuts['low_bottom_in']),
                    (xx(cuts['high_cut_x_in']), cuts['high_bottom_in']),
                ],
                style=LEAN,
            )
            y0 = low.get('column_bottom_in', low['base_elevation_in'] + low['base_thickness_in'])
            yl = low['column_low_floor_in']
            inside = out - sign * cd
            a.poly([(out, y0), (inside, y0), (inside, yl + cd * z['pitch'] / 12), (out, yl)], style=LEAN)
            lf = low.get('foundation') or {}
            if lf.get('type') == 'post_footing' and float(lf.get('hole_diameter_in') or 0) > 0:
                # the lean's own post holes (v0.8.43): ground at the post = bottom + hole depth
                dia = float(lf['hole_diameter_in'])
                xc = out - sign * cd / 2
                a.rect(xc - dia / 2, y0, xc + dia / 2, y0 + float(lf.get('hole_depth_in') or 0), S_HID)
            knee = low.get('knee_geometry')
            if low_line and low.get('knee_geometry_by_seat'):
                seat = low_line.get('rafter_seat_mode') or low.get('rafter_seat_resolved')
                knee = low['knee_geometry_by_seat'].get(str(seat) + ':' + str(rafter_id), knee)
            if knee:
                a.poly([(out - sign * u, yl + v) for u, v in knee['side_contour_in']], style=LEAN)
            clips = z.get('flush_clips') or []
            if clips:
                clip = next(
                    (q for q in clips if station and q.get('main_mark') == station.get('main_mark')),
                    clips[0],
                )
                a.poly(
                    [(xx(cuts['high_face_x_in'] + u), v) for u, v in clip['installed_contour_in']],
                    style=LEAN,
                )
        else:
            a.poly([(x, hi - pd), (out, lo - pd), (out, lo - pd - rd), (x, hi - pd - rd)], style=LEAN)
            a.rect(min(out, out - sign * cd), 0, max(out, out - sign * cd), lo - pd - rd, LEAN)
        _rows = z.get('roof_purlin_layout', {}).get('rows', [])
        _max_out = max([float(rw['horizontal_out_in']) for rw in _rows], default=0.0)
        for row in _rows:
            rx = x + sign * row['horizontal_out_in']
            ry = row['roof_top_in']
            from ..secondary_catalog import get

            pr = get(row['profile_id'])
            fw = max(pr.get('flanges_in') or [3.0])  # eave struts list no flange width in the catalog pages
            a.line(rx, ry, rx, ry - pr['nominal_depth_in'], LEAN)
            # the LOW lean eave purlin: outside face flush with the outside edge of
            # the lean post (flange inboard); other rows flange outboard (owner 0.8.54)
            _inboard = float(row['horizontal_out_in']) >= _max_out - 1e-6 and _max_out > 0
            a.line(rx, ry, rx - sign * fw, ry, LEAN) if _inboard else a.line(rx, ry, rx + sign * fw, ry, LEAN)
        # Lean purlin spacing starts at the main-building eave and runs out to the low eave,
        # above the roof-sheet dimension line. The rows match the cut list and rafter sheet.
        if len(_rows) > 1 and (
            frame_line is None
            or any(int(st.get('frame_line') or -1) == int(frame_line) for st in z.get('stations') or [])
        ):
            points = [
                (x + sign * float(row.get('horizontal_out_in') or 0), float(row.get('roof_top_in') or 0))
                for row in sorted(_rows, key=lambda row: float(row.get('horizontal_out_in') or 0))
            ]
            scale = max(0.1, min(abs(a.v.sx), abs(a.v.sy)))
            slope_dimension_chain(
                a,
                points,
                14.0 + 32.0 / scale,
                origin_label='MAIN EAVE',
                end_label='LOW EAVE',
            )
        # lean girts at the lean post, at the lean's own girt lines (bottom girt
        # first): a small section box on the post's outside face per line
        framing = z.get('wall_framing') or {}
        if (z.get('walls') or {}).get('outer') == 'sheeted' and framing.get('girt_lines_in'):
            gd = float(framing.get('girt_depth_in') or 8)
            for gy in framing['girt_lines_in']:
                a.rect(min(out, out + sign * gd), gy - 1.25, max(out, out + sign * gd), gy + 1.25, LEAN)
            pass  # girt elevations are dimensioned on the lean walls sheet (owner 0.8.55)
        a.text((x + out) / 2, hi + 16, z['id'], 8, anchor='middle')
        a.line(out, 0, out, lo, S_HID)
        if any(z['walls'][k] == 'sheeted' for k in ('start_end', 'finish_end')):
            a.line(x, hi, out, lo, Style(layer='SHEET_SUPPORT', width=1.5, color=(0.25, 0.5, 0.3)))


def girt_clip(a, job, p, col, att):
    from ..connections import f

    y = col['y0'] + f(att.station)
    x = col['x0'] if col['side'] == 'left' else col['x1']
    out = -1 if col['side'] == 'left' else 1
    cp = job.part(att.part)
    if cp.kind == 'mark':
        # flush girt welded directly to the web: draw the girt end (girt depth) at the web line
        center = x - out * f(att.y_from_top)
        half = f(p['girt_depth']) / 2
        a.line(center - half, y, center + half, y, Style(layer='WEB_GIRT_WELD', color=(0.1, 0.3, 0.65), width=1))
        return
    if p['girt_mode'] == 'flush':
        center = x - out * f(att.y_from_top)
        half = f(cp.width) / 2
        # Looking edge-on at the web plates; both longitudinal hands project here.
        a.line(center - half, y, center + half, y, Style(layer='WEB_GIRT_CLIP', color=(0.1, 0.3, 0.65), width=1))
    else:
        a.line(x, y, x + out * f(cp.length), y, S_CL)
