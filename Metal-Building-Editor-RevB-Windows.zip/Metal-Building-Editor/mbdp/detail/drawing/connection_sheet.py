"""Shared installed geometry, beam alignment and actual hole placement."""

from ..connections import connection_bom, f, q
from .canvas import S_NOTE, Canvas, Sheet, View
from .connection_views import bounds, draw_aligned_face, draw_side, side_geometry
from .sheet import _bom_table, _border, _footer, _mark_header, _title_block


def connection_sheet(job, p, qty):
    if p.symbol.get('welded'):
        from .welded_sheet import connection_sheet as welded_sheet

        return welded_sheet(job, p, qty)
    cfg = p.symbol['config']
    s = p.symbol
    apex = cfg['kind'] == 'apex'
    sh = Sheet(p.mark, 'connection')
    c = Canvas(sh)
    _border(c)
    _mark_header(c, p.mark, cfg['kind'].upper() + ' CONNECTION')
    _title_block(c, job, qty, p.mark, p.mark, job.date)
    _bom_table(c, connection_bom(job, p.mark))
    c.ptext(110, 72, 'Reference: ' + s['reference'] + ' | single-web construction', 10)
    c.ptext(
        110,
        91,
        'Column '
        + cfg['column']
        + ' / '
        + job.assemblies[cfg['column']].main.section
        + '; rafter '
        + cfg['rafter']
        + ' / '
        + job.assemblies[cfg['rafter']].main.section
        + '; slope '
        + cfg['rise']
        + ':12',
        10,
    )
    c.ptext(
        110,
        110,
        'Bottom '
        + ('half ' if apex else '')
        + 'length = '
        + f"{s['bottom_length_in']:.6f} in finished"
        + ' | '
        + (
            'derived at rafter-bottom / inner END planes'
            if apex
            else 'column depth + mating plate thickness'
            if cfg['bottom_mode'] == 'column_depth'
            else 'MANUAL OVERRIDE'
        ),
        10,
    )
    c.ptext(
        110, 143, 'ALIGNED SIDE VIEW' + (' — BOTH RAFTERS' if apex else ' — BRACKET SPANS COLUMN TOP'), 11, bold=True
    )
    c.ptext(
        110,
        162,
        (
            'APEX BOT UNDERSIDE = RAFTER UNDERSIDE at inner END planes; plate tails below.'
            if apex
            else 'END inset: outer lower corner flush with bottom end; BACK sits on bottom TOP.'
        ),
        9,
    )
    c.ptext(110, 178, 'Hole-row centerlines project through both plates (two transverse holes per row).', 9)
    geom = side_geometry(job, p, True, not apex)
    xmin, ymin, xmax, ymax = bounds(geom)
    scale = min(13, 520 / (xmax - xmin), 280 / (ymax - ymin))
    v = View(110 - xmin * scale, 490 + ymin * scale, scale, scale)
    draw_side(Canvas(sh, v), job, p, True, not apex)
    B = s['bottom_length_in']
    c.dim_h(
        v.px(-B if apex else 0),
        v.px(B),
        v.py(s.get('bottom_y_in', 0)),
        v.py(s.get('bottom_y_in', 0)),
        517,
        f'{2 * B if apex else B:.6f} in FINISHED bottom',
    )
    c.ptext(
        110,
        549,
        'Bracket and rafter share TOP LINE; centered plate offset '
        + q(s['interface_placement']['plate_to_rafter_top_in']).fmt()
        + ' each end (review assumption).',
        8,
        style=S_NOTE,
    )
    c.ptext(
        110,
        565,
        (
            'Apex bottom raised '
            + q(s.get('bottom_y_in', 0)).fmt()
            + '; square-corner fit mismatch '
            + f"{s.get('apex_corner_mismatch_in', 0):.6f} in (review)."
            if apex
            else 'Column-side height '
            + q(s['h']).fmt()
            + '; END seat and BACK bottom at '
            + cfg['flange_thk']
            + ' above underside.'
        ),
        8,
    )
    c.ptext(
        110,
        581,
        ('Half-apex origin' if apex else 'INNER column face')
        + ' to steel cut along slope: '
        + q(s['top_run_to_rafter_cut_in'] if apex else s['inner_column_to_rafter_cut_in']).fmt()
        + '.',
        8,
    )
    c.ptext(
        110,
        597,
        (
            'START CLIP outside edge aligned to OUTSIDE bracket roof edge; additional to regular rafter clips.'
            if any(x['role'] == 'starting' for x in s.get('roof_clips', []))
            else 'Square cuts / no bevel: verify corner contact, hardware access and weld fit before release.'
        ),
        8,
        style=S_NOTE,
    )
    # Physical end-on view; dimension chain comes from the SAME hole coordinates.
    ep = job.part(p.mark + '-END')
    W, L = f(ep.width), f(ep.length)
    scale = min(14, 205 / L, 130 / W)
    v = View(900 - W * scale / 2, 440, scale, scale)
    draw_aligned_face(Canvas(sh, v), job, p)
    c.ptext(735, 143, 'END / MATE + BEAM ALIGNMENT', 11, bold=True)
    c.ptext(735, 163, 'Normal-to-plate view; dashed I-section behind plate.', 9)
    c.ptext(735, 181, 'Same hole pattern on BOTH sides' + (' / both apex interfaces.' if apex else '.'), 9)
    ys = [0] + sorted({f(h.x) for h in ep.holes}) + [L]
    for a, b in zip(ys, ys[1:]):
        c.dim_v(v.py(a), v.py(b), v.px(W), v.px(W), v.px(W) + 28, q(b - a).fmt(), size=9)
    xs = [0] + sorted({f(h.y) for h in ep.holes}) + [W]
    for a, b in zip(xs, xs[1:]):
        c.dim_h(v.px(a), v.px(b), v.py(L), v.py(L), v.py(L) - 19, q(b - a).fmt(), size=9)
    c.ptext(755, 466, str(len(ep.holes)) + ' HOLES D=' + ep.hole_dia().fmt() + '; hole centers per job standards.', 9)
    c.ptext(755, 484, 'Beam: ' + job.assemblies[cfg['rafter']].main.section + ' | END = MATE', 9)
    c.ptext(755, 506, 'Dashed flange/web overlay exposes potential bolt-access conflicts.', 8, style=S_NOTE)
    c.ptext(755, 524, 'Envelope reference: ' + cfg['end_plate'], 8)
    c.ptext(755, 542, 'Loose mates: ' + str(s['interfaces']) + ' per connection; excluded from weldment BOM.', 8)
    c.ptext(700, 579, 'Fillet leg: ' + cfg['weld_size'] + ' (user default/override)', 9)
    c.ptext(700, 597, 'HOLD: diameter, bolt/weld capacity, material and joint fit.', 9, style=S_NOTE)
    warnings = []
    for layout in job.settings.get('frame_layouts', {}).values():
        for record in layout.get('clip_clearances', []):
            if any(check['plate'] == s['mate'] and check['warning'] for check in record['checks']):
                warnings.extend(record['warnings'])
    for i, text in enumerate(list(dict.fromkeys(warnings))[:2]):
        c.ptext(110, 616 + i * 12, 'WARNING: ' + text, 7.5, style=S_NOTE)
    _footer(c, job, job.revision(), 'uniform side/face scales; user hole centers; matching 1:1 DXF/SVG contours')
    return sh
