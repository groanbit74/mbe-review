"""Source-bound connection schedules; original details are in the source atlas."""

import textwrap
from collections import defaultdict

from ..cladding import fmt
from .canvas import S_TABLE, Canvas, Sheet
from .sheet import _border, _footer, _title_block


def template_sheet(job, fid, kind, index, page=1):
    m = job.assemblies[fid].derivation['framing_additions']
    sh = Sheet(fid + '-' + kind + '-' + str(index) + '-' + str(page), 'additions')
    c = Canvas(sh)
    _border(c)
    _title_block(c, job, 1, sh.name, fid, job.date)
    _footer(c, job, job.revision(), 'Source1277345; original marks unchanged; see source atlas / release checks')
    c.ptext(612, 32, 'SOURCE TEMPLATE', 11, anchor='middle', bold=True)

    def txt(text, y, size=9):
        for line in textwrap.wrap(text, 145):
            c.ptext(110, y, line, size)
            y += 14
        return y

    def table(headers, rows, y):
        xs = [110, 485, 615, 1110]
        rh = 27
        for i, row in enumerate([headers] + rows):
            yy = y + i * rh
            c.prect(110, yy, 1110, yy + rh, S_TABLE)
            for x, text in zip(xs, row):
                for k, line in enumerate(textwrap.wrap(str(text), 70 if x == 615 else 48 if x == 110 else 16)[:2]):
                    c.ptext(x + 4, yy + 11 + k * 11, line, 8, bold=i == 0)

    if kind.startswith('opening'):
        o = m['openings'][index]
        d = o['connection_detail']
        c.ptext(110, 76, o['id'] + ' / ' + d['template'], 14, bold=True)
        if kind == 'opening_girts':
            c.ptext(110, 103, 'GIRT INTERRUPTION CUTS / ' + o['elevation'], 11)
            table(
                ['MARK / OUTSIDE-VIEW X LIMITS', 'CUT LENGTH', 'ELEVATION / BASIS'],
                [
                    [
                        r['mark'] + ' / ' + fmt(r['x0_in']) + ' to ' + fmt(r['x1_in']),
                        fmt(r['cut_length_in']) if r['cut_length_in'] is not None else 'HOLD',
                        fmt(r['y_in']) + ' / ' + r['status'],
                    ]
                    for r in d['girt_segments'][(page - 1) * 16 : page * 16]
                ],
                145,
            )
            txt(
                'Only secondary girts are interrupted. Existing main uprights never move or get cut. Old full-length pieces are replaced in cut summaries/order, not counted again. SD87 end gap is explicit input, not inferred from bolt diameter.',
                640,
            )
        else:
            y = txt(
                'Source: PDF23/D3 SD85C base and SD87 girt; PDF24/D4 SD95 header. Selectable8in Cee DOOR template only; no conversion of W/HSS members.',
                110,
            )
            y = txt(
                'BASE: jamb bottom1/4in above floor; two5/8in anchors per jamb,3in anchor spacing;1-3/4in reference and2-1/2in offset for8in jamb as shown on SD85C. Anchor length/embedment/grade are not specified by those dimensions.',
                y + 8,
            )
            y = txt(
                'HEADER:1/4in gap at EACH jamb; square-cut header = aperture width minus1/2in. Jamb top restraint must be coordinated separately. Vendor clips are NOT invented laser-cut parts.',
                y + 8,
            )
            y = txt(d['bolt_note'], y + 8)
            if not d['applicable']:
                txt('NOT APPLICABLE: ' + ' / '.join(d['issues']), y + 15)
            else:
                counts = defaultdict(int)
                for r in d['components']:
                    counts[r['part']] += r['quantity']
                table(
                    ['COMPONENT', 'QUANTITY', 'SOURCE / SCOPE'],
                    [
                        [k, v, 'Source-specific part; supplier fit, grip, nuts/washers and anchors reviewed separately']
                        for k, v in counts.items()
                    ],
                    290,
                )
                txt(' / '.join(dict.fromkeys(d['issues'])), 620)
    else:
        z = m['lean_tos'][index]
        d = z['transition_detail']
        c.ptext(110, 76, z['id'] + ' / ' + d['template'], 14, bold=True)
        txt(
            'Source PDF'
            + str(d['page'])
            + ' / '
            + d['position']
            + '. D10 upper-right T4 (free high eave) is NOT lower-left T4 (bolted wall penetration). No dimension is taken by scaling an NTS drawing.',
            108,
        )
        table(
            ['COMPONENT / RUN', 'QUANTITY', 'BASIS'],
            [[r['part'], f"{r['quantity']:g} {r['unit']}", r['basis']] for r in d['components']],
            175,
        )
        y = 450
        if d['closure_envelopes']:
            r = d['closure_envelopes'][0]
            y = txt(
                'TD250: rafter depth +1/2 = '
                + fmt(r['rafter_depth_plus_half_in'])
                + '; half W flange +1/4 = '
                + (
                    fmt(r['half_flange_plus_quarter_in'])
                    if r['half_flange_plus_quarter_in'] is not None
                    else 'NOT DEFINED FOR THIS SECTION'
                )
                + '. Source3in lap,3in minimum tabs,1in returns,1-1/2in leg and12in MAX callout retained. These are formed/detail references, NOT a developed flat blank.',
                y,
            )
        txt(' / '.join(d['issues']), max(y + 12, 535))
    return sh
