"""PDF renderer (PyMuPDF).  One page per Sheet, 17x11 landscape, Helvetica (Arial metric-compatible)."""

from __future__ import annotations

import math

import pymupdf

from .canvas import FONT, FONT_BOLD, Circle, Line, Poly, Sheet, Text, text_width


def _draw_items(page: pymupdf.Page, sh: Sheet) -> None:
    # watermarks go under the geometry (text is otherwise painted last and would hide thin lines)
    for it in sh.items:
        if isinstance(it, Text) and it.style.layer == 'WATERMARK':
            _text(page, it)
    shape = page.new_shape()
    for it in sh.items:
        if isinstance(it, Line):
            shape.draw_line((it.x1, it.y1), (it.x2, it.y2))
            shape.finish(color=it.style.color, width=it.style.width, dashes=_dash(it.style.dash))
        elif isinstance(it, Poly):
            pts = [pymupdf.Point(x, y) for x, y in it.pts]
            if len(pts) < 2:
                continue
            shape.draw_polyline(pts + ([pts[0]] if it.closed else []))
            if it.style.fill is not None:
                shape.finish(
                    color=it.style.color if it.style.width > 0 else None,
                    width=max(it.style.width, 0.01),
                    fill=it.style.fill,
                    closePath=it.closed,
                    dashes=_dash(it.style.dash),
                )
            else:
                shape.finish(
                    color=it.style.color, width=it.style.width, closePath=it.closed, dashes=_dash(it.style.dash)
                )
        elif isinstance(it, Circle):
            shape.draw_circle((it.cx, it.cy), it.r)
            shape.finish(color=it.style.color, width=it.style.width, fill=it.style.fill)
    shape.commit()
    for it in sh.items:
        if isinstance(it, Text) and it.style.layer != 'WATERMARK':
            _text(page, it)


def _dash(d):
    if not d:
        return None
    return "[" + " ".join(f"{x:g}" for x in d) + "] 0"


def _text(page: pymupdf.Page, t: Text) -> None:
    font = FONT_BOLD if t.bold else FONT
    w = text_width(t.text, t.size, t.bold)
    # anchor offsets along the text direction; valign offsets perpendicular
    dx = -w / 2 if t.anchor == "middle" else -w if t.anchor == "end" else 0.0
    dy = 0.0
    if t.valign == "middle":
        dy = t.size * 0.35
    elif t.valign == "top":
        dy = t.size * 0.9
    ang = math.radians(t.rot)
    # move along the rotated baseline
    x = t.x + dx * math.cos(ang) + dy * math.sin(ang)
    y = t.y - dx * math.sin(ang) + dy * math.cos(ang)
    color = t.style.color
    if t.rot % 360 == 0:
        page.insert_text((x, y), t.text, fontsize=t.size, fontname=font, color=color)
    else:
        morph = (pymupdf.Point(x, y), pymupdf.Matrix(1, 0, 0, 1, 0, 0).prerotate(t.rot))
        page.insert_text((x, y), t.text, fontsize=t.size, fontname=font, color=color, morph=morph)


def render_pdf(sheets: list[Sheet], path: str, title: str = "") -> str:
    doc = pymupdf.open()
    for sh in sheets:
        page = doc.new_page(width=sh.width, height=sh.height)
        _draw_items(page, sh)
    doc.set_metadata(
        {"title": title or (sheets[0].name if sheets else ""), "producer": "mbdp detailing engine", "creator": "mbdp"}
    )
    doc.save(path, deflate=True)
    doc.close()
    return path


def render_png(sheets: list[Sheet], path: str, dpi: int = 90, index: int = 0) -> str:
    doc = pymupdf.open()
    sh = sheets[index]
    page = doc.new_page(width=sh.width, height=sh.height)
    _draw_items(page, sh)
    page.get_pixmap(dpi=dpi).save(path)
    doc.close()
    return path
