"""Rolled-shape geometry catalog.

Nominal AISC dimensions (inches) and unit weights (lb/ft).  These are *reference
data*: they drive section views, clip fit and BOM weights.  A shop should verify
the table against its mill certs / detailing standard and may extend it through
``register_section``.  Unknown shapes raise ``KeyError`` – the generator never
guesses a depth.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

CATALOG_VERSION = "aisc-v15-nominal"


@dataclass(frozen=True)
class WSection:
    name: str
    d: float  # depth (in)
    bf: float  # flange width (in)
    tf: float  # flange thickness (in)
    tw: float  # web thickness (in)
    plf: Decimal  # nominal weight (lb/ft)

    @property
    def kind(self) -> str:
        return "W"


GAUGE_THICKNESS_IN = {10: 0.1345, 12: 0.1046, 14: 0.0747, 16: 0.0598}


@dataclass(frozen=True)
class ChannelSection:
    name: str
    d: float
    bf: float
    plf: Decimal
    gauge: int
    tf: float | None = None
    tw: float | None = None
    kind: str = 'Channel'
    finish: str = 'Red Oxide'
    doubled: bool = False  # two channels welded back to back (I shape): carport interior rafters
    single: str = ''  # the single channel a doubled section is made of

    @property
    def open_face(self):
        """Purlins sit inside the open face (1/4 in from the web, welded to the flanges)."""
        return True


DOUBLED_SUFFIX = 'x2'


def single_channel_names():
    from .channel_catalog import WEIGHTS

    return [f'MBCI-Channel-{size}p125x2-G{gauge}' for size, rows in WEIGHTS.items() for gauge in rows] + [
        'SSS-SS4214',
        'SSS-SS6214',
        'SSS-SS8214',
        'SSS-SS10214',
    ]


def channel_names():
    """Single open-face channels and their doubled (back-to-back welded I) versions, ``<id>x2``."""
    singles = single_channel_names()
    return singles + [n + DOUBLED_SUFFIX for n in singles]


def channel_section(name):
    from .channel_catalog import get

    wanted = str(name).strip().upper()
    if wanted.endswith(DOUBLED_SUFFIX.upper()):
        base = channel_section(str(name).strip()[: -len(DOUBLED_SUFFIX)])
        return ChannelSection(
            base.name + DOUBLED_SUFFIX,
            base.d,
            2 * base.bf,
            None if base.plf is None else 2 * base.plf,
            base.gauge,
            tf=base.tf,
            tw=None if base.tw is None else 2 * base.tw,
            doubled=True,
            single=base.name,
        )
    canonical = next((n for n in single_channel_names() if n.upper() == wanted), None)
    if canonical is None:
        raise KeyError('Unknown MBCI channel section: ' + str(name))
    if canonical.startswith('SSS-'):
        from .secondary_catalog import get as supplier_profile

        p = supplier_profile(canonical)
    else:
        p = get(canonical)
    # Nominal sheet thickness by gauge (Manufacturers' Standard Gauge, uncoated steel): the
    # half-web deduction of a flush purlin against the channel web is a shop cut datum, not a
    # supplier spec (v0.8.30; the earlier "no gauge conversion" hold blocked every flush channel end).
    t = GAUGE_THICKNESS_IN.get(int(p['gauge']))
    return ChannelSection(
        canonical,
        p['nominal_depth_in'],
        2.0,
        Decimal(str(p['weight_lb_ft'])) if p['weight_lb_ft'] is not None else None,
        p['gauge'],
        tf=t,
        tw=t,
    )


_W = {
    #  name       d      bf     tf     tw     plf
    "W6X9": (5.90, 3.94, 0.215, 0.170, "9"),
    "W6X12": (6.03, 4.00, 0.280, 0.230, "12"),
    "W6X15": (5.99, 5.99, 0.260, 0.230, "15"),
    "W8X10": (7.89, 3.94, 0.205, 0.170, "10"),
    "W8X13": (7.99, 4.00, 0.255, 0.230, "13"),
    "W8X15": (8.11, 4.02, 0.315, 0.245, "15"),
    "W8X18": (8.14, 5.25, 0.330, 0.230, "18"),
    "W8X21": (8.28, 5.27, 0.400, 0.250, "21"),
    "W8X24": (7.93, 6.50, 0.400, 0.245, "24"),
    "W10X12": (9.87, 3.96, 0.210, 0.190, "12"),
    "W10X15": (9.99, 4.00, 0.270, 0.230, "15"),
    "W10X17": (10.1, 4.01, 0.330, 0.240, "17"),
    "W10X19": (10.2, 4.02, 0.395, 0.250, "19"),
    "W10X22": (10.2, 5.75, 0.360, 0.240, "22"),
    "W10X26": (10.3, 5.77, 0.440, 0.260, "26"),
    "W12X14": (11.9, 3.97, 0.225, 0.200, "14"),
    "W12X16": (12.0, 3.99, 0.265, 0.220, "16"),
    "W12X19": (12.2, 4.01, 0.350, 0.235, "19"),
    "W12X22": (12.3, 4.03, 0.425, 0.260, "22"),
    "W12X26": (12.2, 6.49, 0.380, 0.230, "26"),
    "W12X30": (12.3, 6.52, 0.440, 0.260, "30"),
    "W14X22": (13.7, 5.00, 0.335, 0.230, "22"),
    "W14X26": (13.9, 5.03, 0.420, 0.255, "26"),
    "W14X30": (13.8, 6.73, 0.385, 0.270, "30"),
    "W16X26": (15.7, 5.50, 0.345, 0.250, "26"),
    "W16X31": (15.9, 5.53, 0.440, 0.275, "31"),
    "W18X35": (17.7, 6.00, 0.425, 0.300, "35"),
    "W18X40": (17.9, 6.02, 0.525, 0.315, "40"),
    "W21X44": (20.7, 6.50, 0.450, 0.350, "44"),
}

SECTIONS: dict[str, WSection] = {n: WSection(n, d, bf, tf, tw, Decimal(plf)) for n, (d, bf, tf, tw, plf) in _W.items()}


def normalize(name: str) -> str:
    if name.strip().upper().startswith("HSS "):
        from .tube_sections import get

        return get(name).name
    if name.strip().upper().startswith(("MBCI-CHANNEL-", "SSS-SS")):
        return channel_section(name).name
    return name.strip().upper().replace(" ", "")


def get_section(name: str) -> WSection:
    if str(name).strip().upper().startswith("HSS "):
        from .tube_sections import get

        return get(name)
    if str(name).strip().upper().startswith(("MBCI-CHANNEL-", "SSS-SS")):
        return channel_section(name)
    key = normalize(name)
    if key not in SECTIONS:
        raise KeyError(f"section {name!r} is not in the catalog ({CATALOG_VERSION}); add it with register_section()")
    return SECTIONS[key]


def has_section(name: str) -> bool:
    try:
        return get_section(name) is not None
    except (KeyError, ValueError):
        return False


def register_section(name: str, d: float, bf: float, tf: float, tw: float, plf: str | Decimal) -> WSection:
    s = WSection(normalize(name), d, bf, tf, tw, Decimal(str(plf)))
    SECTIONS[s.name] = s
    return s


STEEL_DENSITY_LB_PER_IN3 = Decimal("0.2836")  # 490 pcf
