"""Slip-in walk-door ASSEMBLY, not duplicated fabricated opening jambs.
The half-inch gap is INSIDE, below the downward girt's web underside.
An ordinary clip station is not silently relabeled as that physical underside.
"""

from .cladding import inch
from .secondary_catalog import get


def finish(job, p, model):
    walls = job.assemblies[p.column_mark].derivation.get('endwalls', {})
    for o in model['openings']:
        cfg = p.additions['opening_members'][o['id']]
        if cfg.get('opening_mode') != 'walk_slip_in':
            continue
        wall = walls.get('front_end' if o['face'] == 'front' else 'rear_end', {})
        W = float(p.width.inches)
        lo = o['x_in']
        hi = lo + o['width_in']
        if o['face'] == 'rear':
            lo, hi = W - hi, W - lo
        candidates = [
            r
            for r in wall.get('members', [])
            if r['role'] == 'endwall girt'
            and r['y0_in'] >= o['y_in'] + o['height_in']
            and r['x0_in'] <= lo
            and r['x1_in'] >= hi
        ]
        girts = sorted(candidates, key=lambda r: r['y0_in'])
        g = girts[0] if girts else None
        underside = (
            inch(cfg['walk_girt_web_underside']) if cfg.get('walk_girt_web_underside') not in ('', None) else None
        )
        head = inch(cfg['walk_head_face']) if cfg.get('walk_head_face') not in ('', None) else None
        jamb = inch(cfg['walk_jamb_face']) if cfg.get('walk_jamb_face') not in ('', None) else None
        if head is not None:
            underside = o['y_in'] + o['height_in'] + head + 0.5
        leg = max(get(g['profile_id'])['flanges_in']) if g else None
        original_station = g['y0_in'] if g else None
        if head is not None and g:
            g.update(
                y0_in=underside,
                y1_in=underside,
                original_girt_station_in=original_station,
                web_underside_in=underside,
                flange_tip_elevation_in=underside - leg,
                elevation_basis='OWNER FRAME FACE + CLEAR HEIGHT + INSIDE GAP; nominal flange projection from web underside',
            )
        detail = dict(
            mode='walk_slip_in',
            header_orientation='DOWN',
            inside_gap_in=0.5,
            gap_basis='Door frame OUTSIDE TOP to girt HORIZONTAL WEB UNDERSIDE, inside channel',
            clear_width_in=o['width_in'],
            clear_height_in=o['height_in'],
            girt_member_ref=g['mark'] if g else None,
            girt_station_in=g['y0_in'] if g else None,
            girt_web_underside_in=underside,
            door_frame_outside_top_in=None if underside is None else underside - 0.5,
            frame_quantity=1,
            frame_scope='ONE COMPLETE WALK-DOOR FRAME ASSEMBLY; component sections/cuts not inferred',
            status='RELATIVE FIT DEFINED; absolute web-underside / frame-head dimensions held'
            if underside is None
            else 'VERTICAL DATUM DERIVED; check actual frame section, flange/lip fit and support elevation',
        )
        if head is not None:
            detail.update(
                frame_head_face_in=head,
                frame_jamb_face_in=jamb,
                door_frame_outside_width_in=None if jamb is None else o['width_in'] + 2 * jamb,
                door_frame_outside_height_in=o['height_in'] + head,
                girt_leg_in=leg,
                girt_flange_tip_in=None if leg is None else underside - leg,
                original_girt_station_in=original_station,
                datum_basis='OWNER head/jamb faces; actual setout replaces former connection station',
                status='FRAME ENVELOPE AND RECEIVER ELEVATIONS DERIVED FROM OWNER DIMENSIONS',
            )
        o['walk_slip_fit'] = detail
        o['members'] = []
        if g:
            g['orientation'] = 'FLANGES DOWN / WALK SLIP-IN RECEIVER'
            g['shared_walk_opening'] = o['id']
            o['members'].append(
                dict(
                    mark=g['mark'],
                    shared_member_ref=g['mark'],
                    role='HD',
                    profile=g['profile_id'],
                    family=g['family'],
                    quantity=0,
                    x0_in=o['x_in'],
                    x1_in=o['x_in'] + o['width_in'],
                    y0_in=underside - leg if head is not None and leg is not None else o['y_in'] + o['height_in'],
                    y1_in=underside if head is not None else o['y_in'] + o['height_in'] + o['header_face'],
                    reference_length_in=g.get('reference_span_in') or g['x1_in'] - g['x0_in'],
                    orientation='DOWN / shared existing wall girt',
                    status='REFERENCE ONLY: counted as wall girt; not a second door header',
                )
            )
        else:
            o['issues'].append(
                'WALK SLIP-IN: no modeled wall girt spans above door; add/position actual supporting girt explicitly'
            )
        o['issues'].append(
            'WALK FRAME SECTION FIT: verify purchased frame depth/lips and receiving-channel contact; vertical elevations resolved.'
            if head is not None and jamb is not None and g
            else detail['status'] + '. The1/2in is not a gap below flange tips or a reduction to clear opening.'
        )
        o['status'] = 'WALK SLIP-IN ASSEMBLY / FIT REVIEW'
