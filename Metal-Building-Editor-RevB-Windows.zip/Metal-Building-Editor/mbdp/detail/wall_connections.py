"""Physical girt-clip instances. End posts one inward side, interiors both sides.
Member fit/NC and capacity are distinct from these positional/count rules.
"""

from .framing_additions import uprights


def finish(job, p):
    a = job.assemblies[p.column_mark]
    l = job.settings.get('frame_layouts', {}).get(p.column_mark)
    rows = []
    job.part(p.girt_clip)  # raises KeyError when the girt clip part is missing from the job
    if l is None:
        return

    def add(face, posts, elevations, scope):
        for i, post in enumerate(posts):
            corner = face in ('left', 'right') and post['mark'].startswith('EW-') and post['profile'].startswith('W')
            hss = post['profile'].startswith('HSS')
            solid = p.clip_policy == 'member_sized' and p.connection_style != 'bolted'
            clip_id = 'CLF12' if corner and not solid else p.girt_clip
            adaptation = corner and not solid and float(p.girt_depth.inches) != 8
            selected = job.part(clip_id)
            # Shop standard on welded buildings (owner 2026-10-15): flush girts are welded directly
            # to the web / the corner column's inside flange / the tube face - no clip anywhere
            # (main columns, end-wall posts, corner columns).  Clips are the web_clip option.
            direct_weld = selected.kind == 'mark'
            mount = (
                'COLUMN WEB PARALLEL TO GIRT'
                if corner
                else 'HSS FACE / FLANGE RULE'
                if hss
                else 'COLUMN WEB'
                if p.girt_mode == 'flush'
                else 'OUTSIDE COLUMN FLANGE'
            )
            for y in sorted(set(elevations)):
                if not post['bottom'] <= y <= post['top']:
                    continue
                if p.girt_mode == 'flush':
                    hands = [1] if i == 0 else [-1] if i == len(posts) - 1 else [-1, 1]
                else:
                    hands = [0]
                for hand in hands:
                    if getattr(p, 'bay_zones', {}).get('enabled') and scope == 'primary_interior':
                        x = post['x']
                        length = float(p.length.inches)
                        canonical = length - x if face == 'left' else x
                        actual_hand = -hand if face == 'left' else hand
                        connected_zone = [
                            r
                            for r in a.derivation.get('secondary_runs', {}).get('pieces', [])
                            if r['role'] == 'girt'
                            and r['side'] == face
                            and abs(r['floor_y_in'] - y) < 1e-7
                            and (
                                (actual_hand >= 0 and abs(r['support_start_in'] - canonical) < 1e-7)
                                or (actual_hand <= 0 and abs(r['support_end_in'] - canonical) < 1e-7)
                            )
                        ]
                        if not connected_zone:
                            continue
                    if scope == 'endwall':
                        wall = a.derivation['endwalls'][
                            'outer_front_end'
                            if face == 'outer_front'
                            else 'front_end'
                            if face == 'front'
                            else 'rear_end'
                        ]
                        connected = []
                        for run in wall['members']:
                            if run['role'] != 'endwall girt' or abs(run['y0_in'] - y) > 1e-7:
                                continue
                            direction = (
                                1
                                if run.get('left_support') == post['mark']
                                else -1
                                if run.get('right_support') == post['mark']
                                else None
                            )
                            if direction is not None:
                                outside_hand = -direction if face == 'rear' else direction
                                if hand == 0 or hand == outside_hand:
                                    connected.append(run['mark'])
                        if not connected:
                            continue
                    if direct_weld:
                        rows.append(
                            dict(
                                mark=p.column_mark + '-GC-' + str(len(rows) + 1),
                                face=face,
                                main_mark=post['mark'],
                                station_in=post['x'],
                                elevation_in=y,
                                clip='DIRECT-WELD',
                                quantity=0,
                                mode=p.girt_mode,
                                hand=hand,
                                scope=scope,
                                mount=(
                                    'CORNER COLUMN INSIDE FLANGE'
                                    if corner
                                    else 'TUBE FACE'
                                    if hss
                                    else 'COLUMN WEB (girt coped at the flanges)'
                                ),
                                connected_members=connected if scope == 'endwall' else [],
                                alignment='Girt outside face FLUSH with column outside face',
                                web_center_from_outside_in=float(p.girt_web_y.inches),
                                status='Girt welded directly; no clip (shop standard on welded buildings)',
                            )
                        )
                        continue
                    if post.get('opening_id') and p.connection_style != 'bolted':
                        rows.append(
                            dict(
                                mark=p.column_mark + '-GC-' + str(len(rows) + 1),
                                face=face,
                                main_mark=post['mark'],
                                station_in=post['x'],
                                elevation_in=y,
                                clip='DIRECT-WELD',
                                quantity=0,
                                mode=p.girt_mode,
                                hand=hand,
                                scope=scope,
                                mount='SHARED BEARING JAMB / DIRECT GIRT RECEIVER',
                                connected_members=connected,
                                status='No separate clip counted; receiving face, weld fit and final girt cut held',
                            )
                        )
                        continue
                    rows.append(
                        dict(
                            mark=p.column_mark + '-GC-' + str(len(rows) + 1),
                            face=face,
                            main_mark=post['mark'],
                            station_in=post['x'],
                            elevation_in=y,
                            clip='CLF6-PENDING' if adaptation else clip_id,
                            quantity=1,
                            mode=p.girt_mode,
                            hand=hand,
                            scope=(
                                'sidewall_crosswall'
                                if post['mark'].startswith('EW-') and scope == 'primary_interior'
                                else scope
                            )
                            if i not in (0, len(posts) - 1)
                            else 'sidewall_terminal'
                            if scope == 'primary_interior'
                            else scope,
                            mount=mount,
                            alignment='Girt outside face FLUSH with column outside face'
                            if hand
                            else 'BYPASS outside flange',
                            column_wall_inset_in=float(p.girt_depth.inches) if p.inset_for_bypass else 0,
                            web_center_from_outside_in=float(p.girt_web_y.inches) if hand else None,
                            clip_projection_in=None if adaptation else float(selected.length.inches),
                            clip_depth_in=None if adaptation else float(selected.width.inches),
                            status='HOLD:6in CORNER CLIP MATERIAL-EDGE DATUM NOT RECONCILED; no8in clip substitution'
                            if adaptation
                            else 'PLACEMENT / QUANTITY RULE; verify clip contour, weld access, holes and actual flange clearance; not column drilling',
                        )
                    )

    runs = a.derivation.get('secondary_runs', {})
    for face in ('left', 'right'):
        elevations = [r['floor_y_in'] for r in runs.get('lanes', []) if r['role'] == 'girt' and r['side'] == face]
        add(face, uprights(job, p, face), elevations, 'primary_interior')
    for key, face in [('front_end', 'front'), ('rear_end', 'rear'), ('outer_front_end', 'outer_front')]:
        wall = a.derivation.get('endwalls', {}).get(key)
        if not wall:
            continue
        levels = [m['y0_in'] for m in wall['members'] if m['role'] == 'endwall girt']
        add(face, uprights(job, p, face), levels, 'endwall')
    for row in rows:
        if row['scope'] == 'endwall':
            wall = a.derivation['endwalls'][
                'outer_front_end'
                if row['face'] == 'outer_front'
                else 'front_end'
                if row['face'] == 'front'
                else 'rear_end'
            ]
            web = next(
                (
                    run.get('web_underside_in')
                    for run in wall['members']
                    if run['role'] == 'endwall girt'
                    and run.get('web_underside_in') is not None
                    and abs(run['y0_in'] - row['elevation_in']) < 1e-8
                    and row['main_mark'] in (run.get('left_support'), run.get('right_support'))
                ),
                None,
            )
            if web is not None:
                row['elevation_basis'] = 'OWNER GIRT WEB UNDERSIDE / welded clip TOP CONTACT FACE'
                row['girt_web_underside_in'] = web
                if row['quantity'] and row['clip'] in job.parts:
                    t = float(job.part(row['clip']).thk.inches)
                    row.update(
                        clip_top_elevation_in=web,
                        clip_bottom_elevation_in=web - t,
                        clip_mid_thickness_elevation_in=web - t / 2,
                    )
    a.derivation['wall_girt_connections'] = rows
    l['wall_girt_connections'] = rows
    # This is per physical END member. Primary interior attachments already own
    # their clip quantities via the assembly BOM, so do not order them a second time.
    a.derivation['end_girt_clip_quantity'] = sum(r['quantity'] for r in rows if r['scope'] != 'primary_interior')

    a.derivation['end_girt_clip_counts'] = {
        k: sum(r['quantity'] for r in rows if r['scope'] != 'primary_interior' and r['clip'] == k)
        for k in sorted({r['clip'] for r in rows})
    }
