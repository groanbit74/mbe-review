"""Physical supplier product libraries. No manufacturer-equivalence aliases.
SSS dimensions from owner-supplied Catalog 32 pages; unlisted properties stay unknown.
"""

from .supplier_catalog import catalog as reference

SOURCE = dict(
    title='Triple-S Steel Catalog 32 — owner supplied pages',
    revision='Catalog 32',
    url='http://ssscatalog.com/Triple%20S%20West_Cat%2032/',
    page_effective_date='Not stated on supplied pages',
)


def secondaries():
    out = []
    for r in reference()['products']:
        if r['category'] != 'secondary':
            continue
        code = r['code']
        family = (
            'C'
            if code.startswith('PN') and 'ZEE' not in code and 'SES' not in code
            else 'Z'
            if 'ZEE' in code
            else 'Channel'
            if code.startswith('SS')
            else 'Angle'
            if code.startswith('CAB')
            else 'Eave'
        )
        # Zee table says flange alternatives, not a certified unequal-flange/lap pair.
        variants = (
            [('', r.get('flange_in'))]
            if family != 'Z'
            else [('-F' + str(w).replace('.', 'p'), w) for w in r['flange_options_in']]
        )
        if family == 'Eave':
            variants = [
                ('-low_single' if code == 'PN8SSES' else '-low_double', None),
                ('-high_single' if code == 'PN8SSES' else '-high_double', None),
            ]
        for suffix, width in variants:
            depth = r.get('depth_in', 8 if family == 'Eave' else min(r.get('legs_in', [0])))
            row = dict(
                id='SSS-' + code + suffix,
                manufacturer='Triple-S Steel',
                supplier='sss',
                supplier_code=code,
                family=family,
                designation=code
                + ' — '
                + r['label']
                + (' / flange ' + str(width) + ' in' if family == 'Z' else '')
                + suffix,
                nominal_depth_in=depth,
                flanges_in=[width, width] if width else r.get('legs_in'),
                gauge=r['gauge'],
                weight_lb_ft=None,
                finishes=['Galvanized' if f == 'Galvanized' else 'Red Oxide' for f in r['finishes']],
                thickness_in=None,
                lip_in=0 if family == 'Channel' else None,
                bend_radius_in=None,
                pdf_page=r['page'],
                printed_page=str(r['page']),
                source_info=SOURCE,
                available_stock_ft=r['stock_lengths_ft'],
                unknowns=[
                    'Steel thickness, lips/radii, weight, punching and capacity not provided',
                    'Zee flange option is NOT a verified lap section',
                ],
                dimension_basis='Supplier catalog nominal envelope; no inferred thickness or capacity',
            )
            if family == 'Angle':
                row.update(stock_length_ft=r['stock_lengths_ft'][0], stock_weight_lb={f: None for f in row['finishes']})
            if family == 'Channel':
                row.update(open_face=True, nominal_depth_class_in=round(depth))
            if family == 'Eave':
                row.update(eave_kind=suffix[1:], max_length_ft=30)
            out.append(row)
    return out


# Swatch colors approximated from the supplied chart; screen approximations only.
COLOR_HEX = {
    'Crimson Red': '#b92825',
    'Polar White': '#e5e7e7',
    'Hawaiian Blue': '#497579',
    'Cocoa Brown': '#372718',
    'Tan': '#c8ac8f',
    'Burnished Slate': '#4b483b',
    'Gray': '#a5a7a3',
    'Fern Green': '#45543c',
    'Gallery Blue': '#003e66',
    'Beige': '#aaa694',
    'Charcoal': '#414141',
    'Rustic Red': '#8e3025',
    'Aztec Gold': '#bd9656',
    'Emerald Green': '#254b3d',
    'Light Stone': '#d6cfb6',
    'Galvalume Plus': '#b9bdb8',
    'Burgundy': '#48202a',
    'Copper Penny': '#a64817',
    'Silver Metallic': '#bbb8a5',
}


def colors():
    return [
        dict(
            name='SSS / ' + n,
            hex=h,
            coating='SSS Galvalume Plus'
            if n == 'Galvalume Plus'
            else 'SSS silicone-modified polyester / confirm metallic finish'
            if n in ('Copper Penny', 'Silver Metallic')
            else 'SSS silicone-modified polyester',
            supplier='sss',
            preview_basis='Approximate supplied chart swatch; physical samples authoritative',
        )
        for n, h in COLOR_HEX.items()
    ]


def trims():
    bycode = {r['code']: r for r in reference()['products']}
    out = []
    roles = {
        'corner': ['TRCRS', 'TRCRSU'],
        'base': [],
        'rake': [
            'TRRKTSTD',
            'TRRKTSTDU',
            'TRRKTS',
            'TRBRT',
            'TRBRTU',
            'TRPNR4S',
            'TRPNR6S',
            'TRPNR8S',
            'TROCR4S',
            'TROCR6S',
            'TROCR8S',
            'TROCR4SU',
            'TROCR6SU',
            'TROCR8SU',
        ],
        'high_eave': ['TRETHS', 'TRETHSS'],
        'eave': ['TRETSTD', 'TRETLSS'],
        'jamb': ['TRDJMBT', 'TRDJMBTU'],
        'head': ['TRDHT', 'TRDHTU'],
        'ridge': ['TRRCF', 'TRCRFC', 'TRRSC7', 'TRRSC10'],
        'sill': [],
    }
    face = {
        'TRRKTSTDU': 4.75,
        'TRDJMBTU': 3,
        'TRDHTU': 1.5,
        'TRBRTU': 7.5,
        'TRCRS': 4,
        'TRRKTSTD': 5.25,
        'TRBRT': 7.5,
        'TRETSTD': 4,
        'TRDJMBT': 3,
        'TRDHT': 1.5,
        'TRETHS': 5.25,
    }
    for role, codes in roles.items():
        for code in codes:
            r = bycode[code]
            stock = r.get('stock_lengths_ft')
            out.append(
                dict(
                    id='SSS-' + code,
                    role=role,
                    label=code + ' — ' + r['label'],
                    supplier='sss',
                    supplier_code=code,
                    stock_length_in=max(stock) * 12 if stock else 246,
                    catalog_length_verified=bool(stock),
                    available_stock_ft=stock,
                    pdf_page=r['page'],
                    default_gauge=26,
                    signature300_gauge=26,
                    panel_compatibility='PBU'
                    if 'U panel' in r['label'] or code == 'TRCRSU'
                    else 'PBR'
                    if 'R panel' in r['label']
                    else None,
                    face_in=face.get(code, r.get('face_in')),
                    note='Actual supplier product; unknown supply lengths use PROJECT order limit, not a fabricated catalog length. Installed pitch/junction/hem fit requires review.',
                )
            )
    return out


def panel(ident):
    if ident in ('SSS-PBR', 'SSS-PBU'):
        pbr = ident.endswith('PBR')
        return dict(
            id=ident,
            supplier='sss',
            coverage_in=36,
            rib_spacing_in=12 if pbr else 6,
            rib_height_in=1.25 if pbr else 0.75,
            min_published_length_in=None,
            max_published_length_in=516 if pbr else 504,
            gauges=[26],
            pricing_sheet_width_in=38.25,
            formed_geometry_status='Supplier catalog profile; thickness/bends/punching not supplied',
        )
    if ident != 'MBCI-PBR':
        raise ValueError('Unknown supplier panel product: ' + str(ident))
    from .cladding import catalog

    return catalog()['profile']
