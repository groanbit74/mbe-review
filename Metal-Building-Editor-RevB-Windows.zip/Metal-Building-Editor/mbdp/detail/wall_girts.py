"""Sheets never without girts (v0.8.39).

Owner rule: a sheeted wall carries wall girts - always.  The rule is applied instead of policed:

* :func:`apply` runs right after the wall states are resolved (``enclosure.apply``).  When any
  main wall is SHEETED and the job has no girt lines (a roof-only start, a job typed without
  lines) the standard shop lines for the eave height / foundation / walk door
  (``standards.girt_lines`` - the same rule behind the editor's *Standard* button) are written
  into the frame parameters, and a slab gets its base angle run.  A sheeted END wall whose end
  line is a plain rigid frame of the lot (no end-wall framing) gets the end-wall framing switched
  on for that end - the standard bearing end wall with girts - and the frame lot shrinks by that
  end frame.  A sheeted end wall always includes its girts.
* :func:`check` runs after generation: every sheeted wall surface must have girt pieces behind
  it.  A sheeted wall without girts is a blocker (concrete and input-resolvable), never silent.

What was applied is reported once as an information note on the secondary runs
(``p.applied_rules``) so the owner sees why the girt field is now filled.
"""

from __future__ import annotations

from . import enclosure as E
from .foundation import is_post_footing
from .model import D
from .standards import girt_lines

_END = {'front': 'front_end', 'rear': 'rear_end'}
_SIDE = {'left': 'left', 'right': 'right'}  # surface id -> secondary-run side key


def _cladding(p) -> dict:
    c = getattr(p, 'cladding', None)
    return c if isinstance(c, dict) else {}


def walk_door_present(p) -> bool:
    """A walk door (3070-class: at most 5 ft wide and 7'-6 high) on any wall fixes the 7'-3 header girt."""
    for o in _cladding(p).get('openings') or []:
        if not isinstance(o, dict) or (o.get('kind') or 'door') != 'door':
            continue
        try:
            h = float(D(o.get('height') or '0').inches)
            w = float(D(o.get('width') or '0').inches)
        except Exception:
            continue
        if 0 < h <= 90 and 0 < w <= 60:
            return True
    return False


def sheeted_faces(p) -> list[str]:
    c = _cladding(p)
    if not c or not c.get('enabled'):
        return []
    st = E.states(p)
    return [k for k in E.FACES if st.get(k) == 'sheeted']


def apply(p) -> list[str]:
    """Fill the girt lines / base angle / end-wall framing a sheeted wall needs.

    Returns the notes.  The notes describe the resulting STATE (shop standard girt lines in
    use, base angle run, standard bearing end walls), not the change - so a saved job
    regenerates to the same text.
    """
    notes: list[str] = []
    sheeted = sheeted_faces(p)
    if not sheeted:
        p.applied_rules = getattr(p, 'applied_rules', []) + notes
        return notes
    walls = ', '.join(E.label(k) for k in sheeted)
    post = is_post_footing(p)
    walk = walk_door_present(p)
    standard = [D(x) for x in girt_lines(float(p.eave_height.inches), 'post_footing' if post else 'slab', walk)]
    if not p.girt_elevations:
        p.girt_elevations = list(standard)
    if [x.fmt() for x in p.girt_elevations] == [x.fmt() for x in standard]:
        notes.append(
            'GIRT LINES: shop standard lines '
            + ', '.join(x.fmt() for x in standard)
            + ' - '
            + walls
            + ' sheeted ('
            + ('post footing: first girt 12 in, then even' if post else 'slab: base angle + even lines at 5 ft maximum')
            + (", walk door header girt at 7'-3" if walk else '')
            + ').'
        )
    if not post and not (p.slab and p.starting_wall_run):
        p.slab = True
        p.starting_wall_run = True
    if not post and p.slab and p.starting_wall_run:
        notes.append('BASE ANGLE: slab base angle run under the sheeted walls (shop standard).')
    ends = p.endwalls if isinstance(getattr(p, 'endwalls', None), dict) else None
    if ends is None:
        ends = p.endwalls = {}
    bl = p.bay_layout if isinstance(getattr(p, 'bay_layout', None), dict) else {}
    girt_product = bool((getattr(p, 'secondary', None) or {}).get('girt'))
    standard_ends = []
    for face, end in _END.items():
        if face not in sheeted:
            continue
        prior = bl.get(end) if isinstance(bl.get(end), dict) else {}
        rigid_lot = prior.get('type') == 'rigid_frame'
        framed = bool(ends.get('enabled')) and not rigid_lot
        rec = ends.get(end) if isinstance(ends.get(end), dict) else None
        if not framed:
            # The end line was a main rigid frame of the lot (or there was no end-wall framing at
            # all): the sheeted end becomes the standard bearing end wall with girts.
            if rec is None:
                rec = ends[end] = {}
            # girts only when a girt product exists (legacy jobs without one are reported by check())
            rec.update(type='bearing_endwall', enclosure='sheeted', include_girts=bool(girt_product))
            rec.setdefault('end_posts', 'auto')
            if rigid_lot:
                prior['type'] = 'bearing_endwall'
                p.frames = max(1, int(p.frames) - 1)
            if not ends.get('enabled'):
                ends['enabled'] = True
                # the other end keeps what it was: a lot rigid frame stays in the lot (bay layout
                # type rigid_frame is skipped by the end-wall model)
                other = 'rear_end' if end == 'front_end' else 'front_end'
                other_prior = bl.get(other) if isinstance(bl.get(other), dict) else None
                if other not in ends and other_prior is not None and other_prior.get('type') != 'rigid_frame':
                    ends[other] = {'enclosure': E.states(p).get('rear' if other == 'rear_end' else 'front', 'sheeted')}
        elif rec is not None and girt_product and rec.get('include_girts') is False:
            if rec.get('enclosure', 'sheeted') != 'open':
                rec['include_girts'] = True  # sheets never without girts
        rec = ends.get(end) if isinstance(ends.get(end), dict) else {}
        if rec.get('type', 'bearing_endwall') == 'bearing_endwall' and rec.get('include_girts', girt_product):
            standard_ends.append(E.label(face))
    if standard_ends:
        notes.append(
            'END WALL FRAMING: '
            + ' and '.join(standard_ends)
            + ' sheeted - standard bearing end wall'
            + ('s' if len(standard_ends) > 1 else '')
            + ' (posts by width, girts'
            + (')' if post else ', base angle)')
            + '.'
        )
    p.applied_rules = getattr(p, 'applied_rules', []) + notes
    return notes


def check(job, p) -> list[str]:
    """Blockers for sheeted wall surfaces that have no girt behind them (after generation)."""
    fid = p.column_mark
    owner = job.assemblies.get(fid)
    if owner is None:
        return []
    d = owner.derivation
    cl = d.get('cladding') or {}
    layout = (job.settings.get('frame_layouts') or {}).get(fid) or {}
    pieces = (layout.get('secondary_runs') or d.get('secondary_runs') or {}).get('pieces') or []
    girt_sides = {z.get('side') for z in pieces if z.get('role') == 'girt'}
    ends = d.get('endwalls') or {}
    out: list[str] = []
    for s in cl.get('surfaces') or []:
        sid = s.get('id')
        if s.get('open_wall') or sid not in ('left', 'right', 'front', 'rear'):
            continue
        if sid in _SIDE:
            if sid in girt_sides:
                continue
            if any(z.get('role') == 'girt' for z in pieces):
                hint = 'girts must be kept under every sheeted bay (bay enclosure)'
            else:
                hint = (
                    'the girt lines must be filled (Building settings > Secondary > Girt elevations: '
                    'the Standard button applies the shop lines)'
                )
        else:
            end = _END[sid]
            rec = ends.get(end) if isinstance(ends.get(end), dict) else None
            if rec and any(m.get('role') == 'endwall girt' for m in rec.get('members') or []):
                continue
            if not (p.secondary or {}).get('girt'):
                hint = 'a supplier girt product must be selected (Building settings > Secondary)'
            elif rec:
                hint = 'Include endwall girts must be on for that end'
            else:
                hint = 'the end-wall framing must be switched on for that end (Building settings > Walls)'
        # 'missing' / 'must be' are the words the release gate treats as actionable (holds._ACTIONABLE)
        out.append(
            'SHEETED WALL WITHOUT GIRTS: '
            + str(s.get('elevation') or sid)
            + ' is sheeted but its girts are missing - '
            + hint
            + ', or set the wall OPEN.'
        )
    return out
