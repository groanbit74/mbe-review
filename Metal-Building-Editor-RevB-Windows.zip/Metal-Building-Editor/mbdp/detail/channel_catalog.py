"""MBCI actual unlipped channel products, separate from lipped Cee catalog hash."""

import re

SOURCE = 'https://www.mbci.com/products/channels/'
# Each20ft piece: red oxide / galvanized, fetched2026-10-02.
WEIGHTS = {
    4: {16: (31.13, 32.24), 14: (37.25, 38.36)},
    6: {16: (38.98, 40.37), 14: (46.63, 48.02), 12: (69.60, 70.99)},
    8: {16: (46.82, 48.49), 14: (56.02, 57.68), 12: (83.61, 85.28)},
    10: {16: (54.67, 56.62), 14: (65.40, 67.35), 12: (97.62, 99.57)},
}


def get(ident):
    m = re.fullmatch(r'MBCI-Channel-(4|6|8|10)p125x2-G(12|14|16)', ident)
    if not m:
        raise ValueError('Unknown MBCI channel: ' + str(ident))
    size, gauge = map(int, m.groups())
    if gauge not in WEIGHTS[size]:
        raise ValueError('Channel gauge not listed by manufacturer')
    ro, ga = WEIGHTS[size][gauge]
    return dict(
        id=ident,
        family='Channel',
        designation=f'Channel {size + 0.125} x2 /{gauge}ga',
        nominal_depth_class_in=size,
        nominal_depth_in=size + 0.125,
        flanges_in=[2.0, 2.0],
        gauge=gauge,
        weight_lb_ft=ro / 20,
        weight_by_finish_lb_ft={'Red Oxide': ro / 20, 'Galvanized': ga / 20},
        finishes=['Red Oxide', 'Galvanized'],
        stock_length_ft=20,
        available_stock_ft=[20, 25],
        open_face=True,
        lip_in=0,
        thickness_in=None,
        bend_radius_in=None,
        source=SOURCE,
    )


def section(size, gauge, finish):
    r = get(f'MBCI-Channel-{int(size)}p125x2-G{gauge}')
    if size != int(size) or r['nominal_depth_class_in'] != size:
        raise ValueError('Unsupported channel depth class')
    if finish not in r['finishes']:
        raise ValueError('Unsupported MBCI channel finish')
    return dict(
        id=r['id'],
        family='C',
        depth=r['nominal_depth_in'],
        nominal_depth_class_in=size,
        width=2.0,
        wall=str(gauge) + ' ga',
        gauge=gauge,
        open_face=True,
        weight_lb_ft=r['weight_by_finish_lb_ft'][finish],
        finish=finish,
        catalog_reference=r['id'],
        thickness_in=None,
        lip_in=0,
        bend_radius_in=None,
        source=SOURCE,
        section_basis='Actual MBCI unlipped CHANNEL, depth class +1/8in;2in flanges. Not lipped Cee properties.',
    )
