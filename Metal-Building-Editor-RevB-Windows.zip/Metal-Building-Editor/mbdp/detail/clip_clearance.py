"""Along-slope physical clip-edge to mating-plate-face distances (warning only)."""


def check_edges(clip_low, clip_high, plates, owner, role, part, station):
    checks = []
    for mark, low, high in plates:
        gap = max(low - clip_high, clip_low - high)
        side = 'before clip' if high <= clip_low else 'after clip' if low >= clip_high else 'overlapping clip'
        checks.append(
            dict(
                plate=mark,
                plate_low_in=low,
                plate_high_in=high,
                side=side,
                clearance_in=max(0.0, gap),
                signed_gap_in=gap,
                overlap=gap < -1e-8,
                warning=gap < 3 - 1e-8,
            )
        )
    warnings = [
        f'{role} {part}: {c["plate"]}: '
        + ('OVERLAP' if c['overlap'] else f'{c["clearance_in"]:.3f} in clear')
        + '; 3 in edge-to-face clearance required. Position retained; review fit.'
        for c in checks
        if c['warning']
    ]
    return dict(
        owner=owner,
        role=role,
        part=part,
        station_in=station,
        clip_low_in=clip_low,
        clip_high_in=clip_high,
        required_clearance_in=3.0,
        checks=checks,
        warnings=warnings,
    )
