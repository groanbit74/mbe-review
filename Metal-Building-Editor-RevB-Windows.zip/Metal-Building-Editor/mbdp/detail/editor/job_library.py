"""Job list ("library") helpers: one file per job under ``<workspace>/jobs``.

The editor keeps the job being worked on in ``job.json`` (autosaved after every
edit).  Every autosave is also filed under the job's number in ``jobs/<key>.json``
so that each job stays available by name and the user can switch between jobs
from *Job ▾ → Open job…* instead of only getting back the last job saved.

Keys
----
``library_key(job_no)`` turns a job number into a safe file stem (letters,
digits, ``.``, ``_`` and ``-``; anything else becomes ``_``).  A job whose number
collides with a different job already in the list is filed under ``<key>~2``,
``<key>~3``… — nothing is ever overwritten silently.

Only pure helpers live here; the file juggling is done by ``JobStore``.
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone

_KEY_BAD = re.compile(r"[^A-Za-z0-9._-]+")


def library_key(job_no: str) -> str:
    key = _KEY_BAD.sub("_", (job_no or "").strip()).strip("._")
    return key or "untitled"


def worth_filing(d) -> bool:
    """A job earns a list entry once it has a frame or any assembly.

    ``d`` is a ``Job`` or its JSON dict.  The blank job the editor starts with
    (``NEW``, no members) is not listed; it only becomes a job once something is
    in it."""
    assemblies = d.assemblies if hasattr(d, "assemblies") else (d.get("assemblies") or {})
    settings = d.settings if hasattr(d, "settings") else (d.get("settings") or {})
    return bool(assemblies) or bool(settings.get("frames"))


def unique_key(folder: str, key: str, own: str | None) -> str:
    """``key`` if free (or already ours), else the first free ``key~n``."""
    if key == own or not os.path.exists(os.path.join(folder, key + ".json")):
        return key
    n = 2
    while True:
        cand = f"{key}~{n}"
        if cand == own or not os.path.exists(os.path.join(folder, cand + ".json")):
            return cand
        n += 1


def job_meta(path: str) -> dict:
    """Header + building size of a saved job file, for the job list.

    Reads the JSON directly (no model objects) so listing stays cheap; the
    result is cached by ``JobStore`` on (mtime, size)."""
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        if isinstance(d, dict) and "job" in d and isinstance(d["job"], dict):
            d = d["job"]
    except Exception as e:  # unreadable or foreign file: still listed, but flagged
        return dict(
            job_no=os.path.splitext(os.path.basename(path))[0],
            customer="",
            building="",
            date="",
            size="",
            frames=0,
            assemblies=0,
            error=f"unreadable: {type(e).__name__}",
        )
    frames = (d.get("settings") or {}).get("frames") or {}
    size = ""
    for P in frames.values():
        if not isinstance(P, dict):
            continue
        w, l, e = P.get("width", ""), P.get("length", ""), P.get("eave_height", "")
        size = " × ".join(x for x in (w, l, e) if x)
        rise = P.get("slope_rise")
        if rise not in (None, ""):
            size += f"  {rise}:12"
        if P.get("frame_type") == "monoslope":
            size += "  mono"
        break
    return dict(
        job_no=str(d.get("job_no", "")),
        customer=d.get("customer", "") or "",
        building=d.get("building", "") or "",
        date=d.get("date", "") or "",
        size=size,
        frames=len(frames),
        assemblies=len(d.get("assemblies") or {}),
        # standard sample this entry was filed as (carport / roof_only / three_sided / enclosed);
        # the editor's Samples menu reopens it by this key whatever its number or edits
        sample=str((d.get("settings") or {}).get("sample") or ""),
    )


def stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%f")


# Numbers the 0.8.28 editor proposed on its own (1000001, 1000002, …) before the shop's
# numbering (356 upwards) was configured; they are not continued.
FORMER_AUTO_SERIES = range(1000001, 1000100)


def next_job_no(numbers, start: str = "356", ignore=()) -> str:
    """The number after the highest all-digit job number in ``numbers``.

    ``start`` (the shop's first job number, ``standards.JOB_NO_START`` = 356) when
    none is numeric.  Zero padding is kept (``000123`` → ``000124``); numbers with
    letters or punctuation (``1277345/A``), the numbers in ``ignore`` and the former
    automatic series 1000001–1000099 are skipped, so a job numbering scheme the
    editor does not understand is never "continued" wrongly."""
    skip = {str(x).strip() for x in ignore}
    best = None
    for n in numbers:
        n = str(n or "").strip()
        if not n.isdigit() or n in skip or int(n) in FORMER_AUTO_SERIES:
            continue
        if best is None or int(n) > int(best):
            best = n
    if best is None:
        return start
    return str(int(best) + 1).zfill(len(best))


_SKIP_DIRS = {"node_modules", "__pycache__", "Lib", "Scripts", "site-packages", "runtime", "deleted", ".git"}
_MAX_JOB_FILE = 64 * 1024 * 1024


def job_files(root: str, *, exclude: tuple[str, ...] = (), max_depth: int = 6):
    """Yield ``(path, mtime)`` for every file under ``root`` that could be a saved job.

    Candidates are ``*.json`` and ``*.txt`` files (``job.json``, ``jobs/<key>.json``,
    ``recovery/*.json``, ``backups/<stamp>/job.json``, downloaded ``Job-*.json`` /
    ``job_json.txt``) of a plausible size.  Runtime, library and version-control
    folders are skipped, as is anything under the ``exclude`` paths (the running
    editor's own workspace).  Content is not read here — ``import_candidates`` does."""
    root = os.path.abspath(root)
    excl = tuple(os.path.abspath(e) for e in exclude)
    base_depth = root.rstrip(os.sep).count(os.sep)
    for dirpath, dirnames, filenames in os.walk(root):
        if any(os.path.abspath(dirpath) == e or os.path.abspath(dirpath).startswith(e + os.sep) for e in excl):
            dirnames[:] = []
            continue
        dirnames[:] = sorted(d for d in dirnames if d not in _SKIP_DIRS and not d.startswith("."))
        if dirpath.count(os.sep) - base_depth >= max_depth:
            dirnames[:] = []
        for fn in sorted(filenames):
            if not fn.lower().endswith((".json", ".txt")):
                continue
            path = os.path.join(dirpath, fn)
            try:
                st = os.stat(path)
            except OSError:
                continue
            if 200 <= st.st_size <= _MAX_JOB_FILE:
                yield path, st.st_mtime


def read_job_dict(path: str) -> dict | None:
    """The job dictionary inside ``path`` (plain ``job.json`` or a ``{"job": …}`` wrapper),
    or ``None`` when the file is not a saved building job."""
    try:
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
    except Exception:
        return None
    if isinstance(d, dict) and isinstance(d.get("job"), dict) and "assemblies" in d["job"]:
        d = d["job"]
    if not isinstance(d, dict) or not isinstance(d.get("assemblies"), dict) or not isinstance(d.get("parts"), dict):
        return None
    return d


def import_candidates(root: str, *, exclude: tuple[str, ...] = ()) -> tuple[list[dict], list[dict]]:
    """Scan a previous installation (or any folder) for saved jobs.

    Returns ``(newest, older)``: one entry per job number — the most recently
    modified copy — and the older copies that were passed over (start-up backups
    and recovery copies of the same job).  Blank jobs (no frame, no assembly) are
    ignored.  Each entry is ``dict(path, mtime, job_no, job)`` with ``job`` the
    parsed dictionary."""
    found: dict[str, dict] = {}
    older: list[dict] = []
    for path, mtime in job_files(root, exclude=exclude):
        d = read_job_dict(path)
        if d is None or not worth_filing(d):
            continue
        job_no = str(d.get("job_no", "")).strip()
        rec = dict(path=path, mtime=mtime, job_no=job_no, job=d)
        cur = found.get(job_no)
        if cur is None:
            found[job_no] = rec
        elif mtime > cur["mtime"]:
            older.append(cur)
            found[job_no] = rec
        else:
            older.append(rec)
    return sorted(found.values(), key=lambda r: r["job_no"]), older
