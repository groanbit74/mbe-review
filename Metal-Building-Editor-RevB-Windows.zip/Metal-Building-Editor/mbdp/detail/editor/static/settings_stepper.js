/* Building settings — the stepper (master spec §5 order).
 *
 * ONE module owns three things that used to be scattered over five tabs and the save handler:
 *   1. the step order and which inputs belong to each step;
 *   2. every cross-step prerequisite the server will enforce, evaluated LIVE while typing
 *      (badge on each step, "still needed" list on the step and on Review & save, Go-to links);
 *   3. values OWNED by another input (Bay enclosure owns "separate endwall framing" and the sheet
 *      takeoff): they are set and labelled with their owner, never silently greyed out.
 * Guard: a control named by an open requirement is never left disabled - the trap class behind
 * "requires explicit endwall framing" / "cannot add girts" cannot recur.
 *
 * The form itself (fields, the draft object P, the save request) is still built by wizard() in
 * app.js; this module organises and guards it.  Element ids / data-* hooks are unchanged, so
 * server rejections (diagnostics.rejected -> locateFields) and the UI scripts keep working.
 */
window.organizeBuildingSettings=function({box,P,el,grid,catalog,profiles=[],initial='main',inches,docked=false,setDocked=null,ensureGirtLines=null}){
 const STEPS=[
  ['building','Building & bays','Master dimensions, roof shape, standard bay layout and enclosure.'],
  ['frames','Main frames','Schedule-selected columns and rafters, connections, knees, ridge and bases.'],
  ['secondary','Roof & secondaries','Roof purlin setout and profiles; automatic wall/roof secondary runs.'],
  ['walls','Endwalls','End-wall posts, rafters, girts and support assumptions.'],
  ['openings','Openings','All door/window presets, wall and bay placement, dimensions and preview.'],
  ['cladding','Sheets & trim','Supplier products, sheet takeoff, colors and trim only.'],
  ['review','Review & save','Effective standards and exceptions, then save and regenerate.']];
 const LEGACY={main:'building',bays:'building',supplier:'cladding',advanced:'frames'};
 const TITLE=Object.fromEntries(STEPS.map(([k,t])=>[k,t]));
 const stepNo=k=>STEPS.findIndex(([x])=>x===k)+1;
 const stepRef=k=>'step '+stepNo(k)+' · '+TITLE[k];
 const fmt=n=>window.MBDim?.fmt?window.MBDim.fmt(n):String(n);
 const num=v=>{const n=inches(v);return Number.isFinite(n)?n:NaN;};
 const hint=t=>el('p',{class:'hint'},t);
 const appendPresent=(target,...nodes)=>target.append(...nodes.filter(n=>n!==null&&n!==undefined));

 /* ---------- 1. sort the wizard's flat form into steps ---------- */
 const children=[...box.children],heading=children.shift(),actions=children.pop();
 const errors=children.filter(n=>n.classList?.contains('err-box'));
 const HEADINGS={'Master building geometry':'building','Connections \u2014 every option in one place (seat, construction, ridge, purlin fit)':'connections','Connections \u2014 foundation (slab or post footing)':'connections','Connections \u2014 bases, clips, gaps & weld size (same dialog)':'connections','Connections \u2014 plates, brackets & marks (same dialog)':'connections','Members & marks':'frames','Starting wall run / slab':'secondary','Secondary layout':'secondary'};
 const GROUPS={secondary:'secondary',runs:'secondary',walls:'walls',envelope:'cladding'};
 const buckets={};for(const [k]of STEPS)buckets[k]=[];
 buckets.connections=[];// the connection groups live on one step (round 14); they are not a step of
 // their own, so they are collected here and appended to the main-frames pane
 let bucket='cladding';// the supplier-products section comes before the first heading
 for(const n of children){
  if(errors.includes(n))continue;
  if(n.tagName==='H3'&&HEADINGS[n.textContent.trim()])bucket=HEADINGS[n.textContent.trim()];
  const g=n.dataset?.settingsGroup;
  if(g==='preset'){n.remove();continue;}// retired competing override controls: stored resolved members stay explicit
  if(g&&GROUPS[g]){buckets[GROUPS[g]].push(n);continue;}
  if(n.classList?.contains('supplier-settings')){buckets.cladding.push(n);continue;}
  buckets[bucket].push(n);
 }
 P.section_defaults={};for(const key of ['column_section','rafter_section']){const c=box.querySelector('[data-frame-field="'+key+'"]');if(c)c.disabled=false;}

 const panes={},nav=el('div',{class:'settings-nav stepper',role:'tablist'}),body=el('div',{class:'settings-body'}),summary=el('p',{class:'settings-summary'});
 heading.textContent='Building settings';
 for(const [key,label,blurb]of STEPS){
  panes[key]=el('section',{'data-settings-pane':key,role:'tabpanel'});body.append(panes[key]);
  nav.append(el('button',{type:'button','data-settings-tab':key,role:'tab',title:blurb,onclick:()=>show(key)},el('span',{class:'step-no'},String(stepNo(key))),el('span',{class:'step-title'},label),el('span',{class:'step-state','data-step-state':''})));
 }
 if(setDocked){
  const dockBtn=el('button',{type:'button',class:'mini','data-settings-dock':'',title:'Docked: the drawing stays visible and updates on save. Centred: classic dialog that closes on save.'});
  const tools=el('span',{class:'nav-tools'},el('small',{}),dockBtn);nav.append(tools);
  const paint=()=>{dockBtn.textContent=docked?'Centre dialog':'Dock beside drawing';tools.querySelector('small').textContent=docked?'Docked — drawing updates on save':'Centred dialog';};paint();
  dockBtn.onclick=()=>{docked=!docked;setDocked(docked);paint();};
 }
 const guideButton=el('button',{type:'button',class:'mini','data-settings-help':'','aria-label':'Open help and field guide'},'? Help & field guide');nav.append(guideButton);
 box.replaceChildren(heading,summary,nav,body,...errors,actions);
 actions.classList.add('settings-actions');
 const saveBtn=actions.querySelector('button.primary');saveBtn.textContent='Save building & regenerate';
 const stepNav=el('span',{class:'step-nav'},el('button',{type:'button',class:'mini','data-step-nav':'back',onclick:()=>step(-1)},'‹ Back'),el('span',{class:'step-counter'}),el('button',{type:'button',class:'mini','data-step-nav':'next',onclick:()=>step(1)},'Next ›'));
 actions.prepend(stepNav);

 const movePair=(selector,target,title)=>{const c=box.querySelector(selector);if(!c)return;const label=c.previousElementSibling;if(label?.tagName==='LABEL'){if(title)label.textContent=title;target.append(label,c);}return c;};
 const detail=(title,...nodes)=>{const d=el('details',{class:'more'},el('summary',{},title));d.append(...nodes.filter(Boolean));return d;};

 // Step 1 — Building & bays: the geometry grid as the wizard built it, the wall choice, then the bay plan (below).
 panes.building.append(...buckets.building);
 const wallsBox=el('div',{'data-wall-states':''});panes.building.append(wallsBox);
 // Step 2 — Main frames: the decisions first, the detail collapsed.
 const framesMain=el('div',{class:'grid'});
 for(const [k,t]of [['column_section','Main columns'],['rafter_section','Main rafters'],['connection_style','Main connection construction'],['base_connection','Column base connection']])movePair('[data-frame-field="'+k+'"]',framesMain,t);
 panes.frames.append(hint('Main/interior frame settings are here; endwall members are set on '+stepRef('walls')+'. Use Help & field guide for the shop-standard geometry and field effects.'),framesMain,
  ...buckets.connections,
  detail('Members & marks, high column (detail)',...buckets.frames));
 // Step 3 — Roof & secondaries. Make the standard and its per-frame override visible.
 const products=buckets.secondary.find(n=>n.dataset?.settingsGroup==='secondary'),runs=buckets.secondary.find(n=>n.dataset?.settingsGroup==='runs');
 if(products){const h=products.querySelector('h3');if(h)h.textContent='Purlin, girt & eave products';}
 const secMain=el('div',{class:'grid'});
 for(const [k,t]of [['purlin_mode','Main roof purlin fit — across the roof slope'],['girt_mode','Sidewall girt fit']])movePair('[data-frame-field="'+k+'"]',secMain,t);
 const runChildren=runs?[...runs.children]:[];
 const ownerRule=runChildren.find(n=>n.classList?.contains('standard-rule'));
 const ownerOverride=runChildren.find(n=>n.querySelector?.('[data-welded-fit-override]')&&n.tagName==='LABEL');
 const ownerOverrideHint=ownerOverride?.nextElementSibling;
 const runHeading=runChildren.find(n=>n.tagName==='H3');
 const runEnable=runChildren.find(n=>n.querySelector?.('[data-run-field="enabled"]')&&n.tagName==='LABEL');
 const runEnableInput=runEnable?.querySelector('[data-run-field="enabled"]');
 const runBody=runChildren.find(n=>n.querySelector?.('[data-run-field="spacing"]')&&n.classList?.contains('grid'))||runChildren.at(-1);
 const bayLayoutGrid=runBody?.querySelector('[data-run-field="layout_mode"]')?.closest('.grid');
 const bayList=runBody?.querySelector('[data-bay-list]');
 const bayNote=bayList?.nextElementSibling;
 const bayLayoutSection=el('section',{class:'bay-layout-settings'},el('h3',{},'Automatic building bay layout'));
 if(bayLayoutGrid){bayLayoutGrid.remove();bayLayoutSection.append(bayLayoutGrid);}
 if(bayList){bayList.remove();bayLayoutSection.append(bayList);}
 if(bayNote){bayNote.remove();bayLayoutSection.append(bayNote);}
 if(ownerRule)ownerRule.classList.add('standard-rule-card');
 if(runEnable)runEnable.remove();
 const hiddenRunState=el('span',{hidden:'','data-internal-run-state':''});if(runEnableInput)hiddenRunState.append(runEnableInput);
 const runOptOut=el('input',{type:'checkbox','data-settings-help-key':'secondary-run-optout',checked:runEnableInput?.checked?'':null});
 const runStatus=el('p',{class:'standard-rule-card',role:'status'});
 const paintRunStatus=()=>{const on=!!P.bay_layout?.enabled;if(runEnableInput)runEnableInput.checked=on;runStatus.textContent=on?'Automatic roof, sidewall, and eave secondary generation is active.':'Advanced exception: automatic runs are off; use manual run inputs.';runOptOut.checked=!on;};
 runOptOut.onchange=()=>{const enabled=!runOptOut.checked;P.bay_layout||={};P.bay_layout.enabled=enabled;if(runEnableInput){runEnableInput.checked=enabled;runEnableInput.dispatchEvent(new Event('change',{bubbles:true}));}runBody?.classList.toggle('hidden',!enabled);window.__mbdpRefreshBuildingPreview?.();paintRunStatus();refreshBayStatus();};
 paintRunStatus();window.__mbdpSecondaryRunStatus=paintRunStatus;
 const runOverride=detail('Advanced exception: omit automatic secondary runs',el('label',{},runOptOut,' Disable the managed bay/run generator for this frame'),hint('This exception also turns off the managed bay grid in the current generator. Use only when the job will be entered with manual run inputs.'));
 const roofSpacingInput=box.querySelector('[data-frame-field="auto_roof_spacing"]');
 const roofSpacingStatus=el('p',{class:'standard-rule-card',role:'status'});
 const roofSpacingReset=el('button',{type:'button',class:'mini',onclick:()=>{P.auto_roof_spacing=true;if(roofSpacingInput){roofSpacingInput.checked=true;roofSpacingInput.dispatchEvent(new Event('change',{bubbles:true}));}paintRoofSpacingStatus();}},'Return to automatic spacing');
 function paintRoofSpacingStatus(){const automatic=P.auto_roof_spacing!==false;if(roofSpacingInput)roofSpacingInput.checked=automatic;roofSpacingStatus.textContent=automatic?'Automatic equal roof-row spacing is active (maximum 5 ft).':'Manual roof-row spacing is active; see the manual station fields below.';roofSpacingReset.hidden=automatic;}
 paintRoofSpacingStatus();window.__mbdpRoofSpacingMode=paintRoofSpacingStatus;
 const bayStatus=el('p',{class:'standard-rule-card',role:'status'});
 const bayReset=el('button',{type:'button',class:'mini',onclick:()=>{const R=P.bay_layout||{};R.layout_mode='max_spacing';delete R.bay_lengths;delete R.rule_sha256;const select=box.querySelector('[data-run-field="layout_mode"]');if(select)select.value='max_spacing';window.__mbdpRefreshBuildingPreview?.();refreshBayStatus();}},'Return to automatic equal bays');
 function refreshBayStatus(){
  const R=P.bay_layout||{},L=num(P.length)||0,max=num(R.max_spacing)||240;
  if(z.enabled){bayStatus.textContent='Bay enclosure controls the individual bay lengths above.';bayReset.hidden=true;return;}
  if(!R.enabled){bayStatus.textContent='Managed bay/run generation is off (Advanced exception).';bayReset.hidden=true;return;}
  if(R.layout_mode==='explicit'){bayStatus.textContent='Custom bay lengths are active; their total must equal the building length.';bayReset.hidden=false;return;}
  if(R.layout_mode==='max_spacing'){const n=Math.max(1,Math.ceil(L/max));bayStatus.textContent='Automatic equal bays active: '+n+' bays × '+fmt(L/n)+' (maximum '+fmt(max)+'). Type a bay length below to customize it.';bayReset.hidden=true;return;}
  bayStatus.textContent='Alternate bay layout is active: '+(R.layout_mode||'not selected')+'.';bayReset.hidden=R.layout_mode==='max_spacing';
 }
 window.__mbdpBayLayoutStatus=refreshBayStatus;
 if(runBody)runBody.classList.add('secondary-run-details');
 appendPresent(panes.secondary,products||el('span',{}),secMain,runStatus,ownerRule,ownerOverride,ownerOverrideHint,hiddenRunState,
  runOverride,roofSpacingStatus,roofSpacingReset,
  runBody?detail('Run patterns, end-support assumptions, clearances, and manual quantities',runBody):null,
  detail('Manual roof-row stations, clips, datums, starting run and lap details',...buckets.secondary.filter(n=>n!==products&&n!==runs)),
  ...buckets.secondary.filter(n=>n===runs&&!runBody));
 appendPresent(bayLayoutSection,bayStatus,bayReset,bayLayoutGrid?detail('Advanced layout modes and run-end allowances',bayLayoutGrid):null);
 panes.walls.append(hint('Endwall posts, rafters and girts belong here. Roof/secondary run endpoints use the support assumptions in '+stepRef('secondary')+'. The per-wall roof-fit override remains with the endwall connection details.'),...buckets.walls);
 // Step 5 — Sheets & trim.
 const envelope=buckets.cladding.find(n=>n.dataset?.settingsGroup==='envelope');
 if(envelope){const h=envelope.querySelector('h3');if(h)h.textContent='Sheets & trim settings';}
 panes.cladding.append(...buckets.cladding);
 // Step 6 — Review & save is rendered from the live state (renderReview).

 /* ---------- all door/window controls live in their own step ---------- */
 const openingTitle=[...(envelope?.querySelectorAll('h4')||[])].find(n=>n.textContent.trim()==='Positioned door / window panel openings');
 const openingDescription=openingTitle?.nextElementSibling;
 const openingList=envelope?.querySelector('[data-opening-list]');
 const openingClearance=box.querySelector('[data-addition-field="opening_auto"]')?.closest('label');
 const openingClearanceNote=openingClearance?.nextElementSibling;
 const openingButtons=[...(envelope?.querySelectorAll('[data-cladding-action="add-opening"],[data-cladding-action="add-overhead"],[data-cladding-action="add-window"]')||[])];
 appendPresent(panes.openings,hint('For each preset, choose an elevation and bay. The default is centered in that bay; select an offset or exact X to adjust it. Clearance checking is separate from placement.'),
  openingClearance,openingTitle,openingDescription,openingList,...openingButtons);
 if(openingClearanceNote)panes.openings.append(openingClearanceNote);
 window.placeBuildingOpenings=()=>{
  if(!box.isConnected)return;
  box.querySelectorAll('input').forEach(paintEcho);
  evaluate();
 };
 queueMicrotask(window.placeBuildingOpenings);
 for(const card of box.querySelectorAll('[data-wall-card]')){
  card.open=card.dataset.wallCard==='front_end';
  const details=el('details',{},el('summary',{},'Connection and post-layout details'));const dg=el('div',{class:'grid'});details.append(dg);card.append(details);
  for(const suffix of ['type','post_layout','bays','bay_widths','ridge_joint','roof_depth_clearance','purlin_channel_fit_confirmed','base','head','finish'])movePair('[data-end-field="'+card.dataset.wallCard+'_'+suffix+'"]',dg);
 }
 for(const key of ['front_end','rear_end'])for(const suffix of ['type','column','rafter','posts']){const c=box.querySelector('[data-run-field="'+key+'_'+suffix+'"]');if(c){c.previousElementSibling?.remove();c.remove();}}

 /* ---------- bays & enclosure (step 1) ---------- */
 const z=P.bay_zones=JSON.parse(JSON.stringify(P.bay_zones||{}));
 const zoneBody=el('div',{}),zonePlan=el('div',{class:'zone-plan'}),table=el('div',{});
 const enabled=el('input',{type:'checkbox','data-zone-field':'enabled'});enabled.checked=!!z.enabled;enabled.onchange=()=>{z.enabled=enabled.checked;if(z.enabled&&!z.bays){z.bays=standardZoneBays();z.enclosed_start_line=0;z.outer_front_state='future';}draw();update();};
 // New enclosure layouts use equal bays, with 20 ft as the maximum; preserve existing wall states by position.
 const standardZoneBays=()=>{const L=inches(P.length)||0,n=Math.max(1,Math.ceil(L/240)),x=L/n,old=z.bays||[];return Array.from({length:n},(_,i)=>({... (old[i]||{left:'sheeted',right:'sheeted'}),length:fmt(x)}));};
 panes.building.append(el('h3',{},'Bays & enclosure'),el('label',{},enabled,' Explicit bay lengths and enclosure'),
  el('p',{class:'hint','data-zone-owned':'',hidden:''},'Bay enclosure also controls endwall framing and sheet takeoff. See Help & field guide for scope, product prerequisites, and supported layouts.'),
  zoneBody,bayLayoutSection);
 const input=(obj,k,field)=>el('input',{value:obj[k]??'','data-zone-field':field,oninput:e=>{obj[k]=e.target.value;update();}});
 const select=(obj,k,options,field)=>el('select',{'data-zone-field':field,onchange:e=>{obj[k]=e.target.value;if(['left','right'].includes(k))obj[k+'_girts_now']=false;if(k==='outer_front_state')obj.outer_girts_now=false;draw();update();}},...options.map(([v,t])=>el('option',{value:v,selected:String(obj[k])===String(v)?'':null},t)));
 const provision=(obj,side,field)=>{const k=side==='outer'?'outer_girts_now':side+'_girts_now',state=side==='outer'?obj.outer_front_state:obj[side],c=el('input',{type:'checkbox','data-zone-field':field,onchange:e=>{obj[k]=e.target.checked;update();}});c.checked=!!obj[k];c.disabled=state!=='future';return state==='future'?el('label',{},c,(side==='right'?' Front sidewall — ':side==='left'?' Back sidewall — ':' Outer end — ')+'Install wall framing now (girts, base angle & clips; NO sheets)'):el('span',{});};
 function draw(){zoneBody.hidden=!z.enabled;if(!z.enabled)return;table.replaceChildren();
  z.bays.forEach((b,i)=>table.append(el('fieldset',{},el('legend',{},'Bay '+(i+1)),grid(['Length',input(b,'length','bay_'+i+'_length')],['Front sidewall',select(b,'right',[['sheeted','Sheeted now'],['open','Open'],['future','Future sheeting — exclude now']],'bay_'+i+'_right')],['Back sidewall',select(b,'left',[['sheeted','Sheeted now'],['open','Open'],['future','Future sheeting — exclude now']],'bay_'+i+'_left')]),provision(b,'right','bay_'+i+'_right_girts_now'),el('br'),provision(b,'left','bay_'+i+'_left_girts_now'))));
  const junction=select(z,'enclosed_start_line',z.bays.map((b,i)=>[i,'Frame line '+(i+1)+' — start of bay '+(i+1)]),'enclosed_start_line');junction.addEventListener('change',()=>{if(Number(z.enclosed_start_line)>0&&!P.endwalls.outer_front_end){P.endwalls.outer_front_end=JSON.parse(JSON.stringify(P.endwalls.front_end||{}));P.endwalls.outer_front_end.include_girts=false;/* record created for jobs saved before the outer-end card existed; it is reviewed on step 3 */}});
  zoneBody.replaceChildren(zonePlan,table,grid(['Inside wall / junction (left end of the enclosed bays)',junction],['Outer extension end',select(z,'outer_front_state',[['open','Open now'],['future','Open now / future enclosure'],['sheeted','Sheeted now — end wall sheets, girts and trim (sides stay open)']],'outer_front_state')]),Number(z.enclosed_start_line)>0?provision(z,'outer','outer_girts_now'):el('span',{}),el('div',{class:'btnrow'},el('button',{type:'button',onclick:()=>{z.bays=standardZoneBays();draw();update();}},'Reset to equal bays (20 ft max)'),el('button',{type:'button',onclick:()=>{z.bays.push({length:"20'",left:'sheeted',right:'sheeted'});draw();update();}},'Add right-hand bay'),el('button',{type:'button',onclick:()=>{if(z.bays.length<=2||Number(z.enclosed_start_line)>=z.bays.length-1){alert('Keep the enclosed block and at least two bays.');return;}if(confirm('Remove the last (right-hand) bay? Openings in it must be moved first.')){z.bays.pop();draw();update();}}},'Remove right-hand bay')),
  el('p',{class:'hint zone-topology'},el('b',{},'Supported layout in this version: '),'roof-only (open / future) bays at the LEFT end, then the enclosed junction wall, then enclosed bays continuing to the RIGHT end. A future bay at the right end is not modelled yet - enter the building mirrored (future bay first, junction at the next frame line) and note the orientation on the job.'));
  box.querySelectorAll('input').forEach(paintEcho);
 }
 const totalLen=()=>(z.bays||[]).reduce((a,b)=>a+(num(b.length)||0),0);
 const stations=()=>{const ss=[0];for(const b of z.bays||[])ss.push(ss[ss.length-1]+(num(b.length)||0));return ss;};
 // bay_zones.intervals(): sheeted X ranges of a sidewall in outside view
 const intervals=(side)=>{if(!z.enabled)return[[0,num(P.length)]];const ss=stations(),L=ss[ss.length-1],runs=[];(z.bays||[]).forEach((b,i)=>{if(b[side]!=='sheeted')return;runs.push(side==='left'?[L-ss[i+1],L-ss[i]]:[ss[i],ss[i+1]]);});runs.sort((a,b)=>a[0]-b[0]);const merged=[];for(const [lo,hi]of runs){if(merged.length&&Math.abs(merged[merged.length-1][1]-lo)<1e-7)merged[merged.length-1][1]=hi;else merged.push([lo,hi]);}return merged;};
 const junctionOn=()=>z.enabled&&Number(z.enclosed_start_line)>0;
 const faceLabel=sid=>({right:'Front sidewall',left:'Back sidewall',front:junctionOn()?'Inside wall (enclosed junction)':'Left endwall',rear:'Right endwall'})[sid]||sid;
 const endTitle=key=>{const station=(z.bays||[]).slice(0,Number(z.enclosed_start_line)||0).reduce((a,b)=>a+(num(b.length)||0),0);
  return {front_end:junctionOn()&&station?'Inside wall (enclosed junction) · Frame line '+(Number(z.enclosed_start_line)+1)+' · '+station/12+' ft from the outer left end':'Left endwall',rear_end:(z.enabled?'Right endwall (enclosed) · ':'Right enclosed endwall · ')+(z.enabled?totalLen():num(P.length))/12+' ft',outer_front_end:'Outer left end (bay 1, roof-only) · 0 ft · '+(z.outer_front_state||'open')}[key];};

 // Owned values: the owner sets them and says so next to the control - never a bare disabled box.
 function own(control,text,toStep){if(!control)return;const host=control.closest('label')||control.parentElement;let tag=host.querySelector('[data-owned-by]');
  if(!tag){tag=el('span',{class:'owned','data-owned-by':''},el('span',{}),' ',el('button',{type:'button',class:'mini',onclick:()=>show(toStep)},'Open '+TITLE[toStep]));host.append(tag);}
  tag.children[0].textContent='Managed by '+TITLE[toStep]+'.';tag.hidden=!z.enabled;}
 /* ---------- walls: every wall of the main building is an explicit SHEETED / OPEN choice (v0.8.35) ---------- */
 P.cladding||={};P.endwalls||={};
 const hadStates=!!P.cladding.wall_states;
 const WS=P.cladding.wall_states=Object.assign({left:'sheeted',right:'sheeted',front:'sheeted',rear:'sheeted'},P.cladding.wall_states||{});
 if(!hadStates){for(const [face,end]of[['front','front_end'],['rear','rear_end']]){const enc=P.endwalls[end]?.enclosure;if(enc==='open'||enc==='sheeted')WS[face]=enc;}}
 if(z.enabled)for(const side of['left','right'])WS[side]=(z.bays||[]).some(b=>b[side]==='sheeted')?'sheeted':'open';
 const wallSelects={};
 const wallSelect=(face)=>{const sel=el('select',{'data-wall-state':face,onchange:e=>setWall(face,e.target.value,true)},el('option',{value:'sheeted'},'Sheeted'),el('option',{value:'open'},'OPEN — framing only (no girts, base angle or sheets)'));sel.value=WS[face];wallSelects[face]=sel;return sel;};
 function setWall(face,value,fromStep1){WS[face]=value;if(wallSelects[face]&&wallSelects[face].value!==value)wallSelects[face].value=value;
  if(value==='sheeted'){// sheets never without girts (v0.8.39): a sheeted wall switches the wall takeoff on and fills the standard girt lines
   if(P.cladding.enabled&&P.cladding.walls===false){P.cladding.walls=true;const c=box.querySelector('[data-cladding-field="walls"]');if(c&&!c.checked){c.checked=true;c.dispatchEvent(new Event('change'));}}
   if(ensureGirtLines)ensureGirtLines();}
  if(face==='front'||face==='rear'){const end=face+'_end';P.endwalls[end]||={};P.endwalls[end].enclosure=value;if(!P.endwalls.enabled&&value==='open'){/* a rigid-frame end stays open through the cladding; end-wall framing is chosen on step 3 */}
   const c=box.querySelector('[data-end-field="'+end+'_enclosure"]');if(c&&c.value!==value){c.value=value;c.dispatchEvent(new Event('change'));}}
  else if(z.enabled&&fromStep1){for(const b of z.bays||[]){b[face]=value==='open'?'open':'sheeted';b[face+'_girts_now']=false;}draw();}
  update();}
 for(const [face,end]of[['front','front_end'],['rear','rear_end']]){const c=box.querySelector('[data-end-field="'+end+'_enclosure"]');if(c)c.addEventListener('change',()=>{if(WS[face]!==c.value){WS[face]=c.value;if(wallSelects[face])wallSelects[face].value=c.value;update();}});}
 {const oc=box.querySelector('[data-end-field="outer_front_end_enclosure"]');if(oc){oc.addEventListener('change',()=>{if(junctionOn()){z.outer_front_state=oc.value==='sheeted'?'sheeted':'open';draw();update();}});}}
 const wallsHint=el('p',{class:'hint'});
 wallsBox.append(el('h3',{},'Wall enclosure'),hint('Choose each elevation’s sheeted/open state. Use Help & field guide for framing consequences and wall names.'),
  grid(['Front sidewall',wallSelect('right')],['Back sidewall',wallSelect('left')],['Left endwall',wallSelect('front')],['Right endwall',wallSelect('rear')]),wallsHint);
 function paintWalls(){const wallsOff=P.cladding.enabled&&P.cladding.walls===false;for(const [face,sel]of Object.entries(wallSelects)){sel.disabled=false;if(wallsOff){if(WS[face]!=='open'){WS[face]='open';}}if(sel.value!==WS[face])sel.value=WS[face];}
  wallsHint.textContent=wallsOff?'Roof only: every wall is open. Choose Sheeted on a wall to add it - wall sheets switch on and the standard girt lines are filled in automatically (sheets never without girts).':z.enabled?'Bay enclosure is on: a sidewall choice here sets every bay on that side; refine single bays below.':'';}
 {const c=box.querySelector('[data-cladding-field="walls"]');if(c)c.addEventListener('change',()=>paintWalls());}
 let zonesWere=!!z.enabled;
 function update(){let total=0;zonePlan.replaceChildren();paintWalls();
  if(z.enabled){for(const [i,b]of(z.bays||[]).entries()){const n=inches(b.length);if(Number.isFinite(n))total+=n;const cell=el('div',{class:'zone-cell '+(b.left===b.right&&b.left==='sheeted'?'enclosed':'open'),style:'flex:'+Math.max(1,n||1)},el('strong',{},'B'+(i+1)+' · '+((n||0)/12).toFixed(2)+' ft'),el('span',{},b.left===b.right&&b.left==='sheeted'?'Enclosed':'Roof only / mixed walls'));zonePlan.append(cell);}if(total>0){P.length=total+'"';const c=box.querySelector('[data-frame-field="length"]');if(c){c.value=(total/12)+"'";c.readOnly=true;}}}
  else{const c=box.querySelector('[data-frame-field="length"]');if(c)c.readOnly=false;}
  const count=box.querySelector('[data-frame-field="frames"]');if(count){count.readOnly=!!z.enabled;if(z.enabled)count.value=(z.bays||[]).length-1-(Number(z.enclosed_start_line)>0?1:0);}
  if(z.enabled&&P.endwalls.outer_front_end)P.endwalls.outer_front_end.include_girts=!!z.outer_girts_now;
  // Endwall girts: the outer (roof-only) end follows "Install wall framing now"; the two sheeted
  // ends get girts by default when enclosure is switched on and stay editable.
  if(z.enabled&&!zonesWere)for(const end of ['front_end','rear_end']){const rec=P.endwalls[end];if(rec&&!rec.include_girts){rec.include_girts=true;const c=box.querySelector('[data-end-field="'+end+'_girts"]');if(c)c.checked=true;}}
  zonesWere=!!z.enabled;
  {const c=box.querySelector('[data-end-field="outer_front_end_girts"]');if(c){c.disabled=!!z.enabled;if(z.enabled)c.checked=!!z.outer_girts_now;}}
  for(const end of ['front_end','rear_end']){const c=box.querySelector('[data-end-field="'+end+'_girts"]');if(c)c.disabled=false;}
  // Bay enclosure OWNS separate endwall framing and the sheet takeoff (bay_zones.apply requires them).
  const ends=box.querySelector('[data-end-field="enabled"]');
  if(z.enabled){P.endwalls.enabled=true;if(ends&&!ends.checked){ends.checked=true;ends.dispatchEvent(new Event('change'));}}
  if(ends)ends.disabled=!!z.enabled;
  own(ends,'on; owned by Bay enclosure - the bay states decide which walls are sheeted.','building');
  for(const k of ['layout_mode','bays','max_spacing']){const c=box.querySelector('[data-run-field="'+k+'"]');if(c)c.disabled=!!z.enabled;}
  for(const k of ['enabled','walls','roof']){const c=box.querySelector('[data-cladding-field="'+k+'"]');if(z.enabled){P.cladding[k]=true;if(c&&!c.checked){c.checked=true;c.dispatchEvent(new Event('change'));}}if(c)c.disabled=!!z.enabled;}
  own(box.querySelector('[data-cladding-field="enabled"]'),'on; owned by Bay enclosure - open / future bays are excluded from the takeoff automatically.','building');
  const owned=box.querySelector('[data-zone-owned]');if(owned)owned.hidden=!z.enabled;
  bayLayoutSection.hidden=!!z.enabled;refreshBayStatus();
  const outerCard=box.querySelector('[data-wall-card="outer_front_end"]');if(outerCard)outerCard.classList.toggle('hidden',!junctionOn());
  {const oc=box.querySelector('[data-end-field="outer_front_end_enclosure"]');if(oc&&junctionOn())oc.value=z.outer_front_state==='sheeted'?'sheeted':'open';}
  for(const key of ['front_end','rear_end','outer_front_end']){const n=box.querySelector('[data-wall-title="'+key+'"]');if(n)n.textContent=endTitle(key);}
  summary.textContent=P.width+' wide × '+(z.enabled?(total/12)+' ft':P.length)+' long × '+P.eave_height+' eave | Main: '+P.column_section+' columns / '+P.rafter_section+' rafters | '+P.purlin_mode+' roof';
  paintRunStatus();paintRoofSpacingStatus();refreshBayStatus();evaluate();
 }

 /* ---------- 2. requirements: everything the server will insist on, evaluated live ---------- */
 function requirements(){
  const out=[];const need=(step,text,sel)=>out.push({step,text,sel});
  const zon=!!z.enabled,W=num(P.width),E=num(P.eave_height);
  if(!(W>0))need('building','Width must be a positive dimension (e.g. 40\').','[data-frame-field="width"]');
  if(!(E>0))need('building','Eave height must be a positive dimension.','[data-frame-field="eave_height"]');
  if(!zon&&!(num(P.length)>0))need('building','Length must be a positive dimension (or switch on explicit bay lengths).','[data-frame-field="length"]');
  if(zon){
   if(P.frame_type!=='gable')need('building','Bay enclosure needs a gable building (Shape).','[data-frame-field="frame_type"]');
   (z.bays||[]).forEach((b,i)=>{const n=num(b.length);if(!(n>0&&n<=1200))need('building','Bay '+(i+1)+' length must be positive and at most 100 ft.','[data-zone-field="bay_'+i+'_length"]');});
   const line=Number(z.enclosed_start_line)||0;
   (z.bays||[]).slice(0,line).forEach((b,i)=>{const sides=['left','right'].filter(s=>b[s]==='sheeted');if(sides.length)need('building','Bay '+(i+1)+' is left of the junction wall (Frame line '+(line+1)+'), so it is a roof-only extension in this version: set its '+(sides.length>1?'front and back sidewalls':sides[0]==='right'?'front sidewall':'back sidewall')+' to Open or Future, or move the junction to Frame line 1. A future bay at the RIGHT end is entered mirrored (future bay first).',sides.map(s=>'[data-zone-field="bay_'+i+'_'+s+'"]').join(','));});
   if(line>0&&!P.endwalls?.outer_front_end)need('building','The left roof-only extension needs its own outer end record; re-select the junction frame line to create it.','[data-zone-field="enclosed_start_line"]');
   for(const role of ['purlin','girt','eave'])if(!P.secondary?.[role]?.profile_id)need('secondary','Select the '+role+' product. Bay enclosure lays out the secondary runs automatically and needs the actual product; nothing is substituted.','[data-secondary-role="'+role+'"]');
  }
  if(!zon&&P.endwalls?.enabled&&['front_end','rear_end','outer_front_end'].some(k=>P.endwalls[k]?.include_girts)&&!P.secondary?.girt?.profile_id&&!P.secondary?.endwall_girt?.profile_id)need('secondary','Endwall girts are switched on. Select a sidewall girt to share, or a separate endwall girt product.','[data-secondary-role="endwall_girt"],[data-secondary-role="girt"]');
  // girt_clips.py: member-sized bolted clips exist for 6 in and 8 in members only
  if(P.connection_style==='bolted'&&P.clip_policy==='member_sized')for(const role of ['girt','purlin']){const id=P.secondary?.[role]?.profile_id;if(!id)continue;const d=Number((profiles||[]).find(x=>x.id===id)?.nominal_depth_in);
   if(Number.isFinite(d)&&d!==6&&d!==8)need('secondary','Bolted clips are modelled for 6 in and 8 in members only; the selected '+role+' product is '+d+' in deep. Pick a 6 in or 8 in '+role+' product, or change the clip sizing policy ('+stepRef('frames')+' > detail).','[data-secondary-role="'+role+'"]');}
  if(P.connection_style==='bolted'&&P.auto_connections&&P.frame_type==='gable'&&!String(P.apex_bottom_half||'').trim())need('frames','Enter the finished apex bottom half-length (each side) for the bolted ridge connection.','[data-frame-field="apex_bottom_half"]');
  // frame.py: the one-piece cut-and-fold ridge exists only on fully welded gable frames with W rafters
  if(P.ridge_fabrication==='cut_and_fold'&&!(P.connection_style==='fully_welded'&&P.frame_type==='gable'&&String(P.rafter_section||'').toUpperCase().startsWith('W')))need('frames','The cut-and-fold one-piece rafter needs a fully welded GABLE frame with a W rafter (channel rafters butt at the ridge with face plates). Choose the shared ridge plate or change the frame.','[data-frame-field="ridge_fabrication"]');
  if(P.cladding?.enabled)for(const role of ['wall','roof','trim'])if(!P.cladding?.[role+'_finish']?.color)need('cladding','Choose the '+role.toUpperCase()+' sheet color from the selected supplier. The takeoff cannot label or price sheets without it; colors are never chosen for you.','[data-cladding-field="'+role+'_color"]');
  // Openings: inside the wall and, with bay enclosure, inside a sheeted bay (mirrors cladding.py).
  const L=zon?totalLen():num(P.length);
  (P.cladding?.openings||[]).forEach((o,i)=>{const x=num(o.x),w=num(o.width);if(!(x>=0&&w>0))return;const sid=o.surface,wallW=(sid==='front'||sid==='rear')?W:L,id=o.id||('opening '+(i+1));
   if(x+w>wallW+1e-6){need('openings',id+' extends past the end of the '+faceLabel(sid)+' (wall length '+fmt(wallW)+', outside view).','[data-cladding-field="opening_'+i+'_x"],[data-cladding-field="opening_'+i+'_width"]');return;}
   if(zon&&(sid==='left'||sid==='right')){const ranges=intervals(sid);if(!ranges.some(([lo,hi])=>lo-1e-6<=x&&x+w<=hi+1e-6))need('openings',id+' is on an open / future bay of the '+faceLabel(sid)+'. Sheeted X ranges (outside view): '+(ranges.map(([lo,hi])=>fmt(lo)+' to '+fmt(hi)).join(', ')||'none')+'. Move its X, or sheet that bay in '+stepRef('building')+'.','[data-cladding-field="opening_'+i+'_x"]');}});
  return out;
 }
 let lastIssues=[],current=null;
 function goto(it){show(it.step);box.querySelectorAll('.issue-target').forEach(n=>n.classList.remove('issue-target'));const all=[...box.querySelectorAll(it.sel)];if(!all.length)return;
  for(const n of all){for(let a=n.parentElement;a&&a!==box;a=a.parentElement)if(a.tagName==='DETAILS')a.open=true;n.classList.add('issue-target');}
  all[0].scrollIntoView({block:'center'});all[0].focus?.();}
 function evaluate(){
  const issues=requirements();lastIssues=issues;
  const perStep={};for(const it of issues)perStep[it.step]=(perStep[it.step]||0)+1;
  for(const [k]of STEPS){const b=nav.querySelector('[data-settings-tab="'+k+'"] [data-step-state]');if(!b)continue;const n=k==='review'?issues.length:(perStep[k]||0);b.textContent=n?n+' needed':(k==='review'?'ready':'✓');b.className='step-state '+(n?'todo':'ok');}
  for(const [k,pane]of Object.entries(panes)){if(k==='review')continue;let banner=pane.querySelector(':scope > .step-needed');const mine=issues.filter(it=>it.step===k);if(!mine.length){banner?.remove();continue;}
   if(!banner){banner=el('div',{class:'step-needed',role:'status'});pane.prepend(banner);}
   banner.replaceChildren(el('b',{},'Still needed on this step ('+mine.length+')'),el('ul',{},...mine.map(it=>el('li',{},it.text,' ',el('button',{type:'button',class:'mini',onclick:()=>goto(it)},'Go to')))));}
  // Guard: a control the server will demand is never left disabled.
  for(const it of issues)for(const n of box.querySelectorAll(it.sel))if(n.disabled){console.warn('settings stepper: re-enabled a required control',it.sel);n.disabled=false;}
  saveBtn.textContent=issues.length?'Save — '+issues.length+' input'+(issues.length>1?'s':'')+' still needed':'Save building & regenerate';saveBtn.classList.toggle('needs',!!issues.length);
  if(current==='review')renderReview();
  return issues;
 }
 function facts(){const out=[];
  out.push('Building: '+P.width+' wide × '+(z.enabled?fmt(totalLen())+' (sum of the bays)':P.length)+' long × '+P.eave_height+' eave, '+P.slope_rise+' / 12 '+(P.frame_type||''));
  const words=v=>String(v||'').replace(/_/g,' '),widthIn=num(P.width),schedule=({240:'W8X10',360:'W10X12',480:'W12X14',600:'W12X19'})[Math.round(widthIn)]||'no table entry';
  out.push('Main frames: '+P.column_section+' columns / '+P.rafter_section+' rafters; '+words(P.connection_style)+' connections; '+words(P.base_connection)+' base; interior lot '+P.frames);
  out.push('Width-table reference: '+schedule+' at the current width (suggestion only; selected members remain editable).');
  out.push('Owner welded fit: '+(P.connection_style==='bolted'?'not applied — bolted construction':P.welded_fit_rules?.enabled===false?'explicit nonstandard override for this frame':'standard active automatically'));
  out.push('Roof purlin spacing: '+(P.auto_roof_spacing?'automatic equal spacing, maximum 5 ft':'manual — first '+(P.first_purlin||'not entered')+'; interval '+(P.purlin_spacing||'not entered')));
  const layout=P.bay_layout||{};let baySummary;
  if(z.enabled)baySummary=(z.bays||[]).map((b,i)=>'B'+(i+1)+' '+fmt(num(b.length)||0)+' '+(b.left==='sheeted'&&b.right==='sheeted'?'enclosed':b.left==='sheeted'||b.right==='sheeted'?'mixed walls':'roof only')).join(' · ')+(junctionOn()?'; junction wall at Frame line '+(Number(z.enclosed_start_line)+1)+'; outer end '+(z.outer_front_state||'open'): '');
  else if(layout.layout_mode==='explicit')baySummary=(layout.bay_lengths||[]).map((v,i)=>'B'+(i+1)+' '+fmt(num(v)||0)).join(' · ')+' (explicit lengths)';
  else if(layout.layout_mode==='standard')baySummary=window.MBDim.standardBays(num(P.length)||0).map((v,i)=>'B'+(i+1)+' '+fmt(v)).join(' · ')+' (standard layout)';
  else{const length=num(P.length)||0,spacing=num(layout.max_spacing)||240,count=layout.layout_mode==='max_spacing'?Math.ceil(length/spacing):Number(layout.bays||0);baySummary=count>0?count+' equal bays from '+(layout.layout_mode==='max_spacing'?'maximum spacing':'entered count'):'not laid out';}
  out.push('Bays: '+baySummary);
  out.push('Automatic wall / roof / eave secondary runs: '+(layout.enabled?'ON':'OFF')+'; bay layout '+(layout.layout_mode||'not selected')+'.');
  const ends=P.endwalls||{};out.push('Endwalls: '+(ends.enabled?'separate framing'+['front_end','rear_end','outer_front_end'].filter(k=>ends[k]&&(k!=='outer_front_end'||junctionOn())).map(k=>' · '+endTitle(k)+(ends[k].include_girts?' (girts)':' (no girts)')).join(''):'not framed separately'));
  const ops=P.cladding?.openings||[];out.push('Openings: '+(ops.length?ops.map(o=>{const q=P.additions?.opening_members?.[o.id]||{},placement=q.placement==='centered'?'centered in bay '+(q.bay||1):q.placement==='offset'?'offset '+(q.bay_offset||'0')+' from bay '+(q.bay||1):q.placement==='wall_centered'?'centered on wall':'entered X '+(o.x||'not set');return(o.id||'?')+' '+(o.kind||'')+' on '+faceLabel(o.surface)+', '+placement;}).join(' · '):'none'));
  out.push('Sheets & trim: '+(P.cladding?.enabled?'takeoff on ('+['wall','roof','trim'].map(r=>r+' '+(P.cladding?.[r+'_finish']?.color||'- no color')).join(', ')+')':'takeoff off'));
  out.push('Secondary products: '+['purlin','girt','eave'].map(r=>r+' '+(P.secondary?.[r]?.profile_id||'manual / none')).join(', '));
  return out;}
 function renderReview(){const pane=panes.review;pane.replaceChildren();const issues=lastIssues;
  pane.append(el('h3',{class:issues.length?'review-todo':'review-ok'},issues.length?'Not ready — '+issues.length+' input'+(issues.length>1?'s':'')+' still needed':'Ready to save'));
  if(issues.length)pane.append(el('ul',{class:'review-list'},...issues.map(it=>el('li',{},el('span',{class:'step-tag'},stepNo(it.step)+' · '+TITLE[it.step]),' ',it.text,' ',el('button',{type:'button',class:'mini',onclick:()=>goto(it)},'Go to')))));
  else pane.append(hint('Everything the generator requires is entered. Fit / catalog warnings, if any, are reported after the save in the status line and under Model checks.'));
  pane.append(el('h3',{},'What this save regenerates'),el('ul',{class:'review-facts'},...facts().map(t=>el('li',{},t))),hint('One save regenerates every managed frame, endwall, cut, secondary-run and sheet drawing from these inputs. Nothing is purchased, released or structurally approved.'));}

 /* ---------- interpreted dimension echo (spec §4: show the interpreted value) ---------- */
 const DIM_FRAME=new Set(['width','length','eave_height','purlin_depth','eave_plate_extension','girt_depth','base_elevation','box_height','connection_bottom','apex_bottom_half','peak_clip_edge','top_extension','flange_thk','web_thk','weld_size','column_top_gap','knee_setback','ridge_half_gap','girt_web_y','purlin_web_y','first_purlin','purlin_spacing','flange_brace_y','starting_run']);
 const isDim=i=>i.tagName==='INPUT'&&(i.type==='text'||!i.type)&&(DIM_FRAME.has(i.dataset.frameField||'')||/_length$/.test(i.dataset.zoneField||'')||/^opening_\d+_(x|y|width|height)$/.test(i.dataset.claddingField||''));
 function paintEcho(i){if(!isDim(i))return;const label=i.previousElementSibling;if(!label||label.tagName!=='LABEL')return;let e=label.querySelector('.dim-echo');if(!e){e=el('small',{class:'dim-echo'});label.append(e);}
  const v=String(i.value||'').trim();if(!v){e.textContent='';return;}const n=inches(v);if(!Number.isFinite(n)){e.textContent='= ? not a dimension';e.classList.add('bad');return;}e.classList.remove('bad');const f=fmt(n);e.textContent=f===v?'':'= '+f;}

 /* ---------- contextual help and searchable field index ---------- */
 const archivedHelpNotes=[];
 const helpBackdrop=el('div',{class:'field-guide-backdrop hidden','data-field-guide-backdrop':'',role:'presentation'});
 const helpDialog=el('section',{class:'field-guide-dialog',role:'dialog','aria-modal':'true','aria-label':'Building settings Help & field guide'});
 const helpSearch=el('input',{type:'search',class:'field-guide-search','data-field-guide-search':'',placeholder:'Search fields, notes, defaults, or effects'});
 const helpList=el('div',{class:'field-guide-list','data-field-guide-list':'',role:'list'});
 const helpContent=el('div',{class:'field-guide-content','data-field-guide-content':''});
 const helpClose=el('button',{type:'button',class:'mini','aria-label':'Close field guide',onclick:closeGuide},'Close');
 helpDialog.append(el('header',{class:'field-guide-header'},el('div',{},el('h2',{},'Help & field guide'),el('p',{},'Search every field in this settings form, or browse the reference notes.')),helpClose),helpSearch,
  el('div',{class:'field-guide-columns'},helpList,helpContent));
 helpBackdrop.append(helpDialog);box.append(helpBackdrop);
 function closeGuide(){helpBackdrop.classList.add('hidden');}
 helpBackdrop.addEventListener('click',e=>{if(e.target===helpBackdrop)closeGuide();});
 helpDialog.addEventListener('keydown',e=>{if(e.key==='Escape')closeGuide();});
 function controlLabel(control){
  const label=control.closest('label')|| (control.previousElementSibling?.tagName==='LABEL'?control.previousElementSibling:null) ||
    (control.parentElement?.previousElementSibling?.tagName==='LABEL'?control.parentElement.previousElementSibling:null);
  if(!label)return control.getAttribute('aria-label')||control.title||control.getAttribute('data-frame-field')||control.getAttribute('data-run-field')||control.getAttribute('data-end-field')||control.getAttribute('data-zone-field')||control.getAttribute('data-cladding-field')||control.getAttribute('data-addition-field')||control.id||'Unlabelled input';
  const copy=label.cloneNode(true);copy.querySelectorAll('input,select,textarea,button,.dim-echo,[data-owned-by]').forEach(n=>n.remove());
  return copy.textContent.replace(/\s+/g,' ').trim()||'Unlabelled input';
 }
 function fieldKey(control){
  if(control.hasAttribute('data-settings-help-key'))return 'data-settings-help-key='+control.getAttribute('data-settings-help-key');
  for(const attr of ['data-frame-field','data-run-field','data-welded-fit-override','data-cladding-field','data-addition-field','data-end-field','data-zone-field','data-wall-state','data-bay-length','data-secondary-role','data-preset-field','data-frame-connection-override','data-base-angle'])if(control.hasAttribute(attr))return attr+'='+control.getAttribute(attr);
  return control.id||control.name||control.tagName.toLowerCase();
 }
 function currentValue(control){
  if(control.type==='checkbox')return control.checked?'On':'Off';
  if(control.tagName==='SELECT')return control.selectedOptions?.[0]?.textContent?.trim()||control.value||'Not selected';
  return control.value||control.placeholder||'Not entered';
 }
 function stepFor(control){return control.closest('[data-settings-pane]')?.dataset.settingsPane||'building';}
 function collectGuideEntries(){
  const entries=[],seen=new Set(),meta=window.MBSettingsHelp;
  for(const control of box.querySelectorAll('input:not([type="hidden"]),select,textarea')){
   if(control.closest('[hidden]'))continue;
   const label=controlLabel(control),key=fieldKey(control),step=stepFor(control),dedupe=step+'|'+key+'|'+label;
   if(seen.has(dedupe))continue;seen.add(dedupe);
   const info=meta?.match?.(control),unit=info?.units||control.placeholder||'';
   entries.push({id:'field:'+dedupe,title:info?.title||label,group:TITLE[step]||step,step,label,key,control,
    purpose:info?.purpose||('Sets or selects '+label.replace(/[?.:]+$/,'').toLowerCase()+'.'),
    effect:info?.effect||('Saved as a '+(TITLE[step]||step)+' input and used when the corresponding model, checks, and drawings are regenerated. Field-specific limits appear in Review & save or the applicable drawing check.'),
    units:unit,current:currentValue(control)});
  }
  for(const ref of [...(meta?.references||[]),...archivedHelpNotes])entries.push({...ref,step:null,control:null});
  return entries;
 }
 function renderGuideEntry(entry){
  const nodes=[el('div',{class:'field-guide-kicker'},entry.group||'Field guide'),el('h3',{},entry.title),
   entry.label?el('p',{class:'field-guide-label'},entry.label):null,
   el('h4',{},'Purpose'),el('p',{},entry.purpose||entry.body||''),
   entry.effect?el('div',{},el('h4',{},'Effect on the plan'),el('p',{},entry.effect)):null,
   entry.body&&entry.purpose?el('div',{},el('h4',{},'More detail'),el('p',{},entry.body)):null,
   entry.units?el('p',{class:'field-guide-meta'},'Units / hint: '+entry.units):null,
   entry.current?el('p',{class:'field-guide-meta'},'Current value: '+entry.current):null,
   entry.control?el('button',{type:'button',class:'primary',onclick:()=>{const c=entry.control,pane=c.closest('[data-settings-pane]');if(pane)show(pane.dataset.settingsPane);for(let n=c.parentElement;n&&n!==box;n=n.parentElement)if(n.tagName==='DETAILS')n.open=true;closeGuide();setTimeout(()=>{c.scrollIntoView?.({block:'center'});c.focus?.();},0);}},'Go to this field'):null];
  helpContent.replaceChildren(...nodes.filter(n=>n!==null&&n!==undefined));
 }
 function renderGuideList(query=''){
  const entries=collectGuideEntries(),q=query.trim().toLowerCase();
  const filtered=entries.filter(entry=>[entry.title,entry.label,entry.group,entry.key,entry.purpose,entry.effect,entry.body,entry.units].filter(Boolean).join(' ').toLowerCase().includes(q));
  helpList.replaceChildren(el('p',{class:'field-guide-count'},filtered.length+' result'+(filtered.length===1?'':'s')+' · '+entries.filter(e=>e.control).length+' fields indexed'));
  if(!filtered.length){helpList.append(el('p',{},'No matching field or note. Try a shorter search.'));helpContent.replaceChildren();return;}
  for(const entry of filtered){const b=el('button',{type:'button',class:'field-guide-item',onclick:()=>renderGuideEntry(entry)},el('strong',{},entry.title),el('small',{},(entry.group||'Reference')+(entry.label&&entry.label!==entry.title?' · '+entry.label:'')));helpList.append(b);}
  renderGuideEntry(filtered[0]);
 }
 function openGuide(query='',focusKey=''){
  helpBackdrop.classList.remove('hidden');helpSearch.value=query;renderGuideList(query);
  if(focusKey){const entry=collectGuideEntries().find(e=>e.control&&fieldKey(e.control)===focusKey);if(entry)renderGuideEntry(entry);}
  helpSearch.focus();
 }
 helpSearch.addEventListener('input',()=>renderGuideList(helpSearch.value));
 guideButton.onclick=()=>openGuide();
 function installHelpIcons(){
  for(const control of box.querySelectorAll('input:not([type="hidden"]),select,textarea')){
   if(control.dataset.helpAttached||control.closest('[hidden]')||control.closest('[data-field-guide-backdrop]'))continue;
   const label=control.closest('label')||(control.previousElementSibling?.tagName==='LABEL'?control.previousElementSibling:null)||
    (control.parentElement?.previousElementSibling?.tagName==='LABEL'?control.parentElement.previousElementSibling:null);
   if(!label)continue;
   const labelText=controlLabel(control),key=fieldKey(control),button=el('button',{type:'button',class:'field-help-icon','aria-label':'Help for '+labelText,title:'What this field does',onclick:e=>{e.preventDefault();e.stopPropagation();openGuide(labelText,key);}},'?');
   label.append(button);control.dataset.helpAttached='true';
  }
 }
 function archiveLongHints(){
  let serial=0;
  for(const [step,pane]of Object.entries(panes)){
   if(step==='review')continue;
   for(const note of [...pane.querySelectorAll('p.hint')]){
    const text=note.textContent.replace(/\s+/g,' ').trim();
    if(text.length<125||note.hidden||note.closest('[data-field-guide-backdrop]'))continue;
    let heading=null;
    for(const h of pane.querySelectorAll('h3,h4'))if(h.compareDocumentPosition(note)&Node.DOCUMENT_POSITION_FOLLOWING)heading=h;
    archivedHelpNotes.push({id:'note-'+(++serial),group:TITLE[step],title:(heading?.textContent.trim()||TITLE[step])+' — details',purpose:'Reference note for '+(heading?.textContent.trim()||TITLE[step])+'.',body:text});
    note.remove();
   }
  }
 }
 const helpObserver=new MutationObserver(()=>installHelpIcons());
 helpObserver.observe(box,{childList:true,subtree:true});
 /* ---------- navigation ---------- */
 function show(key){key=LEGACY[key]||key;if(!panes[key])key='building';current=key;window.__mbdpSettingsTab=key;
  for(const [k,pane]of Object.entries(panes))pane.hidden=k!==key;
  nav.querySelectorAll('button[data-settings-tab]').forEach(b=>{b.classList.toggle('active',b.dataset.settingsTab===key);b.setAttribute('aria-selected',String(b.dataset.settingsTab===key));});
  const i=stepNo(key);stepNav.querySelector('.step-counter').textContent='Step '+i+' of '+STEPS.length;stepNav.querySelector('[data-step-nav="back"]').disabled=i<=1;stepNav.querySelector('[data-step-nav="next"]').hidden=i>=STEPS.length;
  if(key==='review')renderReview();
  const sc=box.closest('#modal_box');if(sc)sc.scrollTop=0;}
 function step(d){const i=stepNo(current)-1+d;if(STEPS[i])show(STEPS[i][0]);}
 // Save pre-check (capture phase, before the wizard's own handler): unmet requirements are shown on Review & save; nothing is sent.
 actions.addEventListener('click',e=>{const b=e.target.closest('button.primary');if(!b||!actions.contains(b))return;const issues=evaluate();if(issues.length){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();show('review');}},true);
 let pending=null;
 box.addEventListener('input',e=>{paintEcho(e.target);if(pending)return;pending=setTimeout(()=>{pending=null;evaluate();},80);});
 box.addEventListener('change',()=>update());
 box.querySelectorAll('input').forEach(paintEcho);
 draw();update();show(initial);archiveLongHints();installHelpIcons();renderGuideList();
};
