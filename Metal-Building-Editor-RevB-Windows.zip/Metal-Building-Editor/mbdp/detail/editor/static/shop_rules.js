/* Shop layout rules used by the frame wizard (mirror of mbdp/detail/standards.py).
 *
 *   MBRules.girtLines(eaveIn, foundation, walkDoor)   -> [inches...] (eave strut excluded)
 *   MBRules.girtLinesText(eaveIn, foundation, walkDoor) -> "4'-0\", 8'-0\""
 *   MBRules.endwallPostStations(widthIn)              -> [inches...] | null
 *
 * Wall girts: slab = base angle at the floor, girts evenly spaced at 5 ft maximum up to
 * the eave strut; post footing = no base angle, first girt 12 in above the floor then even
 * at 5 ft maximum; a walk door fixes the 7'-3" header girt (lines above it stay even).
 * tests/test_v0830_rules.py checks this file against the Python rule with node.
 */
window.MBRules = (() => {
  const GIRT_MAX = 60, HEADER = 87, FIRST_POST_FRAME = 12;
  const grid16 = x => Math.round(x * 16) / 16;
  function even(lo, hi, maximum = GIRT_MAX) {
    const run = hi - lo;
    if (run <= 0) return [];
    const n = Math.max(1, Math.ceil(Math.round(run * 16) / (maximum * 16)));
    const out = [];
    for (let i = 1; i < n; i++) out.push(grid16(lo + run * i / n));
    return out;
  }
  function girtLines(eaveIn, foundation = "slab", walkDoor = false) {
    const H = Number(eaveIn);
    if (!(H > 0)) return [];
    const slab = foundation !== "post_footing";
    const lines = [];
    let bottom = 0;
    if (!slab) { bottom = FIRST_POST_FRAME; if (bottom < H) lines.push(FIRST_POST_FRAME); }
    if (walkDoor && HEADER < H && HEADER > bottom) { lines.push(HEADER); bottom = HEADER; }
    for (const x of even(bottom, H)) lines.push(x);
    return [...new Set(lines)].sort((a, b) => a - b);
  }
  function girtLinesText(eaveIn, foundation, walkDoor) {
    return girtLines(eaveIn, foundation, walkDoor).map(x => window.MBDim.fmt(x)).join(", ");
  }
  const POSTS = { 20: [], 30: [15], 40: [20], 50: [20, 30] };
  function endwallPostStations(widthIn) {
    const ft = Number(widthIn) / 12;
    if (!Number.isInteger(ft) || !(ft in POSTS)) return null;
    return POSTS[ft].map(x => x * 12);
  }
  return { girtLines, girtLinesText, endwallPostStations, GIRT_MAX, HEADER, FIRST_POST_FRAME };
})();
