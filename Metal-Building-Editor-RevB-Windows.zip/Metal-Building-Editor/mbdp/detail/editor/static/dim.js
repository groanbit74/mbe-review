/* One client-side dimension grammar, mirroring mbdp/dims.py (_DIM_RE).
 *
 * Before this file existed the editor had two different grammars: the inline
 * property editor accepted `7 3/4"` but rejected `1-1/2`, while the building
 * wizard's private inches() silently mis-read anything it did not expect.
 * Both now defer to MBDim, and the server remains the final authority.
 *
 *   MBDim.ok(text)      -> true when the server will accept the text
 *   MBDim.inches(text)  -> number of inches (NaN when invalid)
 *   MBDim.fmt(inches)   -> canonical shop string, e.g. 147.5 -> 12'-3 1/2"
 */
window.MBDim = (() => {
  const RE = /^\s*([-+])?\s*(?:(\d+(?:\.\d+)?)\s*(?:'|ft\b|feet\b)\s*-?\s*)?(?:(\d+)(?:[\s-]+(\d+)\/(\d+))?|(\d+)\/(\d+)|(\d*\.\d+|\d+\.\d*))?\s*(?:"|''|in\b|inch\b|inches\b)?\s*$/;
  const normalise = t => String(t ?? "").replace(/[\u2019\u2032]/g, "'").replace(/[\u201d\u2033]/g, '"').replace(/''/g, '"');
  function parse(text) {
    const m = RE.exec(normalise(text));
    if (!m) return NaN;
    const [, sign, ft, whole, num, den, num2, den2, dec] = m;
    if (ft === undefined && whole === undefined && num2 === undefined && dec === undefined) return NaN;
    if (dec === ".") return NaN;
    let total = 0;
    if (ft !== undefined) total += Number(ft) * 12;
    if (whole !== undefined) {
      total += Number(whole);
      if (num !== undefined) { if (Number(den) === 0) return NaN; total += Number(num) / Number(den); }
    } else if (num2 !== undefined) {
      if (Number(den2) === 0) return NaN; total += Number(num2) / Number(den2);
    } else if (dec !== undefined) total += Number(dec);
    return sign === "-" ? -total : total;
  }
  function fmt(inches, denominator = 16) {
    if (!Number.isFinite(inches)) return "";
    const neg = inches < 0; let v = Math.abs(inches);
    let n = Math.round(v * denominator), d = denominator;
    while (d > 1 && n % 2 === 0) { n /= 2; d /= 2; }
    const totalWhole = Math.floor(n / d), fracN = n - totalWhole * d;
    const ft = Math.floor(totalWhole / 12), whole = totalWhole - ft * 12;
    let s;
    if (ft) s = `${ft}'-${whole}` + (fracN ? ` ${fracN}/${d}` : "") + '"';
    else if (whole && fracN) s = `${whole} ${fracN}/${d}"`;
    else if (fracN) s = `${fracN}/${d}"`;
    else s = `${whole}"`;
    return (neg ? "-" : "") + s;
  }
  // Owner's frame-bay rule (standards.standard_bays): 20 ft bays, never an equal subdivision;
  // the odd remainder is its own MIDDLE bay when it is 10 ft or more, otherwise it joins the middle bay.
  function standardBays(lengthIn, bay = 240, minOdd = 120) {
    const L = Number(lengthIn);
    if (!(L > 0)) return [];
    const k = Math.floor(L / bay + 1e-9), rem = L - k * bay;
    if (Math.abs(rem) < 1e-9) return Array.from({ length: k }, () => bay);
    if (k === 0) return [L];
    const bays = Array.from({ length: k }, () => bay);
    if (rem >= minOdd - 1e-9) bays.splice(Math.floor((k + 1) / 2), 0, rem); else bays[Math.floor(k / 2)] += rem;
    return bays;
  }
  return { ok: t => String(t ?? "").trim() === "" || Number.isFinite(parse(t)), inches: parse, fmt, RE, standardBays };
})();
