/* Resizable workbench: three panes + checks drawer, every one resizable and collapsible.
 *
 *   nav | drawing (+ checks/BOM drawer) | inspector
 *
 * Sizes and collapsed states are remembered per browser (localStorage).  app.js listens for the
 * 'mbdp:layout' event and re-fits the sheet when a pane changes size.  Building settings can dock
 * on the right (default) so a "Save & regenerate" shows its effect on the drawing immediately.
 *
 *   window.MBDPWorkbench.get()            current settings
 *   window.MBDPWorkbench.set({...})        patch + apply + remember
 *   window.MBDPWorkbench.toggle(name)      'nav' | 'props' | 'drawer' | 'focus'
 *   window.MBDPWorkbench.dockTop()         y of the main layout (docked panel starts there)
 */
(() => {
  const KEY = "mbdp.workbench.v1";
  const root = document.documentElement;
  const layout = document.querySelector("main.layout");
  const center = document.querySelector(".center");
  if (!layout || !center) return;
  const DEFAULTS = { nav: 220, props: 560, drawer: 190, navCollapsed: false, propsCollapsed: false, drawerCollapsed: false, dock: "right", dockW: 660 };
  const LIMITS = { nav: [150, 480], props: [320, 1100], drawer: [60, 700], dockW: [420, 1200] };
  let st = { ...DEFAULTS };
  try { st = { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY) || "{}") }; } catch (e) { /* ignore a corrupt entry */ }
  let focusBackup = null;
  const clamp = (k, v) => Math.min(LIMITS[k][1], Math.max(LIMITS[k][0], Math.round(v)));
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) { /* private mode */ } };

  function apply() {
    root.style.setProperty("--nav-w", st.nav + "px");
    root.style.setProperty("--props-w", st.props + "px");
    root.style.setProperty("--drawer-h", st.drawer + "px");
    root.style.setProperty("--dock-w", st.dockW + "px");
    layout.classList.toggle("nav-collapsed", !!st.navCollapsed);
    layout.classList.toggle("props-collapsed", !!st.propsCollapsed);
    center.classList.toggle("drawer-collapsed", !!st.drawerCollapsed);
    const focused = !!(st.navCollapsed && st.propsCollapsed && st.drawerCollapsed);
    for (const b of document.querySelectorAll("[data-view-toggle]")) {
      const k = b.dataset.viewToggle;
      b.classList.toggle("on", k === "focus" ? focused : k === "drawer" ? !st.drawerCollapsed : false);
    }
    const navBtn = document.querySelector('[data-collapse="nav"]'); if (navBtn) navBtn.textContent = st.navCollapsed ? "›" : "‹";
    const propsBtn = document.querySelector('[data-collapse="props"]'); if (propsBtn) propsBtn.textContent = st.propsCollapsed ? "‹" : "›";
    window.dispatchEvent(new CustomEvent("mbdp:layout", { detail: { ...st } }));
  }

  function set(patch) { Object.assign(st, patch); save(); apply(); }

  function toggle(name) {
    if (name === "nav") return set({ navCollapsed: !st.navCollapsed });
    if (name === "props") return set({ propsCollapsed: !st.propsCollapsed });
    if (name === "drawer") return set({ drawerCollapsed: !st.drawerCollapsed });
    if (name === "focus") {
      const focused = st.navCollapsed && st.propsCollapsed && st.drawerCollapsed;
      if (focused) { set(focusBackup || { navCollapsed: false, propsCollapsed: false, drawerCollapsed: false }); focusBackup = null; }
      else { focusBackup = { navCollapsed: st.navCollapsed, propsCollapsed: st.propsCollapsed, drawerCollapsed: st.drawerCollapsed }; set({ navCollapsed: true, propsCollapsed: true, drawerCollapsed: true }); }
    }
  }

  // ---- drag handling (pointer events; works for mouse, pen and touch) --------------------------
  function draggable(handle, { onStart, onMove, cursor }) {
    handle.addEventListener("pointerdown", e => {
      if (e.button !== 0 || e.target.closest("button")) return;
      e.preventDefault();
      const start = onStart(e);
      handle.setPointerCapture(e.pointerId);
      handle.classList.add("dragging");
      document.body.classList.add("dragging-splitter");
      document.body.style.cursor = cursor;
      const move = ev => onMove(ev, start);
      const up = () => {
        handle.classList.remove("dragging"); document.body.classList.remove("dragging-splitter"); document.body.style.cursor = "";
        handle.removeEventListener("pointermove", move); handle.removeEventListener("pointerup", up); handle.removeEventListener("pointercancel", up);
        save(); apply();
      };
      handle.addEventListener("pointermove", move); handle.addEventListener("pointerup", up); handle.addEventListener("pointercancel", up);
    });
  }

  for (const sp of document.querySelectorAll(".splitter")) {
    const which = sp.dataset.splitter;
    if (which === "nav") draggable(sp, { cursor: "col-resize", onStart: e => ({ x: e.clientX, w: st.navCollapsed ? 0 : st.nav }),
      onMove: (e, s) => { const w = s.w + (e.clientX - s.x); if (w < 90) { st.navCollapsed = true; } else { st.navCollapsed = false; st.nav = clamp("nav", w); } apply(); } });
    if (which === "props") draggable(sp, { cursor: "col-resize", onStart: e => ({ x: e.clientX, w: st.propsCollapsed ? 0 : st.props }),
      onMove: (e, s) => { const w = s.w - (e.clientX - s.x); if (w < 160) { st.propsCollapsed = true; } else { st.propsCollapsed = false; st.props = clamp("props", w); } apply(); } });
    if (which === "drawer") draggable(sp, { cursor: "row-resize", onStart: e => ({ y: e.clientY, h: st.drawerCollapsed ? 34 : st.drawer }),
      onMove: (e, s) => { const h = s.h - (e.clientY - s.y); if (h < 50) { st.drawerCollapsed = true; } else { st.drawerCollapsed = false; st.drawer = clamp("drawer", h); } apply(); } });
    sp.addEventListener("dblclick", () => {
      if (which === "nav") set({ nav: DEFAULTS.nav, navCollapsed: false });
      if (which === "props") set({ props: DEFAULTS.props, propsCollapsed: false });
      if (which === "drawer") set({ drawer: DEFAULTS.drawer, drawerCollapsed: false });
    });
  }
  for (const b of document.querySelectorAll("[data-collapse]")) b.addEventListener("click", () => toggle(b.dataset.collapse));
  for (const b of document.querySelectorAll("[data-view-toggle]")) b.addEventListener("click", () => toggle(b.dataset.viewToggle));

  // Docked settings panel: its left edge resizes the panel width.
  function dockHandle(box) {
    if (box.querySelector(".dock-handle")) return;
    const h = document.createElement("div"); h.className = "dock-handle"; h.title = "Drag to resize the settings panel";
    box.prepend(h);
    draggable(h, { cursor: "col-resize", onStart: e => ({ x: e.clientX, w: st.dockW }),
      onMove: (e, s) => { st.dockW = clamp("dockW", s.w - (e.clientX - s.x)); root.style.setProperty("--dock-w", st.dockW + "px"); } });
  }

  // Keyboard: F = focus mode (not while typing or while a dialog is open).
  window.addEventListener("keydown", e => {
    if (e.key !== "f" && e.key !== "F") return;
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const t = e.target; if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT" || t.isContentEditable)) return;
    const modal = document.getElementById("modal"); if (modal && !modal.classList.contains("hidden") && !modal.classList.contains("docked")) return;
    if (document.querySelector("dialog[open]")) return;
    e.preventDefault(); toggle("focus");
  });

  window.addEventListener("resize", () => window.dispatchEvent(new CustomEvent("mbdp:layout", { detail: { ...st } })));
  window.MBDPWorkbench = { get: () => ({ ...st }), set, toggle, dockHandle, dockTop: () => Math.round(layout.getBoundingClientRect().top), DEFAULTS };
  apply();
})();
