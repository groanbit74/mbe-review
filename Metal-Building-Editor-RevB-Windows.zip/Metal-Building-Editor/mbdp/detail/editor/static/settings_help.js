/* Building-settings field guide. Field records are keyed by the control's data-* hook;
   reference records preserve useful shop notes outside the normal setup flow. */
window.MBSettingsHelp = (() => {
  const fields = {
    'data-frame-field:width': {
      title: 'Building width', units: 'inches or feet',
      purpose: 'Sets the outside wall-to-wall width used to lay out the main frame and roof.',
      effect: 'For a new building, this selects the starting column and rafter sections from the width table. It does not size members structurally. Changing it recalculates managed geometry; manually changed sections stop following the table.'
    },
    'data-frame-field:length': {
      title: 'Building length', units: 'inches or feet',
      purpose: 'Sets the distance between the left and right endwall lines.',
      effect: 'Controls the building bay grid, longitudinal secondary runs, wall extents, and sheet takeoff length. Bay-enclosure mode owns this value and sets it to the sum of entered bay lengths.'
    },
    'data-frame-field:eave_height': {
      title: 'Eave height', units: 'inches or feet above floor',
      purpose: 'Sets the reference roof/eave elevation for the main frame.',
      effect: 'The controlling datum depends on construction: welded frames use the roofline/purlin reference; bolted frames use the top of the eave strut. Mono-slope high elevation is derived from width and pitch.'
    },
    'data-frame-field:slope_rise': {
      title: 'Roof pitch', units: 'rise per 12 inches',
      purpose: 'Sets the roof slope.', effect: 'Changes rafter geometry, roof elevation, purlin stations, and roof-sheet lengths.'
    },
    'data-frame-field:frame_type': {
      title: 'Roof shape', purpose: 'Chooses gable or mono-slope geometry.',
      effect: 'Changes end elevations and frame members. Existing managed frame marks have a fixed shape; use a new frame for a different shape.'
    },
    'data-frame-field:frames': {
      title: 'Interior fabrication lot', purpose: 'Sets the interior primary-frame quantity, separate from the bay count.',
      effect: 'For managed bay layouts, the editor derives this count from the bay grid. Endwall members are counted separately.'
    },
    'data-frame-field:column_section': {
      title: 'Main column section', purpose: 'Selects the section used for main/interior columns.',
      effect: 'A new building starts from the width table. Choosing a section manually stops width-based rescheduling. This is a member selection, not a capacity check.'
    },
    'data-frame-field:rafter_section': {
      title: 'Main rafter section', purpose: 'Selects the section used for main/interior rafters.',
      effect: 'A new building starts from the width table. Choosing a section manually stops width-based rescheduling. This is a member selection, not a capacity check.'
    },
    'data-frame-field:connection_style': {
      title: 'Connection construction', purpose: 'Chooses the welded shop standard or an explicit bolted option.',
      effect: 'Affects frame connection geometry, applicable fit rules, and supplier defaults. A saved deliberate choice stays selected when settings are reopened.'
    },
    'data-frame-field:welded_knee': {
      title: 'Welded rafter seat', purpose: 'Chooses how the welded rafter seats at the main column.',
      effect: 'Inside-flange is the shop standard. Outside-seat is an explicit alternative and changes column/rafter cuts and connection details.'
    },
    'data-frame-field:ridge_fabrication': {
      title: 'Gable ridge fabrication', purpose: 'Chooses the welded ridge treatment where applicable.',
      effect: 'The standard is a one-piece cut-and-fold W rafter. A shared ridge plate uses two rafter pieces; the apex-box option has its own geometry. Options are checked against the selected construction and section.'
    },
    'data-frame-field:purlin_mode': {
      title: 'Roof purlin fit', purpose: 'Chooses whether roof purlins sit on top of or flush with the rafter.',
      effect: 'BYPASS is the welded standard: purlins bear on the rafter top, and the roofline is the purlin top. FLUSH sets purlin tops level with the rafter top and changes clip/cut details.'
    },
    'data-frame-field:girt_mode': {
      title: 'Sidewall girt fit', purpose: 'Chooses bypass or flush fit at the main frame.',
      effect: 'Changes the girt reference plane and cut/attachment geometry. Flush is the welded shop standard; the section/attachment details remain separate inputs.'
    },
    'data-frame-field:girt_attachment': {
      title: 'Flush girt attachment', purpose: 'Chooses direct web welding or a stock clip for flush sidewall girts.',
      effect: 'Changes attachment pieces and fit geometry; it does not change the selected girt profile.'
    },
    'data-frame-field:auto_roof_spacing': {
      title: 'Automatic roof purlin spacing', purpose: 'Places roof purlin rows at equal intervals as the standard.',
      effect: 'Automatic mode divides the eave-to-peak/last-usable station distance equally, with no interval over 5 ft. Entering manual first-distance or interval values switches to manual mode.'
    },
    'data-frame-field:first_purlin': {
      title: 'First purlin distance', units: 'distance along the roof slope',
      purpose: 'Sets the first purlin station from the selected datum in manual mode.',
      effect: 'Editing it switches roof-row spacing from automatic to manual. The automatic mode remains available through “Return to automatic spacing”.'
    },
    'data-frame-field:purlin_spacing': {
      title: 'Manual purlin interval', units: 'distance along the roof slope',
      purpose: 'Sets repeated roof-row spacing in manual mode.',
      effect: 'Editing it switches roof-row spacing from automatic to manual; station rounding and geometric checks still apply.'
    },
    'data-frame-field:first_purlin_datum': {
      title: 'First purlin datum', purpose: 'Selects the physical reference for the first roof purlin distance.',
      effect: 'Changes the starting station, not the repeated interval. Available datums refer to the outside column, column face, or steel rafter cut.'
    },
    'data-frame-field:eave_start_clip': {
      title: 'Additional starting eave clip', purpose: 'Adds a starting clip at the outside edge of each eave bracket.',
      effect: 'Uses the selected purlin clip and mounting mode. It is added to the bracket bill of materials; it is not a substitute for or part of the first-purlin layout.'
    },
    'data-run-field:layout_mode': {
      title: 'Building bay layout', purpose: 'Sets how the building length is divided into bays.',
      effect: 'Automatic equal bays divide the length evenly using the selected maximum spacing. Explicit mode lets you change individual bay lengths; the entered lengths must total the building length.'
    },
    'data-run-field:bays': {
      title: 'Equal bay count', purpose: 'Sets the number of equal building bays in count mode.',
      effect: 'The building length is divided evenly by this count. The count is derived in automatic maximum-spacing mode.'
    },
    'data-run-field:max_spacing': {
      title: 'Maximum bay spacing', units: 'inches or feet',
      purpose: 'Sets the maximum length of an automatically divided bay; it is a layout limit, not a structural capacity.',
      effect: 'The editor chooses a bay count and equal bay lengths so no bay exceeds this spacing.'
    },
    'data-run-field:front_clearance': {
      title: 'Left-end terminal allowance', units: 'inches',
      purpose: 'Sets the terminal allowance for lapped secondary runs at the left end.',
      effect: 'Applies only to the relevant lapped run pattern; it does not change the master building length or support-line locations.'
    },
    'data-run-field:rear_clearance': {
      title: 'Right-end terminal allowance', units: 'inches',
      purpose: 'Sets the terminal allowance for lapped secondary runs at the right end.',
      effect: 'Applies only to the relevant lapped run pattern; it does not change the master building length or support-line locations.'
    },
    'data-run-field:enabled': {
      title: 'Automatic secondary runs (Advanced exception)', purpose: 'The standard is to generate the roof, sidewall, and eave secondary runs from the building bay grid.',
      effect: 'The Advanced opt-out turns off the managed bay/run system. Use it only when the job will be detailed with manual run inputs; the bay grid and generated setout are not retained by the current generator.'
    },
    'data-welded-fit-override:': {
      title: 'Nonstandard welded-fit override', purpose: 'Explicitly opts this frame out of the Owner welded fit rule.',
      effect: 'Unchecked means the welded standard applies automatically. The override is per frame and does not change the separate flush-fit rule.'
    },
    'data-cladding-field:enabled': {
      title: 'Sheet and trim takeoff', purpose: 'Enables per-elevation wall and roof sheet/trim takeoff.',
      effect: 'Bay enclosure owns this setting when active; open/future bays are omitted from the takeoff. Counts are for one building, not multiplied by frame quantity. Panel splice design and net-area-only counts are not generated.'
    },
    'data-addition-field:opening_auto': {
      title: 'Opening clearance check', purpose: 'Checks opening clearance to other uprights.',
      effect: 'A permitted relocation stays within the selected bay. This check is separate from placement; it does not design or remove framing.'
    },
    'data-addition-field:*_surface': {
      title: 'Opening elevation', purpose: 'Selects the wall/elevation where the opening is located.',
      effect: 'Coordinates use the outside view of that elevation. The preview updates when the elevation changes.'
    },
    'data-addition-field:*_placement': {
      title: 'Opening placement mode', purpose: 'Chooses centered in bay, offset from bay center, whole-wall centered, or entered X.',
      effect: 'Door and overhead-door presets start centered in bay 1. Whole-wall centering and entered X follow their own placement rules.'
    },
    'data-addition-field:*_bay': {
      title: 'Opening bay', purpose: 'Selects the bay that contains the opening.',
      effect: 'Centered and offset modes locate the opening relative to this bay. The opening must fit inside an existing bay on the selected elevation.'
    },
    'data-addition-field:*_bay_offset': {
      title: 'Opening offset', units: 'inches or feet; negative is left, positive is right',
      purpose: 'Shifts the opening from the center of the selected bay.',
      effect: 'Used only in offset mode. The preview updates as the offset is edited.'
    },
    'data-addition-field:*_x': {
      title: 'Opening X coordinate', units: 'inches or feet from the elevation’s stated outside-view origin',
      purpose: 'Sets or displays the opening start position.',
      effect: 'Selecting entered-X mode preserves this position; centered and offset modes derive X from the selected bay.'
    },
    'data-addition-field:*_y': {
      title: 'Opening bottom elevation', units: 'inches or feet above floor',
      purpose: 'Sets the opening bottom above floor.', effect: 'Changes the vertical location and clear-height extent used by opening checks and drawings.'
    },
    'data-addition-field:*_width': {
      title: 'Opening clear width', purpose: 'Sets clear width between jamb faces.',
      effect: 'Controls the aperture size, placement center, and opening clearance checks. It is not a nominal door size.'
    },
    'data-addition-field:*_height': {
      title: 'Opening clear height', purpose: 'Sets clear height to the header face.',
      effect: 'Controls the aperture size and opening checks; jamb extent and header settings are separate choices.'
    },
    'data-addition-field:*_coordinate_girts': {
      title: 'Coordinate endwall girts/base angles at jambs', purpose: 'Breaks affected endwall girt or base-angle runs at the opening jambs.',
      effect: 'The setting coordinates run segments with the jamb locations. Exact final member cuts remain held for review; this does not alter the opening location or create jamb members.'
    },
    'data-frame-field:peak_clip_edge': {
      title: 'Peak clip nearest edge from ridge', units: 'distance along roof slope',
      purpose: 'Sets the near-edge station for the apex/peak clip.', effect: 'Changes the clip station on the roof slope; a clearance conflict is reported for review and does not silently move the clip.'
    },
    'data-run-field:purlin_lay': {
      title: 'Purlin stock-length layout', purpose: 'Chooses whether purlin sticks span multiple complete bays or use one piece per bay.',
      effect: 'Joints remain at rafter centerlines. This controls longitudinal stock-piece layout, not roof-slope row spacing.'
    },
    'data-run-field:purlin_lap_in': {
      title: 'Zee lap over each rafter', units: 'total lap in inches',
      purpose: 'Sets the total Zee overlap centered on each intermediate rafter.', effect: 'Applies to the purlin stick joint at that rafter; it is separate from roof-row spacing and any manufacturer lap pattern.'
    },
    'data-run-field:purlin_pattern': {
      title: 'Purlin lap pattern', purpose: 'Selects the longitudinal lap/butt sequence used by the run layout.',
      effect: 'Controls piece stationing and laps along the building length; it does not set roof-slope purlin-row intervals.'
    },
    'data-run-field:girt_pattern': {
      title: 'Girt lap pattern', purpose: 'Selects the longitudinal lap/butt sequence used by the sidewall girt runs.',
      effect: 'Controls piece stationing and laps along the building length; it does not set vertical girt elevations.'
    },
    'data-run-field:purlin_direction': {
      title: 'Purlin offset direction', purpose: 'Sets which end starts the selected run-pattern sequence.',
      effect: 'Changes the longitudinal pattern direction only.'
    },
    'data-run-field:girt_direction': {
      title: 'Girt offset direction', purpose: 'Sets which end starts the selected run-pattern sequence.',
      effect: 'Changes the longitudinal pattern direction only.'
    },
    'data-secondary-role:purlin': {title:'Roof purlin product',purpose:'Selects the catalog purlin profile used by automatic roof runs.',effect:'The nominal profile informs member depth and material references. Catalog selection is not capacity approval.'},
    'data-secondary-role:girt': {title:'Sidewall girt product',purpose:'Selects the catalog girt profile used by automatic wall runs.',effect:'The nominal profile informs member depth and optional inset/fit references. Catalog selection is not capacity approval.'},
    'data-secondary-role:endwall_girt': {title:'Endwall girt product',purpose:'Selects a separate endwall girt profile or follows the sidewall girt when blank.',effect:'Affects endwall member profile and cut references; it does not create endwall framing.'},
    'data-secondary-role:eave': {title:'Eave secondary product',purpose:'Selects the catalog eave/strut product for automatic eave runs.',effect:'The nominal profile drives reference depth and material data; actual seat fit is not inferred.'},
    'data-settings-help-key:secondary-run-optout': {title:'Disable automatic secondary runs (Advanced exception)',purpose:'Opts this frame out of the automatic secondary generator.',effect:'The current generator also turns off the managed bay grid. Use only when the job will use manual run inputs.'},
    'data-wall-state:*': {title:'Wall enclosure state',purpose:'Chooses whether this elevation is sheeted or open.',effect:'Sheeted walls receive the applicable wall framing and takeoff. Open walls omit wall sheets and their associated girts/base angle; endwall framing choices are handled separately.'},
    'data-bay-length:*': {title:'Individual building bay length',units:'inches or feet',purpose:'Overrides the automatic equal length for this particular bay.',effect:'Changing one bay switches the layout to explicit lengths. The sum of all bay lengths must match the building length.'},
    'data-zone-field:*_length': {title:'Enclosure bay length',units:'inches or feet',purpose:'Sets the length of this bay in the enclosure plan.',effect:'All enclosure bay lengths must total the master building length; sidewall states are also assigned by bay.'},
    'data-zone-field:*_right': {title:'Front sidewall state for this bay',purpose:'Sets whether the front sidewall is sheeted, open, or future in this bay.',effect:'Open/future wall areas are excluded from the current sheet takeoff.'},
    'data-zone-field:*_left': {title:'Back sidewall state for this bay',purpose:'Sets whether the back sidewall is sheeted, open, or future in this bay.',effect:'Open/future wall areas are excluded from the current sheet takeoff.'}
  };

  const references = [
    {id:'wall-directions',group:'Building & bays',title:'Wall names and outside-view origins',body:'Front and back are the long sidewalls; left and right are the endwalls. Opening X is measured from the left as drawn for that selected outside view. The opening preview labels the elevation and its origin.'},
    {id:'frame-datum',group:'Building & bays',title:'Eave datum and managed frame shape',body:'The eave reference differs by construction: welded uses the roof/purlin datum; bolted uses the top of the eave strut. Managed frame marks keep their established shape; use a new frame to create a different shape. This is a reference constraint, not a routine setup choice.'},
    {id:'width-table',group:'Main frames',title:'Width schedule is a starting selection, not structural sizing',body:'New buildings start with: 20 ft → W8×10; 30 ft → W10×12; 40 ft → W12×14; 50 ft → W12×19. Manual section selection is allowed and stops automatic rescheduling. This schedule does not check capacity.'},
    {id:'welded-standard',group:'Main frames',title:'Owner welded standard: ridge, seat, and roofline',body:'The default is fully welded with the one-piece cut-and-fold ridge when applicable. The standard seat is inside-flange: the rafter meets the inside column flange and the column reaches the rafter top line at eave height. The welded roofline is the top of the purlin. BYPASS places purlins on the rafter top; FLUSH aligns purlin tops with the rafter top and changes clip/cut details. Ridge plates, outside seats, bolted brackets, and the apex-box option are explicit alternatives. These defaults set fabrication geometry; they do not constitute a structural approval.'},
    {id:'secondary-spacing',group:'Roof & secondaries',title:'Two different spacing directions',body:'Building bays and secondary runs are spaced along the building length. Roof purlin rows are spaced across the roof slope. Automatic modes handle both by default; do not use one spacing input as a substitute for the other.'},
    {id:'run-supports',group:'Roof & secondaries',title:'Endwall support assumptions are not endwall generators',body:'Left/right endwall support fields describe assumed support conditions for along-building secondary runs. They do not create endwall columns, rafters, or girts. Endwall members and their setout are controlled in the Endwalls step.'},
    {id:'start-clip',group:'Roof & secondaries',title:'Additional starting eave clip',body:'Adds one selected purlin clip at the outside edge of each eave bracket and includes it in the bracket bill of materials. It does not replace the first-purlin station.'},
    {id:'endwall-open',group:'Endwalls',title:'Open endwall and interior posts',body:'An open endwall has no interior posts by default; its end rafter spans between the corner columns. Interior end posts can be retained with the explicit end-post setting. This affects endwall framing, not the sidewall bay layout.'},
    {id:'opening-jambs',group:'Openings',title:'Coordinate endwall runs at opening jambs',body:'When enabled, endwall girt and base-angle runs are segmented at opening jambs so their layout follows the opening boundary. Exact cut lengths are still review-held. The checkbox does not place the door or add jamb members.'},
    {id:'sheet-takeoff',group:'Sheets & trim',title:'Sheet and trim takeoff scope',body:'Takeoff is per elevation/roof and per building. Open/future bays are excluded when bay enclosure owns the takeoff. The current takeoff does not create automatic panel splices or net-area-only sheet counts. Counts are not multiplied by the number of frames.'},
    {id:'ridge-seat-detail',group:'Main frames',title:'Detailed welded ridge and rafter-seat rule',body:'For an applicable W-rafter gable, the cut-and-fold ridge keeps one rafter piece: the wedge is 2 × rafter depth × tan(pitch), measured at the bottom flange; it is cut from the bottom flange/web, the rafter is folded on the top flange and the seam is welded. The wedge is part of the blank length. The standard inside-flange seat uses a 3/16 in top bearing plate and 3 in along-pitch rafter overlap; the column reaches the rafter top line at eave height, so its cut does not deduct rafter or purlin depth. Outside-seat, shared ridge plate, welded apex box, and bolted connections are alternatives. Verify generated details before fabrication.'},
    {id:'purlin-fit-detail',group:'Roof & secondaries',title:'Purlin fit and roofline details',body:'For welded frames, BYPASS is standard: purlins bear on the rafter top flange, so the roofline is the top of the purlin; column/eave cuts account for the selected fit. FLUSH is an explicit alternative: on wide-flange rafters the purlin is web-clip supported and clear of the flange edge; in an open-face channel, it sits inside the channel with the specified web clearance. The selected fit changes cuts and attachment details. It does not change the building bay spacing.'},
    {id:'purlin-datum-detail',group:'Roof & secondaries',title:'Purlin/clip station datums',body:'The outside_column datum measures along slope from the outside column face/top-line intersection to the steel cut. column_face uses the legacy inside-face datum; rafter_cut measures directly from the steel cut end. Stations round to 1/16 in. Clip-to-plate clearances below 3 in warn for review rather than moving the clip. The purlin profile is not a full structural model.'},
    {id:'eave-starting-clip-detail',group:'Roof & secondaries',title:'Starting clip versus first purlin',body:'The additional starting clip is a separate bracket item aligned to the outside-building edge of each eave bracket. It is added to the bracket bill of materials and does not replace or move the first purlin station.'},
    {id:'supplier-choice',group:'Sheets & trim',title:'Supplier defaults by construction',body:'The shop supplier rule is SSS for welded buildings and MBCI for bolted buildings. Supplier product choices are shown in the relevant profile/product controls; a product catalog entry is a nominal reference, not an approval of gauge thickness, bend radii, exact fit, or capacity.'}
  ];

  const match = control => {
    const helpKey=control.getAttribute('data-settings-help-key');if(helpKey&&fields['data-settings-help-key:'+helpKey])return fields['data-settings-help-key:'+helpKey];
    for (const attr of ['data-frame-field','data-run-field','data-welded-fit-override','data-cladding-field','data-addition-field','data-end-field','data-zone-field','data-wall-state','data-bay-length','data-secondary-role','data-preset-field','data-frame-connection-override','data-base-angle']) {
      if (!control.hasAttribute(attr)) continue;
      const value = control.getAttribute(attr) || '';
      const exact = attr+':'+value;
      if (fields[exact]) return fields[exact];
      const wildcard = Object.keys(fields).find(k => k.startsWith(attr+':*') && value.endsWith(k.slice((attr+':*').length)));
      if (wildcard) return fields[wildcard];
    }
    return null;
  };
  return {fields,references,match};
})();
