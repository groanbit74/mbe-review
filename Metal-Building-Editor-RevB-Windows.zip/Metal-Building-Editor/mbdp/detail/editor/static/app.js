/* MBDP detailing editor – vanilla JS, whole-job model edited client-side and saved with PUT /api/job. */
(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const el = (tag, attrs = {}, ...kids) => {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) {
      if (k === "class") n.className = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else if (k === "html") n.innerHTML = v;
      else if (v !== undefined && v !== null) n.setAttribute(k, v);
    }
    for (const k of kids.flat()) if (k !== null && k !== undefined) n.append(k.nodeType ? k : document.createTextNode(k));
    return n;
  };

  const FACE_NAMES={front:'Left endwall',rear:'Right endwall',right:'Front sidewall',left:'Back sidewall',roof_right:'Front roof',roof_left:'Back roof',roof_mono:'Mono roof',roof_shared:'Shared ridge'};
  const faceName=k=>FACE_NAMES[k]||k;
  const SHEET_GROUPS={frameline:'Frame lines',sidewall:'Frame lines',roofplan:'Frame lines',
    building:'Building & frames',frame:'Building & frames',ridge:'Building & frames',welded_eave:'Building & frames',
    endwall:'Endwalls',endcuts:'Endwalls',endjoint:'Endwalls',additions:'Lean-tos & framing additions',
    runs:'Secondaries',run_cuts:'Secondaries',secondaries:'Secondaries',cladding:'Sheets & trim',
    order:'Materials & order',materials:'Materials & order',cut:'Member cut sheets',plate:'Plates, clips & connections',connection:'Plates, clips & connections'};
  // The master order is an HTML page in the drawing pane (Tier 2 #10), not a modal and not a sheet.
  const MATERIALS_PAGE={kind:'materials',name:'order',title:'Master order table (page)'};
  const S = { state: null, sel: { type: "assembly", name: null }, sheet: { kind: "assembly", name: null }, zoom: 0.75, saveTimer: null, dirty: false };

  // ------------------------------------------------------------------ server
  // The page's own version travels with every call; the server refuses calls from a page of
  // another version (a browser-cached copy of an earlier editor) instead of letting it fail.
  const PAGE_VERSION = document.querySelector('meta[name="editor-version"]')?.content || "";
  async function api(method, url, body) {
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json", "X-Editor-Version": PAGE_VERSION }, body: body ? JSON.stringify(body) : undefined });
    let j;
    try { j = await r.json(); }
    catch (e) { throw new Error(`The editor did not answer ${method} ${url} (HTTP ${r.status}). Is another program using this port? Close other editor windows and start again.`); }
    if (!r.ok || j.error) {
      if (j.stale_page) { stalePage(j); }
      if(j.diagnostic) rejectedInput(j.diagnostic);
      const err = new Error(j.error || r.statusText);
      if (r.status === 409 || j.conflict) { err.conflict = true; err.revision = j.revision; }
      if (j.stale_page) err.stale_page = true;
      throw err;
    }
    return mergeCatalog(j);
  }
  let staleShown = false;
  function stalePage(j) {
    if (staleShown) return; staleShown = true;
    openModal(el("div", {}, el("h2", {}, "Reload this page"),
      el("p", {}, `This tab is showing editor page v${PAGE_VERSION || "?"} but the editor that is running is v${j.server_version || "?"}. The page must be reloaded before it can be used; your saved jobs are not affected.`),
      el("div", { class: "btnrow" }, el("button", { class: "primary", onclick: () => location.reload() }, "Reload now"))));
  }
  // Static libraries (sections, products, rule evidence ~290 KB) are fetched once from
  // GET /api/catalog; every save/regenerate response carries only the job-dependent part.
  function mergeCatalog(st) {
    if (!st || typeof st !== "object" || !("catalog_partial" in st)) return st;
    if (st.catalog_partial && S.catalog) {
      st.catalog = { ...S.catalog.catalog, ...(st.catalog || {}) };
      st.product_libraries = S.catalog.product_libraries;
      st.plate_rule_evidence = S.catalog.plate_rule_evidence;
      st.catalog_partial = false;
    } else if (!st.catalog_partial && !S.catalog) {
      S.catalog = { catalog: st.catalog, product_libraries: st.product_libraries, plate_rule_evidence: st.plate_rule_evidence };
    }
    return st;
  }
  function setStatus(txt, cls = "") { const s = $("#status"); s.textContent = txt; s.className = "status " + cls; }

  async function load() {
    if (!S.catalog) S.catalog = await api("GET", "/api/catalog");
    S.state = await api("GET", "/api/job");
    if (!S.sel.name || !(S.state.job.assemblies[S.sel.name] || S.state.job.parts[S.sel.name])) {
      const first = Object.keys(S.state.job.assemblies)[0];
      S.sel = { type: "assembly", name: first || null };
      S.sheet = { kind: "assembly", name: first || null };
    }
    renderAll();
  }

  function scheduleSave(event = "edit") {
    S.dirty = true;
    setStatus("unsaved changes…");
    clearTimeout(S.saveTimer);
    S.saveTimer = setTimeout(() => save(event), 700);
  }

  async function save(event = "edit") {
    if(document.querySelector("input.bad")){setStatus("Fix the highlighted invalid dimension before saving. Draft retained.","err");return;}
    try {
      // base_revision = the revision this window edited from; the server refuses (409) when another
      // window or the job list replaced the job in the meantime, instead of overwriting it.
      const st = await api("PUT", "/api/job", { job: S.state.job, event, base_revision: S.state.revision });
      S.state = st; S.dirty = false;
      const rel=st.release;
      setStatus(st.blocked ? "saved – model has errors (release blocked)" : rel&&!rel.complete ? "saved – rev " + st.revision + " – RELEASE CHECK: " + rel.status : "saved – rev " + st.revision, st.blocked ? "err" : rel&&!rel.complete ? "warn" : "ok");
      renderAll(true);
    } catch (e) {
      if (e.conflict) { await saveConflict(e); return; }
      setStatus("not saved: " + e.message, "err");
    }
  }

  async function saveConflict(e) {
    setStatus("not saved – the job changed elsewhere (now " + e.revision + ")", "err");
    const reload = confirm(
      "This job was changed in another window or from the job list since you loaded it.\n\n" +
      "Reload the latest saved version? Your unsaved edits in this window will be discarded.\n" +
      "Choose Cancel to keep editing here (nothing is saved until you reload)."
    );
    if (!reload) return;
    S.dirty = false;
    await load();
    setStatus("reloaded – rev " + S.state.revision, "ok");
  }

  // ------------------------------------------------------------------ rendering: lists
  function issuesFor(mark) { return (S.state.issues || []).filter(i => i.assembly === mark); }
  function dotFor(mark) {
    const is = issuesFor(mark);
    const cls = is.some(i => i.severity === "error") ? "err" : is.some(i => i.severity === "warning") ? "warn" : "";
    return el("span", { class: "dot " + cls });
  }

  function renderLists() {
    const job = S.state.job;
    const al = $("#asm_list"); al.innerHTML = "";
    for (const a of Object.values(job.assemblies)) {
      al.append(el("li", { class: S.sel.type === "assembly" && S.sel.name === a.mark ? "sel" : "", onclick: () => select("assembly", a.mark) },
        dotFor(a.mark), a.mark, el("span", { class: "sub" }, `${a.kind} ×${a.qty}`)));
    }
    // Sheets grouped by kind (the flat list reached 36+ rows for a one-frame building).
    const sl = $("#sheet_list"); sl.innerHTML = "";
    const groups = new Map();
    // Frame lines first: one elevation per frame line, both sidewalls and the roof plan.
    if (S.state.sheets.some(s => SHEET_GROUPS[s.kind] === "Frame lines")) groups.set("Frame lines", []);
    for (const sh of [MATERIALS_PAGE, ...S.state.sheets.filter(s => s.kind !== "assembly")]) {
      const g = SHEET_GROUPS[sh.kind] || "Other";
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(sh);
    }
    S.sheetGroupsOpen ||= {};
    for (const [label, items] of groups) {
      const holdsSel = items.some(sh => S.sheet.kind === sh.kind && S.sheet.name === sh.name);
      const open = S.sheetGroupsOpen[label] ?? (holdsSel || items.length <= 4);
      const ul = el("ul", {}, ...items.map(sh => el("li", { class: S.sheet.kind === sh.kind && S.sheet.name === sh.name ? "sel" : "", onclick: () => showSheet(sh.kind, sh.name) }, sh.title)));
      const d = el("details", open ? { open: "" } : {}, el("summary", {}, label, el("span", { class: "cnt" }, "(" + items.length + ")")), ul);
      d.addEventListener("toggle", () => { S.sheetGroupsOpen[label] = d.open; });
      sl.append(el("li", { class: "grp" }, d));
    }
  }

  function select(type, name) {
    if(document.querySelector("input.bad")){setStatus("Correct the invalid draft before changing selection.","err");return;}
    S.sel = { type, name };
    if (type === "assembly") S.sheet = { kind: "assembly", name };
    else if (type === "part") {
      const p = S.state.job.parts[name];
      if (p && (p.kind === "plate" || p.kind === "clip")) S.sheet = { kind: "plate", name };
      if (p?.symbol?.connection) S.sheet = {kind:"connection",name};
    }
    renderAll();
  }
  function showSheet(kind, name) { S.sheet = { kind, name }; renderPreview(); renderLists(); renderTabs(); renderIssues(); }

  // ------------------------------------------------------------------ preview
  function sheetUrl(ext) { return `/api/sheet/${S.sheet.kind}/${encodeURIComponent(S.sheet.name)}.${ext}?r=${encodeURIComponent(S.state.revision)}`; }
  async function renderPreview() {
    const request= S.previewRequest=(S.previewRequest||0)+1;
    const wrap = $("#svgwrap"), page = $("#page"), pageMode = S.sheet.kind === "materials";
    page.classList.toggle("hidden", !pageMode); wrap.classList.toggle("hidden", pageMode);
    document.querySelector(".center .toolbar")?.classList.toggle("page-mode", pageMode); $("#preview").classList.toggle("page-mode", pageMode);
    if (pageMode) { await renderMaterialsPage(request); return; }
    if (!S.sheet.name) { wrap.innerHTML = "<div style='padding:40px;color:#666'>No sheet selected</div>"; return; }
    try {
      const r = await fetch(sheetUrl("svg"));
      if (!r.ok) { const j = await r.json(); throw new Error(j.error + "\n" + (j.trace || "")); }
      const svg=await r.text();if(request!==S.previewRequest)return;
      wrap.innerHTML = svg;
    } catch (e) {
      if(request!==S.previewRequest)return;
      wrap.innerHTML = `<div class="err-box" style="margin:30px">Drawing could not be generated:\n${e.message}</div>`;
    }
    $("#dl_pdf").href = sheetUrl("pdf"); $("#dl_dxf").href = sheetUrl("dxf"); $("#dl_svg").href = sheetUrl("svg");
    $("#dl_dxf").setAttribute("download", `${({frame:"FRAME-",ridge:"RIDGE-"}[S.sheet.kind]||"")}${S.sheet.name}.dxf`);
    const cutPart=S.sheet.kind==="plate" && S.state.job.parts[S.sheet.name]?.symbol?.cut_contour;
    for(const ext of ["dxf","svg"]) {
      const link=$("#dl_cut_"+ext);link.classList.toggle("hidden",!cutPart);
      link.href=`/api/contour/${encodeURIComponent(S.sheet.name)}.${ext}?units=inch`;
      link.setAttribute("download",`${S.sheet.name}.inch.review.${ext}`);
    }
    applyZoom();
  }
  function applyZoom() {
    if (S.sheet.kind === "materials") return;
    const w = $("#svgwrap"), pv = $("#preview"); w.style.transform = `scale(${S.zoom})`;
    w.style.marginBottom = `${792 * (S.zoom - 1)}px`; w.style.marginRight = `${1224 * (S.zoom - 1)}px`;
    // centre the sheet horizontally when it is narrower than the drawing pane
    w.style.marginLeft = `${Math.max(0, Math.floor((pv.clientWidth - 28 - 1224 * S.zoom) / 2))}px`;
  }
  function zoomFit() {
    const pv = $("#preview"); if (!pv.clientWidth || S.sheet.kind === "materials") return;
    // Whole sheet visible: fit width AND height of the drawing pane (the sheet is 1224 x 792 px).
    S.zoom = Math.max(0.2, Math.min((pv.clientWidth - 30) / 1224, Math.max(120, pv.clientHeight - 30) / 792)); S.fitMode = true; applyZoom();
  }
  // Pane resize / collapse (workbench.js) or window resize: keep the sheet fitted unless the user zoomed by hand.
  let fitTimer = null;
  window.addEventListener("mbdp:layout", () => { if (S.fitMode === false) return; clearTimeout(fitTimer); fitTimer = setTimeout(zoomFit, 40); });
  if (window.ResizeObserver) new ResizeObserver(() => { if (S.fitMode !== false) { clearTimeout(fitTimer); fitTimer = setTimeout(zoomFit, 40); } }).observe($("#preview"));

  // The tab strip shows the views of the thing being looked at (spec: no stacking of every
  // building sheet on every member).  Building-level sheets are reached from the Sheets list
  // or the sidebar and then show their own family here.
  const FRAME_KINDS = new Set(["building", "frame", "ridge", "welded_eave", "frameline", "sidewall", "roofplan"]);
  const fidOf = name => String(name || "").split("~")[0];
  function endLabel(kind, name) {
    const end = String(name).split("~")[1] || "";
    const side = { front_end: "Left endwall", rear_end: "Right endwall", outer_front_end: "Outer left end", outer_rear_end: "Outer right end" }[end] || end;
    return kind === "endcuts" ? side.replace(/endwall|end$/, "end cuts") : kind === "endjoint" ? side + " joint" : side;
  }
  function sheetTabs(pred, title) {
    return S.state.sheets.filter(pred).map(sh => [sh.kind, sh.name, title ? title(sh) : sh.title]);
  }
  function tabFamily() {
    const k = S.sheet.kind, n = S.sheet.name, job = S.state.job;
    if (k === "materials" || k === "order")
      return ["Materials", [["materials", "order", "Order table"], ...sheetTabs(sh => sh.kind === "order", sh => sh.title.replace(/^ORDER\s+/, "").replace(/_/g, " "))]];
    if (FRAME_KINDS.has(k)) {
      const fid = fidOf(n), L = job.settings.frame_layouts?.[fid] || {}, tabs = [];
      if (L.building_geometry) tabs.push(["building", fid, "Building dimensions / orientation"]);
      if (job.settings.frame_layouts?.[fid]) tabs.push(["frame", fid, "Whole frame"]);
      tabs.push(...sheetTabs(sh => sh.kind === "frameline" && fidOf(sh.name) === fid, sh => "Frame line " + sh.line));
      tabs.push(...sheetTabs(sh => sh.kind === "sidewall" && fidOf(sh.name) === fid, sh => sh.name.endsWith("front") ? "Front sidewall" : "Back sidewall"));
      tabs.push(...sheetTabs(sh => sh.kind === "roofplan" && sh.name === fid, () => "Roof plan"));
      if (L.welded) tabs.push(["welded_eave", fid, "Welded eave detail"]);
      if (L.peak_clip) tabs.push(["ridge", fid, "Ridge / peak clips"]);
      return ["FRAME " + fid, tabs];
    }
    if (k === "endwall" || k === "endcuts" || k === "endjoint") {
      const fid = fidOf(n);
      return ["Endwalls " + fid, sheetTabs(sh => (sh.kind === "endwall" || sh.kind === "endcuts" || sh.kind === "endjoint") && fidOf(sh.name) === fid, sh => endLabel(sh.kind, sh.name))];
    }
    if (k === "secondaries" || k === "runs" || k === "run_cuts") {
      const fid = fidOf(n);
      return ["Secondaries " + fid, sheetTabs(sh => ["secondaries", "runs", "run_cuts"].includes(sh.kind) && fidOf(sh.name) === fid, sh => ({ secondaries: "Supplier secondary profiles", runs: "Secondary runs", run_cuts: "Run cut list" })[sh.kind])];
    }
    if (k === "cladding") { const fid = fidOf(n); return ["Sheets & trim " + fid, sheetTabs(sh => sh.kind === "cladding" && fidOf(sh.name) === fid)]; }
    if (k === "additions") { const fid = fidOf(n); return ["Lean-tos & framing " + fid, sheetTabs(sh => sh.kind === "additions" && fidOf(sh.name) === fid)]; }
    // member-level kinds: assembly, cut, plate, connection -> the member (or connection) being looked at
    const asmMark = k === "assembly" ? n : k === "cut" ? Object.values(job.assemblies).find(a => a.main?.mark === n)?.mark
      : S.sel.type === "assembly" ? S.sel.name : null;
    if (asmMark && job.assemblies[asmMark]) {
      const a = job.assemblies[asmMark], fid = a.derivation?.frame_id, tabs = [];
      if (fid && job.settings.frame_layouts?.[fid]) tabs.push(["frame", fid, "Whole frame"]);
      tabs.push(["assembly", a.mark, "Assembly sheet " + a.mark], ["cut", a.main.mark, "Cut sheet " + a.main.mark]);
      const bomParts = new Set((S.state.bom[a.mark] || []).map(l => l.part));
      for (const m of bomParts) { const p = job.parts[m]; if (p && (p.kind === "plate" || p.kind === "clip")) tabs.push(["plate", m, "Piece " + m]); }
      return [a.mark, tabs];
    }
    if (S.sel.type === "part" && (job.parts[S.sel.name]?.symbol?.connection || job.parts[S.sel.name]?.symbol?.owner)) {
      const p = job.parts[S.sel.name]; const owner = p.symbol.connection ? p.mark : p.symbol.owner; const root = job.parts[owner];
      const tabs = [["connection", owner, owner], ...[...new Set(root.attachments.map(a => a.part))].map(nm => ["plate", nm, nm])];
      if (root.symbol.mate) tabs.push(["plate", root.symbol.mate, root.symbol.mate]);
      return ["Connection " + owner, tabs];
    }
    if (S.sel.type === "part" && job.parts[S.sel.name]) return ["Part " + S.sel.name, n ? [[k, n, "Piece " + n]] : []];
    return [n ? k : "", n ? [[k, n, `${k} ${n}`]] : []];
  }
  function renderTabs() {
    const t = $("#sheet_tabs"); t.innerHTML = "";
    const [label, tabs] = tabFamily();
    if (label) t.append(el("span", { class: "tabs-label", "data-tabs-label": "" }, label));
    for (const [kind, name, title] of tabs)
      t.append(el("button", { class: (S.sheet.kind === kind && S.sheet.name === name) ? "sel" : "", "data-tab": kind + ":" + name, onclick: () => showSheet(kind, name) }, title));
  }

  function locateFields(fields,root=document,tone='error',message='') {
    document.querySelectorAll('.issue-inline').forEach(n=>n.remove());
    document.querySelectorAll('.issue-target,.review-target,.issue-section,.issue-tab,.review-section,.review-tab').forEach(n=>{n.classList.remove('issue-target','review-target','issue-section','issue-tab','review-section','review-tab');n.removeAttribute('aria-invalid');n.removeAttribute('aria-describedby');});
    let first=null;
    for(const f of fields||[]) for(const n of root.querySelectorAll('['+f.attribute+']')) if(n.getAttribute(f.attribute)===f.value){
      n.classList.add(tone==='review'?'review-target':'issue-target');if(tone!=='review')n.setAttribute('aria-invalid','true');first ||= n;
      for(let a=n.parentElement;a&&a!==root;a=a.parentElement)if(a.tagName==='DETAILS'){a.open=true;a.classList.add(tone==='review'?'review-section':'issue-section');}
      const pane=n.closest('[data-settings-pane]');if(pane){const tab=root.querySelector('[data-settings-tab="'+pane.dataset.settingsPane+'"]');tab?.classList.add(tone==='review'?'review-tab':'issue-tab');}
      if(message){const id='issue-help-'+Math.random().toString(36).slice(2);const help=el('small',{class:'issue-inline',id,style:tone==='review'?'color:#92400e':''},message);n.setAttribute('aria-describedby',id);n.parentElement.append(help);}
    }
    if(first){const pane=first.closest('[data-settings-pane]');if(pane)root.querySelector('[data-settings-tab="'+pane.dataset.settingsPane+'"]')?.click();first.scrollIntoView({block:'center'});first.focus();}return first;
  }
  function rejectedInput(d) {
    const root=$('#modal:not(.hidden) #modal_box')||$('#props');
    root.querySelector('.diagnostic-rejection')?.remove();
    const note=el('div',{class:'diagnostic-rejection',role:'alert'},el('b',{},'NOT SAVED: '+d.text),el('p',{},d.suggestion),el('p',{},d.impact),el('small',{},d.mapping));root.prepend(note);
    if(!locateFields(d.fields,root,'error',d.suggestion))note.classList.add('issue-target');
  }
  async function issueInput(i) {
    if(S.dirty||document.querySelector('input.bad')||!$('#modal').classList.contains('hidden')){setStatus('Keep your draft: finish or explicitly cancel the current edit before navigating. Drawing shows saved values.','err');return;}
    const t=i.edit;if(!t)return;
    if(t.editor==='wizard')wizard(t.owner);
    else if(t.editor==='additions')await additionsSettings(t.owner);
    else select(t.editor,t.owner);
    const root=$('#modal:not(.hidden) #modal_box')||$('#props');
    const hit=locateFields(t.fields,root,i.category==='review'?'review':'error',i.suggestion);
    root.prepend(el('div',{class:'diagnostic-context'},el('b',{},i.assembly+': '+i.category),el('p',{},i.text),el('p',{},i.suggestion),el('small',{},hit?'Highlighted related input. This is not an automatic fix.':'Related editor opened; exact editable field unavailable (or generated/read-only). No input value changed.')));
  }
  function renderIssues() {
    const ul=$('#issues');ul.innerHTML='';const all=S.state.issues||[];
    $('#issue_count').textContent=`– ${all.filter(i=>i.severity==='error').length} errors, ${all.filter(i=>i.severity==='warning').length} warnings — whole job`;
    ul.append(el('li',{},el('a',{href:'/api/issue-report.pdf',target:'_blank'},'Download issue review + measured comparisons PDF'),el('p',{},'Drawings represent the saved revision. Related controls are not prescribed fixes. Review holds are not necessarily bad input.')));
    if(!all.length)ul.append(el('li',{},'No model findings. This is not fabrication approval.'));
    for(const i of all){
      const row=el('li',{class:i.severity,'data-issue-id':i.id},el('b',{},`${i.severity} / ${i.category||'unmapped'} / ${i.assembly}`),el('p',{},i.text));
      const d=el('details',{},el('summary',{},'Locate / explain / compare'),el('p',{},i.suggestion||'No exact input mapping available.'),el('p',{},i.impact||''));
      if(i.edit)d.append(el('button',{onclick:()=>issueInput(i)},'Locate related input'));
      const drawing=i.drawing&&S.state.sheets.some(s=>s.kind===i.drawing.kind&&s.name===i.drawing.name);
      if(drawing)d.append(el('button',{onclick:()=>{showSheet(i.drawing.kind,i.drawing.name);setStatus('Related saved drawing: '+i.marks.join(', ')+'. No spatial clash marker inferred.');}},'Compare related drawing'));
      else d.append(el('small',{},' Exact drawing target unavailable.'));
      for(const e of i.evidence||[])d.append(el('p',{class:'issue-evidence'},`${e.mark}: ${e.label} = ${e.value_in.toFixed(6)} in`));
      d.append(el('small',{},i.mapping||''));row.append(d);ul.append(row);
    }
  }

  function renderBom() {
    const t = $("#bom"); t.innerHTML = "";
    if (S.sel.type !== "assembly" && !S.state.job.parts[S.sel.name]?.symbol?.connection) return;
    const rows = S.state.bom[S.sel.name];
    if (!rows) { t.append(el("tr", {}, el("td", {}, "BOM not available – fix model errors"))); return; }
    t.append(el("tr", {}, ...["PART", "QNT", "DESCRIPTION", "WEIGHT"].map(h => el("th", {}, h))));
    for (const r of rows) t.append(el("tr", { class: r.part === "TOTAL" ? "total" : "" }, el("td", {}, r.part), el("td", {}, r.qty), el("td", {}, r.description), el("td", {}, r.weight)));
  }

  // ------------------------------------------------------------------ property editors
  const dimOk = v => v === "" || window.MBDim.ok(v);   // one grammar: see dim.js / mbdp/dims.py
  function issuePath(obj,key) {
    const walk=(v,path)=>{if(v===obj)return path+'/'+key;if(!v||typeof v!=='object')return null;for(const [k,x]of Object.entries(v)){const r=walk(x,path+'/'+k);if(r)return r;}return null;};
    return walk(S.state.job,'');
  }
  function inp(obj, key, opts = {}) {
    const i = el("input", { "data-issue-path":issuePath(obj,key), value: obj[key] ?? "", size: opts.size || 10, placeholder: opts.ph || "" });
    if (opts.num) i.type = "number";
    if (opts.readonly) i.readOnly=true;
    if (opts.step) i.step = opts.step;
    i.addEventListener("input", () => {
      let v = i.value;
      if (opts.dim) { i.classList.toggle("bad", !dimOk(v)); if (!dimOk(v)) {clearTimeout(S.saveTimer);setStatus("Invalid dimension: correct the red field (accepted forms: 12, 1-1/2, 7 3/4\", 12\'-6\", 12.5, -1/2). Your draft is retained; drawing shows saved values.","err");return;} v = v.trim() === "" ? null : v.trim(); }
      else if (opts.num) v = v === "" ? (opts.nullable ? null : 0) : Number(v);
      obj[key] = v; scheduleSave(); if (opts.rerender) renderLists();
    });
    return i;
  }
  function sel(obj, key, options, opts = {}) {
    const s = el("select", {"data-issue-path":issuePath(obj,key)}, ...options.map(o => el("option", { value: o, selected: o === obj[key] ? "" : null }, o)));
    if (!options.includes(obj[key]) && obj[key]) s.prepend(el("option", { value: obj[key], selected: "" }, obj[key]));
    s.addEventListener("change", () => { obj[key] = s.value; scheduleSave(); if (opts.rerender) renderProps(); });
    return s;
  }
  function chk(obj, key) {
    const c = el("input", { type: "checkbox" }); c.checked = !!obj[key];
    c.addEventListener("change", () => { obj[key] = c.checked; scheduleSave(); });
    return c;
  }
  const grid = (...pairs) => el("div", { class: "grid" }, ...pairs.flatMap(([l, c]) => [el("label", {}, l), c]));

  function renderProps() {
    const box = $("#props"); box.innerHTML = "";
    if (S.sel.type === "assembly" && S.state.job.assemblies[S.sel.name]) box.append(assemblyEditor(S.state.job.assemblies[S.sel.name]));
    else if (S.sel.type === "part" && S.state.job.parts[S.sel.name]) box.append(partEditor(S.state.job.parts[S.sel.name]));
    else box.append(el("p", { class: "hint" }, "Select an assembly or a part."));
  }

  function assemblyEditor(a) {
    const job = S.state.job, cat = S.state.catalog;
    const partMarks = Object.keys(job.parts);
    const frag = document.createDocumentFragment();
    frag.append(el("h2", {}, a.mark, el("span", { class: "kind" }, a.kind),
      el("button", { class: "mini danger", style: "margin-left:auto", onclick: () => { if(a.derivation?.frame_id)return alert("This is a managed frame member. Use a new job to start a separate frame model."); if (confirm(`Delete assembly ${a.mark}?`)) { delete job.assemblies[a.mark]; S.sel.name = null; scheduleSave("delete " + a.mark); renderAll(); } } }, "delete"),
      el("button", { class: "mini", onclick: () => { if(a.derivation?.frame_id)return alert("Use the frame wizard to generate another managed frame."); const m = prompt("New mark for the copy", a.mark + "-COPY"); if (!m || job.assemblies[m]) return; const c = JSON.parse(JSON.stringify(a)); c.mark = m; job.assemblies[m] = c; scheduleSave("copy " + m); select("assembly", m); } }, "duplicate")));
    if(a.derivation?.frame_id) frag.append(el("button",{class:"primary",onclick:()=>wizard(a.derivation.frame_id)},"Building settings"),
      el("p",{class:"hint"},"Managed frame: changing a member section regenerates this frame, including cuts, clips and connections. Use frame editor for pitch, height and quantities."));
    frag.append(el("h3", {}, "Assembly"));
    const markIn = el("input", { value: a.mark, size: 10 });
    if(a.derivation?.frame_id)markIn.readOnly=true;
    markIn.addEventListener("change", () => { const m = markIn.value.trim(); if (!m || job.assemblies[m]) { markIn.classList.add("bad"); return; } for(const cfg of Object.values(job.settings?.connections||{})) {if(cfg.column===a.mark)cfg.column=m;if(cfg.rafter===a.mark)cfg.rafter=m;} delete job.assemblies[a.mark]; a.mark = m; job.assemblies[m] = a; S.sel.name = m; S.sheet = { kind: "assembly", name: m }; scheduleSave("rename"); renderAll(); });
    frag.append(grid(["Mark", markIn], ["Type", sel(a, "kind", cat.assembly_kinds, { rerender: false })], ["Quantity", inp(a, "qty", { num: true,readonly:!!a.derivation?.frame_id })], ["Sheet date", inp(a, "date", { ph: job.date || "job date" })]));

    frag.append(el("h3", {}, "Main member"));
    const mm = a.main;
    frag.append(grid(["Cut mark", inp(mm, "mark",{readonly:!!a.derivation?.frame_id})], ["Section", ((node)=>{node.disabled=!!a.derivation?.frame_id;return node;})(sel(mm, "section", a.kind==="COLUMN"?(cat.column_sections||cat.sections):(cat.rafter_sections||cat.sections)))], ["Cut length", inp(mm, "cut_length", { dim: true, readonly:!!a.derivation?.frame_id, ph: `24'-11 13/16"` })],
      ["Left end", el("div", { class: "row2" }, sel(mm.left_cut, "type", ["square", "bevel"]), inp(mm.left_cut, "angle", { num: true, step: "0.01" }))],
      ["Right end", el("div", { class: "row2" }, sel(mm.right_cut, "type", ["square", "bevel"]), inp(mm.right_cut, "angle", { num: true, step: "0.01" }))]));
    if(a.derivation?.first_purlin_formula)frag.append(el("div",{class:"deriv"},a.derivation.first_purlin_formula));
    if (mm.derivation) frag.append(el("div", { class: "deriv" }, "derivation: " + mm.derivation));

    // web holes
    frag.append(el("h3", {}, "Web hole groups", el("button", { class: "mini", onclick: () => { mm.web_holes.push({ station: `12'-0"`, y_from_top: `5 1/2"`, dia: `9/16"`, cols: 2, rows: 2, pitch_x: `2 1/2"`, pitch_y: `2 1/2"`, note: "" }); scheduleSave(); renderProps(); } }, "+ group")));
    if (mm.web_holes.length) {
      const t = el("table", { class: "tbl" }, el("tr", {}, ...["station", "from top", "dia", "cols", "rows", "pitch x", "pitch y", "note", ""].map(h => el("th", {}, h))));
      mm.web_holes.forEach((w, i) => t.append(el("tr", {}, el("td", {}, inp(w, "station", { dim: true, size: 8 })), el("td", {}, inp(w, "y_from_top", { dim: true, size: 6 })), el("td", {}, inp(w, "dia", { dim: true, size: 5 })),
        el("td", {}, inp(w, "cols", { num: true })), el("td", {}, inp(w, "rows", { num: true })), el("td", {}, inp(w, "pitch_x", { dim: true, size: 6 })), el("td", {}, inp(w, "pitch_y", { dim: true, size: 6 })), el("td", {}, inp(w, "note", { size: 6 })),
        el("td", { class: "act" }, el("button", { class: "mini danger", onclick: () => { mm.web_holes.splice(i, 1); scheduleSave(); renderProps(); } }, "×")))));
      frag.append(el("div", { class: "tbl-wrap" }, t));
    }

    // attachments
    frag.append(el("h3", {}, "Attachments", el("button", { class: "mini", onclick: () => { a.attachments.push({ part: partMarks[0] || "", face: "top", station: `1'-0"`, side: "both", angle: 90, ref: "center", y_from_top: null, tilt: 0, show_first_hole_ref: false, label: "", note: "" }); scheduleSave(); renderProps(); } }, "+ attachment")));
    frag.append(el("p", { class: "hint" }, "Station = distance from the left end (tape datum) to the part's reference point. Web parts need 'from top' (hole from top of member). End faces ignore the station."));
    const t = el("table", { class: "tbl" }, el("tr", {}, ...["part", "face", "station", "side", "ref", "from top", "angle", "tilt", "1st hole", "note", ""].map(h => el("th", {}, h))));
    a.attachments.forEach((at, i) => t.append(el("tr", {},
      el("td", {}, sel(at, "part", partMarks)), el("td", {}, sel(at, "face", cat.faces)), el("td", {}, inp(at, "station", { dim: true, size: 8 })),
      el("td", {}, sel(at, "side", cat.sides)), el("td", {}, sel(at, "ref", ["center", "left", "right"])), el("td", {}, inp(at, "y_from_top", { dim: true, size: 5 })),
      el("td", {}, inp(at, "angle", { num: true, step: "0.1" })), el("td", {}, inp(at, "tilt", { num: true, step: "0.01" })), el("td", {}, chk(at, "show_first_hole_ref")), el("td", {}, inp(at, "note", { size: 5 })),
      el("td", { class: "act" },
        el("button", { class: "mini", title: "duplicate", onclick: () => { a.attachments.splice(i + 1, 0, JSON.parse(JSON.stringify(at))); scheduleSave(); renderProps(); } }, "⧉"),
        el("button", { class: "mini danger", onclick: () => { a.attachments.splice(i, 1); scheduleSave(); renderProps(); } }, "×")))));
    frag.append(el("div", { class: "tbl-wrap" }, t));
    frag.append(el("div", { class: "btnrow" }, el("button", { class: "mini", onclick: () => addSeries(a) }, "+ clip series (first, spacing, count)")));

    frag.append(el("h3", {}, "Notes"));
    const ta = el("textarea", { rows: 2, style: "width:100%" }, (a.notes || []).join("\n"));
    ta.addEventListener("input", () => { a.notes = ta.value.split("\n").filter(x => x.trim()); scheduleSave(); });
    frag.append(ta);
    if (a.derivation && a.derivation.wizard) frag.append(el("div", { class: "deriv" }, "generated by " + a.derivation.wizard + " wizard\n" + (a.derivation.formula || "") + "\n" + (a.derivation.qty || "")));
    return frag;
  }

  function addSeries(a) {
    const part = prompt("Clip part mark", "PC8D"); if (!part || !S.state.job.parts[part]) return alert("part not in library");
    const first = prompt("First station (e.g. 1'-8 3/16\")", `1'-8 3/16"`); if (!first) return;
    const spacing = prompt("Spacing (e.g. 4'-4\")", `4'-4"`); if (!spacing) return;
    const count = Number(prompt("Count", "5")); if (!count) return;
    const face = prompt("Face (top/bottom)", "top") || "top";
    const toIn = s => { const m = s.replace(/"/g, "").match(/^\s*(?:(\d+)'\s*-?\s*)?(?:(\d+)(?:\s+(\d+)\/(\d+))?|(\d+)\/(\d+))?\s*$/); if (!m) return null; return (+(m[1] || 0)) * 12 + (+(m[2] || 0)) + (m[3] ? m[3] / m[4] : 0) + (m[5] ? m[5] / m[6] : 0); };
    const fmt = x => { const ft = Math.floor(x / 12); let r = x - ft * 12; const w = Math.floor(r + 1e-9); let f = Math.round((r - w) * 16); let n = f, d = 16; while (n && n % 2 === 0) { n /= 2; d /= 2; } return `${ft}'-${w}${n ? " " + n + "/" + d : ""}"`; };
    const f0 = toIn(first), sp = toIn(spacing); if (f0 === null || sp === null) return alert("bad dimension");
    for (let k = 0; k < count; k++) a.attachments.push({ part, face, station: fmt(f0 + k * sp), side: "both", angle: 90, ref: "center", y_from_top: null, tilt: 0, show_first_hole_ref: k === 0, label: "", note: "" });
    scheduleSave("clip series"); renderProps();
  }

  function partEditor(p) {
    const job = S.state.job, cat = S.state.catalog;
    const frag = document.createDocumentFragment();
    if(p.symbol?.plate_rule_generated) {
      frag.append(el("h2",{},p.symbol.plate_family+" — member-sized plate"),el("p",{},p.mark),
        el("p",{class:"err-box"},p.symbol.review_hold),
        el("p",{},`PL ${p.thk} x ${p.width} x ${p.length}`),
        el("p",{class:"hint"},"Members: "+p.symbol.member_contexts.join(", ")),
        el("p",{class:"hint"},p.symbol.formula),el("p",{},"Fillet weld leg: "+p.symbol.weld_size),
        el("button",{onclick:()=>plateStandards()},"Edit plate standards"),
        el("p",{class:"hint"},"Computed plate variants are read-only. Changing standards creates new geometry marks; source-library parts remain unchanged."));
      return frag;
    }
    if(p.symbol?.connection || p.symbol?.owner) {
      const owner=p.symbol.connection?p.mark:p.symbol.owner;
      const root=job.parts[owner];
      frag.append(el("h2",{},p.mark),el("p",{class:"err-box"},"DRAFT — NOT FOR FABRICATION"),
        el("p",{class:"hint"},"Generated geometry is read-only here. Edit the connection parameters or its selected column/rafter section to rebuild the parts."),
        el("button",{onclick:()=>connectionWizard(owner)},"Edit connection / resize"),
        el("button",{class:"mini",onclick:()=>select("part",owner)},"Weldment sheet"));
      if(p.symbol.connection) {
        frag.append(el("button",{class:"mini danger",onclick:async()=>{
          if(S.dirty)return alert("Wait for pending edits to save first.");
          if(!confirm("Delete this connection lot and its generated parts?"))return;
          try {S.state=await api("POST","/api/connection/delete",{mark:owner});S.sel={type:"assembly",name:null};await load();}
          catch(e){alert(e.message);}
        }},"Delete connection lot"));
        frag.append(el("h3",{},"Weldment parts"));
        for(const name of new Set(p.attachments.map(a=>a.part))) frag.append(el("button",{class:"mini",onclick:()=>select("part",name)},name));
        frag.append(el("h3",{},"Loose rafter mating plate"),el("button",{class:"mini",onclick:()=>select("part",p.symbol.mate)},p.symbol.mate));
        for(const note of p.symbol.pending) frag.append(el("p",{class:"hint"},note));
      } else {
        frag.append(el("h3",{},"True-size contours — review before cutting"));
        for(const units of ["inch","mm"]) for(const ext of ["dxf","svg"]) frag.append(el("a",{class:"btn",href:`/api/contour/${encodeURIComponent(p.mark)}.${ext}?units=${units}`,download:""},`1:1 ${ext.toUpperCase()} (${units})`));
        frag.append(el("a",{class:"btn",href:`/api/contour/${encodeURIComponent(p.mark)}.json`,target:"_blank"},"Coordinates / angles"));
        frag.append(el("h3",{},p.symbol.role),el("p",{},`PL ${p.thk} x ${p.width} x ${p.length}`));
        frag.append(el("p",{class:"hint"},"Stock blank shown above. Finished decimal coordinates, every edge length and corner angle are on the detail sheet and in the geometry report."));
      }
      return frag;
    }
    const used = Object.values(job.assemblies).filter(a => a.attachments.some(t => t.part === p.mark)).map(a => a.mark);
    frag.append(el("h2", {}, p.mark, el("span", { class: "kind" }, p.kind),
      el("button", { class: "mini danger", style: "margin-left:auto", onclick: () => { if (used.length) return alert("Part is used by: " + used.join(", ")); if (confirm(`Delete part ${p.mark}?`)) { delete job.parts[p.mark]; S.sel = { type: "assembly", name: null }; scheduleSave("delete part"); renderAll(); } } }, "delete")));
    frag.append(el("p", { class: "hint" }, used.length ? "used in " + used.join(", ") : "not used yet"));
    const markIn = el("input", { value: p.mark, size: 10 });
    markIn.addEventListener("change", () => { const m = markIn.value.trim(); if (!m || job.parts[m]) { markIn.classList.add("bad"); return; } const old = p.mark; delete job.parts[old]; p.mark = m; job.parts[m] = p; for (const a of Object.values(job.assemblies)) for (const t of a.attachments) if (t.part === old) t.part = m; for (const q of Object.values(job.parts)) for (const t of (q.attachments || [])) if (t.part === old) t.part = m; S.sel.name = m; scheduleSave("rename part"); renderAll(); });
    frag.append(el("h3", {}, "Part"));
    frag.append(grid(["Mark", markIn], ["Kind", sel(p, "kind", cat.part_kinds, { rerender: true })], ["Description", inp(p, "description", { ph: "auto from size" })],
      ["Unit weight", inp(p, "unit_weight", { ph: "auto (plate formula / plf)" })], ["Source", inp(p, "source")], ["Notes", inp(p, "notes", { size: 24 })]));
    if (p.kind === "plate" || p.kind === "clip") {
      frag.append(el("h3", {}, "Plate size"));
      frag.append(grid(["Thickness", inp(p, "thk", { dim: true })], ["Width", inp(p, "width", { dim: true })], ["Length", inp(p, "length", { dim: true })]));
      frag.append(el("p", { class: "hint" }, "Clips stand on the flange with their LENGTH vertical; hole x runs along the length (up), y across the width."));
      frag.append(el("h3", {}, "Holes", el("button", { class: "mini", onclick: () => { p.holes.push({ x: `1 1/2"`, y: `1 1/2"`, dia: `9/16"` }); scheduleSave(); renderProps(); } }, "+ hole")));
      const t = el("table", { class: "tbl" }, el("tr", {}, ...["x (along length)", "y (across width)", "dia", ""].map(h => el("th", {}, h))));
      p.holes.forEach((h, i) => t.append(el("tr", {}, el("td", {}, inp(h, "x", { dim: true })), el("td", {}, inp(h, "y", { dim: true })), el("td", {}, inp(h, "dia", { dim: true })),
        el("td", { class: "act" }, el("button", { class: "mini danger", onclick: () => { p.holes.splice(i, 1); scheduleSave(); renderProps(); } }, "×")))));
      frag.append(t);
      frag.append(el("div", { class: "btnrow" }, el("button", { class: "mini", onclick: () => {
        const xs = prompt("x positions along length (comma separated)", `2 1/4", 6 1/4"`); const ys = prompt("y positions across width", `1", 5"`); const dia = prompt("diameter", `9/16"`);
        if (!xs || !ys || !dia) return; p.holes = []; for (const y of ys.split(",")) for (const x of xs.split(",")) p.holes.push({ x: x.trim(), y: y.trim(), dia: dia.trim() }); scheduleSave(); renderProps(); } }, "grid pattern…")));
    } else if (p.kind === "stub") {
      frag.append(el("h3", {}, "Stub"));
      frag.append(grid(["Section", sel(p, "section", cat.sections)], ["Cut length", inp(p, "cut_length", { dim: true })]));
      frag.append(el("h3", {}, "Parts on the stub", el("button", { class: "mini", onclick: () => { p.attachments.push({ part: "PC8D", face: "top", station: `4"`, side: "both", angle: 90, ref: "center", y_from_top: null, tilt: 0, show_first_hole_ref: false, label: "", note: "" }); scheduleSave(); renderProps(); } }, "+")));
      const t = el("table", { class: "tbl" }, el("tr", {}, ...["part", "face", "station", ""].map(h => el("th", {}, h))));
      p.attachments.forEach((at, i) => t.append(el("tr", {}, el("td", {}, sel(at, "part", Object.keys(job.parts).filter(m => m !== p.mark))), el("td", {}, sel(at, "face", cat.faces)), el("td", {}, inp(at, "station", { dim: true })),
        el("td", { class: "act" }, el("button", { class: "mini danger", onclick: () => { p.attachments.splice(i, 1); scheduleSave(); renderProps(); } }, "×")))));
      frag.append(t);
    } else if (p.kind === "bracket" && p.symbol?.connection) {
      frag.append(el("h3",{},"Parametric connection"),el("p",{class:"hint"},"Single web. Derived shop-part proposal; release blocked pending review."),
        el("button",{onclick:()=>connectionWizard(p.mark)},"Edit connection / resize"));
      for (const a of p.attachments) frag.append(el("button",{class:"mini",onclick:()=>select("part",a.part)},a.part));
      frag.append(el("button",{class:"mini",onclick:()=>select("part",p.symbol.mate)},p.symbol.mate+" (loose mate)"));
      for(const note of p.symbol.pending) frag.append(el("p",{class:"hint"},note));
    } else if (p.kind === "bracket") {
      frag.append(el("h3", {}, "Bracket"));
      p.symbol = p.symbol || {};
      frag.append(grid(["Weight (lb)", inp(p, "unit_weight", { ph: "from bracket drawing" })], ["Drawing ref", inp(p, "drawing_ref")], ["Symbol w (in)", inp(p.symbol, "w", { num: true, step: "0.5" })], ["Symbol h (in)", inp(p.symbol, "h", { num: true, step: "0.5" })]));
      frag.append(el("p", { class: "hint" }, "Brackets are weldments with their own drawing; the weight must come from that drawing (no formula is applied)."));
    }
    return frag;
  }

  function plateStandards() {
    if(S.dirty)return alert("Wait for pending edits to save first.");
    const R={...S.state.plate_rules};const evidence=S.state.plate_rule_evidence;
    const box=el("div",{},el("h2",{},"Member-driven plate standards"),
      el("p",{class:"err-box"},"Review rules, NOT an engineering design. Source envelopes are documented; extrapolation and complete bolt layouts are provisional. Source-library plates are never overwritten."),
      el("p",{class:"hint"},"Dimensions are in inches. Defaults reproduce sample B8/B10/B14 and K10/K14 envelopes. B12 and other sizes follow actual member dimensions. Each distinct geometry receives a stable piece-mark suffix."));
    const fields=el("div",{});
    for(const [key,val] of Object.entries(R)) {
      const input=el("input",{value:val,"data-rule":key});input.oninput=()=>R[key]=input.value;
      fields.append(grid([key.replaceAll("_"," "),input]),el("p",{class:"hint"},evidence[key]));
    }
    const error=el("div",{class:"err-box hidden"});const preview=el("div",{});
    box.append(fields,error,el("div",{class:"btnrow"},
      el("button",{class:"primary",onclick:async()=>{try{
        S.state=await api("POST","/api/plate-rules",{rules:R});closeModal();renderAll();setStatus("plate rules saved; member-sized connections rebuilt — review hold","err");
      }catch(e){error.textContent=e.message;error.classList.remove("hidden");}}},"Save rules & rebuild"),
      el("button",{onclick:async()=>{
        try {const rows=await api("GET","/api/plate-catalog");preview.innerHTML="";
          preview.append(el("h3",{},"Saved-rule coverage (all catalog W sections)"),el("p",{class:"hint"},"Preview uses SAVED rules, not unsaved input above."));
          const t=el("table",{class:"tbl"},el("tr",{},...["Section","Family","Variant","Size","Holes","Status"].map(x=>el("th",{},x))));
          for(const r of rows)t.append(el("tr",{},...[r.section,r.family,r.mark,r.size,r.holes,r.status].map(x=>el("td",{},x))));
          preview.append(el("div",{class:"tbl-wrap"},t));
        }catch(e){error.textContent=e.message;error.classList.remove("hidden");}
      }},"Preview catalog coverage"),el("button",{onclick:closeModal},"Cancel")),preview);
    openModal(box);
  }

  function connectionWizard(mark = null) {
    if (S.dirty) { alert("Wait for pending edits to save before opening the connection designer."); return; }
    const job=S.state.job;
    const managed=job.settings?.connections?.[mark]?.frame_id;
    if(managed) { wizard(managed,job.settings.connections[mark].kind==="apex"?"apex_bottom_half":null); return; }
    const cols=Object.values(job.assemblies).filter(a=>a.kind==="COLUMN").map(a=>a.mark);
    const rafs=Object.values(job.assemblies).filter(a=>a.kind==="RAFTER").map(a=>a.mark);
    if(!cols.length || !rafs.length) { alert("Create a column and rafter first (frame wizard)."); return; }
    let n=1; while(job.parts[`KB-${n}`]) n++;
    const P={apex_bottom_half:`6"`,mark:mark||`KB-${n}`,kind:"low",column:cols[0],rafter:rafs[0],rise:"1",bottom_mode:"column_depth",bottom:`10 1/2"`,top_extension:`0"`,
      flange_thk:`1/4"`,web_thk:`3/16"`,end_plate:"K-14",qty:1,weld_size:`1/4"`,plate_mode:"member",pitch_source:"manual",...(job.settings?.connections?.[mark]||{})};
    if(P.kind==='apex' && mark)P.apex_bottom_half=String(job.parts[mark].symbol.bottom_length_in)+'"';
    function connectionFields(){
      const field=k=>document.querySelector('[data-connection-field="'+k+'"]');
      if(!field('bottom'))return;
      field('bottom').disabled=P.kind==='apex'||P.bottom_mode!=='manual';
      field('bottom_mode').disabled=P.kind==='apex';
      field('apex_bottom_half').disabled=P.kind!=='apex';
      field('end_plate').disabled=P.plate_mode!=='library';
      field('rise').disabled=P.pitch_source!=='manual';
    }
    const input=k=>{const x=el("input",{value:P[k],"data-connection-field":k}); if(k==="bottom")x.disabled=P.bottom_mode!=="manual"; if(k==="mark"&&mark)x.readOnly=true; x.oninput=()=>P[k]=x.value; return x;};
    const choose=(k,opts)=>{const x=el("select",{"data-connection-field":k},...opts.map(o=>el("option",{value:o,selected:o===P[k]?"":null},o)));x.onchange=()=>{P[k]=x.value;connectionFields();};return x;};
    const error=el("div",{class:"err-box hidden"});
    openModal(el("div",{},el("h2",{},"Standalone connection — low / high / apex"),
      el("p",{class:"hint"},"Single-web plate construction. Low = low eave; high = mono-slope high eave. Apex mirrors the high-eave halves into ONE continuous web, equal pitch each side. Bracket spans column TOP. Default bottom = actual column depth + mating plate thickness; manual bottom is used only in manual mode. Inset END and BACK sit on bottom TOP. Width follows column flange; height follows the aligned rafter. Changing those member sections rebuilds this connection."),
      grid(["Connection mark",input("mark")],["Type",choose("kind",["low","high","apex"])],
        ["Column (width driver)",choose("column",cols)],["Rafter (depth driver)",choose("rafter",rafs)],
        ["Pitch source",choose("pitch_source",["manual","frame"])],["Rise / 12 (manual)",input("rise")],["Bottom length rule",choose("bottom_mode",["column_depth","manual"])],["Manual eave bottom length",input("bottom")],["Apex bottom half-length (each side)",input("apex_bottom_half")],
        ["Top extension, LOW only",input("top_extension")],["Flange / back thickness",input("flange_thk")],
        ["Single web thickness",input("web_thk")],["Plate sizing",choose("plate_mode",["member","library"])],["Library envelope / diameter (library mode)",choose("end_plate",Object.values(job.parts).filter(p=>p.kind==="plate"&&!p.symbol?.owner).map(p=>p.mark))],
        ["Fillet weld leg (shop default 1/4)",input("weld_size")],["Standalone lot quantity",input("qty")]),
      el("p",{class:"hint"},"This is a separately quantified connection lot; it does NOT replace frame attachments, revise rafter cuts or add connections to the building automatically. Matching loose rafter plates are included. Plate thicknesses start from the supplied 10-inch examples; they are not design-approved for other sections."),
      el("p",{class:"err-box"},"Review hold: welds and connection design require approval. Tight-fit, no-bevel profiles are available as true-size DXF/SVG plus full coordinate/angle sheets. No G-code until machine/controller is known."),error,
      el("div",{class:"btnrow"},el("button",{class:"primary",onclick:async()=>{
        try{const request={...P};if(P.kind==="apex"&&!String(P.apex_bottom_half||"").trim())throw new Error("Enter a positive finished apex bottom half-length for each side.");if(P.kind!=="apex")delete request.apex_bottom_half;S.state=await api("POST","/api/connection",request);closeModal();select("part",P.mark);setStatus("connection generated — review required","err");}
        catch(e){error.textContent=e.message;error.classList.remove("hidden");}
      }},"Generate connection + shop parts"),el("button",{onclick:closeModal},"Cancel"))));
    connectionFields();
  }

  // ------------------------------------------------------------------ wizard modal
  function supplierProductFields(){
    const saved=S.state.job.settings.product_suppliers;
    const cfg=JSON.parse(JSON.stringify(saved||{primary:S.state.job.settings.sourcing?.primary||'sss'}));
    for(const key of ['secondaries','sheets','trim'])cfg[key]||=cfg.primary;
    const rev=S.state.revision,choices={},fields=el('div',{class:'supplier-lines'}),message=el('p',{class:'hint'});let proposal=null;
    const names={sss:'Triple-S Steel',mbci:'MBCI'};
    const controls={};
    const select=(key,label)=>{const n=el('select',{'data-product-category':key,onchange:e=>{cfg[key]=e.target.value;if(key==='primary')for(const k of ['secondaries','sheets','trim']){cfg[k]=cfg.primary;controls[k].value=cfg.primary;}proposal=null;fields.replaceChildren();message.textContent='Preview required. Supplier selections change actual products, not labels.';}},...Object.entries(names).map(([v,t])=>el('option',{value:v,selected:cfg[key]===v?'':null},t)));controls[key]=n;return [label,n];};
    const preview=async()=>{try{proposal=await api('POST','/api/supplier-products/preview',{revision:rev,categories:cfg});fields.replaceChildren();for(const f of proposal.fields){choices[f.key]=f.suggested||'';const input=el('select',{'data-product-choice':f.key,onchange:e=>{choices[f.key]=e.target.value;message.textContent='Product selections updated. Review the shape/gauge changes and colors, then Apply to regenerate the saved job.';}},el('option',{value:''},'SELECT REPLACEMENT — required'),...f.options.map(o=>el('option',{value:o.id,selected:choices[f.key]===o.id?'':null},o.label)));fields.append(el('div',{class:'product-choice'},el('b',{},f.old+' → '+names[cfg[f.category]]),input,el('small',{},f.uses.join('; '))));}message.textContent=proposal.notes.join(' ')+(proposal.fields.length?' Review every changed shape/gauge and explicitly select supplier colors.':' No cross-supplier replacements needed; Apply saves the category policy.');}catch(e){message.textContent=e.message;}};
    return el('section',{class:'supplier-settings'},el('h3',{},'Supplier PRODUCTS — actual shapes / colors'),el('p',{class:'hint'},saved?'Active supplier products govern every frame, order and customer view.':'Existing model has not been converted by the old supplier-label settings. Use this product workflow.'),grid(select('primary','Primary supplier'),select('secondaries','Secondaries supplier override'),select('sheets','Sheets supplier override'),select('trim','Trim supplier override')),el('div',{class:'btnrow'},el('button',{'data-product-preview':'',onclick:preview},'Preview product replacements'),el('button',{'data-product-apply':'',onclick:async()=>{try{if(!proposal)throw Error('Preview product replacements first.');if(proposal.fields.some(f=>!choices[f.key]))throw Error('Choose every required replacement/color. Nothing has been saved.');if(!confirm('Apply to ALL SAVED frames and regenerate physical products/cuts/customer views? Other unsaved entries in this frame form will be discarded.'))return;S.state=await api('POST','/api/supplier-products/apply',{revision:rev,categories:cfg,choices});closeModal();renderAll();setStatus('Supplier products applied — review changed fits and remaining holds.','warn');}catch(e){message.textContent=e.message;}}},'Apply supplier products to saved job')),el('p',{},el('a',{href:'/api/supplier-reference.pdf',target:'_blank'},'SSS source shapes / colors'),' | ',el('a',{href:'/api/supplier-catalog.xlsx',target:'_blank'},'SSS catalog workbook')),message,fields);
  }

  function supplierFields(cfg,revisionChanged) {
    const note=el('p',{class:'hint'}),list=el('div',{class:'supplier-lines'});
    const names={sss:'Triple-S Steel',mbci:'MBCI',other:'Other / manual quote'};
    const select=(value,choices,change,attrs={})=>el('select',{...attrs,onchange:e=>change(e.target.value)},...choices.map(([v,t])=>el('option',{value:v,selected:value===v?'':null},t)));
    let busy=false;
    async function preview(){
      if(busy)return;busy=true;note.textContent='Loading current saved material lines…';
      try{
        const [p,cat]=await Promise.all([api('POST','/api/sourcing-preview',{revision:revisionChanged(),sourcing:cfg}),api('GET','/api/supplier-catalog')]);
        list.replaceChildren();
        const search=el('input',{placeholder:'Filter by mark / material / catalog label',size:42});list.append(search);
        const rows=[];
        for(const r of p.items){
          const key=r.sourcing_key;
          const get=()=>cfg.overrides[key]||={supplier:cfg.primary,catalog_id:'',vendor:'',note:''};
          const n=el('details',{'data-sourcing-line':key},el('summary',{},r.order_id+' | '+r.supplier_name+' | '+(r.supplier_code?r.supplier_code+' — ':'')+r.supplier_label+' | '+(r.supplier_status.includes('HOLD')?'HOLD | ':r.supplier_status.includes('UNMATCHED')?'UNMATCHED | ':'QUOTE REVIEW | ')+r.quantity+' @ '+r.order_length),el('p',{},'AS DRAWN: '+r.material+' / '+r.finish+' / '+r.grade),el('small',{},r.references));
          const status=el('p',{class:'hint'},r.supplier_status),code=select(cfg.overrides[key]?.catalog_id||'',[['','No catalog code selected — quote AS DRAWN'],...cat.products.map(x=>[x.id,(x.code||'No printed code')+' — '+x.label+' (p'+x.page+')'])],v=>{get().catalog_id=v;supplier.value=get().supplier;status.textContent='Selection changed — preview to recheck. No fit or substitution approval.';},{'data-sourcing-code':key});
          const vendor=el('input',{value:cfg.overrides[key]?.vendor||'',placeholder:'Other supplier name',oninput:e=>get().vendor=e.target.value,'data-sourcing-vendor':key});
          const supplier=select(cfg.overrides[key]?.supplier||'inherit',[['inherit','Follow primary supplier'],...Object.entries(names)],v=>{if(v==='inherit')delete cfg.overrides[key];else Object.assign(get(),{supplier:v,catalog_id:'',vendor:''});code.value='';vendor.value='';code.disabled=(v==='inherit'?cfg.primary:v)!=='sss';vendor.disabled=v!=='other';status.textContent='Selection changed — preview to recheck.';},{'data-sourcing-supplier':key});
          code.disabled=r.supplier!=='sss';vendor.disabled=r.supplier!=='other';
          n.append(grid(['Supplier override',supplier],['SSS catalog candidate (NOT approved equivalent)',code],['Other supplier name',vendor],['Quote / fit note',el('input',{value:cfg.overrides[key]?.note||'',oninput:e=>{get().note=e.target.value;supplier.value=get().supplier;}})]),status);list.append(n);rows.push(n);
        }
        search.oninput=()=>rows.forEach(n=>n.hidden=!n.textContent.toLowerCase().includes(search.value.toLowerCase()));
        const used=new Set(p.items.map(r=>r.sourcing_key));const unused=Object.keys(cfg.overrides).filter(k=>!used.has(k));
        note.textContent='Preview only. '+p.items.length+' SAVED-model material lines; unsaved frame geometry is not included. '+unused.length+' stored overrides no longer match a current specification/length and are NOT applied. Quantities and stock packing unchanged.';
      }catch(e){note.textContent=e.message;}finally{busy=false;}
    }
    const primary=select(cfg.primary,[['sss','Triple-S Steel (shop standard)'],['mbci','MBCI']],v=>{cfg.primary=v;list.replaceChildren();note.textContent='Primary supplier changed in draft. Preview labels, then Save supplier choices (or Generate). Explicit overrides stay assigned.';},{'data-sourcing-primary':''});
    return el('section',{class:'supplier-settings'},el('h3',{},'Supplier / mixed sourcing — job-wide'),grid(['Primary supplier',primary]),el('p',{class:'hint'},'Supplier selection changes purchasing labels only, NOT sections, colors, installed geometry or release holds. Catalog candidates require fit/supply confirmation. Accessories are not automatically added to quantities.'),el('div',{class:'btnrow'},el('button',{'data-sourcing-preview':'',onclick:preview},'Preview / edit per-item suppliers'),el('button',{'data-sourcing-save':'',onclick:async()=>{try{const st=await api('POST','/api/sourcing',{revision:revisionChanged(),sourcing:cfg});S.state=st;revisionChanged(st.revision);note.textContent='Supplier choices saved. Geometry unchanged; other edits in this frame dialog are still unsaved. Download material lists to see the chosen labels.';}catch(e){note.textContent=e.message;}}},'Save supplier choices only')),el('p',{},el('a',{href:'/api/supplier-catalog.xlsx',target:'_blank'},'SSS catalog workbook'),' | ',el('a',{href:'/api/supplier-reference.pdf',target:'_blank'},'Supplied catalog pages PDF')),note,list);
  }

  function wizard(frameId = null, focusField = null, initialTab = "main") {
    if(S.dirty) {alert("Wait for pending changes to save first.");return;}
    const job = S.state.job;
    const sourcing=JSON.parse(JSON.stringify(job.settings.sourcing||{primary:'sss',overrides:{}}));sourcing.overrides||={};let sourceRevision=S.state.revision;
    const parts = Object.keys(job.parts).filter(n=>!job.parts[n].symbol?.owner && !job.parts[n].symbol?.connection);
    const P = {additions:{opening_auto:true},auto_roof_spacing:true,starting_wall_run:true,starting_run:`0"`,slab:false,base_angle:{profile_id:"SSS-CAB1",finish:"Red Oxide"},secondary:{},welded_knee:"inside_flange",base_connection:"base_plate",clip_policy:"member_sized",connection_style:"fully_welded",purlin_depth:`8"`,eave_plate_extension:`3"`,inset_for_bypass:false,girt_depth:`8"`, frame_type:"gable",high_column_mark:nextMark("COL","COLUMN",1),high_column_cut_mark:nextCut(2),high_column_section:"",high_girt_elevations:"",prefix: "RF1", frames: 1, width: `50'`, eave_height: `14'`, slope_rise: "1", column_section: "W12X19", rafter_section: "W12X19",
      column_mark: nextMark("COL", "COLUMN"), rafter_mark: nextMark("RF1", "RAFTER"), column_cut_mark: nextCut(), rafter_cut_mark: nextCut(1),
      base_plate: "B-14", knee_bracket: "BR14HE1", rafter_end_plate: "K-14", column_top_gap: `0"`, knee_setback: `0"`, ridge_half_gap: `0"`,
      girt_clip: "PC8D", girt_elevations: `7'-6", 11'-6"`, purlin_clip: "PC8D", first_purlin: `4'-10"`, first_purlin_datum:"outside_column", purlin_spacing: `4'-4"`,
      flange_brace_clip: "CLF2", flange_brace_at: "0, 2, 4", flange_brace_y: `11"`,
      eave_strut_depth:`8"`,base_elevation:`0"`,foundation:"slab",footing_depth:`3'`,footing_diameter:`18"`,box_height:`14"`,height_mode:"top_eave_strut",auto_connections:true,
      eave_start_clip:true,apex_bottom_half:`6"`,peak_clip_edge:`11"`,apex_reference_half:null,connection_bottom_mode:"column_depth",connection_bottom:`10 1/2"`,top_extension:`0"`,flange_thk:`1/4"`,web_thk:`3/16"`,weld_size:`1/4"`,plate_mode:"member",
      girt_mode:"flush",purlin_mode:"bypass",girt_attachment:"web_weld",ridge_fabrication:"standard",girt_web_y:`4"`,purlin_web_y:`4"`,girt_side:"NS",purlin_side:"NS",
      ... (frameId ? job.settings.frames[frameId] : {}) };
    // Default new / unset controls to the shop standard, but never reset a deliberate choice
    // when an owner reopens settings on a job: bolted construction, manual spacing, and a
    // per-frame fit override must remain explicit and persistent once selected.
    P.connection_style ||= 'fully_welded';
    P.auto_roof_spacing ??= true;
    P.welded_fit_rules = { ...(P.welded_fit_rules || {}) };
    P.welded_fit_rules.enabled ??= true;
    P.bay_layout = { ...(P.bay_layout || {}) };
    P.bay_layout.enabled ??= true;
    P.additions = { ...(P.additions || {}) };
    P.additions.opening_auto ??= true;
    function inches(value){ return window.MBDim.inches(value); }   // shared grammar (dim.js)
    const widthSection = width => ({240:'W8X10',360:'W10X12',480:'W12X14',600:'W12X19'})[Math.round(inches(width))] || '';
    if (!frameId && widthSection(P.width)) P.column_section = P.rafter_section = widthSection(P.width);
    const legacyPanelLength=P.cladding?.enabled?inches(P.cladding.length):null;
    const legacyBayLength=P.bay_layout?.enabled?inches(P.bay_layout.spacing)*Number(P.bay_layout.bays):null;
    const lengthConflict=!P.length&&legacyPanelLength&&legacyBayLength&&Math.abs(legacyPanelLength-legacyBayLength)>.00001;
    P.length ||= P.cladding?.enabled?P.cladding.length:(legacyBayLength?String(legacyBayLength)+'"':"60'");
    function refreshBuildingPreview(){
      const node=document.querySelector('[data-building-summary]');if(!node)return;
      const L=inches(P.length),r=P.bay_layout||{},max=inches(r.max_spacing||"20'");
      const lens=bayLengths();
      const n=r.layout_mode==='max_spacing'?Math.ceil(L/max):['standard','explicit'].includes(r.layout_mode)?lens.length:Number(r.bays||4);
      let message='Width: front to back sidewall. Length: left to right endwall. ';
      const fmtFt=x=>window.MBDim.fmt(x);
      if(P.bay_zones?.enabled)message+='Explicit bay lengths are controlled on Bays & enclosure. ';
      else if(r.enabled&&r.layout_mode==='standard'&&lens.length)message+='Standard bays: '+lens.map(fmtFt).join(' + ')+' = '+fmtFt(L)+'. ';
      else if(r.enabled&&r.layout_mode==='explicit'&&lens.length){const tot=lens.reduce((a,b)=>a+b,0);message+='Bays entered: '+lens.map(fmtFt).join(' + ')+' = '+fmtFt(tot)+(Math.abs(tot-L)>1e-6?' — DOES NOT MATCH the length '+fmtFt(L)+'. ':'. ');}
      else if(r.enabled&&L>0&&n>0&&Number.isFinite(n))message+=n+' equal bays x '+(L/n/12).toFixed(4)+' ft = '+(L/12).toFixed(4)+' ft. ';
      else message+='All enabled panels and bays use this master length. ';
      if(P.frame_type==='monoslope')message+='Mono: BACK low eave; FRONT high eave derived from width x pitch.';
      node.textContent=message;
      const count=document.querySelector('[data-run-field="bays"]');if(count){count.readOnly=r.layout_mode!=='count';if(count.readOnly&&Number.isFinite(n)){count.value=n;r.bays=n;}}
      // the primary frame lot follows the grid in the standard / entered-bay layouts
      const lot=document.querySelector('[data-frame-field="frames"]');
      if(lot){const follows=r.enabled&&!P.bay_zones?.enabled&&['standard','explicit','max_spacing'].includes(r.layout_mode);lot.readOnly=follows;
        if(follows&&lens.length){const rigid=['front_end','rear_end'].filter(e=>r[e]?.type==='rigid_frame').length;P.frames=lens.length-1+rigid;lot.value=P.frames;}
        const tag=lot.parentElement?.querySelector('[data-lot-note]')||lot.insertAdjacentElement('afterend',el('span',{'data-lot-note':'',class:'hint',style:'margin-left:6px'}));
        tag.textContent=follows?'set from the bay layout ('+(lens.length-1)+' interior lines'+(['front_end','rear_end'].some(e=>r[e]?.type==='rigid_frame')?' + rigid end frames':'')+')':'';}
      drawBayList();window.__mbdpBayLayoutStatus?.();
    }
    window.__mbdpRefreshBuildingPreview=refreshBuildingPreview;
    // Bay lengths shown / edited on the bay layout card: automatic = equal bays up to max spacing; explicit = typed
    function bayLengths(){const r=P.bay_layout||{},L=inches(P.length);
      if(!r.enabled)return[];
      if(r.layout_mode==='explicit')return(r.bay_lengths||[]).map(x=>inches(x)||0);
      if(r.layout_mode==='standard')return window.MBDim.standardBays(L);
      const n=r.layout_mode==='max_spacing'?Math.ceil(L/(inches(r.max_spacing||"20'")||240)):Number(r.bays||4);
      return n>0&&Number.isFinite(n)?Array.from({length:n},()=>L/n):[];}
    function drawBayList(){const host=document.querySelector('[data-bay-list]');if(!host)return;const r=P.bay_layout;host.replaceChildren();if(!r.enabled)return;
      const lens=bayLengths(),typed=r.layout_mode==='explicit';
      const row=el('div',{style:'display:flex;flex-wrap:wrap;gap:6px;align-items:center'});
      lens.forEach((x,i)=>{const inp=el('input',{value:window.MBDim.fmt(x),size:9,title:'Bay '+(i+1)+(typed?'':' — type a size to override this bay'),'data-bay-length':i});
        inp.addEventListener('change',()=>{const list=bayLengths().map((v,j)=>j===i?(inches(inp.value)||0):v);r.layout_mode='explicit';r.bay_lengths=list.map(v=>window.MBDim.fmt(v));delete r.rule_sha256;const sel=document.querySelector('[data-run-field="layout_mode"]');if(sel)sel.value='explicit';refreshBuildingPreview();});
        row.append(el('label',{style:'display:inline-flex;flex-direction:column;font-size:.85em'},el('span',{},'Bay '+(i+1)),inp));});
      if(typed)row.append(el('button',{type:'button',class:'mini',onclick:()=>{r.bay_lengths=[...(r.bay_lengths||[]),"20'"];refreshBuildingPreview();}},'+ bay'),el('button',{type:'button',class:'mini',onclick:()=>{if((r.bay_lengths||[]).length>1){r.bay_lengths=r.bay_lengths.slice(0,-1);refreshBuildingPreview();}}},'− bay'));
      else if(r.layout_mode!=='max_spacing')row.append(el('button',{type:'button',class:'mini',onclick:()=>{r.layout_mode='max_spacing';delete r.bay_lengths;delete r.rule_sha256;const sel=document.querySelector('[data-run-field="layout_mode"]');if(sel)sel.value='max_spacing';refreshBuildingPreview();}},'Use automatic equal bays'));
      host.append(row);}
    if(frameId && !job.settings.frames[frameId].connection_bottom_mode)P.connection_bottom_mode="manual";
    if(frameId && !job.settings.frames[frameId].first_purlin_datum)P.first_purlin_datum="rafter_cut";
    if(frameId && !job.settings.frames[frameId].plate_mode)P.plate_mode="library";
    if(P.apex_bottom_half==null)P.apex_bottom_half=String(Math.round((job.parts['AP-'+frameId]?.symbol?.bottom_length_in||6)*1000000))+'/1000000"';
    if(P.peak_clip_edge==null)P.peak_clip_edge="";
    P.apex_reference_half=null; // UI now edits FINISHED bottom half, never hidden reference half.
    if(P.high_girt_elevations==null)P.high_girt_elevations="";
    if(Array.isArray(P.high_girt_elevations))P.high_girt_elevations=P.high_girt_elevations.length?P.high_girt_elevations.join(", "):"none";
    if(Array.isArray(P.girt_elevations))P.girt_elevations=P.girt_elevations.join(", ");
    // Shop girt rule (shop_rules.js = standards.girt_lines): a NEW frame starts with the standard
    // lines for its eave height / foundation / walk door and follows edits to those until the girt
    // field itself is edited; the "Standard" button re-applies the rule at any time.
    const girtAuto={on:!frameId};
    const walkDoorPresent=()=>(P.cladding?.openings||[]).some(o=>(o.kind||'door')==='door'&&inches(o.height||'0')<=90&&inches(o.width||'0')<=60);
    const standardGirts=()=>window.MBRules.girtLinesText(inches(P.eave_height),P.foundation,walkDoorPresent());
    if(!frameId){P.girt_elevations=standardGirts();if(P.foundation==='post_footing'){P.slab=false;P.starting_wall_run=false;}else{P.slab=true;P.starting_wall_run=true;}}
    if(Array.isArray(P.flange_brace_at))P.flange_brace_at=P.flange_brace_at.join(", ");
    P.secondary=JSON.parse(JSON.stringify(P.secondary||{}));
    const productPolicy=job.settings.product_suppliers||{primary:'sss',secondaries:'sss',sheets:'sss',trim:'sss'};
    const productSupplier=id=>String(id).startsWith('SSS-')||String(id).startsWith('SSS / ')?'sss':'mbci';
    const secCatalog={...S.state.catalog.secondary,profiles:(S.state.product_libraries?.secondaries||S.state.catalog.secondary.profiles).filter(x=>productSupplier(x.id)===productPolicy.secondaries)};
    // Shop standard (server: standards.SSS_STANDARD) pre-fills a NEW frame under the matching supplier policy; every value stays editable.
    const supplierStd=(cat)=>((S.state.catalog.supplier_defaults||{})[productPolicy[cat]]||null);
    if(!frameId&&supplierStd('secondaries')){
      const STD=supplierStd('secondaries');
      P.base_angle=JSON.parse(JSON.stringify(STD.base_angle));
      for(const role of ['purlin','girt','eave'])if(!(P.secondary[role]&&P.secondary[role].profile_id))P.secondary[role]=JSON.parse(JSON.stringify(STD.secondary[role]));
      P.bay_layout=P.bay_layout||{};for(const [k,v] of Object.entries(STD.bay_layout||{}))if(P.bay_layout[k]==null)P.bay_layout[k]=v;
    }
    const secControls={};
    const secondaryManualDepths={purlin:P.purlin_depth,girt:P.girt_depth,eave:[`6"`,`8"`].includes(P.eave_strut_depth)?P.eave_strut_depth:`8"`};
    function secondaryFields(){
      const items=el("div",{},el("h3",{},"Supplier secondary profiles"),el("p",{class:"hint"},"Optional, source-pinned nominal profiles. Purlin selection drives welded purlin depth; sidewall girt drives its optional inset; ENDWALL GIRT can use a separate product/depth (blank follows sidewall girt); eave selection drives bolted nominal strut depth. Blank retains manual dimensions. Gauge thickness, lips, bend radii and exact installed fit are NOT inferred. Ordered quantities below are optional TOTAL LOT pieces, not per frame; blank means not counted. Automatic bays/laps are configured separately below. No capacity is inferred."));
      for(const role of ["purlin","girt","endwall_girt","eave","accessory"]){
        const spec=P.secondary[role]||{profile_id:"",finish:"Red Oxide",quantity:"",piece_length:""};P.secondary[role]=spec;
        const allowed=[...secCatalog.profiles,...(role==="eave"?(S.state.catalog.eave_references||[]):[])].filter(x=>role==="eave"?((x.family==="Eave"&&x.eave_kind.startsWith("low_"))||(["C","Z"].includes(x.family)&&x.nominal_depth_in>=4&&x.nominal_depth_in<=8)):role==="accessory"?["Angle","Channel"].includes(x.family):["C","Z"].includes(x.family));
        const pick=el("select",{"data-secondary-role":role},el("option",{value:""},role==="endwall_girt"?"Follow sidewall girt (default)":"Manual / none"),...allowed.map(x=>el("option",{value:x.id},x.designation+(x.eave_kind?" / "+x.eave_kind:"")+(x.stock_length_ft?" / "+x.stock_length_ft+" ft stock":""))));pick.value=spec.profile_id;
        const finish=el("select",{"data-secondary-finish":role});
        const length=el("input",{value:spec.piece_length||"",size:9,"data-secondary-length":role});length.oninput=()=>spec.piece_length=length.value;
        const qty=el("input",{value:spec.quantity||"",size:6,"data-secondary-qty":role});qty.oninput=()=>spec.quantity=qty.value;
        const note=el("p",{class:"hint"});
        function update(){
          const entry=allowed.find(x=>x.id===spec.profile_id);finish.innerHTML="";
          for(const name of entry?.finishes||["Red Oxide"])finish.append(el("option",{value:name},name));
          if(entry&&!entry.finishes.includes(spec.finish))finish.append(el("option",{value:spec.finish},spec.finish+" — NOT LISTED; choose finish"));finish.value=spec.finish;
          note.textContent=entry?.custom_reference?"USER6in NOMINAL EAVE REFERENCE ONLY: supplier profile, gauge, weight and actual seat fit are not established. No supplier product is substituted.":entry?"Source p."+entry.pdf_page+" | "+secCatalog.source.revision+" | nominal depth "+entry.nominal_depth_in+' in | '+(entry.flanges_in?"flanges "+entry.flanges_in.join(" / ")+" in":"actual flange dimensions not specified")+" | "+(entry.weight_lb_ft!==null?entry.weight_lb_ft+" lb/ft":"finish-specific stock weight")+(entry.family==="Eave"?" | HOLD: actual height depends on pitch; differing technical-manual sections differ.":""):"No catalog profile selected.";
          finish.disabled=length.disabled=qty.disabled=!entry;
        }
        pick.onchange=()=>{const key={purlin:"purlin_depth",girt:"girt_depth",eave:"eave_strut_depth"}[role];if(key&&!spec.profile_id&&pick.value)secondaryManualDepths[role]=P[key];if(key&&!pick.value){P[key]=secondaryManualDepths[role];control(key).value=P[key];}spec.profile_id=pick.value;delete P.secondary.catalog_sha256;if(!pick.value){spec.quantity="";spec.piece_length="";}update();applicable();};
        finish.onchange=()=>spec.finish=finish.value;
        update();secControls[role]={pick,spec};
        items.append(grid([role==="eave"?"LOW EAVE (mono high quantity pending)":role==="endwall_girt"?"ENDWALL GIRT (blank follows sidewall)":role.toUpperCase(),pick],["Finish",finish],["Ordered piece length (optional)",length],["TOTAL lot pieces (optional)",qty]),note);
      }
      items.append(el("button",{onclick:()=>browseSecondaries(()=>openModal(box,{dock:settingsDocked()}))},"Browse selected supplier sections"));
      return items;
    }
    function browseSecondaries(back){
      const table=el("table",{class:"bom-table"});const search=el("input",{placeholder:"Filter: Z, 8 x, Channel, Eave…",size:42});
      const draw=()=>{table.innerHTML="";table.append(el("tr",{},...['Section (local ID)','Gauge','Flanges (in)','Weight','Source page'].map(t=>el("th",{},t))));for(const x of secCatalog.profiles.filter(x=>(x.designation+' '+x.id).toLowerCase().includes(search.value.toLowerCase()))){table.append(el("tr",{},...[x.designation+(x.eave_kind?' '+x.eave_kind:'')+(x.stock_length_ft?' / '+x.stock_length_ft+' ft':''),x.gauge,x.flanges_in?.join(' / ')||'unknown',x.weight_lb_ft!==null?x.weight_lb_ft+' lb/ft':JSON.stringify(x.stock_weight_lb),x.pdf_page].map(v=>el("td",{},String(v)))));}};search.oninput=draw;draw();
      openModal(el("div",{},el("h2",{},"Selected supplier product sections"),el("p",{class:"hint"},secCatalog.source.title+' | '+secCatalog.source.revision+' | page effective '+secCatalog.source.page_effective_date+'. Local application IDs are not MBCI order codes. Catalog envelopes only; no inferred thickness, lips, capacities or prices.'),search,table,el("button",{onclick:back},"Back to frame wizard")));
    }
    const stdAngle=productPolicy.secondaries==="sss"?"SSS-CAB1":"MBCI-Angle-2x4-G14";P.base_angle=JSON.parse(JSON.stringify(P.base_angle||{profile_id:stdAngle,finish:"Red Oxide"}));
    P.base_angle.profile_id ||= stdAngle;P.base_angle.finish ||= "Red Oxide";
    const bayDefaults={};
    P.bay_layout=JSON.parse(JSON.stringify(P.bay_layout||{}));
    function runFields(){
      const R=P.bay_layout;Object.entries({enabled:true,bays:4,spacing:`20'`,front_clearance:`1/4"`,rear_clearance:`1/4"`,purlin_pattern:'A_butt',girt_pattern:'A_butt',purlin_lay:'span',purlin_lap_in:'',purlin_direction:'forward',girt_direction:'forward'}).forEach(([k,v])=>{if(R[k]==null)R[k]=v;});
      const input=(obj,k,id)=>el('input',{value:obj[k]||'',size:12,'data-run-field':id||k,oninput:e=>{obj[k]=e.target.value;refreshBuildingPreview();}});
      const select=(obj,k,opts,id)=>el('select',{'data-run-field':id||k,onchange:e=>{const was=obj[k];obj[k]=e.target.value;delete R.rule_sha256;if(k==='layout_mode'&&obj[k]==='explicit'&&!(R.bay_lengths||[]).length){R.layout_mode=was==='explicit'?'standard':was;R.bay_lengths=bayLengths().map(v=>window.MBDim.fmt(v));R.layout_mode='explicit';}refreshBuildingPreview();}},...opts.map(([v,t])=>el('option',{value:v,selected:obj[k]===v?'':null},t)));
      // new frames follow the shop standard (20 ft bays); frames saved with a count keep their equal bays
      R.layout_mode ||= (R.bay_lengths?.length?'explicit':(frameId&&job.settings.frames[frameId]?.bay_layout?.bays?'count':frameId?'standard':'max_spacing'));R.max_spacing ||= `20'`;
      const body=el('div',{class:R.enabled?'':'hidden'},grid(['Bay layout',select(R,'layout_mode',[['standard','Standard — 20 ft bays, odd bay in the middle'],['explicit','Bay sizes entered below'],['count','Equal bays — enter count (legacy)'],['max_spacing','Automatic equal bays — maximum spacing']])],['Equal bay count',input(R,'bays')],['Auto maximum spacing (not capacity)',input(R,'max_spacing')],['Left-end terminal allowance (lapped)',input(R,'front_clearance')],['Right-end terminal allowance (lapped)',input(R,'rear_clearance')]),el('div',{'data-bay-list':''}),el('p',{class:'hint'},'End support stations coincide with endwall planes (zero offset assumption).'));

      const patterns=Object.entries(S.state.catalog.run_patterns.patterns).map(([k,v])=>[k,v.label]);
      for(const role of ['purlin','girt'])body.append(grid([role+' lap length',select(R,role+'_pattern',patterns)],[role+' offset direction',select(R,role+'_direction',[['forward','As printed: LEFT END → RIGHT END'],['reverse','Reversed: RIGHT END → LEFT END']])]));
      // Round 16: purlin stock lengths land on the rafter CENTRES.  One stock length spans every whole bay it
      // can (15 + 15 -> one 30 ft stick); a purlin is never spliced between rafters.  A Zee laps over a rafter.
      delete R.purlin_stock_in;
      body.append(grid(['Purlin lay',select(R,'purlin_lay',[['span','Stock lengths span whole bays — joints only at rafter centres (standard)'],['per_bay','One piece per bay']])],['Zee lap over each rafter (TOTAL, centred on the rafter; blank = 12 in SSS Zee shop standard / butt otherwise; enter 0 for a butt)',input(R,'purlin_lap_in')]),el('p',{class:'hint'},'Stock lengths follow the product (Order settings > stock lengths; an SSS Cee is bought 20 / 25 / 30 ft, an SSS Zee 21 / 26 / 30 ft). A flush run sits beside each rafter, so it stays one piece per bay and is cut to length from stock.'));
      for(const role of ['purlin','girt'])for(const which of ['starting','middle']){
        const k=role+'_'+which+'_clearance';bayDefaults[k]=R[k]==null;
        if(R[k]==null)R[k]=P[role+'_mode']==='flush'?`1/8"`:`1/2"`;
        const x=input(R,k);x.addEventListener('input',()=>bayDefaults[k]=false);
        body.append(grid([role+' '+(which==='starting'?'starting / end':'middle')+' bay clearance (TOTAL)',x]));
      }
      body.append(el('p',{class:'hint'},'Flush: CL spacing minus half of each facing web, minus TOTAL clearance (default 1/8 in). End web sizes use entered end references; missing sizes HOLD end-bay cuts. Simple bypass: total end gaps default 1/2 in per piece (1/4 each end). Lap extents remain manufacturer-defined; left/right-end terminal allowances above apply only to lapped runs.'));
      for(const end of ['front_end','rear_end']){
        const e=R[end]||{type:'bearing_endwall',column_section:'',rafter_section:'',post_spacing:''};R[end]=e;
        body.append(el('h4',{},end==='front_end'?'Left endwall support':'Right endwall support'),grid(['End type',select(e,'type',[['bearing_endwall','Post-supported load-bearing endwall'],['reduced_rigid','Reduced rigid frame']],end+'_type')],['Column / post section reference',select(e,'column_section',[['','PENDING'],...(S.state.catalog.column_sections||S.state.catalog.sections).map(s=>[s,s])],end+'_column')],['Rafter section reference',select(e,'rafter_section',[['','PENDING'],...(S.state.catalog.rafter_sections||S.state.catalog.sections).map(s=>[s,s])],end+'_rafter')],['Post spacing (bearing only)',input(e,'post_spacing',end+'_posts')]));
      }
      body.append(el('p',{class:'hint'},'Select the supplier roof/girt/eave profiles above. Clear their manual order lengths and quantities before enabling runs. Cees are simple-span only here; lap choices require verified unequal-flange Zees. Common-web scope: 6–10 in C/Z or 12 in Z. Starting eave clips support the two eave runs, not extra C/Z rows. Eave lengths/weights remain PENDING. These reference fields alone do not generate end members. Enable Separate endwall framing below for setout/counts; structural sizing is never inferred. Primary frame lot quantity remains separate (interior grid lines = bays minus one).'));
      const on=el('input',{type:'checkbox','data-run-field':'enabled',onchange:e=>{R.enabled=e.target.checked;body.classList.toggle('hidden',!R.enabled);refreshBuildingPreview();}});on.checked=R.enabled;
      const weldedOverride = el('input',{type:'checkbox','data-welded-fit-override':'',checked:P.welded_fit_rules?.enabled===false?'':null,onchange:e=>{P.welded_fit_rules||={};P.welded_fit_rules.enabled=!e.target.checked;updateWeldedRuleMessage();}});
      return el('div',{},el('p',{class:'standard-rule'},el('strong',{},'OWNER WELDED STANDARD — ACTIVE BY DEFAULT'),': bypass purlins end at outside-edge planes and butt at interior rafter centerlines with zero gap; column-web girt clips use the long-side-parallel orientation where clips are used.'),el('label',{},weldedOverride,' Nonstandard welded-fit override for this frame'),el('p',{class:'hint'},'This override applies only to welded-fit rules for this frame. Flush purlins retain their own fit rule. Bolted construction is a separate explicit connection choice.'),el('h3',{},'Equal-bay secondary runs'),el('label',{},on,' Automatically generate roof, sidewall and both eave secondary runs'),body);
    }
    P.welded_fit_rules=JSON.parse(JSON.stringify(P.welded_fit_rules||{}));
    P.section_defaults=JSON.parse(JSON.stringify(P.section_defaults||{}));
    P.endwalls=JSON.parse(JSON.stringify(P.endwalls||{}));
    function endwallFields(){
      const E=P.endwalls;
      const input=(obj,k,id,placeholder='')=>el('input',{value:obj[k]??'',size:13,placeholder,'data-end-field':id,oninput:e=>{obj[k]=e.target.value;if(k==='x'&&obj.id){const r=P.additions.opening_members[obj.id]||={};r.placement='existing';}}});
      const select=(obj,k,items,id)=>el('select',{'data-end-field':id,onchange:e=>obj[k]=e.target.value},...items.map(([v,t])=>el('option',{value:v,selected:(obj[k]||'')===v?'':null},t)));
      const body=el('div',{class:E.enabled?'':'hidden'});
      // All three wall cards are built up front; the outer (roof-only) end card is shown by
      // settings_stepper.js only while bay enclosure places the junction right of Frame line 1.
      for(const end of ['front_end','rear_end','outer_front_end']){
        const prior=P.bay_layout[end]||{};
        const e=E[end]||{type:prior.type||'bearing_endwall',bays:'',rafter_override:'',column_override:prior.column_section||'',post_family:'W',post_section:'W6X9',post_profile_id:'',post_finish:'Red Oxide',tube_size:'4x4',tube_wall:'14 ga',tube_actual_wall:'',base_thickness:`1/2"`,top_clearance:`0"`,include_girts:true,enclosure:'sheeted'};E[end]=e;e.post_layout||=(e.bays||e.bay_widths)?'bays':'standard';e.enclosure||='sheeted';e.end_posts||='auto';
        const optional=[['','Follow preset / rafter'],...(S.state.catalog.column_sections||S.state.catalog.sections).map(v=>[v,v])];
        const family=select(e,'post_family',[['W','Wide flange W6–W8'],['C','Selected supplier Cee — girt depth'],['Channel','Open-face channel'],['HSS','Requested HSS / tube']],end+'_family');
        const wide=grid(['Intermediate W post',select(e,'post_section',S.state.catalog.sections.filter(v=>/^W[68]X/.test(v)).map(v=>[v,v]),end+'_post')]);
        const cee=grid(['Intermediate post product',select(e,'post_profile_id',[['','Match girt depth / default 14 ga'],...secCatalog.profiles.filter(x=>['C','Channel'].includes(x.family)).map(x=>[x.id,x.designation])],end+'_cee')]);
        const tube=el('div',{},grid(['Tube size (requested nominal)',select(e,'tube_size',S.state.catalog.endwall_rules.tube_sizes.map(x=>[x,x]),end+'_tube')],['Tube wall label',select(e,'tube_wall',S.state.catalog.endwall_rules.tube_walls.map(x=>[x,x]),end+'_wall')],['Actual wall thickness (optional verified value)',input(e,'tube_actual_wall',end+'_actual')]),el('p',{class:'hint'},'Tube sizes are requested nominal dimensions, NOT verified availability. Gauge is NOT converted to thickness. Tube weight and CNC output remain held. Actual wall value does not approve capacity or connection fit.'));
        const forceChannel=()=>{const channel=/^(MBCI-Channel|SSS-SS)/.test(e.rafter_override||'')||e.rafter_override==='channel';const mode=body.querySelector('[data-end-field="'+end+'_roof_mode"]');if(channel){e.roof_mode='flush';if(mode)mode.value='flush';}if(mode)mode.disabled=channel;};
        body.addEventListener('change',forceChannel);queueMicrotask(forceChannel);
        const reveal=()=>{wide.classList.toggle('hidden',e.post_family!=='W');cee.classList.toggle('hidden',!['C','Channel'].includes(e.post_family));tube.classList.toggle('hidden',e.post_family!=='HSS');const choices=secCatalog.profiles.filter(x=>x.family===e.post_family),node=cee.querySelector('select');node.replaceChildren(el('option',{value:''},e.post_family==='Channel'?'Choose actual channel product':'Match girt depth / default 14 ga'),...choices.map(x=>el('option',{value:x.id},x.designation)));if(e.post_profile_id&&!choices.some(x=>x.id===e.post_profile_id))node.append(el('option',{value:e.post_profile_id},'Previous product — choose matching family'));node.value=e.post_profile_id||'';};family.addEventListener('change',reveal);reveal();
        const girts=el('input',{type:'checkbox','data-end-field':end+'_girts',onchange:x=>e.include_girts=x.target.checked});girts.checked=!!e.include_girts;
        const enclosure=select(e,'enclosure',[['sheeted','Sheeted end wall — girts and wall sheets'],['open','OPEN end wall — posts and end rafter only (no girts, base angle or sheets)']],end+'_enclosure');
        const syncEnclosure=()=>{const open=e.enclosure==='open';girts.disabled=open;if(open){girts.checked=false;e.include_girts=false;}};enclosure.addEventListener('change',syncEnclosure);queueMicrotask(syncEnclosure);
        e.post_head_overrides ||= {};
        const savedEnd=job.settings.frame_layouts?.[frameId]?.endwalls?.[end];
        const savedPosts=savedEnd?.posts||[];
        const outerHeads=savedPosts.filter(r=>r.role==='outer column');
        const addedHeads=savedPosts.filter(r=>r.role!=='outer column');
        const headOverridePanel=el('details',{class:'connection-override-list'+(end==='outer_front_end'&&!(P.bay_zones?.enabled&&Number(P.bay_zones.enclosed_start_line)>0)?' hidden':'')},el('summary',{},'Per-location corner connection overrides (optional)'));
        if(!outerHeads.length){
          headOverridePanel.append(el('p',{class:'hint'},'Generate the endwall layout once to list its corner-column marks here.'));
        }else{
          const choices=[['','Inherit endwall default'],['legacy','COLUMN SEAT / legacy'],['direct_welded','PITCH-CUT / direct contact'],['side_welded','INSIDE FACE / column to roof line']];
          for(const post of outerHeads){
            headOverridePanel.append(grid([post.mark,select(e.post_head_overrides,post.mark,choices,end+'_head_'+post.mark)]));
          }
          for(const mark of Object.keys(e.post_head_overrides))if(!outerHeads.some(post=>post.mark===mark)){
            headOverridePanel.append(grid([mark+' — no current corner column; clear or revise this stale override',select(e.post_head_overrides,mark,choices,end+'_head_'+mark)]));
          }
          if(addedHeads.length)headOverridePanel.append(el('p',{class:'hint'},'Added posts and bearing jambs use the existing pitch-cut / direct-contact head. No alternate geometry is defined for these locations.'));
        }
        body.append(el('details',{'data-wall-card':end,open:'',class:end==='outer_front_end'&&!(P.bay_zones?.enabled&&Number(P.bay_zones.enclosed_start_line)>0)?'hidden':''},el('summary',{'data-wall-title':end},end==='outer_front_end'?'Outer left end (bay 1, roof-only)':end==='front_end'?'Left endwall / inside wall (junction)':'Right endwall'),grid(['End wall enclosure',enclosure],['Interior end posts',select(e,'end_posts',[['auto','Auto — standard posts when SHEETED, NONE when OPEN (end rafter = main rafter section: rigid end frame)'],['always','Always — standard posts by width, also on an open end'],['never','Never — no interior posts, end rafter spans corner column to corner column']],end+'_end_posts')],['End support system',select(e,'type',[['bearing_endwall','Post-supported bearing endwall'],['reduced_rigid','Reduced rigid + nonbearing wall posts']],end+'_type')],['Post layout',select(e,'post_layout',[['standard','Standard posts by width (30: 15/15, 40: 20/20, 50: 20/10/20; else equal ≤ 20 ft)'],['bays','Bay count / widths'],['stations','Editable interior stations']],end+'_post_layout')],['Custom post centerlines from outside-view left wall, left-to-right (30 ft example: 9 ft 10 in, 20 ft 2 in)',input(e,'post_stations',end+'_post_stations','30 ft example: 9 ft 10 in, 20 ft 2 in')],['TOTAL bays across endwall (odd counts allowed)',input(e,'bays',end+'_bays','blank = standard posts by width (30: 15/15, 40: 20/20, 50: 20/10/20; else ≤ 20 ft)')],['Optional unequal bay widths (comma separated)',input(e,'bay_widths',end+'_bay_widths','Total = outer post centerline span')],['Corner-column / rafter connection',select(e,'post_head',[['side_welded','(a) INSIDE FACE - corner column to the ROOF LINE, rafter welded to its inside face (standard with FLUSH channel)'],['legacy','(b) ON THE COLUMN SEAT - rafter sits ON the corner column (standard with BYPASS W)'],['direct_welded','(c) DIRECT WELD - corner column pitch-cut and welded to the rafter underside, no cap']],end+'_post_head')],['End ridge detail (face clip: channel only)',select(e,'ridge_joint',[['legacy','Prior reference geometry'],['face_clip','3/16 x5 tall x7 wide FACE CLIP / butt']],end+'_ridge_joint')],['End roof secondary fit',select(e,'roof_mode',[['bypass','Bypass end rafter (standard): purlins over the rafter, rake angle on top of the purlins'],['flush','Flush end rafter (channel / override): purlins between flanges, roof line = top of rafter']],end+'_roof_mode')],['Owner confirms purlin fits channel — omit added depth clearance',(()=>{const n=el('input',{type:'checkbox','data-end-field':end+'_purlin_channel_fit_confirmed',onchange:v=>e.purlin_channel_fit_confirmed=v.target.checked});n.checked=!!e.purlin_channel_fit_confirmed;return n;})()],['TOTAL depth clearance (ignored when confirmed)',input(e,'roof_depth_clearance',end+'_roof_depth_clearance','1/4')],['End rafter override',select(e,'rafter_override',[['','Standard: W preset (W8×10 to 40 ft, W10×12 above) — bypass + rake angle'],['channel','Open-face channel matching the purlin depth (6/8/10 in) — flush, purlins inside the channel'],...(S.state.catalog.rafter_sections||S.state.catalog.sections).map(v=>[v,v])],end+'_rafter')],['Outer column W / tube (blank: W rafter, otherwise main column)',select(e,'column_override',optional,end+'_column')],['Intermediate post family',family]),wide,cee,tube,grid(['Post finish (Cee / tube reference)',select(e,'post_finish',[['Red Oxide','Red Oxide'],['Galvanized','Galvanized']],end+'_finish')],['End-post base plate thickness allowance',input(e,'base_thickness',end+'_base')],['Corner-column seat / direct-head clearance (added posts meet rafter underside directly)',input(e,'top_clearance',end+'_head')],['Include endwall girts at existing wall elevations',girts])));
        body.append(headOverridePanel);
      }
      const compatibility=el('p',{class:'hint','data-end-compatibility':'notice'});
      const refreshCompatibility=()=>{
        const changed=['front_end','rear_end'].filter(k=>{
          const r=E[k]||{};return !/^(MBCI-Channel|SSS-SS)/.test(String(r.rafter_override||'W')) && (r.purlin_channel_fit_confirmed || r.ridge_joint==='face_clip' || r.channel_ridge_retired);
        });
        compatibility.textContent=changed.length?'SECTION CHANGE: '+changed.map(k=>k==='front_end'?'LEFT':'RIGHT').join(' / ')+' end: channel-fit confirmation and channel-only peak plates will NOT carry over to W rafters. Those clips are removed on Apply; the W end-ridge connection remains explicitly REVIEW REQUIRED. Columns and openings keep their separate settings.':'Each end has its own rafter and roof-mode settings. These controls are editable on every job; interior rafters remain independent.';
      };
      body.addEventListener('change',refreshCompatibility);refreshCompatibility();body.append(compatibility);
      body.append(el('p',{class:'hint'},'Shop standard: W8×10 through 40 ft, W10×12 above 40 ft, BYPASS with the rake angle on top of the purlins (4 in leg down over the purlin ends); only open-face channel end rafters are flush (channel depth = purlin depth: 6 in channel for 6 in purlins, 8 in for 8 in, 10 in for 10 in; the purlin sits inside the open face 1/4 in from the web, welded to the flanges). Carports: interior rafter = two channels welded back to back (I), single channel end rafters. Posts centred by width: 30 ft = 15/15, 40 ft = 20/20, 50 ft = 20/10/20; other widths equal bays at 20 ft maximum. Outer columns follow rafter unless overridden. Bay count controls post count; odd counts allowed. Widths must sum to outer post-centerline span. No ridge post is forced; a post may land there naturally. Spans over20ft warn. Reduced-frame intermediate posts are labeled nonbearing. Endwall quantities are separate and counted once per end, not multiplied by interior frame quantity.'));
      body.append(el('p',{class:'hint'},'Only Building settings > End walls & openings edits these inputs; the endwall elevation tabs are review drawings, not a second editor and do not override settings. Added intermediate and opening/bearing-jamb posts retain pitch-cut direct contact. Corner columns inherit the endwall default unless their per-location override below is set. Endwall girt product/depth is chosen in Secondaries (blank follows sidewall girt); elevations/layout remain shared. Endwall girt lengths use simple butt fit or flush web clearances, not sidewall lap patterns.'));
      const on=el('input',{type:'checkbox','data-end-field':'enabled',onchange:x=>{E.enabled=x.target.checked;body.classList.toggle('hidden',!E.enabled);}});on.checked=!!E.enabled;
      return el('div',{},el('h3',{},'Separate endwall framing'),el('label',{},on,' Generate left and right endwall setout / quantities'),body);
    }
    P.additions=JSON.parse(JSON.stringify(P.additions||{}));P.additions.opening_auto??=true;P.additions.opening_members||={};
    P.cladding=JSON.parse(JSON.stringify(P.cladding||{}));
    function claddingFields(){
      const C=P.cladding,cat=S.state.catalog.cladding;
      if(productPolicy.sheets==='sss'){C.panel_profile_id||=supplierStd('sheets')?.cladding?.panel_profile_id||'SSS-PBR';C.supplier_products=true;}
      if(productPolicy.trim==='sss')C.supplier_products=true;
      const input=(obj,k,id,placeholder='inches or ft-in')=>el('input',{value:obj[k]??'',placeholder,size:14,'data-cladding-field':id,oninput:e=>{const oldId=obj.id;obj[k]=e.target.value;if(k==='id'&&P.additions.opening_members[oldId]){P.additions.opening_members[obj.id]=P.additions.opening_members[oldId];delete P.additions.opening_members[oldId];}if(k==='x'&&obj.id){const r=P.additions.opening_members[obj.id]||={};r.placement='existing';const sel=document.querySelector('[data-addition-field="'+obj.id+'_placement"]');if(sel)sel.value='existing';}}});
      const select=(obj,k,items,id)=>el('select',{'data-cladding-field':id,onchange:e=>obj[k]=e.target.value},...items.map(([v,t])=>el('option',{value:v,selected:String(obj[k]??'')===String(v)?'':null},t)));
      const check=(k,defaultValue=true)=>{if(C[k]===undefined)C[k]=defaultValue;const n=el('input',{type:'checkbox','data-cladding-field':k,onchange:e=>C[k]=e.target.checked});n.checked=C[k];return n;};
      const body=el('div',{class:C.enabled?'':'hidden'});
      body.append(el('p',{class:'hint'},'36-in coverage PBR, 12-in rib centers, 1¼-in ribs. Vertical walls; single-piece eave→ridge roofs / low→high mono. No automatic panel splices or net-area-only sheet counts. Counts are ONE building, independent of frame quantity.'),grid(['Building length',el('span',{},'Uses master Length at top — no independent input')],['Include wall panels',check('walls')],['Include roof panels',check('roof')],['Eave + base trim (option - not automatic)',check('eave_base_trim',false)]));
      function finishFields(obj,id,trim=false){
        const swatch=el('span',{style:'display:inline-block;width:42px;height:24px;border:1px solid #777;vertical-align:middle'}),note=el('span',{class:'hint'});
        const color=select(obj,'color',[['','SELECT supplier color'],...cat.colors.filter(x=>productSupplier(x.name)===productPolicy[trim?'trim':'sheets']).map(x=>[x.name,x.name+' — '+x.coating])],id+'_color');
        const gauge=trim?null:select(obj,'gauge',(productPolicy.sheets==='sss'?[26]:[26,24,22]).map(x=>[x,x+' ga']),id+'_gauge');
        const update=()=>{const color=cat.colors.find(x=>x.name===obj.color);swatch.style.background=color?.hex||'#fff';if(trim)obj.gauge=color?.coating.startsWith('Signature 300')?24:26;note.textContent=' '+(trim?obj.gauge+' ga trim. ':'')+(color?.coating||'')+' — preview only, confirm metal chip / availability';};
        color.addEventListener('change',()=>{if(obj.color==='Copper Metallic'){obj.gauge=24;if(gauge)gauge.value='24';}update();});if(gauge)gauge.addEventListener('change',update);update();
        return el('div',{},grid(['Color',color],...(gauge?[['Gauge',gauge]]:[])),swatch,note);
      }
      for(const [role,color] of [['wall','Light Stone'],['roof','Polar White'],['trim','Burnished Slate']]){
        const stdFinish=supplierStd(role==='trim'?'trim':'sheets')?.cladding?.[role+'_finish'];
        C[role+'_finish'] ||= stdFinish?JSON.parse(JSON.stringify(stdFinish)):{color:productPolicy[role==='trim'?'trim':'sheets']==='sss'?'':color,gauge:26};body.append(el('h4',{},role.toUpperCase()+' default finish'),finishFields(C[role+'_finish'],role,role==='trim'));
      }
      C.surface_finishes ||= {};
      const overrides=el('details',{},el('summary',{},'Optional color / gauge overrides by elevation and roof'));
      for(const sid of ['front','rear','left','right','roof_left','roof_right','roof_mono']){
        const holder=el('div',{}),enabled=el('input',{type:'checkbox','data-cladding-field':sid+'_override'});enabled.checked=!!C.surface_finishes[sid];
        const show=()=>{holder.replaceChildren();if(enabled.checked){C.surface_finishes[sid] ||= {...C[sid.startsWith('roof')?'roof_finish':'wall_finish']};holder.append(finishFields(C.surface_finishes[sid],sid));}else delete C.surface_finishes[sid];};enabled.onchange=show;show();overrides.append(el('label',{},enabled,' '+faceName(sid)+' override'),holder);
      }
      body.append(grid(['Sheet product',select(C,'panel_profile_id',productPolicy.sheets==='sss'?[['SSS-PBR','SSS PBR — 36in / 12in ribs'],['SSS-PBU','SSS PBU — 36in / 6in ribs']]:[['MBCI-PBR','MBCI PBR']], 'panel_profile_id')]),overrides,el('h4',{},'Owner sheet and trim length standard'));
      body.append(grid(['Apply owner length standard (overrides manual eave/lean overhangs)',check('owner_length_rules',false)],['Slab-level door jamb trim: add 1½ in sheet lug',check('slab_jamb_lug',false)]));
      C.roof_edges||={};
      for(const sid of ['roof_left','roof_right','roof_mono']){
        const e=C.roof_edges[sid]||={};
        const flag=(key,def)=>{e[key]??=def;const x=el('input',{type:'checkbox','data-cladding-field':sid+'_'+key,onchange:v=>e[key]=v.target.checked});x.checked=e[key];return x;};
        body.append(grid([faceName(sid)+' — gutter at outer eave',flag('gutter',false)],['Wall sheets at this OUTER edge (incl. continuous lean)',flag('wall_sheets',C.walls!==false)]));
      }
      body.append(el('p',{class:'hint'},'When enabled: sheets and trim ordered to length; trim maximum20ft6in retained. Standard eave8in ALONG roof. Gutter projection2in beyond outside building, plus1½in for wall sheets, converted to slope length. Head trim +3in TOTAL. Slab jamb lug applies only to floor-level doors. General trim end extras below remain additional. Continuous lean uses its roof-side edge settings.'),el('h4',{},'Edge allowances — explicit project inputs'));
      const allowances=[['wall_bottom_clearance','Wall bottom clearance above floor','0'],['wall_top_allowance','Wall top allowance (+ extends / − cuts back)','0'],['roof_eave_extension','Roof eave extension ALONG SLOPE','0'],['roof_ridge_cutback','Roof ridge cutback ALONG SLOPE (gable)','0'],['roof_high_cutback','Roof high-side cutback ALONG SLOPE (mono)','0'],['roof_front_overhang','Roof LEFT END overhang ALONG BUILDING','0'],['roof_rear_overhang','Roof RIGHT END overhang ALONG BUILDING','0'],['trim_lap','Trim joint lap — PROJECT ASSUMPTION','2'],['trim_end_allowance','Trim extra EACH run end (returns/miters)','0']];
      for(const [k,label,def] of allowances){C[k]??=def;body.append(grid([label,input(C,k,k)]));}
      body.append(el('p',{class:'hint'},'Zero edge allowances are geometric references, NOT approved installation details. Trim lap defaults to 2 in as an explicit editable project assumption—not a manufacturer requirement. Confirm returns, miters, closures and seals. Eave SECONDARY member cuts remain held separately.'));
      C.trim_stock ||= {};const defaults={corner:'FL-830',base:'FL-530',rake:'FL-16',high_eave:'FL-17',eave:'FL-19',jamb:'FL-23',head:'FL-26',ridge:'FL-38',sill:''};
      const stdTrim=supplierStd('trim')?.cladding?.trim_stock||null;
      const stock=el('details',{},el('summary',{},'Trim profile references — lengths follow job order settings'));
      for(const [role,id] of Object.entries(defaults)){
        C.trim_stock[role]??=stdTrim?(stdTrim[role]||''):productPolicy.trim==='sss'?'':id;const opts=cat.trims.filter(x=>x.role===role&&productSupplier(x.id)===productPolicy.trim).map(x=>[x.id,x.id+' — '+x.label+' — '+x.stock_length_in+' in catalog reference']);if(role==='sill'||productPolicy.trim==='sss')opts.unshift(['','PENDING — no product ordered; choose profile or supplier override']);stock.append(grid([role.replace('_',' ').toUpperCase(),select(C.trim_stock,role,opts,'trim_'+role)]));
      }
      stock.append(el('p',{class:'hint'},'Signature 300 trim uses 24 ga; other trim defaults to 26 ga. FL-848 sill applies ONLY to fixed glass. Trim defaults to exact short lengths and a 20 ft 6 in maximum for long segments (Stock / exact rules). These profile IDs are references, not custom-length supplier SKUs. Structural slab 2×4 angle is separate. No gutter sizing, peak boxes/end caps, closures, sealants, screws or offcut optimization in these counts.'));body.append(stock);
      C.openings ||= [];const list=el('div',{'data-opening-list':''});
      const OVERHEAD_STOCK=[[8,8],[10,10],[12,12],[14,14],[16,14]]; // stock overhead door sizes (ft): one-click choices; any size can still be typed
      const openingPreview=o=>{
        const host=el('div',{class:'opening-preview'}),status=el('p',{class:'hint'});
        const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');
        svg.setAttribute('viewBox','0 0 420 170');svg.setAttribute('role','img');svg.setAttribute('aria-label','Schematic opening location preview');
        svg.style.width='100%';svg.style.maxWidth='520px';svg.style.height='auto';svg.style.border='1px solid #bbb';svg.style.background='#fff';
        const shape=(name,attrs)=>{const n=document.createElementNS(ns,name);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));svg.append(n);return n;};
        host.append(svg,status);
        const update=()=>{
          const q=P.additions.opening_members[o.id]||{},surface=o.surface||'right',sidewall=surface==='right'||surface==='left';
          const zoneBays=P.bay_zones?.enabled?(P.bay_zones.bays||[]).map(b=>inches(b.length)||0):[];
          const totalZone=zoneBays.reduce((a,b)=>a+b,0);
          const wallLen=sidewall?(totalZone||inches(P.length)||0):(inches(P.width)||0);
          let segments;
          if(sidewall){segments=zoneBays.length?zoneBays:bayLengths();if(surface==='left')segments=[...segments].reverse();}
          else{
            const end=P.endwalls?.[surface==='front'?'front_end':'rear_end']||{};
            if(end.post_layout==='stations'){
              const stations=(Array.isArray(end.post_stations)?end.post_stations:String(end.post_stations||'').split(',')).map(inches).filter(x=>x>0&&x<wallLen).sort((a,b)=>a-b);
              const edges=[0,...stations,wallLen];segments=edges.slice(1).map((x,i)=>x-edges[i]);
            }else if(end.bay_widths){const widths=Array.isArray(end.bay_widths)?end.bay_widths:String(end.bay_widths).split(',');segments=widths.map(inches).filter(x=>x>0);}
            else if(Number(end.bays)>0)segments=Array.from({length:Math.floor(Number(end.bays))},()=>wallLen/Math.floor(Number(end.bays)));
            else if(wallLen===600)segments=[240,120,240];
            else if(wallLen===360)segments=[180,180];
            else if(wallLen===480)segments=[240,240];
            else segments=Array.from({length:Math.max(1,Math.ceil(wallLen/240))},()=>wallLen/Math.max(1,Math.ceil(wallLen/240)));
          }
          if(!segments?.length)segments=[wallLen||1];
          const w=inches(o.width)||0,h=inches(o.height)||0,bottom=inches(o.y)||0,bay=Math.max(1,Math.floor(Number(q.bay)||1));
          const mode=q.placement||'existing';let x=inches(o.x)||0;
          if(mode==='wall_centered')x=(wallLen-w)/2;
          else if(mode==='centered'||mode==='offset'){
            if(bay<=segments.length){const start=segments.slice(0,bay-1).reduce((a,b)=>a+b,0);x=start+(segments[bay-1]-w)/2+(mode==='offset'?(inches(q.bay_offset)||0):0);}
            else x=NaN;
          }
          const wallH=Math.max(inches(P.eave_height)||144,bottom+h,1),x0=30,y0=18,drawW=360,drawH=126,ground=y0+drawH,scaleX=drawW/(wallLen||1),scaleY=drawH/wallH;
          svg.replaceChildren();
          shape('rect',{x:x0,y:y0,width:drawW,height:drawH,fill:'#fafafa',stroke:'#263445','stroke-width':1.5});
          shape('line',{x1:x0,y1:ground,x2:x0+drawW,y2:ground,stroke:'#263445','stroke-width':1.5});
          let station=0;for(let i=0;i<segments.length-1;i++){station+=segments[i];const bx=x0+station*scaleX;shape('line',{x1:bx,y1:y0,x2:bx,y2:ground,stroke:'#9aa7b5','stroke-dasharray':'4 3'});}
          if(Number.isFinite(x)&&w>0&&h>0){
            const openX=x0+x*scaleX,openY=ground-(bottom+h)*scaleY,openW=Math.max(2,w*scaleX),openH=Math.max(2,h*scaleY);
            shape('rect',{x:openX,y:openY,width:openW,height:openH,fill:'#b8d9ff',stroke:'#1f5c92','stroke-width':2});
          }
          const loc=Number.isFinite(x)?window.MBDim.fmt(x):'selected bay not available';
          status.textContent='Schematic preview · '+faceName(surface)+' · bay '+bay+' · '+mode.replace('_',' ')+' · X '+loc+' from this elevation’s stated origin. Opening: '+window.MBDim.fmt(w)+' × '+window.MBDim.fmt(h)+', bottom Y '+window.MBDim.fmt(bottom)+'. Not a framing/connection design.';
        };
        return {host,update};
      };
      const drawOpenings=()=>{
        list.replaceChildren();C.openings.forEach((o,i)=>{
          const row=el('div',{class:'cladding-opening',style:'border:1px solid #bbb;padding:10px;margin:10px 0'},grid(['Opening ID',input(o,'id','opening_'+i+'_id','Unique mark')],['Elevation (exterior view)',select(o,'surface',['right','left','front','rear'].map(x=>[x,x==='front'&&P.bay_zones?.enabled&&Number(P.bay_zones.enclosed_start_line)>0?'Enclosed junction wall (see location above)':faceName(x)]),'opening_'+i+'_surface')],['Kind',select(o,'kind',[['door','Walk door (3070 standard: header = 7\'-3 girt, jambs to that girt)'],['overhead','Overhead door (jambs full height to eave strut / end rafter, header at door height)'],['window','Window — sill profile pending'],['fixed_glass','Fixed-glass window (FL-848 optional)']],'opening_'+i+'_kind')],['X from LEFT as drawn',input(o,'x','opening_'+i+'_x')],['Bottom Y above FLOOR',input(o,'y','opening_'+i+'_y')],['Clear width BETWEEN JAMB FACES',input(o,'width','opening_'+i+'_width')],['Clear height TO HEADER FACE',input(o,'height','opening_'+i+'_height')]),openingRuleFields(P,o),el('button',{type:'button',onclick:()=>{C.openings.splice(i,1);drawOpenings();}},'Remove '+o.id));const preview=openingPreview(o);row.append(preview.host);row.addEventListener('input',preview.update);row.addEventListener('change',preview.update);preview.update();list.append(row);
        });
        queueMicrotask(()=>window.placeBuildingOpenings?.());
      };drawOpenings();
      body.append(el('label',{},el('input',{type:'checkbox',checked:P.additions.opening_auto?'':null,'data-addition-field':'opening_auto',onchange:e=>P.additions.opening_auto=e.target.checked}),' Enforce 6 in upright clearance (placement remains separate)'),el('p',{class:'hint'},'Rake angle is automatic TOP sheet screw support on every sheeted BYPASS end wall (on top of the purlins, 4 in leg down over the purlin ends); flush channel end walls and open end walls have none. Base angle is BOTTOM support. Main and lean-to endwalls follow the same rule.'),el('h4',{},'Positioned door / window panel openings'),el('p',{class:'hint'},'Outside-view coordinates: FRONT sidewall starts at LEFT endwall; BACK sidewall starts at RIGHT endwall. LEFT endwall starts at BACK sidewall; RIGHT endwall starts at FRONT sidewall. Saved IDs preserve physical opening locations. X increases right on the drawing; Y is above floor. Enter ACTUAL inside-face opening dimensions, not nominal door sizes. Window bottom Y locates the clear opening above floor. Openings do NOT remove or redesign steel framing.'),list,el('button',{type:'button','data-cladding-action':'add-opening',onclick:()=>{let n=1;while(C.openings.some(x=>x.id==='O'+n))n++;C.openings.push({id:'O'+n,surface:'right',kind:'door',x:'0',y:'0',width:"3'",height:"7'"});drawOpenings();}},'Add walk door (3\'-0 x 7\'-0)'),' ',...OVERHEAD_STOCK.map(([w,h])=>el('button',{type:'button','data-cladding-action':'add-overhead','data-size':w+'x'+h,title:'Add '+w+' × '+h+' ft overhead door; edit its size in Openings',onclick:()=>{let n=1;while(C.openings.some(x=>x.id==='OH'+n))n++;C.openings.push({id:'OH'+n,surface:'right',kind:'overhead',x:'0',y:'0',width:w+"'",height:h+"'"});drawOpenings();}},'OH door '+w+'x'+h)),' ',el('button',{type:'button','data-cladding-action':'add-window',onclick:()=>{let n=1;while(C.openings.some(x=>x.id==='W'+n))n++;C.openings.push({id:'W'+n,surface:'right',kind:'window',x:'0',y:"3'",width:"3'",height:"3'"});drawOpenings();}},'Add window'));
      const on=check('enabled',false);on.addEventListener('change',()=>body.classList.toggle('hidden',!C.enabled));
      return el('div',{},el('h3',{},'PBR sheets, openings & trim'),el('label',{},on,' Generate per-elevation / roof sheet and trim takeoff'),body);
    }

    function sectionPresetFields(){
      const R=P.section_defaults;const on=el('input',{type:'checkbox','data-preset-field':'enabled',onchange:e=>{R.enabled=e.target.checked;applicable();}});on.checked=!!R.enabled;
      const override=(k)=>el('select',{'data-preset-field':k,onchange:e=>R[k]=e.target.value},...['',...(k==='column_override'?(S.state.catalog.column_sections||S.state.catalog.sections):(S.state.catalog.rafter_sections||S.state.catalog.sections))].map(v=>el('option',{value:v,selected:(R[k]||'')===v?'':null},v||'Use width preset')));
      return el('div',{},el('h3',{},'Interior mainframe section presets'),el('label',{},on,' Use MY width table (not structural sizing)'),el('p',{class:'hint'},'Exact widths only: 20 ft W8×10; 30 ft W10×12; 40 ft W12×14; 50 ft W12×19. Other widths require manual mode. Column and rafter overrides remain independent.'),grid(['Preset column override',override('column_override')],['Preset rafter override',override('rafter_override')]));
    }
    const check=(key)=>{const x=el('input',{type:'checkbox','data-frame-field':key});x.checked=!!P[key];x.onchange=()=>{P[key]=x.checked;if(key==='slab'&&P.slab){P.starting_wall_run=true;control('starting_wall_run').checked=true;}applicable();};return x;};
    const inset=el("input",{type:"checkbox",id:"inset_for_bypass"});inset.checked=P.inset_for_bypass;inset.onchange=()=>{P.inset_for_bypass=inset.checked;applicable();};
    const starting=el("input",{type:"checkbox",id:"eave_start_clip","data-frame-field":"eave_start_clip"});starting.checked=P.eave_start_clip;starting.onchange=()=>P.eave_start_clip=starting.checked;
    const auto=el("input",{type:"checkbox"});auto.checked=P.auto_connections;auto.onchange=()=>P.auto_connections=auto.checked;
    const f = (k, o = {}) => { const i = el("input", { value: P[k], size: o.size || 12, "data-frame-field":k }); if(frameId && ["column_mark","rafter_mark","high_column_mark"].includes(k))i.readOnly=true; i.addEventListener("input", () => {P[k] = i.value;refreshBuildingPreview();}); return i; };
    const s = (k, opts) => { const x = el("select", {"data-frame-field":k}, ...opts.map(o => Array.isArray(o) ? el("option", { value: o[0], selected: o[0] === (P[k] || (k === "girt_attachment" ? "web_weld" : k === "ridge_fabrication" ? "standard" : "")) ? "" : null }, o[1]) : el("option", { value: o, selected: o === P[k] ? "" : null }, k==="connection_style"?({bolted:"Option — bolted brackets",fully_welded:"Shop standard — FULLY WELDED (seat, web-welded girts, cut-and-fold ridge)",welded_box:"Option — welded apex box, no bolts"}[o]):k==="foundation"?({slab:"A — Slab (columns from top of slab)",post_footing:"B — Post footing (posts embedded in holes)"}[o]):o))); if(frameId && k==="frame_type")x.disabled=true; x.addEventListener("change", () => {P[k] = x.value;if(k==="frame_type")monoFields.classList.toggle("hidden",P.frame_type!=="monoslope");if(k==="foundation")applicable();refreshBuildingPreview();}); return x; };
    const girtMoves=el("textarea",{rows:3,"data-frame-field":"girt_clip_adjustments",style:"width:100%"},(P.girt_clip_adjustments||[]).map(x=>`${x.column}, ${x.index}, ${x.offset}`).join("\n"));
    girtMoves.oninput=()=>{P.girt_clip_adjustments=girtMoves.value.split(/\n/).filter(x=>x.trim()).map(line=>{const v=line.split(',').map(x=>x.trim());return {column:v[0],index:Number(v[1]),offset:v.slice(2).join(',')};});};
    const monoFields=el("div",{class:P.frame_type==="monoslope"?"":"hidden"},el("h3",{},"High column (mono-slope)"),grid(["High column mark",f("high_column_mark")],["High column cut mark",f("high_column_cut_mark")],["High column section (blank follows low)",s("high_column_section",["",...(S.state.catalog.column_sections||S.state.catalog.sections)])],["High girt elevations (blank follows low)",f("high_girt_elevations",{size:24})]),el("p",{class:"hint"},"High eave is calculated on Generate: LOW eave + FULL outside-steel width x pitch / 12. Both heights are floor to TOP of eave strut. Base elevation and strut depth are shared. High girts are floor-referenced: blank follows low, or enter a separate comma-separated list; none means no high girt clips."));
    P.welded_knee_overrides ||= {};
    const primaryConnectionHost=el('div',{});
    const primaryConnectionPanel=el('details',{},el('summary',{},'Per-physical-column rafter seat overrides — inherits the selected frame default'),el('p',{class:'hint'},'Each repeated rigid-frame line has independently selectable left and right columns. Blank inherits the Rafter seat default above. The selected mode changes the column cut, rafter cut and head detail; distinct member marks and quantities are generated.'),primaryConnectionHost);
    const drawPrimaryConnectionSchedule=()=>{
      primaryConnectionHost.replaceChildren();
      if(P.connection_style==='bolted'){
        primaryConnectionHost.append(el('p',{class:'hint'},'Not available for bolted primary frames; those use the bolted knee geometry and its existing frame-wide connection settings.'));
        return;
      }
      const count=Math.max(1,Math.min(10000,Math.floor(Number(P.frames)||1)));
      const sideLabels=P.frame_type==='monoslope'?{left:'Low / left column',right:'High / right column'}:{left:'Left column',right:'Right column'};
      const options=[['','Inherit frame default'],['inside_flange','Inside flange — column to rafter top line'],['outside_seat','Outside seat — rafter on pitch-cut column']];
      for(let n=1;n<=count;n++){
        const row=[];
        for(const side of ['left','right']){
          const key=n+':'+side;
          const select=el('select',{'data-frame-connection-override':key,onchange:e=>{if(e.target.value)P.welded_knee_overrides[key]=e.target.value;else delete P.welded_knee_overrides[key];}},...options.map(([v,t])=>el('option',{value:v,selected:(P.welded_knee_overrides[key]||'')===v?'':null},t)));
          row.push(['Frame '+n+' — '+sideLabels[side],select]);
        }
        primaryConnectionHost.append(grid(...row));
      }
    };
    drawPrimaryConnectionSchedule();
    const err = el("div", { class: "err-box hidden" });
    const box = el("div", {},
      el("h2", {}, frameId ? "Edit frame geometry" : "Rigid-frame wizard"),
      supplierProductFields(),
      el("h3", {}, "Master building geometry"),
      grid(['Width — front to back sidewall',f('width')],['Length — left to right endwall',f('length')],['Eave height (mono: BACK / low)',f('eave_height')],['Roof pitch — rise / 12',f('slope_rise')],['Shape',s('frame_type',['gable','monoslope'])]),
      el('p',{'data-building-summary':'',class:'hint'},'One building geometry drives the entire job.'),
      lengthConflict?el('p',{class:'err-box'},'LEGACY LENGTH CONFLICT: panels used '+legacyPanelLength/12+' ft; bays used '+legacyBayLength/12+' ft. Master Length initially uses the panel length. Confirm/change it above before Generate; bays will be recalculated.'):null,
      el('p',{class:'hint'},'Wall orientation, eave datum, and managed-frame shape limits are in Help & field guide.'),
      grid(['Interior fabrication lot (separate from bay geometry)',f('frames')]),
      el("h3", {}, "Connections \u2014 every option in one place (seat, construction, ridge, purlin fit)"),
      grid(
        ["Rafter seat (welded frames)",s("welded_knee",[["inside_flange","Standard — inside-flange seat"],["outside_seat","Option — outside seat"]])],
        ["Connection construction",s("connection_style",[["fully_welded","Standard — fully welded"],["bolted","Option — bolted"],["welded_box","Option — welded apex box"]])],
        ["Welded gable ridge",s("ridge_fabrication",[["standard","Standard — cut-and-fold one-piece rafter"],["cut_and_fold","Force cut-and-fold (explicit)"],["plate","Option — shared 1/2 in ridge plate"]])],
        ["Welded roof purlin depth (nominal)",f("purlin_depth")],
        ["Welded eave plate extension below rafter",f("eave_plate_extension")],
        ["C — inset columns for bypass girts",inset],
        ["Bypass girt depth / column inset",f("girt_depth")]),
      primaryConnectionPanel,
      el("p",{class:"hint"},"Shop defaults, alternatives, and their geometry effects are in Help & field guide."),
      el("h3", {}, "Connections \u2014 foundation (slab or post footing)"),
      grid(["Foundation",s("foundation",["slab","post_footing"])],["Post footing hole depth (standard 3'-0\")",f("footing_depth")],["Post footing hole diameter (standard 18\")",f("footing_diameter")]),
      el("p",{class:"hint",id:"foundation_help"},"Slab: columns bear on base plates at the top of slab (floor datum). Post footing: posts are embedded the full hole depth; no base plate; the column cut / order length is the floor-to-top length PLUS the hole depth, girt stations and the FLOOR LINE mark are measured from the bottom of the post, and end-wall posts and lean-to columns follow the same rule."),
      el("h3", {}, "Connections \u2014 bases, clips, gaps & weld size (same dialog)"),
      grid(["Column base connection",s("base_connection",["base_plate","floor_weld"])],["Clip sizing policy",s("clip_policy",["legacy","member_sized"])],["Eave strut depth",s("eave_strut_depth",['6"','8"'])],["Base bottom / floor weld-plate TOP elevation",f("base_elevation")],
        ["Generate linked connections",auto],["Box height (manual connections only)",f("box_height")],
        ["Bottom length rule",s("connection_bottom_mode",["column_depth","manual"])],["Manual eave bottom length",f("connection_bottom")],["Apex bottom half-length (each side)",f("apex_bottom_half")],["Peak clip nearest edge from ridge (along slope)",f("peak_clip_edge")],["Low-eave top extension",f("top_extension")],
        ["Flange / back plate thickness",f("flange_thk")],["Web plate thickness",f("web_thk")],
        ["Fillet weld leg (shop default 1/4)",f("weld_size")]),
      el("p",{class:"hint hidden",id:"supplier_rule_note","data-supplier-rule":""},""),
      el("p",{class:"hint",id:"bolted_frame_help"},"Bolted ridge dimensions, clip clearances, and cut references are in Help & field guide."),
      el("h3", {}, "Members & marks"),
      el("div", { class: "grid" }, el("label", {}, "Column section — W / tube (connections held)"), s("column_section", S.state.catalog.column_sections||S.state.catalog.sections), el("label", {}, "Rafter section"), s("rafter_section", S.state.catalog.rafter_sections||S.state.catalog.sections),
        el("label", {}, "Column mark"), f("column_mark"), el("label", {}, "Rafter mark"), f("rafter_mark"), el("label", {}, "Column cut mark"), f("column_cut_mark"), el("label", {}, "Rafter cut mark"), f("rafter_cut_mark")),
      monoFields,
      el("h3", {}, "Connections \u2014 plates, brackets & marks (same dialog)"),
      grid(["Plate sizing",s("plate_mode",["member","library"])],["Job-wide plate rules",el("button",{class:"mini",onclick:()=>{if(confirm("Opening plate standards discards this unsaved frame form. Continue?"))plateStandards();}},"Plate standards…")]),
      el("p",{class:"hint"},"Member mode derives B/K/R plates; inactive library selectors are hidden. Library mode activates the base/end plate choices and retains their stored base holes. The outside-flange base-hole rule applies to member-sized B plates. Proportions and bolt layouts remain review-held; see Plate standards."),
      el("div", { class: "grid" }, el("label", {}, "Base plate (library only)"), s("base_plate", parts.filter(n=>job.parts[n].kind==="plate")), el("label", {}, "Knee bracket (manual only)"), s("knee_bracket", parts.filter(n=>job.parts[n].kind==="bracket")), el("label", {}, "End plates (library only)"), s("rafter_end_plate", parts.filter(n=>job.parts[n].kind==="plate")),
        el("label", {}, "Column top gap"), f("column_top_gap"), el("label", {}, "Knee setback (each eave, horizontal)"), f("knee_setback"), el("label", {}, "Extra ridge allowance (gable only)"), f("ridge_half_gap")),
      el('div',{'data-settings-group':'preset'},sectionPresetFields()),el('div',{'data-settings-group':'secondary'},secondaryFields()),el('div',{'data-settings-group':'runs'},runFields()),el('div',{'data-settings-group':'walls'},endwallFields()),el('div',{'data-settings-group':'envelope'},claddingFields()),
      el('h3',{},'Starting wall run / slab'),
      grid(['Starting wall run',check('starting_wall_run')],['Starting wall elevation (floor datum)',f('starting_run')],['Slab — replace starting run with 2 × 4 base angle',check('slab')]),
      grid(['Base angle gauge',el('select',{'data-base-angle':'profile_id',onchange:e=>P.base_angle.profile_id=e.target.value},...(productPolicy.secondaries==='sss'?['SSS-CAB1','SSS-CAB125','SSS-CAB1GALV','SSS-CAB125GALV']:['MBCI-Angle-2x4-G14','MBCI-Angle-2x4-G16']).map(v=>el('option',{value:v,selected:P.base_angle.profile_id===v?'':null},v)))],['Base angle finish',el('select',{'data-base-angle':'finish',onchange:e=>P.base_angle.finish=e.target.value},...['Red Oxide','Galvanized'].map(v=>el('option',{value:v,selected:P.base_angle.finish===v?'':null},v)))]),
      el('p',{class:'hint'},'Slab base angle is 2 in vertical, 4 in on slab. Starting elevation defaults to 0 in and is adjustable. No clip/anchor at or below the column base is invented. Roof eave supports remain separate.'),
      el('span',{hidden:'','data-internal-roof-spacing':''},check('auto_roof_spacing')),
      el("h3", {}, "Secondary layout"),
      grid(["Additional starting clip at OUTSIDE bracket edge",starting]),
      el("p",{class:"hint"},"Starting clip uses the selected purlin clip and mounting mode; its outside edge aligns with the outside-building edge of each eave bracket. It is added to the bracket BOM, not subtracted from or substituted for the first-purlin layout."),
      el("p",{class:"hint"},"outside_column (new default): distance ALONG SLOPE from OUTSIDE column face/top-line intersection, minus distance to steel cut. column_face retains the legacy INSIDE-face datum (inset bracket spans column top; END/MATE and setback included). Negative net deduction is valid when the rafter top cut lies behind the inner-face datum. rafter_cut: legacy distance directly from steel cut end. Stations round to 1/16; subsequent clips follow the spacing. Default bottom length = column depth + mating plate thickness (manual length ignored in column_depth mode). K-plate inset flush at bottom end; back plate seats on bottom top; bracket top aligns with rafter top. Plate centering remains review-held."),
      grid(["Girts",s("girt_mode",["bypass","flush"])],["Purlins",s("purlin_mode",["bypass","flush"])],
        ["Flush girt attachment",s("girt_attachment",[["web_weld","Welded to the column web (shop standard)"],["web_clip","Stock purlin clip welded to the web"]])],
        ["Girt flush clip center from top",f("girt_web_y")],["Purlin flush clip center from top",f("purlin_web_y")],
        ["Girt web side",s("girt_side",["NS","FS","both"])],["Purlin web side",s("purlin_side",["NS","FS","both"])]),
      el("p",{class:"hint"},"Bypass: clips outside the column. Flush sidewall girts (shop standard): welded directly to the column web, bay less half the web each end less 1/8 in, the outer flange coped around the column flange so the girt face matches the outside flange. Clip alternative: a stock purlin clip welded to the web (6 in girt 3x5, 8 in 5x7, 10 in 7x9; long side welded, short side sticking out), girt = inside to inside of the flanges less 1/4 in. End-wall flush girts weld to the corner column inside flange (corner stands like a frame column) and to the post webs. Purlins at an open-face channel rafter sit inside the channel 1/4 in from the web, welded to the flanges top and bottom (no clips)."),
      el("label",{},"Optional girt clip moves: COLUMN, 1-based clip index, signed vertical offset",girtMoves),
      el("p",{class:"hint"},"Example: COL-1, 2, 1/2. One move per line; blank removes overrides. Moves apply to ALL copies of that column assembly, and sidewall run elevations follow. This does not create a unique physical-column variant or move independent endwall girts. Out-of-column positions are rejected."),
      el("div", { class: "grid" }, el("label", {}, "Girt clip"), s("girt_clip", parts), el("label", {}, "Girt elevations"), el("span",{},f("girt_elevations", { size: 24 }),el("button",{type:"button","data-girt-standard":"",title:"Apply the standard girt elevations for the current eave and foundation",onclick:()=>{girtAuto.on=true;P.girt_elevations=standardGirts();control('girt_elevations').value=P.girt_elevations;}},"Standard")),
        el("label", {}, "Purlin clip"), s("purlin_clip", parts), el("label", {}, "First purlin datum"), s("first_purlin_datum",["outside_column","column_face","rafter_cut"]), el("label", {}, "First purlin distance (along slope)"), f("first_purlin"), el("label", {}, "Purlin spacing (typing turns Automatic spacing off)"), f("purlin_spacing"), el("label", {}, "Flange-brace clip"), s("flange_brace_clip", parts),
        el("label", {}, "Brace at purlin #"), f("flange_brace_at"), el("label", {}, "Brace hole from top"), f("flange_brace_y")),
      err,
      el("div", { class: "btnrow" }, el("button", { class: "primary", onclick: async () => {
        try { const request={...P,sourcing,revision:sourceRevision};
          if(P.connection_style!=="fully_welded"&&P.auto_connections&&P.frame_type==="gable"&&!String(P.apex_bottom_half||"").trim())throw new Error("Enter a positive finished apex bottom half-length for each side.");
          if(!P.auto_connections||P.frame_type!=="gable"){request.apex_bottom_half=null;request.peak_clip_edge=null;}
          if(!P.auto_connections)request.eave_start_clip=false;
          if(P.connection_style!=="bolted"){request.auto_connections=true;request.column_top_gap=request.knee_setback=request.ridge_half_gap=request.top_extension=`0"`;}
          const st = await api("POST", "/api/frame", request); S.state = st; const reopenTab = settingsDocked() ? (window.__mbdpSettingsTab || "main") : null; closeModal(); select("assembly", st.generated[0]); if(st.job.settings.frame_layouts?.[st.generated[0]])showSheet("frame",st.generated[0]); const layout=st.job.settings.frame_layouts?.[st.generated[0]];const warnings=[...(layout?.clip_warnings||[]),...(layout?.secondary_warnings||[])];const rel=st.release||{};setStatus("saved " + st.generated.join(", ")+(rel.complete===false?" — RELEASE CHECK: "+rel.count+" open item(s), see the banner":"")+(warnings.length?" — "+warnings.length+" shop-rule note(s) (Model checks)":""),rel.complete===false?"warn":"ok");
          if (reopenTab) setTimeout(() => { if (!S.dirty) wizard(st.generated[0], null, reopenTab); }, 0); }
        catch (e) { err.textContent = e.message; err.classList.remove("hidden"); } } }, "Generate"), el("button", { onclick: closeModal }, "Cancel")));
    openModal(box,{dock:settingsDocked()});
    refreshBuildingPreview();
    const control=k=>box.querySelector('[data-frame-field="'+k+'"]');
    let widthScheduleActive = !frameId;
    const applyWidthSchedule = () => {
      if (!widthScheduleActive) return;
      const section = widthSection(P.width);
      if (!section) return;
      P.column_section = P.rafter_section = section;
      control('column_section').value = section;
      control('rafter_section').value = section;
      refreshBuildingPreview();
    };
    control('width').addEventListener('input', applyWidthSchedule);
    for (const key of ['column_section','rafter_section']) control(key).addEventListener('change', () => { widthScheduleActive = false; });
    control('frames').addEventListener('input',drawPrimaryConnectionSchedule);
    control('connection_style').addEventListener('change',drawPrimaryConnectionSchedule);
    control('frame_type').addEventListener('change',drawPrimaryConnectionSchedule);
    const show=(k,yes)=>{const x=control(k);if(x){x.classList.toggle('hidden',!yes);x.previousElementSibling.classList.toggle('hidden',!yes);}};
    function updateWeldedRuleMessage(){
      const rule=box.querySelector('.standard-rule');if(!rule)return;
      if(P.connection_style==='bolted')rule.textContent='BOLTED OPTION — the welded purlin/end-fit rule is not applied.';
      else if(P.welded_fit_rules?.enabled===false)rule.textContent='NONSTANDARD FIT OVERRIDE — Owner welded fit is not applied to this frame.';
      else rule.textContent='OWNER WELDED STANDARD — applied automatically. Nonstandard fit is an explicit per-frame override.';
    }
    function applicable(){
      const welded=P.connection_style!=="bolted",linked=welded||P.auto_connections, gable=P.frame_type==='gable';starting.disabled=!linked;
      const weldedOverride=box.querySelector('[data-welded-fit-override]');
      if(weldedOverride){weldedOverride.disabled=!welded;if(!welded){P.welded_fit_rules.enabled=true;weldedOverride.checked=false;}}
      updateWeldedRuleMessage();
      box.querySelector('#bolted_frame_help').classList.toggle('hidden',welded);
      // shop rule (owner, round 16): SSS for welded buildings, MBCI for bolted ones - say which one this job has
      const rule=((S.state.catalog.layout_rules||{}).supplier_by_construction||{})[P.connection_style],names={sss:'Triple-S Steel (SSS)',mbci:'MBCI'},mine=productPolicy.primary;
      box.querySelector('#supplier_rule_note').textContent=rule?'Shop rule: '+(welded?'welded':'bolted')+' buildings use '+names[rule]+'. '+(rule===mine?'This job is on '+names[mine]+' products.':'This job is on '+names[mine]+' products - switch them with Supplier PRODUCTS on step 6 (Sheets & trim), then Preview and Apply.'):'';
      for(const key of ['purlin_depth','eave_plate_extension'])show(key,welded);
      const ps=control('purlin_mode');
      if(ps){ps.disabled=false;ps.title='Help & field guide: purlin fit, roofline datum, and fabrication effects.';}
      const foldable=P.connection_style==='fully_welded'&&gable&&String(P.rafter_section||'').toUpperCase().startsWith('W');
      show('ridge_fabrication',foldable);if(!foldable&&P.ridge_fabrication==='cut_and_fold'){P.ridge_fabrication='standard';const rf=control('ridge_fabrication');if(rf)rf.value='standard';}
      if(P.girt_mode!=='bypass'){P.inset_for_bypass=false;inset.checked=false;}
      inset.disabled=!linked||P.girt_mode!=='bypass';show('girt_depth',P.inset_for_bypass);
      control('eave_strut_depth').disabled=false;show('eave_strut_depth',!welded);control('girt_depth').disabled=!P.inset_for_bypass;
      for(const role of ['purlin','girt'])for(const which of ['starting','middle']){
        const k=role+'_'+which+'_clearance';const x=box.querySelector('[data-run-field="'+k+'"]');
        if(x&&bayDefaults[k]){P.bay_layout[k]=P[role+'_mode']==='flush'?`1/8"`:`1/2"`;x.value=P.bay_layout[k];}
      }
      for(const k of ['first_purlin','purlin_spacing','first_purlin_datum']){const x=control(k);if(x){x.disabled=false;x.title='Manual roof-row station input; see Help & field guide.';const useManual=()=>{P[k]=x.value;if(P.auto_roof_spacing){P.auto_roof_spacing=false;const autoSpacing=control('auto_roof_spacing');if(autoSpacing)autoSpacing.checked=false;}window.__mbdpRoofSpacingMode?.();};x.addEventListener('input',useManual);x.addEventListener('change',useManual);}}
      control('column_section').disabled=!!P.section_defaults.enabled;control('rafter_section').disabled=!!P.section_defaults.enabled;
      auto.disabled=welded;
      if(welded){P.auto_connections=true;auto.checked=true;}
      const wl=control('width').previousElementSibling;wl.textContent=(welded||P.inset_for_bypass)?'Width — front to back WALL lines':'Width — front to back frame lines';
      control('eave_height').previousElementSibling.textContent=welded?'Eave height — ROOF LINE = TOP OF RAFTER (purlin tops flush; mono BACK low)':'Eave height — TOP OF EAVE STRUT (mono BACK low)';
      const post=P.foundation==='post_footing';show('footing_depth',post);show('footing_diameter',post);
      control('base_connection').disabled=post;control('base_elevation').disabled=post;
      show('base_plate',P.plate_mode==='library'&&!post);show('rafter_end_plate',P.plate_mode==='library'&&!welded);
      show('knee_bracket',!linked);show('box_height',!linked);
      control('connection_bottom').disabled=P.connection_bottom_mode!=='manual'||!linked;
      for(const key of ['apex_bottom_half','peak_clip_edge'])control(key).disabled=!linked||!gable;
      for(const key of ['connection_bottom_mode','top_extension','flange_thk','web_thk'])control(key).disabled=!linked;
      control('girt_side').disabled=true;control('girt_web_y').disabled=true;if(P.girt_mode==='flush'){P.girt_side='both';control('girt_side').value='both';}
      control('ridge_half_gap').disabled=!gable||welded;
      if(welded){for(const key of ['column_top_gap','knee_setback','ridge_half_gap','top_extension']){P[key]=`0"`;control(key).value=P[key];}for(const key of ['connection_bottom_mode','connection_bottom','top_extension','column_top_gap','knee_setback'])control(key).disabled=true;control('apex_bottom_half').disabled=P.connection_style!=='welded_box'||!gable;}
      for(const key of ['flange_thk','web_thk'])if(welded)control(key).disabled=P.connection_style!=='welded_box';
      for(const [role,key] of [["purlin","purlin_depth"],["girt","girt_depth"],["eave","eave_strut_depth"]]){
        const entry=secCatalog.profiles.find(x=>x.id===P.secondary[role]?.profile_id);const x=control(key);
        if(entry){P[key]=entry.nominal_depth_in+'"';if(x.tagName==='SELECT'&&![...x.options].some(o=>o.value===P[key]))x.append(el("option",{value:P[key]},P[key]+' (catalog nominal)'));x.value=P[key];x.disabled=true;}
        else if(role==="purlin")x.disabled=false;else if(role==="eave"){for(const o of [...x.options])if(![`6"`,`8"`].includes(o.value))o.remove();x.value=P[key];}
      }
    }
    // Shop standard on welded buildings (owner 2026-10-15): girts FLUSH, welded to the column web; clips are the option.
    control('connection_style').addEventListener('change',()=>{const ps=control('purlin_mode');
      if(P.connection_style!=='bolted'){if(P.girt_mode==='bypass'){P.girt_mode='flush';P.girt_attachment='web_weld';const g=control('girt_mode');if(g)g.value='flush';const ga=control('girt_attachment');if(ga)ga.value='web_weld';}}
      else if(P.purlin_mode==='flush'){P.purlin_mode='bypass';if(ps)ps.value='bypass';}
      applicable();});
    for(const key of ['plate_mode','frame_type','connection_bottom_mode','connection_style','girt_mode','purlin_mode','rafter_section'])control(key).addEventListener('change',applicable);
    for(const role of ['purlin','girt'])control(role+'_mode').addEventListener('change',()=>{for(const which of ['starting','middle'])bayDefaults[role+'_'+which+'_clearance']=true;applicable();});
    auto.addEventListener('change',applicable);applicable();
    const refreshGirts=()=>{if(!girtAuto.on)return;const text=standardGirts();if(text!==P.girt_elevations){P.girt_elevations=text;const x=control('girt_elevations');if(x)x.value=text;}};
    // Sheets never without girts (v0.8.39): the moment a wall is sheeted on a job without girt
    // lines (a roof-only start) the standard lines are filled in and follow the eave / foundation.
    const ensureGirtLines=()=>{if(String(P.girt_elevations||'').trim())return;girtAuto.on=true;refreshGirts();if(P.foundation!=='post_footing'){P.slab=true;P.starting_wall_run=true;const a=control('slab'),b=control('starting_wall_run');if(a)a.checked=true;if(b)b.checked=true;}};
    {const w=box.querySelector('[data-cladding-field="walls"]');if(w)w.addEventListener('change',()=>{if(w.checked)ensureGirtLines();});}
    control('girt_elevations').addEventListener('input',()=>{girtAuto.on=false;});
    control('eave_height').addEventListener('input',refreshGirts);
    control('foundation').addEventListener('change',()=>{if(!frameId){const post=P.foundation==='post_footing';P.slab=!post;P.starting_wall_run=!post;const a=control('slab'),b=control('starting_wall_run');if(a)a.checked=P.slab;if(b)b.checked=P.starting_wall_run;}refreshGirts();});
    box.addEventListener('change',refreshGirts);
    window.organizeBuildingSettings({box,P,el,grid,catalog:S.state.catalog,profiles:secCatalog.profiles,initial:focusField?"advanced":initialTab,inches,ensureGirtLines,
      docked:settingsDocked(),setDocked:(on)=>{window.MBDPWorkbench?.set({dock:on?"right":"center"});$("#modal").classList.toggle("docked",on);document.querySelector("main.layout")?.classList.toggle("settings-docked",on);if(on){document.documentElement.style.setProperty("--dock-top",window.MBDPWorkbench.dockTop()+"px");window.MBDPWorkbench.dockHandle(box);}}});
    if(focusField){const x=control(focusField);if(x){x.scrollIntoView({block:'center'});x.focus();x.select();}}

  }
  function settingsDocked() { const w = window.MBDPWorkbench; return !!w && w.get().dock !== "center"; }
  function nextMark(prefix, kind, offset=0) { const marks = Object.keys(S.state.job.assemblies); let n = kind === "COLUMN" ? 1 : 2; if (kind === "COLUMN") prefix = "COL"; for(;;n++){if(!marks.includes(`${prefix}-${n}`)){if(offset===0)return `${prefix}-${n}`;offset--;}} }
  function nextCut(off = 0) { const used = new Set(Object.values(S.state.job.assemblies).map(a => a.main.mark)); let n = 100; const out = []; while (out.length < off + 1) { if (!used.has(`RF-${n}`)) out.push(`RF-${n}`); n += 100; } return out[off]; }

  function openModal(content, opts = {}) {
    const m = $("#modal"), box = $("#modal_box"); box.innerHTML = ""; box.append(content);
    const dock = !!opts.dock && !!window.MBDPWorkbench;
    m.classList.toggle("docked", dock); document.querySelector("main.layout")?.classList.toggle("settings-docked", dock);
    if (dock) { document.documentElement.style.setProperty("--dock-top", window.MBDPWorkbench.dockTop() + "px"); window.MBDPWorkbench.dockHandle(box); }
    m.classList.remove("hidden"); box.scrollTop = 0;
  }
  function closeModal() { const m = $("#modal"); m.classList.add("hidden"); m.classList.remove("docked"); document.querySelector("main.layout")?.classList.remove("settings-docked"); }
  window.addEventListener("keydown", e => { if (e.key === "Escape" && !$("#modal").classList.contains("hidden") && !document.querySelector("dialog[open]")) { const t = e.target; if (t && t.tagName === "SELECT") return; closeModal(); } });

  // ------------------------------------------------------------------ new assembly / part
  function newAssembly() {
    const job = S.state.job; const mark = prompt("Assembly mark", nextMark("RF1", "COLUMN")); if (!mark || job.assemblies[mark]) return;
    job.assemblies[mark] = { mark, kind: "BEAM", qty: 1, main: { mark: mark.replace(/-.*$/, "") + "-CUT", section: "W12X22", cut_length: `20'-0"`, left_cut: { type: "square", angle: 0 }, right_cut: { type: "square", angle: 0 }, web_holes: [], derivation: "entered" }, attachments: [], notes: [], derivation: {}, date: "" };
    scheduleSave("new assembly " + mark); select("assembly", mark);
  }
  function newPart() {
    const job = S.state.job; const mark = prompt("Part mark", "PL-1"); if (!mark || job.parts[mark]) return;
    job.parts[mark] = { mark, kind: "plate", thk: `1/2"`, width: `6"`, length: `1'-0"`, holes: [], section: null, cut_length: null, attachments: [], unit_weight: null, description: "", symbol: {}, drawing_ref: "", source: "user", notes: "" };
    scheduleSave("new part " + mark); select("part", mark);
  }

  // Release check banner (v0.8.39): the release status is always in view - a job that cannot be
  // released says why at the top of the page instead of in a status line only.
  function renderReleaseBanner(){
    const bar=$("#release_banner");if(!bar)return;const rel=S.state.release;const frames=S.state.job?.settings?.frames||{};
    bar.replaceChildren();bar.className='release';
    if(!rel||!Object.keys(frames).length){bar.classList.add('hidden');return;}
    if(rel.complete){bar.classList.add('complete');bar.append(el('strong',{},'RELEASE CHECK: COMPLETE'),el('span',{},' - every sheet can be issued FOR CONSTRUCTION.'));return;}
    bar.classList.add('blocked');
    const open=S.releaseOpen??false,items=rel.items||[],shown=open?items:items.slice(0,2);
    const ul=el('ul',{},...shown.map(t=>el('li',{},t)));
    if(items.length>2)ul.append(el('li',{},el('button',{class:'mini',onclick:()=>{S.releaseOpen=!open;renderReleaseBanner();}},open?'Show fewer':'Show all '+rel.count+' items')));
    bar.append(el('strong',{},'RELEASE CHECK: '+rel.status+' -'),ul,el('button',{class:'mini',onclick:()=>{document.querySelector('#issues')?.scrollIntoView({block:'start'});}},'Model checks'));
  }
  function renderGeometryBar(){
    const bar=$("#geometry_bar");bar.replaceChildren();const frames=S.state.job.settings.frames||{},ids=Object.keys(frames),fid=S.state.job.assemblies[S.sel.name]?.derivation?.frame_id||ids[0];
    if(!fid){bar.append(el('strong',{},'Master building geometry'),el('button',{onclick:()=>wizard()},'Create frame / building'));return;}
    const P=frames[fid],rev=S.state.revision,G={width:P.width,length:P.length||'',eave_height:P.eave_height,slope_rise:P.slope_rise};
    bar.append(el('label',{},'Main frame',el('select',{'data-geometry-frame':'',onchange:e=>select('assembly',e.target.value)},...ids.map(id=>el('option',{value:id,selected:id===fid?'':null},id)))));
    for(const [key,title] of [['width','WIDTH'],['length','LENGTH'],['eave_height','LOW EAVE HEIGHT'],['slope_rise','PITCH / 12']])bar.append(el('label',{},title,el('strong',{'data-geometry-field':key},G[key])));
    bar.append(el('label',{},'SHAPE',el('strong',{'data-geometry-shape':''},P.frame_type==='gable'?'Gable':'Monoslope')),el('button',{class:'primary',onclick:()=>wizard(fid)},'Building settings'));
  }
  function openingRuleFields(P,o){
    P.additions||={};P.additions.opening_members||={};const q=P.additions.opening_members[o.id]||={};q.placement??=(o.kind==='door'||o.kind==='overhead')?'centered':'existing';if((o.kind==='door'||o.kind==='overhead')&&q.placement==='centered')q.bay??='1';
    const input=(k,label)=>[label,el('input',{'data-addition-field':o.id+'_'+k,value:q[k]??'',size:15,oninput:e=>q[k]=e.target.value})];
    const choose=(k,opts)=>el('select',{'data-addition-field':o.id+'_'+k,onchange:e=>q[k]=e.target.value},...opts.map(([v,t])=>el('option',{value:v,selected:(q[k]||'')===v?'':null},t)));
    const sections=[['','Follow wall girt / legacy open-face choice'],...(S.state.product_libraries?.secondaries||S.state.catalog.secondary.profiles).filter(x=>['C','Channel'].includes(x.family)&&(String(x.id).startsWith('SSS-')?'sss':'mbci')===(S.state.job.settings.product_suppliers?.secondaries||'sss')).map(x=>[x.id,x.designation]),...(S.state.job.settings.product_suppliers?.secondaries==='sss'?[]:(S.state.catalog.rafter_sections||[]).filter(x=>x.startsWith('MBCI-Channel-'))).map(x=>[x,x])];
    const jambSections=[...sections,...(S.state.catalog.tube_sections||[]).map(x=>[x,x+' — HSS tube upright'])];
    q.jamb_role||='ordinary';q.header_orientation||='up';q.opening_mode||='ordinary';q.header_mode||=(q.framing_rule_version?'member':o.kind==='door'?'girt':'member');q.jamb_extent||=(q.framing_rule_version?'header':o.kind==='overhead'?'full':'header');
    return el('div',{},el('p',{class:'hint'},'Ordinary header flanges UP. Jamb and header may use DIFFERENT actual catalog sections. HSS tube is available for jamb uprights (not headers). Roof-bearing jambs are shared endwall posts, not extra ordinary jambs.'),grid(
      ['Coordinate endwall girt / base-angle runs at jambs (final cuts held)',el('input',{type:'checkbox',checked:q.coordinate_girts?'':null,'data-addition-field':o.id+'_coordinate_girts',onchange:e=>q.coordinate_girts=e.target.checked})],
      ['Opening assembly',choose('opening_mode',[['ordinary','Ordinary framed opening'],['walk_slip_in','Walk-door frame slips into DOWN girt;1/2in gap below web']])],input('walk_head_face','Walk frame HEAD face height (e.g.2.5; derives web datum)'),input('walk_jamb_face','Walk frame JAMB face width (e.g.2.5)'),input('walk_girt_web_underside','Optional explicit web underside (must agree with entered head face)'),input('girt_insertion','Girt insertion INTO jamb (not a clearance; welded standard2in)'),
      ['Header',choose('header_mode',[['member','Separate header member at the door height'],['girt','Wall girt above the head is the header (walk-door standard: 7\'-3 girt, jambs stop at it)']])],
      ['Jamb height',choose('jamb_extent',[['header','Jambs to the header top'],['full','Full height to the eave strut / end rafter (overhead-door standard)']])],
      ['Jamb role',choose('jamb_role',[['ordinary','Ordinary opening jambs'],['roof_bearing','Roof-bearing endwall jamb/posts (welded)']])],
      ['Jamb section override (includes HSS tube uprights)',choose('jamb_override',jambSections)],['Header section override',choose('header_override',sections)],
      ['Header flange orientation',choose('header_orientation',[['up','UP — ordinary header'],['down','DOWN — explicit alternate / legacy']])],
      ['Fallback open-face BOTH (only where no override selected)',el('input',{type:'checkbox',checked:q.open_face?'':null,'data-addition-field':o.id+'_open_face',onchange:e=>q.open_face=e.target.checked})],
      ['Position',choose('placement',[['wall_centered','Centered on ENTIRE wall'],['centered','Centered in selected bay'],['offset','Offset from bay center'],['existing','Use entered X']])],input('bay','Bay number (centered / offset placement)'),input('bay_offset','Offset from bay center: minus LEFT / plus RIGHT')),
      el('p',{class:'hint'},'Bearing jambs use entered X or whole-wall centering. Their own posts are opening boundaries;6in clearance still applies to OTHER uprights. No automatic bearing-opening relocation. Edit ordinary post stations explicitly; no post is silently removed. Shared members are counted once in the endwall schedule. Head/base connections and exact cuts remain held.'),
      grid(['Connection source template',choose('connection_template',[['','Project default (girts cut at jambs, clip-connected)'],['1277345-SD85C-SD95','8in lipped Cee source kit (1277345-SD85C-SD95)']])],input('girt_end_clearance','Girt clear end gap (manufacturer / general1/8in)')));

  }
  // Lean frame lines (1, 2, 3 ... from the START of the lean, outside view) with their main-building
  // stations: from the generated model when the lean exists, else from the main bay layout.
  function leanLineStations(fid,P,r){
    const fromModel=()=>{const saved=(S.state.job.settings.frame_layouts?.[fid]?.framing_additions?.lean_tos||[]).find(z=>z.id===r.id);
      return saved&&Array.isArray(saved.stations)?saved.stations.map(st=>({line:st.index,station:st.x_in})):[];};
    const L=window.MBDim.inches(P.length)||0,b=P.bay_layout||{};if(!b.enabled||!L)return fromModel();
    let lens=[];
    if(b.layout_mode==='explicit')lens=(b.bay_lengths||[]).map(x=>window.MBDim.inches(x)||0);
    else if(b.layout_mode==='standard')lens=window.MBDim.standardBays(L);
    else{const n=b.layout_mode==='max_spacing'?Math.ceil(L/(window.MBDim.inches(b.max_spacing||"20'")||240)):Number(b.bays||4);lens=n>0&&Number.isFinite(n)?Array.from({length:n},()=>L/n):[];}
    const ss=[0];lens.forEach(x=>ss.push(ss[ss.length-1]+x));
    let lo,hi;
    if(r.bays&&r.bays.from&&r.bays.to){lo=ss[r.bays.from-1];hi=ss[r.bays.to];if(lo===undefined||hi===undefined)return[];if(r.face==='left'){[lo,hi]=[L-hi,L-lo];}}
    else if(r.full_length||!['left','right'].includes(r.face)){lo=0;hi=L;}
    else{lo=window.MBDim.inches(r.start)||0;hi=lo+(window.MBDim.inches(r.length)||0);}
    const view=ss.map(x=>r.face==='left'?L-x:x).sort((a,b)=>a-b);
    const lines=view.filter(x=>x>=lo-1e-6&&x<=hi+1e-6).map((x,i)=>({line:i+1,station:x}));
    return lines.length>=2?lines:fromModel();
  }
  // Column grades (v0.8.43): the separate box - grade at each column relative to the set level; cut lengths follow
  function fmtGrade(g){g=Number(g)||0;return Math.abs(g)<1e-9?'':(g<0?'-':'+')+window.MBDim.fmt(Math.abs(g));}
  async function gradesSettings(frameId=null){
    try{
      clearTimeout(S.saveTimer);if(S.dirty)await save('before column grades');if(S.dirty)throw Error('Save pending changes first');
      const frames=S.state.job.settings.frames||{},ids=Object.keys(frames);
      const fid=frameId||S.state.job.assemblies[S.sel.name]?.derivation?.frame_id||ids[0];
      if(!fid||!frames[fid]){alert('Create a managed frame first.');return;}
      const rev=S.state.revision,P=frames[fid],saved=P.grades||{};
      const G={datum:saved.datum||'',mixed_bay:saved.mixed_bay||'lower',columns:{}};
      Object.entries(saved.columns||{}).forEach(([k,v])=>{G.columns[k]=typeof v==='number'?fmtGrade(v):String(v??'');});
      const cg=S.state.job.settings.frame_layouts?.[fid]?.column_grades||{},rows=cg.rows||[];
      const error=el('div',{class:'err-box hidden'});
      const box=el('div',{},el('h2',{},'Column grades'),el('p',{class:'hint'},'Standard: every column stands at the SET LEVEL (0 = top of the main slab / finished floor) - leave the boxes blank. Where the slab or the ground is not level, enter the grade AT EACH COLUMN relative to the set level: a slab column takes the top of slab there, a post in a hole takes the GROUND level there (post length = top - ground + hole depth). Minus = below the set level = a longer column; plus = above = shorter. The eave, roof line and girt lines stay level. Main columns of different lengths get their own marks (COL-1, COL-1A ...); end-wall and lean posts already carry one mark per post. Entries like -1 1/2, +1/4 or -1\'-6" are accepted (3 ft limit).'));
      if(ids.length>1)box.append(el('label',{},'Main frame ',el('select',{'data-grade-frame':'',onchange:e=>gradesSettings(e.target.value)},...ids.map(id=>el('option',{value:id,selected:id===fid?'':null},id)))));
      box.append(grid(['Set level (note on the schedule)',el('input',{value:G.datum,size:40,placeholder:'SET LEVEL (0) = top of the main slab / finished floor','data-grade-field':'datum',oninput:e=>G.datum=e.target.value})],['Sheets and base angle of a bay whose two columns differ',el('select',{'data-grade-field':'mixed_bay',onchange:e=>G.mixed_bay=e.target.value},...[['lower','Order LONGER — follow the LOWER slab of the bay (standard: sheets and base angle are ordered long and the transition sheet is cut to fit)'],['higher','Clear the HIGHER slab of the bay (option — shorter sheets, no site cut)']].map(([v,t])=>el('option',{value:v,selected:G.mixed_bay===v?'':null},t)))]));
      if(!rows.length)box.append(el('p',{class:'hint'},'The columns are listed here after the frame is generated (Building settings > Save & regenerate).'));
      const groups=[['main','Main frame columns - per frame line and side (right = front sidewall, left = back sidewall)'],['post','End-wall / cross-wall posts and door jambs'],['lean','Lean-to posts (grade = ground level at the post when the lean stands in post holes)']];
      groups.forEach(([kind,title])=>{const mine=rows.filter(r=>r.kind===kind);if(!mine.length)return;
        const fs=el('fieldset',{},el('legend',{},title));
        const table=el('table',{class:'grades'},el('thead',{},el('tr',{},...['Line','Where','Mark','Section','Foundation','Standard cut','Grade (blank = 0)','Cut at this grade'].map(h=>el('th',{},h)))));
        const tb=el('tbody',{});
        mine.forEach(r=>{const inp=el('input',{value:G.columns[r.key]??'',size:9,placeholder:'0','data-grade-key':r.key,oninput:e=>{const v=e.target.value.trim();if(v)G.columns[r.key]=v;else delete G.columns[r.key];}});
          tb.append(el('tr',{},el('td',{},String(r.line??'-')),el('td',{},r.where||''),el('td',{},r.shop_mark||r.mark),el('td',{},r.section||''),el('td',{},r.foundation||''),el('td',{},window.MBDim.fmt(r.standard_cut_in||0)),el('td',{},inp),el('td',{},(r.cut||'')+(r.shop_mark&&r.shop_mark!==r.mark?' ('+r.shop_mark+')':''))));});
        table.append(tb);fs.append(table);box.append(fs);});
      if(cg.variants&&cg.variants.length)box.append(el('p',{class:'hint'},'Current marks by length: '+cg.variants.map(v=>v.mark+' = '+v.of+' at '+v.grade+' x'+v.quantity+' ('+v.cut+')').join('; ')+'.'));
      box.append(error,el('div',{class:'btnrow'},el('button',{class:'primary','data-grade-action':'save',onclick:async()=>{try{S.state=await api('POST','/api/grades',{frame_id:fid,revision:rev,grades:G});closeModal();select('assembly',fid);showSheet('frame',fid);setStatus('Column grades applied - see the COLUMN GRADE SCHEDULE sheet','warn');}catch(e){error.textContent=e.message;error.classList.remove('hidden');}}},'Apply column grades'),el('button',{'data-grade-action':'clear',onclick:()=>{G.columns={};box.querySelectorAll('[data-grade-key]').forEach(i=>i.value='');}},'Clear all (standard)'),el('button',{onclick:closeModal},'Cancel')));openModal(box);
    }catch(e){alert(e.message);}
  }
  async function additionsSettings(frameId=null){
    try{
      clearTimeout(S.saveTimer);if(S.dirty)await save('before framing additions');if(S.dirty)throw Error('Save pending changes first');
      const frames=S.state.job.settings.frames||{},ids=Object.keys(frames);
      const fid=frameId||S.state.job.assemblies[S.sel.name]?.derivation?.frame_id||ids[0];
      if(!fid||!frames[fid]){alert('Create a managed frame first.');return;}
      const rev=S.state.revision,P=frames[fid],C=JSON.parse(JSON.stringify(P.additions||{}));C.opening_auto??=true;C.rake_angles??=true;C.opening_members||={};C.lean_tos||=[];
      const error=el('div',{class:'err-box hidden'});
      const input=(o,k,id=k)=>el('input',{value:o[k]??'',size:19,'data-addition-field':id,oninput:e=>o[k]=e.target.value});
      const choose=(o,k,items,id=k)=>el('select',{'data-addition-field':id,onchange:e=>o[k]=e.target.value},...items.map(([v,t])=>el('option',{value:v,selected:(o[k]??'')===v?'':null},t)));
      const check=(o,k,label,id=k)=>el('label',{},el('input',{type:'checkbox',checked:o[k]?'':null,'data-addition-field':id,onchange:e=>o[k]=e.target.checked}),' '+label);
      const box=el('div',{},el('h2',{},'Lean-to settings'),el('p',{class:'hint'},'Shop standard: the lean rafter is cut plumb and welded directly to the outside face of the main column (no gap); the lean post runs to the rafter top line and the rafter is welded to its inside face (no cap on an open-face channel); the roof purlins sit in the rafter channel 1/4 in from the web. Options: welded clip with a 2 in gap, bolted end plate (legacy). Main-building openings/end walls are in Full frame settings.'));
      box.append(el('label',{},'Main frame ',el('select',{'data-addition-frame':'',onchange:e=>additionsSettings(e.target.value)},...ids.map(id=>el('option',{value:id,selected:id===fid?'':null},id)))));
      const profiles=[['','PENDING — select a member'],...S.state.catalog.sections.map(s=>[s,s]),...(S.state.product_libraries?.secondaries||S.state.catalog.secondary.profiles).filter(x=>['C','Channel'].includes(x.family)&&(String(x.id).startsWith('SSS-')?'sss':'mbci')===(S.state.job.settings.product_suppliers?.secondaries||'sss')).map(x=>[x.id,x.id]),...S.state.catalog.endwall_rules.tube_sizes.flatMap(s=>S.state.catalog.endwall_rules.tube_walls.map(w=>['HSS '+s+' x '+w,'HSS '+s+' x '+w]))];
      const list=el('div',{});
      const LEAN_WALLS=[['outer','Outer wall (along the lean post line)'],['start_end','Start end wall'],['finish_end','Finish end wall'],['main_below','MAIN wall under the lean roof']];
      function drawLeans(){list.replaceChildren();C.lean_tos.forEach((r,i)=>{
        // v0.8.35: every lean wall is an explicit choice; a new lean-to is ROOF ONLY (legacy flags mapped once)
        if(!r.walls){const legacy=('sheeted_ends' in r)||('sheeted_outer_wall' in r)||('open_main_below' in r);const ends=legacy?(r.sheeted_ends===false?'open':'sheeted'):'open';r.walls={outer:legacy?(r.sheeted_outer_wall===false?'open':'sheeted'):'open',start_end:ends,finish_end:ends,main_below:legacy&&r.open_main_below?'open':'sheeted'};}
        delete r.sheeted_ends;delete r.sheeted_outer_wall;delete r.open_main_below;r.end_posts??='auto';r.girt_mode||='flush';r.girt_attachment??=(P.girt_attachment||'web_weld');r.end_post??='';
        r.foundation??='main';r.footing_depth??='';r.footing_diameter??='';r.roof_edge||={};r.roof_edge.wall_sheets??=(r.walls.outer==='sheeted');r.roof_purlins||={};r.roof_purlins.share_main_eave??=(r.roof_continuity==='main_plane');r.roof_purlins.max_spacing??='60';r.high_connection??='welded_direct';r.rafter_seat??='inside_flange';
        // lean-to rafter: W, lipped Cee or OPEN-FACE channel 6-8 in (single id - the standard rule pairs interior rafters back to back itself (I shape); the two end rafters stay single; per-line choices below)
        const rf=profiles.filter(([v])=>!v||v.startsWith('W')||(S.state.product_libraries?.secondaries||S.state.catalog.secondary.profiles).some(p=>p.id===v&&['C','Channel'].includes(p.family)&&!/x2$/.test(String(p.id))&&p.nominal_depth_in>=6&&p.nominal_depth_in<=(p.open_face?10.5:8.5)));const col=profiles.filter(([v])=>!v||v.startsWith('W')||v.startsWith('HSS')||(S.state.product_libraries?.secondaries||S.state.catalog.secondary.profiles).some(p=>p.id===v&&p.open_face&&!/x2$/.test(String(p.id))));
        // Rafter by frame line (round 11): standard rule or, per line, a W / single open-face channel / doubled channel (I)
        const secs=(S.state.product_libraries?.secondaries||S.state.catalog.secondary.profiles).filter(p=>['C','Channel'].includes(p.family)&&(String(p.id).startsWith('SSS-')?'sss':'mbci')===(S.state.job.settings.product_suppliers?.secondaries||'sss')&&p.nominal_depth_in>=6&&p.nominal_depth_in<=10.5);
        const lineOpts=[['','Standard rule (ends single, interior lines doubled back to back for a channel; W single)'],...S.state.catalog.sections.filter(x=>x.startsWith('W')).map(x=>[x,x+' — wide flange (purlins per the roof secondary fit)']),...secs.filter(p=>p.open_face&&!/x2$/.test(String(p.id))).map(p=>[p.id,p.id+' — open-face channel, SINGLE (purlins in the channel)']),...secs.filter(p=>/x2$/.test(String(p.id))).map(p=>[p.id,p.id.replace(/x2$/,'')+' x2 — DOUBLED open-face channel welded back to back, I shape (purlins in the channels)'])];
        function rafterLines(r,i){r.rafter_lines||={};r.rafter_seat_overrides||={};r.high_connection_overrides||={};const highOverrideChoices=[['','Inherit lean default'],['welded_direct','Direct weld to main column'],['clip','Welded clip (uses this lean’s clip fit)'],['end_plate','Bolted end plate (explicit dimensions / holes required)']];const seatOverrideChoices=r.low_connection==='bolted'?[['','Not available for bolted low connection']]:[['','Inherit lean default'],['inside_flange','Inside face — post to rafter top line'],['outside_seat','Outside seat — pitch-cut post below rafter']];const lines=leanLineStations(fid,P,r);const host=el('div',{'data-lean-lines':i});
          host.append(el('h4',{},'Rafter and support connection at each lean frame line'));
          if(!lines.length){host.append(el('p',{class:'hint'},'Set the main bay layout (Building settings, step 1) and the lean extent; the lines are listed here after the next Save & regenerate.'));return host;}
          host.append(grid(...lines.map(({line,station})=>['Line '+line+' @ '+window.MBDim.fmt(station)+(line===1?' (start end rafter)':line===lines.length?' (finish end rafter)':''),choose(r.rafter_lines,String(line),lineOpts,'lean_'+i+'_line_'+line)])));
          host.append(el('h4',{},'Low-end rafter seat overrides (each physical lean post)'));
          host.append(grid(...lines.map(({line,station})=>['Line '+line+' @ '+window.MBDim.fmt(station),choose(r.rafter_seat_overrides,String(line),seatOverrideChoices, 'lean_'+i+'_seat_'+line)])));
          host.append(el('h4',{},'High-end connection overrides (each physical main-column support)'));
          host.append(grid(...lines.map(({line,station})=>['Line '+line+' @ '+window.MBDim.fmt(station),choose(r.high_connection_overrides,String(line),highOverrideChoices,'lean_'+i+'_high_'+line)])));
          host.append(el('p',{class:'hint'},'Each lean support inherits the lean-wide high/low defaults unless overridden. High-end options are per support; bolted end plates require explicit geometry inputs below. Blank low-end choices inherit. Overrides are validated against current physical support lines.'));
          host.append(el('p',{class:'hint'},'Blank = the standard rule for the section chosen under Rafter. A W line follows the Roof secondary fit: FLUSH = purlins between the flanges welded to the web (rafter top = roofline), BYPASS = purlins over the rafter (rafter top = roofline minus purlin depth) - its lean post is cut a purlin depth shorter. Open-face channel lines (single or doubled) always carry the purlins IN the channel and run to the roofline. Each line gets its own rafter blank and post cut on the LEAN RAFTER CUTS sheet.'));
          return host;}
        const bayN=(P.bay_layout?.bay_lengths||[]).length||Number(P.bay_layout?.bays||0)||0;
        const bayRange=el('input',{value:r.bays?(r.bays.from+'-'+r.bays.to):'',size:10,placeholder:bayN?'e.g. 2-'+bayN+' (of '+bayN+')':'main bay layout first','data-addition-field':'lean_'+i+'_bays',oninput:e=>{const m=e.target.value.match(/^\s*(\d+)\s*[-\u2013]\s*(\d+)\s*$/);if(m){r.bays={from:+m[1],to:+m[2]};r.full_length=false;}else delete r.bays;}});
        const wallSel=(k)=>el('select',{'data-addition-field':'lean_'+i+'_wall_'+k,onchange:e=>{r.walls[k]=e.target.value;if(k==='outer')r.roof_edge.wall_sheets=e.target.value==='sheeted';}},...[['open','OPEN'],['sheeted','SHEETED']].map(([v,t])=>el('option',{value:v,selected:r.walls[k]===v?'':null},t)));
        list.append(el('fieldset',{},el('legend',{},'Lean-to '+(i+1)),grid(['ID',input(r,'id','lean_'+i+'_id')],['Attach to',choose(r,'face',['right','left','front','rear'].map(s=>[s,faceName(s)]),'lean_'+i+'_face')],['Start X (outside view)',input(r,'start','lean_'+i+'_start')],['Length along wall',input(r,'length','lean_'+i+'_length')],['Projection out from wall',input(r,'projection','lean_'+i+'_projection')],['Roof connection plane',choose(r,'roof_continuity',[['separate','Separate roof / entered height and pitch'],['main_plane','Continue the main roof plane (roofline = top of purlin carried on; height and pitch derived)']],'lean_'+i+'_roof_continuity')],['Roof overhang ALONG slope',input(r,'roof_overhang','lean_'+i+'_roof_overhang')],['Low eave (top of purlin)',input(r,'low_eave','lean_'+i+'_low_eave')],['Pitch rise / 12',input(r,'pitch','lean_'+i+'_pitch')],['Roof purlin depth',input(r,'purlin_depth','lean_'+i+'_purlin_depth')],['Rafter (every line; an open-face channel is single at the two ends and doubled back to back, I shape, on the interior lines - per-line choices below)',choose(r,'rafter',rf,'lean_'+i+'_rafter')],['Doubled open-face interior rafters',choose(r,'doubled_rafter',[['welded','(a) Welded back to back (standard)'],['spacer','(b) 1/8 in plate, open-face width, full length between the channels']],'lean_'+i+'_doubled_rafter')],['Lean END rafter (open-face channel leans)',choose(r,'end_rafter_style',[['standard','Standard single open-face channel'],['special_open_c','Special open-C: C purlin into the main end rafter + open-face Cee stopping 1/2 in from the sheet']],'lean_'+i+'_end_rafter_style')],['Lean columns (W, tube or open-face channel)',choose(r,'column',col,'lean_'+i+'_column')],['Connection to the main building',choose(r,'high_connection',[['welded_direct','Welded directly to the main column — no gap (standard)'],['clip','Welded clip — rafter 2 in clear of the column (option)'],['end_plate','Bolted end plate / 4 holes (legacy)']],'lean_'+i+'_high_connection')],['Rafter seat at the lean post',choose(r,'rafter_seat',[['inside_flange','Inside face — post to the rafter top line, rafter side-welded (standard)'],['outside_seat','On top of the post — plumb cut flush with the post outside face'],['inherit','Follow the main frame rafter seat']],'lean_'+i+'_rafter_seat')],['Low eave style',choose(r,'low_connection',[['bolted','Monoslope bolted bracket'],['fully_welded','Monoslope welded'],['welded_box','Monoslope welded / box option']],'lean_'+i+'_low_connection')],['Roof secondary fit for W rafter lines (open-face channels: purlins IN the channel, always)',choose(r,'purlin_mode',[['flush','Flush — purlins between the W flanges, web-welded; rafter top = roofline'],['bypass','Bypass — purlins over the W; rafter top = roofline minus purlin depth (shorter post)']],'lean_'+i+'_purlin_mode')],['Wall secondary fit (lean girts: own setting, flush standard)',choose(r,'girt_mode',[['flush','Flush'],['bypass','Bypass']],'lean_'+i+'_girt_mode')]),rafterLines(r,i),el('h4',{},'Separate-lean outer roof edge (owner length standard)'),check(r.roof_edge,'gutter','Gutter at separate-lean eave','lean_'+i+'_gutter'),check(r.roof_edge,'wall_sheets','Wall sheets at separate-lean outer edge','lean_'+i+'_edge_wall_sheets'),el('p',{class:'hint'},'Applied only when Owner length standard is enabled. Continuous-main-plane lean uses roof-side gutter/wall inputs in cladding instead. Standard8in overrides manual overhang; gutter projection2in plus1½in with wall sheets.'),el('h4',{},'Lean roof purlins'),check(r.roof_purlins,'enabled','Generate lean roof purlins (welded end rule required)','lean_'+i+'_roof_purlins'),grid(['Purlin profile (blank follows main selected purlin)',choose(r.roof_purlins,'profile_id',[['','Follow main purlin'],...(S.state.product_libraries?.secondaries||S.state.catalog.secondary.profiles).filter(x=>['C','Z'].includes(x.family)&&(String(x.id).startsWith('SSS-')?'sss':'mbci')===(S.state.job.settings.product_suppliers?.secondaries||'sss')).map(x=>[x.id,x.id])],'lean_'+i+'_purlin_profile')],['Maximum spacing ALONG slope (planning only)',input(r.roof_purlins,'max_spacing','lean_'+i+'_purlin_spacing')]),check(r.roof_purlins,'share_main_eave','Continued main roof plane only: top row is the main eave member (not counted twice)','lean_'+i+'_share_main_eave'),el('h4',{},'Extent along the wall'),check(r,'full_length','Whole building length (every main bay)','lean_'+i+'_full_length'),grid(['Main bays from-to (e.g. 2-3; blank = whole length / Start X + Length)',bayRange]),el('h4',{},'Lean-to walls — sheeted or open (new lean-to = roof only)'),grid(...LEAN_WALLS.map(([k,t])=>[t,wallSel(k)])),grid(['Lean end-wall posts',choose(r,'end_posts',[['auto','Standard — only when that end is sheeted and the projection exceeds 20 ft'],['always','Always (also on an open end)'],['never','Never']],'lean_'+i+'_end_posts')],['Lean end-post section (blank = same as the lean columns)',choose(r,'end_post',col,'lean_'+i+'_end_post')],['Lean girt elevations (blank = shop rule from the lean low eave; the main building heights do not apply)',input(r,'girt_elevations','lean_'+i+'_girt_elevations')],['Lean girt attachment',choose(r,'girt_attachment',[['web_weld','Welded to the web / tube face (standard, coped at W flanges)'],['web_clip','Stock web clips (6 in 3x5, 8 in 5x7, 10 in 7x9)']],'lean_'+i+'_girt_attachment')],['Lean post foundation',choose(r,'foundation',[['main','Post holes (standard - lean posts do NOT sit on the main slab)'],['slab','Slab - base plates on a slab'],['post_footing','Post holes - posts embedded (augered footing, no base plate)']],'lean_'+i+'_foundation')],['Post hole depth (blank = standard 3 ft)',input(r,'footing_depth','lean_'+i+'_footing_depth')],['Post hole diameter (blank = standard 18 in)',input(r,'footing_diameter','lean_'+i+'_footing_diameter')]),el('p',{class:'hint'},'Lean posts stand on the main framing lines (one per main frame line inside the lean). Sheeted lean walls get girts on the sidewall lines (slab: base angle then 5 ft maximum; post footing: 12 in then 5 ft maximum) under the flush shop rules; sheeted ends get the rake angle; a lowered lean roof gets a custom-formed wall-to-roof transition at the main wall (none when the roof follows the main roofline). Intermediate channel rafters are paired back to back; the two end rafters stay single. A lean roof that CONTINUES the main roof plane: an open-face channel rafter keeps its purlins IN the channel and its top IS the roofline; a W rafter line is FLUSH by default (purlin tops flush, rafter top = roofline = eave height) and can be set BYPASS, which puts the rafter top one purlin depth lower and cuts the post shorter. At the main column the plumb end is welded directly to what is on the column line: inside flange - the column face (the column runs to the rafter top line at eave height, so the rafter end meets it flush with nothing above the column top); outside seat / bypass end rafter - on the column seat beside the main rafter end when the depths match, otherwise to the main rafter end and the eave strut.'),grid(['Rafter peak elevation above floor (blank = derived reference)',input(r,'rafter_peak_height','lean_'+i+'_rafter_peak_height')],['Actual Cee web thickness EACH (do not infer gauge)',input(r,'cee_web_thickness','lean_'+i+'_cee_web_thickness')],['High welded clip fit',choose(r,'high_clip_fit',[['legacy','Previous 6in horizontal clip'],['gap_overlap','1.5in rafter gap + 6in web overlap (along slope)']],'lean_'+i+'_high_clip_fit')],['Clip hand from column web centerplane',choose(r,'clip_hand',[['positive','Positive side'],['negative','Negative side']],'lean_'+i+'_clip_hand')],['Clip fillet weld leg (default1/4in)',input(r,'clip_weld_size','lean_'+i+'_clip_weld_size')],['Bypass END-PLATE bolt preset',choose(r,'bolt_preset',[['','No preset / manual review'],['1277345-R5-SP2','R5/R6 SP2:4 A325 5/8in x2in']],'lean_'+i+'_bolt_preset')]),el('p',{class:'hint'},'Flush high clip:1/2in thick; select previous6in horizontal projection or1.5in along-slope gap plus6in web overlap; finished vertical root height NOMINAL rafter depth minus2in. Both edges pitch-cut; centered using rafter peak minus actual PLUMB end depth/2. Lateral offset uses contacting web/plate faces. Legacy welded-clip geometry only - each line follows its own roof-line fit. Preset SP2 specifies bolts only, NOT holes or plate geometry.'),grid(['Wall/roof source detail',choose(r,'transition_template',[['','Not selected'],['1277345-D9-T1','D9 T1 — wall/roof'],['1277345-D10-T2','D10 T2 — penetration / upper left'],['1277345-D10-T3','D10 T3 — penetration / upper middle'],['1277345-D10-T4-BOLTED','D10 T4 — BOLTED / lower left']],'lean_'+i+'_transition_template')]),grid(['Hole horizontal gauge',input(r,'hole_gauge','lean_'+i+'_hole_gauge')],['Hole vertical pitch',input(r,'hole_pitch','lean_'+i+'_hole_pitch')],['Hole diameter',input(r,'hole_diameter','lean_'+i+'_hole_diameter')],['Automatic plate width rule',choose(r,'plate_width_rule',[['round_up','Rafter flange rounded UP to whole inch'],['exact','Exact rafter flange width']],'lean_'+i+'_plate_width_rule')],['End-plate width (blank=automatic)',input(r,'plate_width','lean_'+i+'_plate_width')],['End-plate height (blank=rafter depth)',input(r,'plate_height','lean_'+i+'_plate_height')],['End-plate thickness (blank=1/2in)',input(r,'plate_thickness','lean_'+i+'_plate_thickness')]),el('p',{class:'hint'},'Blank plate sizes use Q05 rafter dimensions/1/2in thickness; editing overrides, clearing restores automatic. Blank hole dimensions stay pending. Entered 2×2 coordinates are checked against the column face and exported for review; existing column NC is NOT drilled automatically.'),el('button',{type:'button',onclick:()=>{C.lean_tos.splice(i,1);drawLeans();}},'Remove lean-to')));
      });}
      drawLeans();box.append(check(C,'detail_completion','Include nominal receiver FIELD-FIT blanks, lean roof clips and scope reconciliation','detail_completion'),el('h3',{},'Lean-to setout'),list,el('button',{'data-addition-action':'add-lean',onclick:()=>{let n=1;while(C.lean_tos.some(r=>r.id==='LT'+n))n++;C.lean_tos.push({id:'LT'+n,face:'right',start:'0',length:P.length||"60'",projection:"12'",low_eave:"10'",pitch:'1',purlin_depth:P.purlin_depth,rafter:'',column:'',roof_continuity:'separate',roof_overhang:'8',high_connection:'welded_direct',high_clip_fit:'owner_gap',rafter_seat:'inside_flange',clip_hand:'positive',clip_weld_size:'1/4',bolt_preset:'',low_connection:'fully_welded',purlin_mode:'flush',girt_mode:'flush',girt_attachment:P.girt_attachment||'web_weld',end_posts:'auto',end_post:'',rafter_lines:{},roof_purlins:{enabled:true,max_spacing:'60',share_main_eave:false},walls:{outer:'open',start_end:'open',finish_end:'open',main_below:'sheeted'}});drawLeans();}},'Add lean-to'));
      box.append(error,el('div',{class:'btnrow'},el('button',{class:'primary','data-addition-action':'save',onclick:async()=>{try{S.state=await api('POST','/api/framing-additions',{frame_id:fid,revision:rev,additions:C});closeModal();select('assembly',fid);showSheet('frame',fid);setStatus('Framing setout saved — review Holds / opening moves','warn');}catch(e){error.textContent=e.message;error.classList.remove('hidden');}}},'Apply lean-tos / show whole frame'),el('button',{onclick:closeModal},'Cancel')));openModal(box);
    }catch(e){alert(e.message);}
  }

  // ------------------------------------------------------------------ Materials page
  const dimText=x=>{let n=Math.round(Number(x)*16),feet=Math.floor(n/192),whole=Math.floor((n%192)/16),num=n%16,den=16;while(num&&num%2===0){num/=2;den/=2;}return(feet?feet+"'-":'')+whole+(num?' '+num+'/'+den:'')+'"';};
  const lf=x=>(Number(x||0)/12).toFixed(1)+' LF';
  function traceTree(p,item){
    const cuts=p.piece_trace.filter(r=>r.order_id===item.order_id),box=el('div',{class:'trace'});
    const link=r=>r.drawing&&S.state.sheets.some(s=>s.kind===r.drawing.kind&&s.name===r.drawing.name)?el('button',{class:'mini',onclick:()=>showSheet(r.drawing.kind,r.drawing.name)},'View drawing'):el('small',{},'reference / location review');
    for(const stock of [...new Set(cuts.map(r=>r.stock_id))]){
      const rows=cuts.filter(r=>r.stock_id===stock),r=rows[0];
      box.append(el('h4',{},stock+' · '+dimText(r.stock_length_in)+' '+r.material+' · remnant '+dimText(r.remnant_in)+' · kerf '+dimText(r.kerf_loss_in)+(Number(r.end_loss_in)?' · end allowances '+dimText(r.end_loss_in):'')));
      for(const c of rows)box.append(el('div',{class:'trace-piece'},el('b',{},c.cut_mark+' #'+c.instance+' — '+dimText(c.blank_length_in)),el('span',{},c.location),link(c)));
    }
    for(const use of item.uses||[])box.append(el('div',{class:'trace-piece'},el('b',{},use.mark),el('span',{},use.location),link(use)));
    if(!cuts.length&&!(item.uses||[]).length)box.append(el('p',{},'LOCATION REVIEW — source references: '+item.references));
    return box;
  }
  async function renderMaterialsPage(request){
    const page=$("#page");
    if(!S.orderPlan||S.orderPlan.revision!==S.state.revision){
      page.replaceChildren(el('p',{class:'hint',style:'padding:20px'},'Building the master order…'));
      try{const p=await api('GET','/api/order');if(request!==S.previewRequest)return;S.orderPlan=p;}
      catch(e){if(request===S.previewRequest)page.replaceChildren(el('div',{class:'err-box',style:'margin:20px'},'Master order could not be built: '+e.message));return;}
    }
    const p=S.orderPlan,a=(href,text,blank)=>el('a',{class:'btn',href,target:blank?'_blank':null},text);
    const head=el('div',{class:'page-head'},
      el('div',{},el('h2',{},'Master material order'),
        el('p',{class:'hint','data-order-summary':''},'Job '+p.job_no+' · revision '+String(p.revision).slice(0,8)+' · '+p.items.length+' supplier lines · '+p.pending.length+' review entries · stock ordered '+lf(p.ordered_linear_stock_in)+' for '+lf(p.blank_linear_stock_in)+' of blanks (baseline '+lf(p.baseline_linear_stock_in)+'; remnant '+lf(p.remnant_in)+', kerf '+lf(p.kerf_loss_in)+')')),
      el('div',{class:'btnrow'},a('/api/print/supplier.pdf','Supplier order PDF',true),a('/api/print/supplier.xlsx','Supplier XLSX'),a('/api/print/pricing.xlsx','Pricing XLSX'),a('/api/master-order.xlsx','Internal workbook (XLSX)'),a('/api/master-order.pdf','Detailed order PDF',true),a('/api/sss-alternate-rfq.xlsx','SSS alternate RFQ'),
        el('button',{class:'primary','data-page-action':'rules',onclick:orderSettings},'Stock & order rules…'),el('button',{'data-page-action':'pricing',onclick:priceSettings},'Price book / material list…')));
    const filter=el('input',{placeholder:'Filter: supplier item, order id, material, mark or location','data-trace-search':'',value:S.orderFilter||''});
    const body=el('div',{});
    const td=(x,cls)=>el('td',{class:cls||null},x==null?'':String(x));
    const draw=()=>{
      body.replaceChildren();const q=filter.value.toLowerCase();S.orderFilter=filter.value;
      for(const dept of [...new Set(p.items.map(i=>i.department))]){
        const rows=p.items.filter(i=>i.department===dept&&(!q||JSON.stringify([i,p.piece_trace.filter(r=>r.order_id===i.order_id)]).toLowerCase().includes(q)));
        if(!rows.length)continue;
        const sm=p.summary?.[dept]||{};
        const tbl=el('table',{class:'order'},el('thead',{},el('tr',{},...['Supplier item','Order','Qty','Length','Material','Grade / finish','Status',''].map(h=>el('th',{},h)))));
        const tb=el('tbody',{});
        for(const it of rows){
          const open=S.orderOpen?.has(it.order_id);
          const btn=el('button',{class:'mini','data-trace-order':it.order_id},open?'Trace ▴':'Trace ▾');
          const tr=el('tr',{'data-order-row':it.order_id,class:open?'open':''},td(it.supplier_id),td(it.order_id),td(it.quantity+(it.unit?' '+it.unit:'')),td(it.order_length||'—'),td(it.display_material||it.material),td((it.grade||'')+' / '+(it.finish||'')),td(it.status||'','status'),el('td',{},btn));
          const detail=el('tr',{class:'trace-row'+(open?'':' hidden')},el('td',{colspan:'8'},open?traceTree(p,it):''));
          btn.onclick=()=>{S.orderOpen||=new Set();const now=!S.orderOpen.has(it.order_id);if(now){S.orderOpen.add(it.order_id);detail.firstChild.replaceChildren(traceTree(p,it));}else S.orderOpen.delete(it.order_id);detail.classList.toggle('hidden',!now);tr.classList.toggle('open',now);btn.textContent=now?'Trace ▴':'Trace ▾';};
          tb.append(tr,detail);
        }
        tbl.append(tb);
        body.append(el('h3',{},dept,el('small',{},' '+rows.length+' lines'+(sm.proposed_pieces!=null?' · '+sm.proposed_pieces+' pieces':'')+(sm.pending_entries?' · '+sm.pending_entries+' pending':''))),tbl);
      }
      const pend=p.pending.filter(r=>!q||JSON.stringify(r).toLowerCase().includes(q));
      if(pend.length){
        const tbl=el('table',{class:'order pending'},el('thead',{},el('tr',{},...['Department','Material','Qty','Reference','Required length','Reason'].map(h=>el('th',{},h)))),
          el('tbody',{},...pend.map(r=>el('tr',{},td(r.department),td(r.material),td(r.quantity),td(r.reference),td(r.required_length||'PENDING'),td(r.reason,'status')))));
        body.append(el('h3',{},'Review entries — not ordered',el('small',{},' '+pend.length)),tbl);
      }
      if(!body.children.length)body.append(el('p',{class:'hint'},'Nothing matches the filter.'));
    };
    filter.oninput=draw;draw();
    const notes=el('details',{class:'page-notes'},el('summary',{},'Planning notes and trace rules'),...(p.notes||[]).map(n=>el('p',{},n)),el('p',{},p.trace_note||''));
    page.replaceChildren(head,filter,body,notes);
  }
  async function priceSettings(){
    try{
      clearTimeout(S.saveTimer);if(S.dirty)await save('before price book');if(S.dirty)throw new Error('Save job changes successfully before editing the price book');
      const cur=((S.state.job.settings||{}).material_list)||{};
      const C=JSON.parse(JSON.stringify({price_book:cur.price_book||[],edits:cur.edits||{},custom_lines:cur.custom_lines||[],job_costs:cur.job_costs||{}}));
      const error=el('div',{class:'err-box hidden'});
      const num=(obj,k,label)=>el('input',{value:obj[k]??'',size:10,'data-price-field':label||k,oninput:e=>obj[k]=e.target.value});
      const txt=(obj,k,label,size)=>el('input',{value:obj[k]??'',size:size||18,'data-price-field':label||k,oninput:e=>obj[k]=e.target.value});
      const box=el('div',{},el('h2',{},'Price book & material list'),el('p',{class:'hint'},'The program fills Quantity / Length / Size / Shape / Description / Color / Label on the Material List sheet of the internal workbook. You fill price and sq.ft. price here (matched by material text) or in the workbook yellow cells. UNPRICED lines never block the job. Basis: each = per piece, ft = per linear foot, sqft = per sq ft of 3 ft coverage panel.'));
      const bookBox=el('div',{});
      const drawBook=()=>{bookBox.replaceChildren(...C.price_book.map((r,i)=>el('fieldset',{},el('legend',{},'Price '+(i+1)),grid(['Material contains (e.g. PN8ZEE, PN6, PBR, W12X14)',txt(r,'match','book_'+i+'_match',28)],['Supplier contains (blank = any)',txt(r,'supplier','book_'+i+'_supplier')],['Basis',el('select',{'data-price-field':'book_'+i+'_basis',onchange:e=>r.basis=e.target.value},...[['each','per piece'],['ft','per linear foot'],['sqft','per sq ft (panel)']].map(([v,t])=>el('option',{value:v,selected:r.basis===v?'':null},t)))],['price',num(r,'price','book_'+i+'_price')],['sq.ft. price',num(r,'sqft_price','book_'+i+'_sqft')]),el('button',{onclick:()=>{C.price_book.splice(i,1);drawBook();}},'Remove price'))));};
      drawBook();
      box.append(el('h3',{},'Price book'),bookBox,el('button',{'data-price-action':'add-price',onclick:()=>{C.price_book.push({match:'',supplier:'',basis:'each',price:'',sqft_price:''});drawBook();}},'Add price'));
      const costBox=el('div',{});
      const labels=['material','labor','walk','rollup','insulation','wall light','slab','roof vent','gutter'];
      costBox.append(...labels.map(l=>grid([l+' ($ job estimate line)',num(C.job_costs,l,'cost_'+l)])));
      box.append(el('h3',{},'Job estimate lines (below the material list)'),costBox);
      const customBox=el('div',{});
      const drawCustom=()=>{customBox.replaceChildren(...C.custom_lines.map((r,i)=>el('fieldset',{},el('legend',{},'Manual line '+(i+1)),grid(['Description',txt(r,'description','cust_'+i+'_desc',28)],['Quantity',num(r,'quantity','cust_'+i+'_qty')],['Length (ft-in, optional)',txt(r,'length_in','cust_'+i+'_len')],['Size',txt(r,'size','cust_'+i+'_size')],['Shape',txt(r,'shape','cust_'+i+'_shape')],['Color',txt(r,'color','cust_'+i+'_color')],['Label',txt(r,'label','cust_'+i+'_label')],['price (per piece)',num(r,'price','cust_'+i+'_price')]),el('button',{onclick:()=>{C.custom_lines.splice(i,1);drawCustom();}},'Remove line'))));};
      drawCustom();
      box.append(el('h3',{},'Manual material lines (screws per bag, doors, anything the model does not draw)'),customBox,el('button',{'data-price-action':'add-line',onclick:()=>{C.custom_lines.push({description:'',quantity:1,length_in:'',size:'',shape:'',color:'',label:'',price:''});drawCustom();}},'Add manual line'));
      box.append(error,el('div',{class:'btnrow'},el('button',{class:'primary','data-price-action':'save',onclick:async()=>{try{S.state=await api('POST','/api/material-list',{settings:C,revision:S.state.revision});S.orderPlan=null;renderAll();showSheet('materials','order');setStatus('Price book saved — download the internal workbook for the Material List sheet','ok');priceSettings();}catch(e){error.textContent=e.message;error.classList.remove('hidden');}}},'Save price book'),el('button',{onclick:closeModal},'Cancel')));
      openModal(box,{dock:true});
    }catch(e){setStatus(e.message,'err');}
  }
  async function orderSettings(){
    try{
      clearTimeout(S.saveTimer);if(S.dirty)await save('before order settings');if(S.dirty)throw new Error('Save job changes successfully before editing order settings');
      const plan=(S.orderPlan&&S.orderPlan.revision===S.state.revision)?S.orderPlan:await api('GET','/api/order'),C=JSON.parse(JSON.stringify(plan.config));
      const error=el('div',{class:'err-box hidden'});
      const input=(obj,k,label)=>el('input',{value:obj[k]??'',size:24,'data-order-field':label||k,oninput:e=>obj[k]=e.target.value});
      const choice=(obj,k,items,label)=>el('select',{'data-order-field':label||k,onchange:e=>obj[k]=e.target.value},...items.map(([v,t])=>el('option',{value:v,selected:obj[k]===v?'':null},t)));
      const box=el('div',{},el('h2',{},'Stock & order rules — material optimizer'),el('p',{class:'hint'},'One JOB order, separated into Frame, Secondaries and Sheets / Trim. Matching materials only. Packing minimizes footage among compared plans—not guaranteed global optimum or cheapest price. All quantities remain review-held.'));
      const stocks={};
      for(const [family,label] of [['beam','Beams / wide flange'],['purlin','C/Z purlins, girts and Cee posts'],['hss','HSS / tube'],['channel','Structural unlipped channels']]){
        stocks[family]=C[family+'_stock_ft'].join(', ');
        box.append(el('h3',{},label),grid(['Stock lengths in FEET (comma-separated)',input(stocks,family,family+'_stock_ft')],['Ordering mode',choice(C,family+'_mode',[['stock','Optimize from stock lengths'],['exact','Custom exact lengths + marks'],['compare','Compare both — ORDER STOCK']])],['Grade (do not assume substitution)',input(C,family+'_grade')]));
      }
      box.append(grid(['Beam finish',input(C,'beam_finish')],['HSS finish (when unspecified in model)',input(C,'hss_finish')],['Plate grade',input(C,'plate_grade')],['Saw kerf — INCHES',input(C,'kerf_in')],['Extra allowance EACH stock end — INCHES',input(C,'end_allowance_in')]),el('p',{class:'hint'},'Default ¼-in separating cuts, zero extra end allowance. The cut before a leftover remnant is also deducted from that remnant. Stock planning uses LONG blanks, never the low-point column reference. No automatic member splice.'));
      box.append(el('h3',{},'Sheets / trim ordering'),grid(['Trim rule',choice(C,'trim_policy',[['exact_short_max_long','Exact short pieces; cap long segments'],['catalog','Use selected catalog stock lengths']])],['Maximum trim segment — INCHES (246 = 20 ft 6 in)',input(C,'trim_max_in')]),el('p',{class:'hint'},'Door trim/corners/etc. are exact lengths. Long runs include the entered lap, with an exact final piece. Lengths are YOUR supplier-order rule, not verified MBCI stock SKUs. Panel blanks stay exact; short/long supply flags remain.'));
      const overrides=el('details',{},el('summary',{},'Per-material stock / exact overrides'));
      for(const g of plan.groups){
        const obj={mode:C.mode_overrides[g.id]||'default'};const sel=choice(obj,'mode',[['default','Follow family default'],['stock','Stock'],['exact','Custom exact lengths + marks'],['compare','Compare both — ORDER STOCK']],g.id);
        sel.addEventListener('change',()=>{if(obj.mode==='default')delete C.mode_overrides[g.id];else C.mode_overrides[g.id]=obj.mode;});
        overrides.append(grid([g.profile+' / '+g.finish+' / '+g.grade,sel]));
      }
      overrides.append(el('p',{class:'hint'},'Overrides match the full material specification. A changed profile/grade/finish creates a new group and follows its family default.'));box.append(overrides);
      const E=C.material_engine;const enabled=el('input',{type:'checkbox','data-order-engine':'enabled',onchange:e=>E.enabled=e.target.checked});enabled.checked=E.enabled;
      box.append(el('h3',{},'Material engine / clip procurement'),el('label',{},enabled,' Enable clip sourcing / flat-bar planning'),el('p',{class:'hint'},'Existing jobs retain their prior CLIP purchase policy until enabled. Custom exact orders always include marks; stock-end allowances are not added to custom pieces. Compare orders STOCK only; select Custom to change the order. Model connection deductions are NEVER applied twice. Nominal bay spacing is not the cut length. Roof zero-gap cuts stay unchanged.'));
      box.append(grid(['Shear loss PER CUT above 1/8 inch — INCHES',input(E,'heavy_shear_loss_in')],['Shear loss PER CUT at/below 1/8 inch — blank = unresolved',input(E,'thin_shear_loss_in')]));
      const stockBox=el('div',{});const drawFlat=()=>{stockBox.replaceChildren();E.flat_stock.forEach((r,i)=>stockBox.append(el('fieldset',{},el('legend',{},'Flat stock '+(i+1)),grid(['ID (optional)',input(r,'id','flat_'+i+'_id')],['Thickness INCHES',input(r,'thickness_in','flat_'+i+'_thickness')],['Width INCHES',input(r,'width_in','flat_'+i+'_width')],['Length INCHES (240 = 20 ft)',input(r,'length_in','flat_'+i+'_length')],['Grade',input(r,'grade','flat_'+i+'_grade')],['Finish',input(r,'finish','flat_'+i+'_finish')]),el('button',{onclick:()=>{E.flat_stock.splice(i,1);drawFlat();}},'Remove flat stock '+(i+1)))));};drawFlat();
      const stockDetails=el('details',{},el('summary',{},'Available stock sizes — expand to edit'),stockBox);stockDetails.open=E.flat_stock.length<6;
      box.append(el('h3',{},'Available flat bars — enter supplier sizes'),el('p',{class:'hint'},'No sizes assumed. Width must match one verified blank side, with rotation allowed: no silent ripping. Thickness/grade/finish must match. Reserve the full loss for every cut. Omit final separation only at an exact finished stock end.'),stockDetails,el('button',{'data-order-action':'add-flat',onclick:()=>{E.flat_stock.push({id:'',thickness_in:'',width_in:'',length_in:'',grade:C.plate_grade,finish:'UNSPECIFIED'});drawFlat();stockDetails.open=true;}},'Add flat-bar stock size'));
      box.append(el('button',{'data-order-action':'sss-stock',onclick:async()=>{try{const cat=await api('GET','/api/sss-catalog');const th=new Set((plan.clip_requirements||[]).filter(r=>(E.clip_options[r.mark]?.mode||r.mode)==='shop').map(r=>r.thickness_in));for(const r of cat.flat_stock){if(th.has(r.thickness_in)&&!E.flat_stock.some(s=>s.id===r.id))E.flat_stock.push(r);}drawFlat();}catch(e){error.textContent=e.message;error.classList.remove('hidden');}}},'Add SSS catalog strip / flat candidates'),el('p',{class:'hint'},'Verified subset: 1/8 and 3/16 hot-rolled strip, 1/2 flat bar; 20 ft lengths (2026 guide pp20/22). Adds only shop-clip thicknesses. Catalog candidates, NOT confirmed local inventory. Grade/finish remain unspecified: verify before purchase. Existing stock entries retained.'));
      const clips=el('details',{open:true},el('summary',{},'Clip / plate sourcing — counted once'));
      for(const r of plan.clip_requirements||[]){
        const opt=E.clip_options[r.mark]||{};E.clip_options[r.mark]=opt;
        const mode={value:opt.mode||'default'};const sel=choice(mode,'value',[['default','Default: '+r.default_mode],['supplier','Buy FINISHED from supplier'],['shop','SHOP fabricate from flat bar'],...(r.kind==='plate'?[['blank','Buy rectangular blank (prior rule)']]:[])],'clip_'+r.mark+'_mode');
        sel.addEventListener('change',()=>{if(mode.value==='default')delete opt.mode;else opt.mode=mode.value;});
        const optional=(k)=>el('input',{value:opt[k]??'',size:18,'data-clip-option':r.mark+'_'+k,oninput:e=>{if(e.target.value==='')delete opt[k];else opt[k]=e.target.value;}});
        const confirmed=el('input',{type:'checkbox','data-clip-option':r.mark+'_route_confirmed',onchange:e=>opt.route_confirmed=e.target.checked});confirmed.checked=!!opt.route_confirmed;
        const advanced=el('details',{},el('summary',{},'Blank / shear route and material overrides'),el('p',{class:'hint'},'Rectangular clips default to one separation. Shaped clips require a reviewed cut count + route confirmation. Formed clips ALSO need a verified developed blank. Finished legs are not flat sizes. Each extra cut reserves its allowance along the bar feed: confirm this fits your route. No machine instructions are generated.'),grid(['Verified blank width INCHES (enter BOTH dimensions)',optional('blank_width_in')],['Verified blank length INCHES',optional('blank_length_in')],['Reviewed cuts per blank INCLUDING separation',optional('shear_cuts_per_blank')],['Grade override (blank follows global plate grade)',optional('grade')],['Finish override (blank follows requirement)',optional('finish')]),el('label',{},confirmed,' I reviewed the blank, feed allowance and shear cut count'));
        clips.append(el('fieldset',{},el('legend',{},r.mark+' / '+r.kind+' / qty '+r.quantity),grid(['Source',sel],['Supplier part code (optional; no SKU inferred)',optional('supplier_code')]),el('p',{class:'hint'},'Envelope '+r.thickness_in+' thick x '+r.envelope_width_in+' x '+r.envelope_length_in+' in; '+(r.formed?'FORMED: developed blank unknown':r.rectangular?'RECTANGULAR':'SHAPED')+'; '+r.grade+' / '+r.finish),advanced));
      }
      box.append(clips);
      const preview=el('div',{'data-order-preview':''});
      const parseStocks=()=>{for(const family of ['beam','purlin','hss','channel']){const xs=stocks[family].split(',').map(x=>Number(x.trim()));if(xs.some(x=>!Number.isFinite(x)||x<=0))throw Error('Stock feet must be positive comma-separated numbers');C[family+'_stock_ft']=xs;}};
      box.append(el('button',{'data-order-action':'preview',onclick:async()=>{try{parseStocks();const p=await api('POST','/api/order-preview',{settings:C,revision:plan.revision});preview.replaceChildren(el('h3',{},'PREVIEW — NOT SAVED'),el('p',{},p.items.length+' supplier lines; '+p.pending.length+' review entries. Flat bars: '+p.flat_bars.length+'. Shop blanks placed: '+p.flat_allocations.length+'.'));
        for(const r of p.material_comparisons)preview.append(el('p',{},r.profile+' / '+r.finish+' / '+r.grade+': stock '+(r.stock_ordered_length_in==null?'UNRESOLVED':(r.stock_ordered_length_in/12).toFixed(2)+' LF')+'; custom '+(r.custom_ordered_length_in/12).toFixed(2)+' LF; '+r.status));
        for(const r of p.clip_requirements)if(E.enabled)preview.append(el('p',{},r.mark+': '+r.mode+' / qty '+r.quantity+' / '+(r.status||'prior blank purchase')));
        error.classList.add('hidden');}catch(e){error.textContent=e.message;error.classList.remove('hidden');}}},'Preview plan (no save)'),preview);
      const runs=el('div',{});const draw=()=>{
        runs.replaceChildren();C.additional_trim_runs.forEach((r,i)=>runs.append(el('div',{style:'border:1px solid #bbb;padding:10px;margin:10px 0'},grid(['Profile / gauge / shape specification',input(r,'profile','extra_'+i+'_profile')],['Finish / color',input(r,'finish','extra_'+i+'_finish')],['Run length (inches or ft-in)',input(r,'length_in','extra_'+i+'_length')],['Number of identical runs',input(r,'quantity','extra_'+i+'_quantity')],['Lap in INCHES',input(r,'lap_in','extra_'+i+'_lap')]),el('button',{onclick:()=>{C.additional_trim_runs.splice(i,1);draw();}},'Remove run '+(i+1)))));
      };draw();box.append(el('h3',{},'Additional gutter / trim runs'),el('p',{class:'hint'},'Gutters are NOT automatically sized or counted from roof geometry. Enter confirmed run lengths and profile/color here to include them. Hydraulic sizing, outlets, end caps and supports remain separate.'),runs,el('button',{'data-order-action':'add-trim',onclick:()=>{C.additional_trim_runs.push({profile:'',finish:'',length_in:'',quantity:1,lap_in:2});draw();}},'Add gutter / trim run'));
      box.append(error,el('div',{class:'btnrow'},el('button',{class:'primary','data-order-action':'save',onclick:async()=>{
        try{
          for(const family of ['beam','purlin','hss','channel']){const xs=stocks[family].split(',').map(x=>Number(x.trim()));if(xs.some(x=>!Number.isFinite(x)||x<=0))throw new Error('Enter stock lengths as positive comma-separated numbers in feet');C[family+'_stock_ft']=xs;}
          S.state=await api('POST','/api/order-options',{settings:C,revision:plan.revision});S.orderPlan=null;renderAll();showSheet('materials','order');setStatus('Master order regenerated — review Holds and material specifications','warn');orderSettings();
        }catch(e){error.textContent=e.message;error.classList.remove('hidden');}
      }},'Save rules & rebuild order'),el('button',{onclick:closeModal},'Cancel')));
      openModal(box,{dock:true});
      if(S.sheet.kind!=='materials')showSheet('materials','order');
    }catch(e){setStatus(e.message,'err');}
  }

  // ------------------------------------------------------------------ header binding
  function bindHeader() {
    for (const k of ["job_no", "customer", "building", "date", "checked_by"]) {
      const i = $("#" + k); i.value = S.state.job[k] || "";
      i.oninput = () => { S.state.job[k] = i.value; scheduleSave("header"); };
    }
  }

  function renderAll(keepScroll = false) {
    refreshSaveLink();
    $("#btn_additions").disabled=false;$("#btn_master_order").disabled=false;$("#btn_order_settings").disabled=false;
    renderGeometryBar();renderReleaseBanner();bindHeader(); renderLists(); renderTabs(); renderIssues(); renderBom();
    const y = $("#props").scrollTop;
    if(!document.querySelector("#props input.bad"))renderProps(); if (keepScroll) $("#props").scrollTop = y;
    renderPreview();
  }

  // ------------------------------------------------------------------ wiring
  // Load sample job: the four starting options (356 carport, 357 roof only, 358 three-sided,
  // 359 enclosed - filed in every job list) or the Clark Jordan reference.
  const SAMPLE_FALLBACK=[{key:"carport",job_no:"356",building:"Sample 356 - carport (mono-slope)"},{key:"roof_only",job_no:"357",building:"Sample 357 - roof only"},{key:"three_sided",job_no:"358",building:"Sample 358 - three-sided"},{key:"enclosed",job_no:"359",building:"Sample 359 - enclosed"},{job_no:"1277345",building:"Clark Jordan reference"}];
  $("#btn_upgrade").onclick = async () => {
    if(!confirm("Convert the open job to the current shop standard (SSS products, standard lean-to connection, current layout rules)? Every change is listed afterwards; the job is regenerated."))return;
    try{const st=await api("POST","/api/job/upgrade",{});S.state=st;await load();reportUpgrade(st);}catch(e){alert(e.message);}
  };
  const SAMPLE_DIMS={carport:{width:"20'",length:"40'",eave_height:"8'",slope_rise:"1",bay_lengths:"20, 20"},roof_only:{width:"40'",length:"60'",eave_height:"12'",slope_rise:"1",bay_lengths:"20, 20, 20"},three_sided:{width:"40'",length:"60'",eave_height:"12'",slope_rise:"1",bay_lengths:"20, 20, 20"},enclosed:{width:"40'",length:"60'",eave_height:"12'",slope_rise:"1",bay_lengths:"20, 20, 20"}};
  function openSample(smp){
    const which=smp.key||smp.job_no, dims=SAMPLE_DIMS[smp.key];
    if(!dims){(async()=>{try{await switchTo(api("POST","/api/job/sample",{which}),"opened sample job "+smp.job_no);}catch(e){alert(e.message);}})();return;}
    const C={...dims};
    const inp=(k,label,size)=>{const i=el("input",{value:C[k],size:size||10,"data-sample-field":k});i.oninput=()=>C[k]=i.value;return [label,i];};
    const err=el("p",{class:"error"});
    const box=el("div",{},el("h2",{},"Open sample "+smp.job_no+" - customise the size"),el("p",{class:"hint"},(smp.building||"")+" - the sample is a starting option: set the building size here and it opens already customised. Bay lengths are feet or ft-in, comma separated; the length follows the bays. Everything else (walls, lean-tos, openings) stays editable in the wizard afterwards."),grid(inp("width","Width - front to back"),inp("length","Length - left to right (follows the bays)"),inp("eave_height","Eave height"),inp("slope_rise","Roof pitch - rise / 12",6),inp("bay_lengths","Bay lengths along the length",24)),err,el("div",{class:"btnrow"},el("button",{class:"primary","data-sample-open":smp.job_no,onclick:async()=>{try{closeModal();await switchTo(api("POST","/api/job/sample",{which,customize:C}),"opened sample job "+smp.job_no+" customised to "+C.width+" x "+C.length);}catch(e){openModal(box);err.textContent=e.message;}}},"Open customised"),el("button",{onclick:async()=>{closeModal();try{await switchTo(api("POST","/api/job/sample",{which}),"opened sample job "+smp.job_no);}catch(e){alert(e.message);}}},"Open as-is"),el("button",{onclick:closeModal},"Cancel")));
    openModal(box);
  }
  $("#btn_sample").onclick = () => {
    $("#job_menu").removeAttribute("open");
    const samples=(S.state.catalog&&S.state.catalog.samples)||SAMPLE_FALLBACK;
    const box=el("div",{},el("h2",{},"Open a sample job"),el("p",{class:"hint"},"The job you leave stays in the job list. Samples 356-359 are the shop standard (SSS products): the 20' x 40' x 8' carport and the 40' x 60' x 12' roof-only, three-sided and enclosed buildings (3 bays @ 20', 1:12). Opening one asks for the size first - samples are meant to be customised."));
    for(const smp of samples){
      box.append(el("div",{class:"btnrow"},el("button",{class:"primary","data-sample":smp.job_no,onclick:()=>{closeModal();openSample(smp);}},"Open "+smp.job_no),el("span",{},el("strong",{},smp.building||""),smp.description?el("small",{}," — "+smp.description):"")));
    }
    box.append(el("div",{class:"btnrow"},el("button",{onclick:closeModal},"Cancel")));
    openModal(box);
  };
  // Samples ▾ header menu: one click per sample building (same endpoint as Load sample job…).
  for(const b of document.querySelectorAll('[data-open-sample]'))b.onclick=()=>{$("#samples_menu")?.removeAttribute("open");const smp=(((S.state.catalog||{}).samples)||SAMPLE_FALLBACK).find(x=>(x.key||x.job_no)===b.dataset.openSample)||{key:b.dataset.openSample,job_no:b.dataset.openSample};openSample(smp);};
  // New job: the number proposed is the next one after the highest in the job list (360 after the
  // four samples); the user may type another. A number that is already listed is confirmed first.
  async function askJobNumber(title) {
    let next = "360", listed = [];
    try { next = (await api("GET", "/api/jobs/next-number")).job_no || next; listed = (await api("GET", "/api/jobs")).jobs || []; } catch (e) { /* offline list: plain prompt */ }
    for (;;) {
      const job_no = prompt(title + "\n\nNext free number: " + next, next); if (job_no === null || !job_no.trim()) return null;
      const taken = listed.find(j => j.job_no === job_no.trim());
      if (!taken || confirm("Job " + job_no.trim() + (taken.customer ? " (" + taken.customer + ")" : "") + " is already in the job list.\n\nOK = use this number anyway (the list will show both; the file name tells them apart)\nCancel = choose another number")) return job_no.trim();
    }
  }
  // New job…: job number, customer, then the starting option (blank + wizard, or a copy of one of
  // the four standard buildings under the new number, ready to edit in the wizard).
  function askStartingOption(job_no, customer) {
    const samples=((S.state.catalog&&S.state.catalog.samples)||SAMPLE_FALLBACK).filter(s=>s.key);
    const go=async(start_from)=>{closeModal();try{await switchTo(api("POST","/api/job/new",{job_no,customer,start_from:start_from||""}),"new job "+job_no+(start_from?" from the "+start_from.replace("_"," ")+" starting option":" — enter the building in the frame wizard"));wizard();}catch(e){alert(e.message);}};
    const box=el("div",{},el("h2",{},"Start job "+job_no+" from…"),el("p",{class:"hint"},"A starting option copies one of the shop-standard buildings under the new job number; change the size, bays and walls in the frame wizard that opens next. Blank starts the wizard with the SSS defaults only."));
    box.append(el("div",{class:"btnrow"},el("button",{class:"primary",onclick:()=>go("")},"Blank (frame wizard)"),el("span",{},el("small",{},"nothing pre-built; the wizard asks for everything"))));
    for(const smp of samples)box.append(el("div",{class:"btnrow"},el("button",{"data-start-from":smp.key,onclick:()=>go(smp.key)},(smp.building||smp.key).replace(/^SAMPLE \d+ - /,"")),el("span",{},smp.description?el("small",{},smp.description):"")));
    box.append(el("div",{class:"btnrow"},el("button",{onclick:closeModal},"Cancel")));
    openModal(box);
  }
  $("#btn_new").onclick = async () => { $("#job_menu").removeAttribute("open"); const job_no = await askJobNumber("Job number for the new job"); if (!job_no) return; const customer = prompt("Customer", ""); if (customer === null) return; askStartingOption(job_no, customer); };
  $("#btn_add_asm").onclick = newAssembly;
  $("#btn_wizard").onclick = () => wizard(S.state.job.assemblies[S.sel.name]?.derivation?.frame_id||Object.keys(S.state.job.settings.frames||{})[0]||null);
  $("#btn_additions").onclick=()=>additionsSettings();
  $("#btn_grades").onclick=()=>gradesSettings();
  $("#btn_order_settings").onclick=orderSettings;
  $("#btn_master_order").onclick=()=>showSheet('materials','order');
  $("#btn_connection").onclick = () => connectionWizard();
  $("#btn_plate_rules").onclick = () => plateStandards();
  $("#zoom_in").onclick = () => { S.zoom = Math.min(3, S.zoom * 1.25); S.fitMode = false; applyZoom(); };
  $("#zoom_out").onclick = () => { S.zoom = Math.max(0.2, S.zoom / 1.25); S.fitMode = false; applyZoom(); };
  $("#zoom_fit").onclick = zoomFit;
  $("#modal").addEventListener("click", e => { if (e.target.id === "modal") closeModal(); });
  window.addEventListener("beforeunload", e => { if (S.dirty) { e.preventDefault(); e.returnValue = ""; } });

  $("#btn_whole_frame").onclick=()=>{
    const frames=Object.keys(S.state.job.settings.frame_layouts||{});
    if(!frames.length){wizard();return;}
    if(frames.length===1){select("assembly",frames[0]);showSheet("frame",frames[0]);return;}
    openModal(el("div",{},el("h2",{},"Choose whole frame"),...frames.map(id=>el("button",{onclick:()=>{closeModal();select("assembly",id);showSheet("frame",id);}},"FRAME-"+id)),el("button",{onclick:closeModal},"Cancel")));
  };
  // ------------------------------------------------------------------ job list (one file per job under data/editor/jobs)
  const libraryKey=(no)=>((no||"").trim().replace(/[^A-Za-z0-9._-]+/g,"_").replace(/^[._]+|[._]+$/g,"")||"untitled");
  function fmtWhen(iso){try{const d=new Date(iso);return d.toLocaleDateString()+" "+d.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});}catch(e){return iso;}}
  async function switchTo(promise,done){
    clearTimeout(S.saveTimer);S.dirty=false;S.state=await promise;closeModal();S.sel={type:"assembly",name:null};await load();history.replaceState(null,'','?resume=1');setStatus(done,"ok");setTimeout(zoomFit,50);
    reportUpgrade(S.state);
  }
  // A job saved by an older version is converted to the shop standard when the current rules reject
  // it as saved (v0.8.41); the server lists what it changed in state.upgraded - show it once.
  function reportUpgrade(st){
    const notes=st&&Array.isArray(st.upgraded)?st.upgraded:[];if(!notes.length)return;
    if(notes.length===1&&/^Nothing to change/.test(notes[0])){setStatus(notes[0],"ok");return;}
    setStatus("converted to the current shop standard — "+notes.length+" change(s)","warn");
    const box=el("div",{},el("h2",{},"Converted to the current shop standard"),el("p",{class:"hint"},"The program made the following changes so the job follows the current shop rules (SSS products, standard connections, current layout rules); everything else you entered is unchanged. The list is kept in the job file (settings.upgrade_log)."),
      el("ul",{},...notes.map(n=>el("li",{},n))),el("div",{class:"btnrow"},el("button",{class:"primary",onclick:closeModal},"OK")));
    openModal(box);
  }
  async function openJobList(){
    let res;
    try{res=await api("GET","/api/jobs");}catch(e){alert(e.message);return;}
    const jobs=res.jobs||[];
    const box=el("div",{},el("h2",{},"Jobs"),
      el("p",{class:"hint"},"Every job is saved automatically under its job number. Open one to continue it — the job you leave stays in the list exactly as you left it. Deleted jobs are moved to data/editor/jobs/deleted."));
    if(!jobs.length)box.append(el("p",{},"No jobs yet. A job appears here as soon as it has a frame."));
    else{
      const tbl=el("table",{class:"joblist"},el("thead",{},el("tr",{},...["Job no.","Customer","Building","Size (W × L × eave)","Frames","Last saved",""].map(h=>el("th",{},h)))));
      const body=el("tbody",{});
      for(const j of jobs){
        const dup=jobs.filter(x=>x.job_no===j.job_no).length>1;
        const acts=el("td",{class:"acts"});
        if(j.open)acts.append(el("span",{class:"open-tag"},"open now"));
        else acts.append(el("button",{class:"primary","data-job-open":j.key,onclick:async()=>{try{await switchTo(api("POST","/api/jobs/open",{key:j.key}),"opened job "+j.job_no+(j.customer?" — "+j.customer:""));}catch(e){alert(e.message);}}},"Open"));
        acts.append(el("a",{class:"btn",href:"/api/jobs/file?key="+encodeURIComponent(j.key),download:"Job-"+j.key+".json",title:"Download this job as a file (for another computer or a backup)"},"Download"));
        if(!j.open)acts.append(el("button",{"data-job-delete":j.key,title:"Move this job to data/editor/jobs/deleted",onclick:async()=>{if(!confirm("Remove job "+j.job_no+(j.customer?" ("+j.customer+")":"")+" from the job list? It is moved to data/editor/jobs/deleted, not destroyed."))return;try{await api("POST","/api/jobs/delete",{key:j.key});openJobList();}catch(e){alert(e.message);}}},"Delete"));
        body.append(el("tr",{class:j.open?"open":"", "data-job-row":j.key},
          el("td",{},el("strong",{},j.job_no||j.key),dup?el("small",{class:"warn",title:"Two listed jobs carry this number; the file name tells them apart"}," (duplicate number — file "+j.key+")"):"",j.error?el("small",{class:"warn"}," "+j.error):""),
          el("td",{},j.customer||""),el("td",{},j.building||""),el("td",{},j.size||"—"),el("td",{},String(j.frames||0)),el("td",{},fmtWhen(j.modified)),acts));
      }
      tbl.append(body);box.append(tbl);
    }
    box.append(el("div",{class:"btnrow"},
      el("button",{"data-job-action":"new",onclick:()=>{closeModal();$("#btn_new").onclick();}},"New job…"),
      el("button",{"data-job-action":"import",onclick:()=>$("#btn_open").onclick()},"Open job file from this computer…"),
      el("button",{"data-job-action":"add-files",onclick:()=>$("#btn_add_files").onclick()},"Add job files to the list…"),
      el("button",{"data-job-action":"import-folder",onclick:()=>$("#btn_import_folder").onclick()},"Import from a previous installation…"),
      el("button",{onclick:closeModal},"Close")));
    openModal(box);
  }
  $("#btn_jobs").onclick=()=>{$("#job_menu").removeAttribute("open");openJobList();};
  $("#btn_open_hdr").onclick=()=>openJobList();
  // "Save job file…" is a plain download link; keep its file name in step with the open job.
  function refreshSaveLink(){const a=$("#btn_save_hdr");if(a&&S.state)a.download="Job-"+libraryKey(S.state.job.job_no)+".json";}
  // Add several saved job files to the list at once (not opened). Each file is validated by the server.
  $("#btn_add_files").onclick=()=>{$("#job_menu").removeAttribute("open");$("#job_files").value="";$("#job_files").click();};
  $("#job_files").onchange=async(ev)=>{
    const files=[...(ev.target.files||[])];if(!files.length)return;
    const jobs=[],bad=[];
    for(const f of files){try{const body=JSON.parse(await f.text());const job=body&&body.job&&body.job.assemblies?body.job:body;if(!job||!job.assemblies||!job.parts)throw new Error("not a saved building job");jobs.push({name:f.name,job});}catch(e){bad.push(f.name+": "+e.message);}}
    let res=null;
    if(jobs.length){try{res=await api("POST","/api/jobs/add",{jobs});}catch(e){alert("Could not add the files: "+e.message);return;}}
    const lines=[];
    for(const r of (res?res.results:[])){lines.push((r.status==="added"?"added: ":r.status==="same"?"already in the list: ":"rejected: ")+"job "+(r.job_no||"?")+(r.customer?" ("+r.customer+")":"")+" — "+r.source+(r.error?" — "+r.error:""));}
    for(const b of bad)lines.push("rejected: "+b);
    alert(lines.join("\n")||"Nothing added.");
    openJobList();
  };
  // Import every saved job found under a folder (a previous installation, a backup folder).
  $("#btn_import_folder").onclick=async()=>{
    $("#job_menu").removeAttribute("open");
    const path=prompt("Folder of the previous installation (or any folder with saved jobs).\nExamples: C:\\mbe8.22   or   C:\\mbe8.22\\Metal-Building-Editor\\data\\editor\n\nThe newest copy of each job number found there (job.json, backups, recovery copies, downloaded Job-*.json files) is added to the job list. Nothing is opened or changed in that folder.","");
    if(path===null||!path.trim())return;
    setStatus("importing jobs from "+path.trim()+" …");
    let r;try{r=await api("POST","/api/jobs/import-folder",{path:path.trim()});}catch(e){setStatus("import failed: "+e.message,"err");alert("Import failed: "+e.message);return;}
    const msg=["Folder: "+r.folder,"Added to the job list: "+r.added.length+(r.added.length?" — "+r.added.map(x=>x.job_no+(x.customer?" ("+x.customer+")":"")).join(", "):""),"Already in the list (identical): "+r.same.length,"Older copies of the same jobs skipped: "+r.older_copies_skipped,r.rejected.length?"Rejected: "+r.rejected.map(x=>x.source+" — "+x.error).join("; "):""].filter(Boolean).join("\n");
    setStatus("imported "+r.added.length+" job"+(r.added.length===1?"":"s")+" from "+r.folder,"ok");
    alert(msg);openJobList();
  };
  $("#btn_duplicate").onclick=async()=>{
    $("#job_menu").removeAttribute("open");
    const job_no=await askJobNumber("Job number for the copy of job "+S.state.job.job_no);if(!job_no)return;
    const customer=prompt("Customer for the copy",S.state.job.customer||"");if(customer===null)return;
    try{await switchTo(api("POST","/api/jobs/duplicate",{job_no,customer}),"job "+S.state.job.job_no+" copied as "+job_no+" — you are now in the copy");}catch(e){alert(e.message);}
  };
  // Open a saved job file (data/editor/job.json or the "Download saved job" text file) from this computer.
  $("#btn_open").onclick=()=>{$("#job_menu").removeAttribute("open");$("#job_file").value="";$("#job_file").click();};
  $("#job_file").onchange=async(ev)=>{
    const file=ev.target.files&&ev.target.files[0];if(!file)return;
    let body;
    try{body=JSON.parse(await file.text());}catch(e){alert("This is not a saved job file (JSON expected): "+e.message);return;}
    const job=body&&body.job&&body.job.assemblies?body.job:body;
    if(!job||typeof job!=="object"||!job.assemblies||!job.parts){alert("This file does not contain a saved building job.");return;}
    let library="keep";
    try{
      const listed=((await api("GET","/api/jobs")).jobs||[]).find(x=>x.key===libraryKey(job.job_no));
      if(listed&&!listed.open){
        library=confirm("Job "+job.job_no+(listed.customer?" ("+listed.customer+")":"")+" is already in the job list.\n\nOK = replace the listed job with this file (the listed copy is kept in recovery).\nCancel = keep both (the file is listed as "+libraryKey(job.job_no)+"~2).")?"replace":"keep";
      }else if(listed&&listed.open){
        if(!confirm("Job "+job.job_no+" is the job that is open now. Replace it with the file "+file.name+"? The current copy is kept in recovery."))return;
        library="replace";
      }
    }catch(e){/* no list: plain open */}
    try{await switchTo(api("PUT","/api/job",{job,event:"open job file "+file.name,library}),"opened "+file.name+" — job "+S.state.job.job_no);}
    catch(e){alert("Job file rejected: "+e.message);}
  };
  $("#btn_recover").onclick=async()=>{
    $("#job_menu").removeAttribute("open");
    if(!confirm("Replace the current job with the most recent recovery copy? (The current job stays in the job list.)"))return;
    try{clearTimeout(S.saveTimer);S.dirty=false;S.state=await api("POST","/api/job/recover");closeModal();S.sel={type:"assembly",name:null};await load();setStatus("previous job recovered","ok");}catch(e){alert(e.message);}
  };
  async function opening(){
    await load();
    if(S.state.job.settings.reconstruction_v0820){const fid=Object.keys(S.state.job.settings.frames||{})[0];if(fid)showSheet('building',fid);}
    if(new URLSearchParams(location.search).get("resume")!=="1"){
      if(Object.keys(S.state.job.assemblies||{}).length){
        const resume=()=>{closeModal();history.replaceState(null,'','?resume=1');setStatus('Resumed saved job — no reset or replacement','ok');setTimeout(zoomFit,50);};
        let others=0;try{others=((await api("GET","/api/jobs")).jobs||[]).filter(j=>!j.open).length;}catch(e){}
        openModal(el('div',{},el('h2',{},'Your saved job is available'),
          el('p',{},'Job '+S.state.job.job_no+(S.state.job.customer?' — '+S.state.job.customer:'')+' is open here. Opening the editor will NOT replace it with a blank job.'+(others?' '+others+' other job'+(others>1?'s are':' is')+' in the job list.':'')),
          el('div',{class:'btnrow'},el('button',{class:'primary','data-start-action':'resume',onclick:resume},'Resume saved job'),
            others?el('button',{'data-start-action':'jobs',onclick:openJobList},'Open a different job…'):'',
            el('button',{'data-start-action':'new',onclick:()=>$('#btn_new').onclick()},'Start a new job'))));
      }else{wizard();setStatus('New job — enter your building in the frame wizard.');}
    }
    setTimeout(zoomFit,50);
  }
  // Small surface for the other scripts (outputs.js): read the live state, trigger a save.
  window.MBDP = { state: () => S.state, save: (event) => save(event || "edit") };
  opening().catch(e => {
    setStatus("load failed: " + e.message, "err");
    if (e.stale_page) return;  // the reload dialog is already up
    openModal(el("div", {}, el("h2", {}, "The editor page could not load"),
      el("p", {}, e.message),
      el("p", { class: "hint" }, "Nothing has been changed on disk. If this keeps happening after a reload, send the message above together with the black console window's last lines."),
      el("div", { class: "btnrow" }, el("button", { class: "primary", onclick: () => location.reload() }, "Reload page"), el("button", { onclick: closeModal }, "Close"))));
  });
})();
