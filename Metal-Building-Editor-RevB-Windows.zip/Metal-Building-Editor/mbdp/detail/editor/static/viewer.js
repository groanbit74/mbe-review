/* In-page output viewer.
 *
 * Every output link (sheet PDF / DXF / SVG, the Outputs dialog, the issue-review PDF) opens HERE
 * instead of relying on a new browser tab or a download.  Embedded previews (an <iframe> without
 * allow-popups / allow-downloads, e.g. a hosted preview pane) silently swallow both, which looked
 * like "the output files do not work".  PDFs are shown page by page (server-rendered PNG via
 * /api/view), workbooks as tables, DXF via its SVG twin.  "Open in new tab" and "Copy link" are
 * still offered for a real browser tab, where the native viewer and downloads work.
 * Plain left-clicks are intercepted; Ctrl/Cmd/Shift/middle clicks keep the browser's behaviour.
 */
(() => {
  const EXT = /\.(pdf|xlsx|dxf|svg|png|zip|txt)$/i;
  const dlg = document.getElementById("output_viewer");
  if (!dlg) return;
  const $ = (s) => dlg.querySelector(s);
  const el = (tag, attrs = {}, ...kids) => { const n = document.createElement(tag); for (const [k, v] of Object.entries(attrs)) { if (v == null) continue; if (k === "class") n.className = v; else if (k.startsWith("on")) n[k] = v; else n.setAttribute(k, v); } n.append(...kids.filter(x => x != null)); return n; };
  const body = $(".v-body"), title = $(".v-title"), meta = $(".v-meta"), pages = $(".v-pages"), note = $(".v-note"), linkBox = $(".v-link");
  const state = { src: "", kind: "", n: 0, zoom: 100 };
  const embedded = (() => { try { return window.self !== window.top; } catch (e) { return true; } })();

  function absolute(src) { return new URL(src, location.href).href; }
  function setZoom(z) { state.zoom = Math.max(40, Math.min(240, z)); body.style.setProperty("--v-zoom", state.zoom + "%"); $(".v-zoom-label").textContent = state.zoom + "%"; }
  function pageIndicator() {
    if (state.kind !== "pdf") { pages.textContent = ""; return; }
    const imgs = [...body.querySelectorAll(".v-page")]; const top = body.getBoundingClientRect().top + 8;
    let cur = 1; for (let i = 0; i < imgs.length; i++) if (imgs[i].getBoundingClientRect().top <= top + 40) cur = i + 1;
    pages.textContent = `page ${cur} of ${state.n}`;
  }
  function scrollToPage(delta) {
    const imgs = [...body.querySelectorAll(".v-page")]; if (!imgs.length) return;
    const top = body.getBoundingClientRect().top + 8; let cur = 0;
    for (let i = 0; i < imgs.length; i++) if (imgs[i].getBoundingClientRect().top <= top + 40) cur = i;
    const next = Math.max(0, Math.min(imgs.length - 1, cur + delta)); imgs[next].scrollIntoView({ block: "start" });
  }
  function showLink(src, why) {
    linkBox.hidden = false; linkBox.querySelector("input").value = absolute(src);
    linkBox.querySelector(".v-why").textContent = why || "";
  }
  async function copyLink() {
    const input = linkBox.querySelector("input"); input.select();
    try { await navigator.clipboard.writeText(input.value); flash("Link copied — paste it into a browser tab."); }
    catch (e) { try { document.execCommand("copy"); flash("Link copied — paste it into a browser tab."); } catch (e2) { flash("Select the link and copy it (Ctrl/Cmd+C)."); } }
  }
  function flash(t) { note.textContent = t; note.hidden = !t; clearTimeout(flash.t); flash.t = setTimeout(() => { note.hidden = true; }, 4000); }
  function fmtSize(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : n > 1024 ? Math.round(n / 1024) + " KB" : n + " B"; }

  async function open(src, label) {
    state.src = src; state.kind = ""; state.n = 0;
    title.textContent = label || src.split("/").pop().split("?")[0]; meta.textContent = "rendering…"; pages.textContent = "";
    body.replaceChildren(el("p", { class: "hint" }, "Rendering the output…"));
    $(".v-newtab").href = src; linkBox.hidden = true; note.hidden = true;
    if (!dlg.open) { if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", ""); }
    setZoom(100);
    let m;
    try {
      const r = await fetch(`/api/view?src=${encodeURIComponent(src)}`);
      m = await r.json(); if (!r.ok || m.error) throw new Error(m.error || r.statusText);
    } catch (e) {
      body.replaceChildren(el("div", { class: "err-box" }, el("b", {}, "This output could not be produced: "), String(e.message || e)));
      meta.textContent = "";
      return;
    }
    state.kind = m.kind; title.textContent = label ? `${label} — ${m.filename}` : m.filename;
    meta.textContent = `${m.kind === "pdf" ? m.pages + (m.pages === 1 ? " page · " : " pages · ") : ""}${fmtSize(m.size)}`;
    body.replaceChildren();
    if (m.kind === "pdf") {
      state.n = m.pages;
      const rev = encodeURIComponent(document.body.dataset.revision || "");
      for (let i = 0; i < m.pages; i++) {
        const img = el("img", { class: "v-page", loading: i < 2 ? "eager" : "lazy", alt: `page ${i + 1}`, src: `/api/view?src=${encodeURIComponent(src)}&as=page&page=${i}&dpi=110&r=${rev}` });
        if (m.page_size) img.style.aspectRatio = `${m.page_size[0]} / ${m.page_size[1]}`;
        body.append(img);
      }
      pageIndicator();
    } else if (m.kind === "table") {
      for (const sh of m.sheets) {
        const tbl = el("table", { class: "v-table" });
        sh.rows.forEach((row, ri) => { const tr = el("tr", {}); for (const c of row) tr.append(el(ri === 0 ? "th" : "td", {}, c == null ? "" : String(c))); tbl.append(tr); });
        body.append(el("h4", {}, sh.name, sh.truncated ? el("small", {}, " (first 400 rows / 40 columns shown — open the workbook for everything)") : null), tbl);
      }
    } else if (m.kind === "svg") {
      const wrap = el("div", { class: "v-svg" }); wrap.innerHTML = m.svg; body.append(wrap);
    } else if (m.kind === "dxf") {
      body.append(el("p", { class: "hint" }, "DXF is a CAD file; this is its drawing as rendered by the editor. Use “Open in new tab” or the copied link in a browser tab to save the .dxf."));
      try { const r = await fetch(m.preview); const wrap = el("div", { class: "v-svg" }); wrap.innerHTML = await r.text(); body.append(wrap); } catch (e) { /* preview optional */ }
    } else if (m.kind === "image") {
      body.append(el("img", { class: "v-page", src }));
    } else if (m.kind === "zip") {
      const list = el("table", { class: "v-table" }, el("tr", {}, el("th", {}, "File in the archive"), el("th", {}, "Size")));
      for (const it of m.entries) list.append(el("tr", {}, el("td", {}, it.name), el("td", {}, fmtSize(it.size))));
      body.append(el("p", { class: "hint" }, `${m.count} files, ${fmtSize(m.size)} zipped. Archives cannot be shown inline — open the editor in a browser tab (or paste the copied link there) to save it.`), list);
    } else if (m.kind === "text") {
      body.append(el("pre", { class: "v-text" }, m.text + (m.truncated ? "\n… (truncated)" : "")));
    } else {
      body.append(el("p", {}, `${fmtSize(m.size)} ${m.content_type}. Open it in a browser tab to save it.`));
    }
    if (embedded) showLink(src, "You are in an embedded preview: it blocks new tabs and downloads. To save the file, open the editor in its own browser tab (the host's “open in new tab” control) or paste this link there.");
  }

  // controls
  $(".v-close").onclick = () => dlg.close();
  $(".v-prev").onclick = () => scrollToPage(-1);
  $(".v-next").onclick = () => scrollToPage(1);
  $(".v-zoom-out").onclick = () => setZoom(state.zoom - 20);
  $(".v-zoom-in").onclick = () => setZoom(state.zoom + 20);
  $(".v-zoom-fit").onclick = () => setZoom(100);
  $(".v-copy").onclick = () => { if (linkBox.hidden) showLink(state.src, ""); copyLink(); };
  linkBox.querySelector("button").onclick = copyLink;
  $(".v-newtab").addEventListener("click", (e) => {
    const w = window.open(state.src, "_blank");
    if (!w) { e.preventDefault(); showLink(state.src, "The browser (or the embedding page) blocked a new tab. Copy the link and paste it into a browser tab."); }
  });
  body.addEventListener("scroll", () => { requestAnimationFrame(pageIndicator); });
  dlg.addEventListener("click", (e) => { if (e.target === dlg) dlg.close(); });
  dlg.addEventListener("keydown", (e) => { if (e.key === "ArrowRight" || e.key === "PageDown") { scrollToPage(1); e.preventDefault(); } if (e.key === "ArrowLeft" || e.key === "PageUp") { scrollToPage(-1); e.preventDefault(); } });

  // every output link opens in the viewer (plain left-click only)
  document.addEventListener("click", (e) => {
    if (e.defaultPrevented || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest("a[href]"); if (!a || a.closest("#output_viewer")) return;
    let u; try { u = new URL(a.getAttribute("href"), location.href); } catch (err) { return; }
    if (u.origin !== location.origin || !u.pathname.startsWith("/api/") || !EXT.test(u.pathname)) return;
    e.preventDefault();
    const label = (a.textContent || "").trim().replace(/\s+/g, " ").slice(0, 80);
    open(u.pathname + u.search, label);
  });
  window.MBDPViewer = { open };
})();
