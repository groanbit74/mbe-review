/* Outputs dialog + Job menu wiring.  Independent of app.js: every link is a plain GET. */
(() => {
  const dlg = document.getElementById("outputs_dialog");
  const open = () => { if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", ""); };
  document.getElementById("btn_outputs").addEventListener("click", () => { syncStatus(); refreshRelease(); open(); });
  // Drawing status lives in job.settings.drawing_status; app.js exposes the state through window.MBDP.
  const pick = document.getElementById("drawing_status");
  const stateEl = document.getElementById("release_state");
  let release = null;
  function syncStatus() {
    const st = window.MBDP && window.MBDP.state();
    if (st && st.job) pick.value = (st.job.settings || {}).drawing_status || "REVIEW";
  }
  // Release check = hard model errors + open actionable items (missing input, failed fit, order holds).
  async function refreshRelease() {
    stateEl.textContent = "checking…"; stateEl.className = "release-state";
    try {
      const r = await fetch("/api/release-report"); release = await r.json();
      if (release.complete) { stateEl.textContent = "RELEASE CHECK: COMPLETE"; stateEl.className = "release-state ok"; }
      else {
        const n = release.blocking_count;
        stateEl.textContent = "RELEASE CHECK: " + n + " open item" + (n === 1 ? "" : "s");
        stateEl.className = "release-state open";
        stateEl.title = release.blockers.slice(0, 8).map(b => "[" + b.scope + "] " + b.reference + ": " + b.reason).join("\n");
      }
    } catch (e) { stateEl.textContent = "release check unavailable"; }
  }
  pick.addEventListener("change", () => {
    const st = window.MBDP && window.MBDP.state();
    if (!st || !st.job) return;
    if (pick.value === "FOR CONSTRUCTION" && release && !release.complete) {
      const list = release.blockers.slice(0, 6).map(b => "• " + b.reference + ": " + b.reason).join("\n");
      if (!confirm("The release check still lists " + release.blocking_count + " open item(s):\n\n" + list +
                   (release.blocking_count > 6 ? "\n…" : "") + "\n\nIssue FOR CONSTRUCTION anyway?")) {
        pick.value = (st.job.settings || {}).drawing_status || "REVIEW";
        return;
      }
    }
    st.job.settings = st.job.settings || {};
    st.job.settings.drawing_status = pick.value;
    window.MBDP.save("drawing status " + pick.value);
  });
  // Close when clicking the backdrop.
  dlg.addEventListener("click", e => { if (e.target === dlg) dlg.close(); });
  // Keyboard shortcut: Ctrl/Cmd+Shift+O opens Outputs.
  window.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "o") { e.preventDefault(); open(); } });
  // Job menu closes after any action inside it.
  const menu = document.getElementById("job_menu");
  menu.querySelector(".menu-body").addEventListener("click", e => { if (e.target.closest("button, a")) menu.removeAttribute("open"); });
  document.addEventListener("click", e => { if (!menu.contains(e.target)) menu.removeAttribute("open"); });
})();
