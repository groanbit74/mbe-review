"""Web editor for the detailing model with live drawing preview."""
