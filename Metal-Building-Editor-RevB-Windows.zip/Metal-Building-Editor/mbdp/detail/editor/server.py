"""Editor HTTP server (stdlib only).

Routes
------
GET  /                         editor UI
GET  /api/job                  job JSON + issues + revision (+ static catalog with ?full=1)
GET  /api/catalog              static section / product / rule libraries (cached by the browser)
PUT  /api/job                  replace the job (validated, saved, audited); body {job, event, library?,
                               base_revision?}; base_revision = optimistic lock -> 409 {conflict, revision}
                               event "open job file <name>" imports a file; library="replace" lets it
                               take over an existing list entry with the same number (kept in recovery)
POST /api/job/sample           open a sample job: {which: '356'|'357'|'358'|'359' or key} (samples filed
                               in every job list) or {which: '1277345'} (Clark Jordan re-modelled)
POST /api/job/new              blank job with the standard part library and the SSS shop standard;
                               {start_from: carport|roof_only|three_sided|enclosed} starts from that sample
POST /api/job/recover          reload the most recent recovery copy
GET  /api/jobs                 the job list: every job filed under its number in <workspace>/jobs
GET  /api/jobs/file?key=K      download one listed job as Job-<K>.json (without opening it)
POST /api/jobs/open            {key}: make a listed job the working copy (the current one stays listed)
POST /api/jobs/delete          {key}: move a listed job to jobs/deleted (not the open job)
POST /api/jobs/duplicate       {job_no, customer?}: copy the open job under a new number and open it
POST /api/frame                rigid-frame wizard -> adds column + rafter assemblies
GET  /api/sheets               list of sheets [{kind, name}]
GET  /api/sheet/<kind>/<name>.svg|.pdf|.dxf
GET  /api/drawings.pdf         all sheets in one PDF
GET  /api/export.zip           full package (PDF, DXF, SVG, lists, plate DXF, NC, manifest)
GET  /api/preview/<kind>/<name>.png   raster preview
"""

from __future__ import annotations

import io
import json
import mimetypes
import os
import re
import shutil
import tempfile
import threading
import zipfile
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

from ... import __version__ as VERSION
from .. import model as M
from .. import sections
from ..drawing import all_sheets, assembly_sheet, cut_sheet, plate_sheet, render_dxf, render_pdf, render_svg
from ..drawing.render_pdf import render_png
from ..drawing.sheet import usage
from ..frame import FrameParams, generate_frame
from ..shopdata import export_package
from ..standards import JOB_NO_START, LEGACY_SAMPLE_JOB_NO, MBCI_STANDARD, SSS_STANDARD, job_settings
from ..templates import sample_job, standard_parts

STATIC = os.path.join(os.path.dirname(__file__), "static")


_COMMON_W_ORDER = ('W6X9', 'W8X10', 'W10X12', 'W10X15', 'W12X14', 'W12X16', 'W12X19', 'W12X22')
_COMMON_HSS_ORDER = (
    'HSS 4x4 x 14 ga',
    'HSS 4x4 x 11 ga',
    'HSS 4x4 x 3/16',
    'HSS 4x6 x 14 ga',
    'HSS 4x6 x 11 ga',
    'HSS 4x6 x 3/16',
)


def _shop_section_order(names):
    """Common shop sections first, then section sizes numerically, not alphabetically."""
    from .. import sections as section_lib
    from ..tube_sections import get as tube_get

    def key(name):
        if name in _COMMON_W_ORDER:
            return (0, _COMMON_W_ORDER.index(name), 0, name)
        if name.startswith('W'):
            try:
                sec = section_lib.get_section(name)
                return (1, float(sec.d), float(getattr(sec, 'plf', 0) or 0), name)
            except Exception:
                return (1, 999, 0, name)
        if name in _COMMON_HSS_ORDER:
            return (2, _COMMON_HSS_ORDER.index(name), 0, name)
        if name.upper().startswith('HSS '):
            try:
                sec = tube_get(name)
                return (3, float(sec.bf), float(sec.d), float(sec.plf or 0), name)
            except Exception:
                return (3, 999, 999, 0, name)
        return (4, 0, 0, name)

    return sorted(names, key=key)


def _shop_product_order(rows):
    """List C purlins, then 4/6/8-in open-face channels, in shop-friendly order."""
    fam_rank = {'C': 0, 'Channel': 1, 'Z': 2, 'Eave': 3, 'Angle': 4}

    def key(row):
        d = float(row.get('nominal_depth_in') or 0)
        fam = row.get('family', '')
        return (
            fam_rank.get(fam, 9),
            0 if round(d) in (4, 6, 8) else 1,
            d,
            str(row.get('nominal_size') or ''),
            int(row.get('gauge') or 0),
            str(row.get('id') or ''),
        )

    return sorted(rows, key=key)


def static_stamp() -> str:
    """Cache-busting token: newest mtime of the static files (changes whenever any of them is edited)."""
    newest = max((os.path.getmtime(os.path.join(STATIC, f)) for f in os.listdir(STATIC)), default=0.0)
    return f"{int(newest):x}"


class JobStore:
    """JSON file + audit log; whole-job saves keep the server simple and the model consistent.

    Files in the workspace
    ----------------------
    ``job.json``            the job being worked on (autosaved after every edit)
    ``jobs/<key>.json``     the job list: every job filed under its job number, kept
                            up to date by the same autosave (see ``job_library``)
    ``jobs/deleted/``       jobs removed from the list (never pruned; delete by hand)
    ``recovery/``           the last ten jobs replaced by New job / Open job file /
                            Load sample / Recover (safety net, pruned to ten)
    ``audit.jsonl``         one line per save
    """

    SWITCH_PREFIXES = ("new job", "open job", "duplicate job", "load sample job", "recover previous job")

    def __init__(self, workspace: str, seed: str = "sample", samples: bool = False):
        """``seed`` decides what a brand-new workspace starts with; ``samples`` files
        the four standard sample jobs (356-359) in the job list once per workspace
        (the interactive editor passes True; scripts and tests keep their lists bare).

        ``"blank"`` (the interactive editor): an empty job with the standard part
        library, so the user's first building is never mixed with demonstration
        members (specification §3: no silent demo job).  ``"sample"`` (default for
        scripts and the regression tests): the re-modelled Clark Jordan job."""
        self.dir = workspace
        os.makedirs(workspace, exist_ok=True)
        self.path = os.path.join(workspace, "job.json")
        self.audit = os.path.join(workspace, "audit.jsonl")
        self.jobs_dir = os.path.join(workspace, "jobs")
        self.lock = threading.RLock()
        self.filed_key: str | None = None  # list entry the working copy is filed under
        self._meta_cache: dict[str, tuple] = {}
        fresh_list = not os.path.isdir(self.jobs_dir)
        os.makedirs(self.jobs_dir, exist_ok=True)
        if os.path.exists(self.path):
            with open(self.path) as fh:
                raw = fh.read()
            self.job = M.Job.loads(raw)
            self._adopt_entry(raw)
        elif seed == "blank":
            self.job = M.Job(job_no="NEW", customer="", building="Main Bldg.", parts=standard_parts())
            self.job.settings.update(job_settings())
            self._save("init: blank job (standard part library, SSS shop standard)")
        else:
            self.job = sample_job()
            self._save("init: sample job")
        if fresh_list:
            n = self._import_recovery_copies()
            if n:
                self._audit(f"job list created: {n} previous job(s) imported from recovery copies")
        from ..connections import normalize_columns, rebuild

        before = self.job.revision()
        normalize_columns(self.job)
        from ..plate_rules import migrate_plate_defaults, migrate_weld_defaults

        migrate_weld_defaults(self.job)
        migrate_plate_defaults(self.job)
        from ..frame import sync_frames

        sync_frames(self.job)
        rebuild(self.job)
        if before != self.job.revision():
            self._save("upgrade v0.7: raised apex bottom, linked gable / mono-slope and whole-frame setout")
        else:
            self._file_current()  # make sure the working copy has its list entry
        if samples:
            self.seed_samples()

    # ---- sample jobs ---------------------------------------------------
    SAMPLES_MARKER = ".samples-filed-v2"  # v2 (0.8.31): 356 carport, 357 roof only, 358 three-sided, 359 enclosed

    def _listed_sample(self, which: str):
        """The job-list row holding this sample (customer SAMPLE + tag in the building name),
        whatever its number - a workspace filed before the carport existed keeps its numbers."""
        from ..samples import is_sample

        for r in self.list_jobs():
            if not r.get("error") and is_sample(r, which):
                return r
        return None

    def seed_samples(self) -> list[str]:
        """File the standard sample jobs (356-359) in the job list, once per workspace
        (marker file in ``jobs/``).  A sample already listed under another number (older
        workspace) is kept; a missing one takes its own number when free, else the next
        free number.  They are never opened automatically and a failure to build one never
        stops the editor."""
        from ..samples import SAMPLES
        from ..samples import sample_job as build_sample

        marker = os.path.join(self.jobs_dir, self.SAMPLES_MARKER)
        if os.path.exists(marker):
            return []
        filed = []
        with self.lock:
            for which in SAMPLES:
                if self._listed_sample(which):
                    continue
                listed = {r["job_no"] for r in self.list_jobs()}
                number = which if which not in listed else self.next_job_no()
                try:
                    rec = self.file_job(build_sample(which, number), source=f"sample job {which}")
                    if rec["status"] == "added":
                        filed.append(rec["key"])
                except Exception as e:  # pragma: no cover - a broken sample must not block start-up
                    self._audit(f"sample job {which} not filed: {str(e)[:200]}")
            with open(marker, "w") as fh:
                fh.write(",".join(filed) + "\n")
        if filed:
            self._audit("sample jobs filed in the job list: " + ", ".join(filed))
        return filed

    def open_sample(self, which: str) -> None:
        """*Load sample job*: open the listed sample (keeps any edits the user made to
        it) or file a fresh copy; ``1277345`` is the hand-modelled Clark Jordan job."""
        from ..samples import sample_job as build_sample
        from ..samples import which_of

        which = str(which or "").strip()
        if which in ("", LEGACY_SAMPLE_JOB_NO):
            self.replace(sample_job(), "load sample job")
            return
        which = which_of(which)
        with self.lock:
            row = self._listed_sample(which)
            if row is not None:
                self.open_job(row["key"])
                return
            listed = {r["job_no"] for r in self.list_jobs()}
            number = which if which not in listed else self.next_job_no()
            self.replace(build_sample(which, number), f"load sample job {which}")

    def customize_geometry(self, custom) -> None:
        """Resize the open job's building from the sample-opening dialogue (owner round 16).

        Width / length / eave height / pitch and an explicit bay-length list are applied to
        the (single) frame and the job is regenerated, so a sample opens already customised
        instead of forcing the user to fight the saved bay layout in the wizard.
        """
        if not isinstance(custom, dict) or not custom:
            return
        from ..frame import FrameParams, generate_frame
        from ..model import D

        job = M.Job.loads(self.job.dumps())
        frames = job.settings.get('frames') or {}
        if not frames:
            return
        fid = next(iter(frames))
        params = FrameParams.from_json(frames[fid])
        for key in ('width', 'length', 'eave_height'):
            if str(custom.get(key) or '').strip():
                setattr(params, key, D(str(custom[key]).strip()))
        if str(custom.get('slope_rise') or '').strip():
            from fractions import Fraction

            params.slope_rise = Fraction(str(custom['slope_rise']).strip()).limit_denominator(48)
        bays = str(custom.get('bay_lengths') or '').strip()
        if bays:
            lengths = [
                (x.strip() if ("'" in x or '"' in x) else x.strip() + "'")  # a bare number is feet here
                for x in bays.split(',')
                if x.strip()
            ]
            for x in lengths:
                D(x)
            params.bay_layout = dict(params.bay_layout or {})
            params.bay_layout.update(layout_mode='explicit', bays=len(lengths), bay_lengths=lengths)
            total = sum(float(D(x).inches) for x in lengths)
            params.length = D(total)
            zones = (params.bay_zones or {}).get('bays') or []
            params.bay_zones = dict(params.bay_zones or {})
            params.bay_zones['bays'] = [
                dict(zones[i] if i < len(zones) else {}, length=x, left='sheeted', right='sheeted')
                if not zones
                else dict(zones[i], length=x)
                for i, x in enumerate(lengths)
            ]
        generate_frame(job, params)
        self.replace(job, 'customise sample geometry (opening dialogue)')

    def sample_rows(self) -> list[dict]:
        """Samples for the menus: number they hold in this job list, label, description."""
        from ..samples import SAMPLES

        out = []
        for which, spec in SAMPLES.items():
            row = self._listed_sample(which)
            out.append(
                dict(
                    key=spec["key"],
                    job_no=row["job_no"] if row else which,
                    building=spec["building"],
                    description=spec["description"],
                )
            )
        return out

    # ---- saving --------------------------------------------------------
    def _audit(self, event: str) -> None:
        with open(self.audit, "a") as fh:
            fh.write(
                json.dumps(
                    {
                        "t": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                        "event": event,
                        "revision": self.job.revision(),
                    }
                )
                + "\n"
            )

    @staticmethod
    def _write(path: str, text: str) -> None:
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            fh.write(text)
        os.replace(tmp, path)

    def _save(self, event: str) -> None:
        self._write(self.path, self.job.dumps())
        self._audit(event)
        self._file_current()

    def _entry(self, key: str) -> str:
        if not key or key != key.strip() or any(c in key for c in "/\\\0") or key.startswith(".") or ".." in key:
            raise ValueError("Unknown job")
        return os.path.join(self.jobs_dir, key + ".json")

    def _adopt_entry(self, raw: str) -> None:
        """On start-up, find the list entry the working copy belongs to.

        An entry with the same job number whose content equals ``job.json`` is
        ours.  If none matches byte for byte (``job.json`` was replaced by hand
        while the editor was stopped), the entry noted in ``jobs/.open-job`` is
        adopted when it carries the same number — the hand copy then updates it
        (its previous content is kept in ``recovery``).  Otherwise the working
        copy is filed as a new entry on the first save."""
        from .job_library import library_key

        base = library_key(self.job.job_no)
        candidates = [
            fn[:-5] for fn in os.listdir(self.jobs_dir) if fn.endswith(".json") and fn[:-5].split("~")[0] == base
        ]
        for key in sorted(candidates):
            try:
                if self.read_entry(key) == raw:
                    self.filed_key = key
                    return
            except Exception:
                continue
        hint = ""
        try:
            with open(os.path.join(self.jobs_dir, ".open-job")) as fh:
                hint = fh.read().strip()
        except OSError:
            pass
        if hint in candidates:
            try:
                self._keep_recovery_copy(M.Job.loads(self.read_entry(hint)))
            except Exception:
                pass
            self.filed_key = hint
            self._write(self._entry(hint), raw)

    def _file_current(self) -> None:
        """Mirror the working copy into the job list under its job number.

        A job is filed once it has a frame or an assembly (or was filed before).
        Changing the job number in the header moves the entry; a number that
        belongs to a *different* listed job gets a ``~2`` variant instead of
        overwriting it."""
        from .job_library import library_key, unique_key, worth_filing

        if not (self.filed_key or worth_filing(self.job)):
            return
        key = unique_key(self.jobs_dir, library_key(self.job.job_no), self.filed_key)
        if self.filed_key and self.filed_key != key:
            old = self._entry(self.filed_key)
            if os.path.exists(old):
                os.unlink(old)
            self._meta_cache.pop(self.filed_key, None)
        self._write(self._entry(key), self.job.dumps())
        if key != self.filed_key:
            self._write(os.path.join(self.jobs_dir, ".open-job"), key + "\n")
        self.filed_key = key

    def _keep_recovery_copy(self, job: M.Job | None = None) -> None:
        job = job or self.job
        folder = os.path.join(self.dir, "recovery")
        os.makedirs(folder, exist_ok=True)
        from .job_library import stamp

        self._write(os.path.join(folder, stamp() + ".json"), job.dumps())
        for old in sorted(os.listdir(folder))[:-10]:
            if old.endswith(".json"):
                os.unlink(os.path.join(folder, old))

    def _import_recovery_copies(self) -> int:
        """First start with the job list: previous jobs that only survived as
        recovery copies become list entries (latest copy per job number wins;
        the working copy is filed afterwards and takes precedence)."""
        from .job_library import library_key, worth_filing

        folder = os.path.join(self.dir, "recovery")
        if not os.path.isdir(folder):
            return 0
        n = 0
        for fn in sorted(os.listdir(folder)):
            if not fn.endswith(".json"):
                continue
            try:
                with open(os.path.join(folder, fn)) as fh:
                    d = json.load(fh)
                if not isinstance(d, dict) or not worth_filing(d):
                    continue
                shutil.copy2(os.path.join(folder, fn), self._entry(library_key(str(d.get("job_no", "")))))
                n += 1
            except Exception:
                continue
        return n

    def replace(self, job: M.Job, event: str, *, filed_key: str | None = None) -> None:
        """Make ``job`` the working copy.

        Edits keep the current list entry (so renumbering moves it); switching
        events — ``new job``, ``open job …``, ``duplicate job …``, ``load sample
        job``, ``recover previous job`` — leave the previous job's entry alone and
        file the new one under its own number (``filed_key`` pins the entry when
        the job came from the list itself)."""
        from ..plate_rules import migrate_plate_defaults, migrate_weld_defaults

        migrate_weld_defaults(job)
        migrate_plate_defaults(job)
        with self.lock:
            if event.startswith(self.SWITCH_PREFIXES):
                if self.job.assemblies:
                    self._keep_recovery_copy()
                self.filed_key = filed_key
            self.job = job
            self._save(event)

    # ---- job list ------------------------------------------------------
    def list_jobs(self) -> list[dict]:
        from .job_library import job_meta

        rows = []
        with self.lock:
            for fn in sorted(os.listdir(self.jobs_dir)):
                if not fn.endswith(".json"):
                    continue
                key = fn[:-5]
                path = os.path.join(self.jobs_dir, fn)
                st = os.stat(path)
                sig = (st.st_mtime_ns, st.st_size)
                cached = self._meta_cache.get(key)
                if not cached or cached[0] != sig:
                    cached = (sig, job_meta(path))
                    self._meta_cache[key] = cached
                row = dict(cached[1])
                row.update(
                    key=key,
                    bytes=st.st_size,
                    open=(key == self.filed_key),
                    modified=datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(timespec="seconds"),
                )
                rows.append(row)
        rows.sort(key=lambda r: r["modified"], reverse=True)  # newest first …
        rows.sort(key=lambda r: not r["open"])  # … with the open job on top
        return rows

    def read_entry(self, key: str) -> str:
        path = self._entry(key)
        if not os.path.exists(path):
            raise ValueError(f"Job {key} is not in the job list")
        with open(path, encoding="utf-8") as fh:
            return fh.read()

    def open_job(self, key: str) -> list[str]:
        """Open a listed job; a job saved by an older version that the current rules reject is
        converted to the shop standard first (``legacy_upgrade``).  Returns the change list."""
        job = M.Job.loads(self.read_entry(key))
        from ..legacy_upgrade import open_or_upgrade

        notes = open_or_upgrade(job)
        self.replace(
            job, f"open job {key} from job list" + (" (converted to the shop standard)" if notes else ""), filed_key=key
        )
        return notes

    def delete_job(self, key: str) -> None:
        with self.lock:
            path = self._entry(key)
            if key == self.filed_key:
                raise ValueError("This is the open job; open another job first, then delete it")
            if not os.path.exists(path):
                raise ValueError(f"Job {key} is not in the job list")
            from .job_library import stamp

            folder = os.path.join(self.jobs_dir, "deleted")
            os.makedirs(folder, exist_ok=True)
            shutil.move(path, os.path.join(folder, f"{key}-{stamp()}.json"))
            self._meta_cache.pop(key, None)
            self._audit(f"delete job {key} from job list (moved to jobs/deleted)")

    def duplicate_job(self, job_no: str, customer: str | None = None) -> None:
        with self.lock:
            job_no = str(job_no or "").strip()
            if not job_no:
                raise ValueError("Enter a job number for the copy")
            job = M.Job.loads(self.job.dumps())
            old = job.job_no
            job.job_no = job_no
            if customer is not None:
                job.customer = customer
            self.replace(job, f"duplicate job {old} as {job_no}")

    def next_job_no(self) -> str:
        """The job number proposed for *New job…* / *Duplicate job as…*: one past the
        highest all-digit number in the job list (and the open job), else 356
        (``standards.JOB_NO_START``; the samples take 356-359, so the first real job is 360)."""
        from .job_library import next_job_no

        with self.lock:
            numbers = [r["job_no"] for r in self.list_jobs()] + [self.job.job_no]
        # The Clark Jordan reference keeps its real number; it never advances the counter.
        return next_job_no(numbers, JOB_NO_START, ignore=(LEGACY_SAMPLE_JOB_NO,))

    def file_job(self, data: dict | M.Job, source: str = "") -> dict:
        """Add a job to the job list without opening it.

        Used by *Add job files…* and *Import from a previous installation…*.  The
        job is validated by loading it into the model; an entry whose content is
        already in the list (same job number, same revision) is reported as
        ``same`` and not duplicated; a different job carrying a listed number is
        filed as ``<key>~2`` as elsewhere.  Returns ``dict(status, key, job_no,
        customer, source)`` with ``status`` ``added`` or ``same``."""
        from .job_library import library_key, unique_key, worth_filing

        job = data if isinstance(data, M.Job) else M.Job.from_json(data)
        if not worth_filing(job):
            raise ValueError(f"{source or 'This file'} is an empty job (no frame, no assembly)")
        rev = job.revision()
        with self.lock:
            base = library_key(job.job_no)
            for fn in sorted(os.listdir(self.jobs_dir)):
                if fn.endswith(".json") and fn[:-5].split("~")[0] == base:
                    try:
                        if M.Job.loads(self.read_entry(fn[:-5])).revision() == rev:
                            return dict(
                                status="same", key=fn[:-5], job_no=job.job_no, customer=job.customer, source=source
                            )
                    except Exception:
                        continue
            key = unique_key(self.jobs_dir, base, None)
            self._write(self._entry(key), job.dumps())
            self._audit(f"add job {key} to job list from {source or 'file'}")
        return dict(status="added", key=key, job_no=job.job_no, customer=job.customer, source=source)

    def import_folder(self, path: str) -> dict:
        """File every saved job found under ``path`` (a previous installation, a
        backup folder, a downloads folder) in the job list: the newest copy of
        each job number is added, older start-up backups / recovery copies of the
        same job are counted as skipped, blank jobs are ignored.  The open job is
        not changed."""
        from .job_library import import_candidates

        path = os.path.abspath(os.path.expanduser(str(path or "").strip().strip('"')))
        if not path or not os.path.exists(path):
            raise ValueError(f"Folder not found: {path or '(empty)'}")
        if os.path.isfile(path):
            path = os.path.dirname(path)
        newest, older = import_candidates(path, exclude=(self.dir,))
        results = []
        for rec in newest:
            try:
                results.append(self.file_job(rec["job"], source=rec["path"]))
            except Exception as e:  # one bad file must not stop the rest
                results.append(
                    dict(status="rejected", key=None, job_no=rec["job_no"], source=rec["path"], error=str(e)[:200])
                )
        return dict(
            folder=path,
            added=[r for r in results if r["status"] == "added"],
            same=[r for r in results if r["status"] == "same"],
            rejected=[r for r in results if r["status"] == "rejected"],
            older_copies_skipped=len(older),
        )

    def retire_entry(self, key: str) -> None:
        """Replace-on-import: the existing list entry goes to ``recovery`` and the
        key becomes ours, so the next save overwrites it."""
        with self.lock:
            path = self._entry(key)
            if os.path.exists(path):
                self._keep_recovery_copy(M.Job.loads(self.read_entry(key)))
                os.unlink(path)
                self._meta_cache.pop(key, None)


def sheet_for(job: M.Job, kind: str, name: str, issues):
    if kind == 'additions':
        from ..drawing.additions_sheet import additions_sheet

        fid, key, index, page = name.rsplit('~', 3)
        return additions_sheet(job, fid, key, int(index), int(page))
    if kind == 'order':
        from ..drawing.order_sheet import order_sheet

        key, page = name.rsplit('~', 1)
        return order_sheet(job, key, int(page))
    if kind == 'building':
        from ..drawing.building_sheet import building_sheet

        return building_sheet(job, name)
    if kind == 'cladding':
        from ..drawing.cladding_sheet import schedule_sheet, surface_sheet

        fid, role, sid, page = name.rsplit('~', 3)
        return (
            surface_sheet(job, fid, sid)
            if role == 'cladding'
            else schedule_sheet(job, fid, role, int(page), sid or None)
        )
    if kind == 'endjoint':
        from ..drawing.endwall_joint_sheet import sheet as joint_sheet

        fid, end = name.rsplit('~', 1)
        return joint_sheet(job, fid, end)
    if kind in ('endwall', 'endcuts'):
        from ..drawing.endwall_sheet import cut_sheet as end_cut_sheet
        from ..drawing.endwall_sheet import endwall_sheet

        if kind == 'endwall':
            fid, end = name.rsplit('~', 1)
            return endwall_sheet(job, fid, end)
        fid, end, page = name.rsplit('~', 2)
        return end_cut_sheet(job, fid, end, int(page))
    if kind in ('runs', 'run_cuts'):
        from ..drawing.run_sheet import cut_sheet as run_cut_sheet
        from ..drawing.run_sheet import run_sheet

        return run_sheet(job, name) if kind == 'runs' else run_cut_sheet(job, name)
    if kind == 'secondaries':
        from ..drawing.secondary_sheet import secondary_sheet

        return secondary_sheet(job, name)
    if kind == 'welded_eave':
        from ..drawing.welded_sheet import eave_sheet

        return eave_sheet(job, name)
    if kind == 'ridge':
        from ..drawing.ridge_sheet import ridge_sheet

        return ridge_sheet(job, name)
    if kind == 'frame':
        from ..drawing.frame_sheet import frame_sheet

        return frame_sheet(job, name)
    if kind == 'frameline':
        from ..drawing.frameline_sheets import frameline_sheet

        fid, index = name.rsplit('~', 1)
        return frameline_sheet(job, fid, int(index))
    if kind == 'sidewall':
        from ..drawing.frameline_sheets import sidewall_sheet

        fid, side = name.rsplit('~', 1)
        return sidewall_sheet(job, fid, side)
    if kind == 'roofplan':
        from ..drawing.frameline_sheets import roof_plan_sheet

        return roof_plan_sheet(job, name)
    if kind == "connection":
        from ..drawing.connection_sheet import connection_sheet

        return connection_sheet(job, job.part(name), int(job.settings['connections'][name]['qty']))
    if kind == "assembly":
        return assembly_sheet(job, job.assemblies[name], issues)
    mains, parts = usage(job)
    if kind == "cut":
        for a in job.assemblies.values():
            if a.main.mark == name:
                return cut_sheet(job, a, mains[name])
        raise KeyError(name)
    if kind == "plate":
        from ..drawing.sheet import drawing_part_quantities

        return plate_sheet(job, job.part(name), drawing_part_quantities(job, parts).get(name, 0))
    raise KeyError(kind)


def release_summary(job: M.Job) -> dict:
    """The release check in one line for the editor banner: status + the first blockers."""
    try:
        from ..release_checks import report

        rep = report(job)
    except Exception as e:  # the banner must never take the editor down
        return {"status": "RELEASE CHECK UNAVAILABLE", "complete": False, "count": 0, "items": [str(e)[:200]]}
    items = []
    for b in rep.get("blockers", []):
        text = str(b.get("reason", ""))
        ref = str(b.get("reference", "") or "")
        line = (ref + ": " if ref and ref not in text else "") + text
        if line not in items:
            items.append(line)
    return {
        "status": rep["issue_status"],
        "complete": bool(rep.get("complete")),
        "count": int(rep.get("blocking_count", len(items))),
        "items": items[:8],
    }


def sheet_list(job: M.Job) -> list[dict]:
    out = [{"kind": "assembly", "name": a.mark, "title": f"{a.mark} {a.kind}"} for a in job.assemblies.values()]
    out += [
        dict(kind='building', name=k, title='BUILDING-' + k + ' master geometry')
        for k, v in job.settings.get('frame_layouts', {}).items()
        if v.get('building_geometry')
    ]
    out += [
        dict(kind='frame', name=k, title='FRAME-' + k + ' ' + v['frame_type'] + ' elevation')
        for k, v in job.settings.get('frame_layouts', {}).items()
    ]
    from .. import frame_lines as FL

    for k, v in job.settings.get('frame_layouts', {}).items():
        # Frame-line family: one elevation per cross-frame line, both sidewall framing
        # elevations and the roof framing plan (interior bypass / end-wall flush roof datum).
        for rec in FL.lines(job, k):
            if not rec['framed']:
                continue
            out.append(
                dict(
                    kind='frameline',
                    name=k + '~' + str(rec['index']),
                    title='FRAME LINE %d/%d %s @ %s'
                    % (rec['index'], rec['count'], rec['label'].title(), FL._ft(rec['station_in'])),
                    line=rec['index'],
                    station_in=rec['station_in'],
                    line_kind=rec['kind'],
                )
            )
        out.append(dict(kind='sidewall', name=k + '~front', title='SIDEWALL-F-' + k + ' front sidewall framing'))
        out.append(dict(kind='sidewall', name=k + '~back', title='SIDEWALL-B-' + k + ' back sidewall framing'))
        out.append(dict(kind='roofplan', name=k, title='ROOF-PLAN-' + k + ' roof framing plan'))
    out += [
        dict(
            kind='ridge',
            name=k,
            title='RIDGE-'
            + k
            + (
                ' cut-and-fold ridge (one-piece rafter, standard)'
                if v.get('ridge_joint') == 'cut_and_fold'
                else ' apex / shared ridge plate'
            ),
        )
        for k, v in job.settings.get('frame_layouts', {}).items()
        if v.get('peak_clip')
    ]
    out += [
        dict(kind='welded_eave', name=k, title='EAVE-' + k + ' welded eave')
        for k, v in job.settings.get('frame_layouts', {}).items()
        if v.get('welded')
    ]
    out += [
        dict(kind='secondaries', name=a.mark, title='SECONDARIES-' + a.mark + ' supplier profiles')
        for a in job.assemblies.values()
        if a.derivation.get('secondary_catalog')
    ]
    out += [
        dict(kind=kind, name=a.mark, title=title + a.mark)
        for a in job.assemblies.values()
        if a.derivation.get('secondary_runs')
        for kind, title in [('runs', 'RUNS-'), ('run_cuts', 'RUN-CUTS-')]
    ]
    import math

    from ..drawing.order_sheet import descriptors as order_descriptors
    from ..ordering import build as order_plan

    out += [
        dict(kind='order', name=k + '~' + str(p), title='ORDER ' + k.replace('_', ' ') + ' ' + str(p))
        for k, p in order_descriptors(order_plan(job))
    ]
    from ..building import name as face_name

    for a in job.assemblies.values():
        if a.derivation.get('framing_additions'):
            from ..drawing.additions_sheet import descriptors as addition_descriptors

            out.extend(
                dict(
                    kind='additions',
                    name=a.mark + '~' + k + '~' + str(i) + '~' + str(p),
                    title='FRAMING ' + k + ' ' + str(i + 1) + ' / ' + str(p),
                )
                for k, i, p in addition_descriptors(a.derivation['framing_additions'])
            )
        if a.derivation.get('cladding'):
            from ..drawing.cladding_sheet import descriptors

            out.extend(
                dict(
                    kind='cladding',
                    name=a.mark + '~' + kind + '~' + sid + '~' + str(page),
                    title='PBR ' + kind + ' ' + face_name(sid) + ' ' + str(page),
                )
                for kind, sid, page in descriptors(a.derivation['cladding'])
            )
        for end, data in a.derivation.get('endwalls', {}).items():
            label = data.get('endwall_name') or face_name(
                end
            )  # zoned jobs: 'Inside wall (enclosed junction)', 'Outer left end (roof-only)'
            if data.get('ridge_face_clip'):
                out.append(dict(kind='endjoint', name=a.mark + '~' + end, title='END JOINTS ' + a.mark + ' ' + label))
            out.append(dict(kind='endwall', name=a.mark + '~' + end, title='ENDWALL-' + a.mark + ' ' + label))
            out.extend(
                dict(
                    kind='endcuts',
                    name=a.mark + '~' + end + '~' + str(page),
                    title='END-CUTS-' + a.mark + ' ' + label + ' ' + str(page),
                )
                for page in range(1, math.ceil(len(data['cuts']) / 18) + 1)
            )
    seen = set()
    for a in job.assemblies.values():
        if a.main.mark not in seen:
            seen.add(a.main.mark)
            out.append({"kind": "cut", "name": a.main.mark, "title": f"{a.main.mark} cut sheet"})
    _, parts = usage(job)
    from ..drawing.sheet import drawing_part_quantities

    parts = drawing_part_quantities(job, parts)
    for mark in parts:
        p = job.part(mark)
        if p.symbol.get("connection"):
            out.append({"kind": "connection", "name": mark, "title": mark + " connection weldment"})
        if p.kind in ("plate", "clip") and None not in (p.thk, p.width, p.length):
            out.append({"kind": "plate", "name": mark, "title": f"{mark} piece sheet"})
    return out


# ---- in-app output viewer -------------------------------------------------------
# Embedded previews (an <iframe> without allow-popups / allow-downloads) swallow target="_blank"
# links and downloads, so every output can also be VIEWED in the page: PDFs page by page as
# PNG, workbooks as tables, DXF via its SVG twin.  /api/view only re-dispatches an existing
# output route and converts the bytes; nothing is generated twice within one revision.
_VIEW_SRC = re.compile(r"^/api/(sheet/[^/?]+/[^/?]+\.(pdf|svg|dxf|png)|[\w\-/]+\.(pdf|xlsx|zip|txt))(\?.*)?$")
_VIEW_CACHE: dict = {}


def _view_cache_get(key):
    return _VIEW_CACHE.get(key)


def _view_cache_put(key, value):
    if len(_VIEW_CACHE) >= 8:
        _VIEW_CACHE.pop(next(iter(_VIEW_CACHE)))
    _VIEW_CACHE[key] = value


def _pdf_page_png(data: bytes, page: int, dpi: int) -> bytes:
    import pymupdf

    doc = pymupdf.open(stream=data, filetype="pdf")
    page = max(0, min(page, doc.page_count - 1))
    return doc[page].get_pixmap(dpi=dpi).tobytes("png")


def _view_manifest(src: str, data: bytes, ctype: str, filename: str | None) -> dict:
    out = {
        "src": src,
        "filename": filename or src.rsplit("/", 1)[-1].split("?")[0],
        "size": len(data),
        "content_type": ctype,
    }
    if ctype == "application/pdf":
        import pymupdf

        doc = pymupdf.open(stream=data, filetype="pdf")
        r = doc[0].rect if doc.page_count else None
        out.update(kind="pdf", pages=doc.page_count, page_size=[r.width, r.height] if r else None)
    elif ctype.endswith("spreadsheetml.sheet"):
        from openpyxl import load_workbook

        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        sheets = []
        for ws in wb.worksheets:
            rows = []
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i >= 400:
                    break
                rows.append(["" if v is None else (v.isoformat() if hasattr(v, "isoformat") else v) for v in row[:40]])
            sheets.append({"name": ws.title, "rows": rows, "truncated": ws.max_row > 400 or (ws.max_column or 0) > 40})
        out.update(kind="table", sheets=sheets)
    elif ctype.startswith("image/svg"):
        out.update(kind="svg", svg=data.decode("utf-8", "replace"))
    elif ctype == "application/dxf":
        out.update(kind="dxf", preview=re.sub(r"\.dxf(?=\?|$)", ".svg", src))
    elif ctype.startswith("image/"):
        out.update(kind="image")
    elif ctype in ("application/zip", "application/x-zip-compressed"):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos = z.infolist()
        out.update(
            kind="zip", entries=[{"name": i.filename, "size": i.file_size} for i in infos[:400]], count=len(infos)
        )
    elif ctype.startswith("text/"):
        out.update(kind="text", text=data[:100000].decode("utf-8", "replace"), truncated=len(data) > 100000)
    else:
        out.update(kind="binary")
    return out


def make_handler(store: JobStore):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=STATIC, **k)

        def log_message(self, fmt, *args):  # quiet
            pass

        _static_file = False

        def end_headers(self):
            if self._static_file:  # static js/css: always revalidate (304 when unchanged)
                self.send_header("Cache-Control", "no-cache")
            super().end_headers()

        # ---- helpers -----------------------------------------------------
        STALE_PAGE = (
            "This browser tab is showing an OLD copy of the editor page (kept by the browser from an "
            f"earlier version), but the editor that is running is v{VERSION}. Press Ctrl+F5 to reload the "
            "page (or close the tab and start the editor again). Your saved jobs are not affected."
        )

        def _stale_page(self) -> bool:
            """True when a browser page of another editor version is calling the API.

            Every fetch() from the current page carries ``X-Editor-Version``; browsers
            add ``Sec-Fetch-Mode: cors`` / ``same-origin`` to fetch() calls, so plain
            navigations, <img>/<embed> loads, scripts, curl and the tests (no
            Sec-Fetch headers) are never refused."""
            if self.headers.get("Sec-Fetch-Mode", "") not in ("cors", "same-origin"):
                return False
            return self.headers.get("X-Editor-Version", "") != VERSION

        def _json(self, obj, code=200):
            data = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def _bytes(self, data: bytes, ctype: str, filename: str | None = None):
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            if filename:
                self.send_header("Content-Disposition", f'inline; filename="{filename}"')
            self.end_headers()
            self.wfile.write(data)

        def _render_source(self, src: str):
            """Run an existing output route in-process and return (bytes, content type, filename)."""
            key = (src, store.job.revision())
            hit = _view_cache_get(key)
            if hit:
                return hit
            captured: dict = {}
            saved = self.path
            self.path = src
            self._bytes = lambda data, ctype, filename=None: captured.update(data=data, ctype=ctype, filename=filename)
            self._json = lambda obj, code=200: captured.update(
                error=(obj.get("error") if isinstance(obj, dict) else str(obj)) or f"HTTP {code}"
            )
            try:
                self.do_GET()
            finally:
                self.path = saved
                del self._bytes
                del self._json
            if "data" not in captured:
                raise ValueError(captured.get("error") or "no output produced")
            value = (captured["data"], captured["ctype"], captured["filename"])
            _view_cache_put(key, value)
            return value

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(n) or b"{}")

        def _catalog(self, job: M.Job | None = None) -> dict:
            """Static libraries: identical for every job and every revision.

            Served once by GET /api/catalog and cached by the browser, instead of
            being re-serialised (~290 KB) inside every autosave response.  Only the
            job-dependent entries (``rafter_sections`` follows the supplier policy)
            stay inside ``_state``."""
            from ..cladding import catalog as cladding_catalog
            from ..endwalls import rules as end_rules
            from ..plate_rules import EVIDENCE
            from ..secondary_catalog import catalog as secondary_catalog
            from ..secondary_runs import evidence as run_evidence

            return {
                "product_libraries": __import__("mbdp.detail.supplier_products", fromlist=["libraries"]).libraries(),
                "plate_rule_evidence": EVIDENCE,
                "catalog": {
                    "cladding": cladding_catalog("all"),
                    "endwall_rules": end_rules(),
                    "run_patterns": run_evidence(),
                    "secondary": {
                        **secondary_catalog(),
                        "profiles": _shop_product_order(secondary_catalog()["profiles"]),
                    },
                    "sections": _shop_section_order(sections.SECTIONS),
                    "column_sections": _shop_section_order(
                        list(sections.SECTIONS) + __import__("mbdp.detail.tube_sections", fromlist=["names"]).names()
                    ),
                    "tube_sections": _shop_section_order(
                        __import__("mbdp.detail.tube_sections", fromlist=["names"]).names()
                    ),
                    "eave_references": [__import__("mbdp.detail.eave_reference", fromlist=["get"]).get()],
                    "faces": list(M.FACES),
                    "sides": list(M.SIDES),
                    "part_kinds": list(M.PART_KINDS),
                    "assembly_kinds": list(M.ASSEMBLY_KINDS),
                    # shop standard the wizard pre-fills for a new frame (per supplier policy)
                    "supplier_defaults": {"sss": SSS_STANDARD, "mbci": MBCI_STANDARD},
                    # shop layout rules (girts, purlins, end-wall posts, doors) - standards.layout_rules
                    "layout_rules": __import__("mbdp.detail.standards", fromlist=["layout_rules"]).layout_rules(),
                    "samples": store.sample_rows()
                    + [
                        dict(
                            job_no=LEGACY_SAMPLE_JOB_NO,
                            building="Clark Jordan reference (hand-modelled)",
                            description="The re-modelled Clark Jordan job used by the regression tests.",
                        )
                    ],
                },
            }

        def _state(self, job: M.Job | None = None, full: bool | None = None) -> dict:
            """Job state.  ``full`` controls whether the static catalog is embedded.

            Defaults to the request's ``?full=1`` query flag (the browser asks for
            the full payload once on load, then merges its cached catalog)."""
            if full is None:
                from urllib.parse import parse_qs

                full = parse_qs(urlparse(self.path).query).get("full", ["0"])[0] == "1"
            job = job or store.job
            issues = M.validate(job)
            from ..connections import connection_bom

            connection_rows = {}
            for mark in job.settings.get('connections', {}):
                lines = connection_bom(job, mark)
                connection_rows[mark] = [
                    {
                        "part": l.part,
                        "qty": l.qty,
                        "description": l.description,
                        "weight": M.fmt_weight(l.total, l.kind),
                    }
                    for l in lines
                ]
                connection_rows[mark].append(
                    {
                        "part": "TOTAL",
                        "qty": "",
                        "description": "weldment only; loose mates separate",
                        "weight": str(M.total_weight(lines)),
                    }
                )
            from ..plate_rules import rules

            # Job-dependent catalog entry: the rafter list follows the supplier policy.
            dynamic_catalog = {
                "rafter_sections": _shop_section_order(
                    list(sections.SECTIONS)
                    + [
                        n
                        for n in sections.channel_names()
                        if n.startswith("SSS-")
                        == (
                            job.settings.get("product_suppliers", {}).get(
                                "secondaries", job.settings.get("product_suppliers", {}).get("primary", "sss")
                            )
                            == "sss"
                        )
                    ]
                )
            }
            state = {
                "plate_rules": rules(job),
                "job": job.to_json(),
                "issues": __import__("mbdp.detail.diagnostics", fromlist=["enrich"]).enrich(job, issues),
                "revision": job.revision(),
                "blocked": M.has_errors(issues),
                "release": release_summary(job),
                "sheets": sheet_list(job),
                "catalog": dynamic_catalog,
                "catalog_partial": not full,  # browser merges GET /api/catalog when true
                "bom": {
                    **connection_rows,
                    **{
                        a.mark: [
                            {
                                "part": l.part,
                                "qty": l.qty,
                                "description": l.description,
                                "weight": M.fmt_weight(l.total, l.kind),
                            }
                            for l in M.bom(job, a)
                        ]
                        + [
                            {
                                "part": "TOTAL",
                                "qty": "",
                                "description": "",
                                "weight": M.fmt_weight(M.total_weight(M.bom(job, a)), "main"),
                            }
                        ]
                        for a in job.assemblies.values()
                        if _bom_ok(job, a)
                    },
                },
            }
            if full:
                static = self._catalog(job)
                state["product_libraries"] = static["product_libraries"]
                state["plate_rule_evidence"] = static["plate_rule_evidence"]
                state["catalog"] = {**static["catalog"], **dynamic_catalog}
                state["catalog_partial"] = False
            return state

        # ---- GET -----------------------------------------------------------
        def do_GET(self):
            u = urlparse(self.path)
            path = unquote(u.path)
            try:
                if path == "/api/view":
                    from urllib.parse import parse_qs

                    q = parse_qs(u.query)
                    src = q.get("src", [""])[0]
                    if not _VIEW_SRC.match(src):
                        return self._json({"error": "src must be an existing /api output path"}, 400)
                    data, ctype, filename = self._render_source(src)
                    if q.get("as", ["manifest"])[0] == "page":
                        if ctype != "application/pdf":
                            return self._json({"error": "pages exist for PDF outputs only"}, 400)
                        dpi = max(40, min(220, int(q.get("dpi", ["110"])[0])))
                        return self._bytes(_pdf_page_png(data, int(q.get("page", ["0"])[0]), dpi), "image/png")
                    return self._json(_view_manifest(src, data, ctype, filename))
                if path == '/api/issue-report.pdf':
                    from ..diagnostics import report_sheets

                    with store.lock:
                        job = M.Job.loads(store.job.dumps())
                    with tempfile.TemporaryDirectory() as td:
                        file = os.path.join(td, 'issue-review.pdf')
                        render_pdf(report_sheets(job), file)
                        return self._bytes(open(file, 'rb').read(), 'application/pdf', 'issue-review.pdf')
                if path in ('/api/release-report', '/api/release-report.pdf'):
                    from ..release_checks import report
                    from ..release_checks import sheets as release_sheets

                    rep = report(store.job)
                    if path.endswith('.pdf'):
                        with tempfile.TemporaryDirectory() as td:
                            file = os.path.join(td, 'release_checks.pdf')
                            render_pdf(release_sheets(store.job, rep), file)
                            return self._bytes(open(file, 'rb').read(), 'application/pdf', 'release_checks.pdf')
                    return self._json(rep)
                if path in ('/api/order', '/api/material-list', '/api/master-order.xlsx', '/api/master-order.pdf'):
                    from ..ordering import build as order_plan

                    plan = order_plan(store.job)
                    if path == '/api/order':
                        return self._json(plan)
                    if path == '/api/material-list':
                        from ..pricing import material_list

                        return self._json(material_list(store.job, plan))
                    with tempfile.TemporaryDirectory() as td:
                        if path.endswith('.xlsx'):
                            from ..order_workbook import write_workbook

                            file = write_workbook(store.job, os.path.join(td, 'master_order.xlsx'), plan)
                            return self._bytes(
                                open(file, 'rb').read(),
                                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                'master_order.xlsx',
                            )
                        from ..drawing.order_sheet import all_order_sheets

                        file = os.path.join(td, 'master_order.pdf')
                        render_pdf(all_order_sheets(store.job, plan), file)
                        return self._bytes(open(file, 'rb').read(), 'application/pdf', 'master_order.pdf')
                if path == '/api/sss-alternate-rfq.xlsx':
                    from ..sss_catalog import quote_workbook

                    with store.lock:
                        job = M.Job.loads(store.job.dumps())
                    with tempfile.TemporaryDirectory() as td:
                        file = quote_workbook(job, os.path.join(td, 'sss-rfq.xlsx'))
                        return self._bytes(
                            open(file, 'rb').read(),
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'SSS-alternate-RFQ.xlsx',
                        )
                if path in ('/api/supplier-catalog', '/api/supplier-catalog.xlsx', '/api/supplier-reference.pdf'):
                    from ..supplier_catalog import catalog, write_workbook

                    if path == '/api/supplier-catalog':
                        return self._json(catalog())
                    if path.endswith('.pdf'):
                        from pathlib import Path

                        return self._bytes(
                            (Path(__file__).parent.parent / 'data/sss-supplier-reference.pdf').read_bytes(),
                            'application/pdf',
                            'SSS-supplier-reference.pdf',
                        )
                    with tempfile.TemporaryDirectory() as td:
                        file = write_workbook(os.path.join(td, 'supplier-catalog.xlsx'))
                        return self._bytes(
                            open(file, 'rb').read(),
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'SSS-supplier-catalog.xlsx',
                        )
                if path == '/api/sss-catalog':
                    from ..sss_catalog import catalog

                    data = catalog()
                    from ..supplier_catalog import catalog as products

                    data['product_catalog'] = products()
                    return self._json(data)
                if path in ('/api/customer-elevations.pdf', '/api/main-roof-purlins.pdf'):
                    from urllib.parse import parse_qs

                    from ..drawing.customer_elevations import sheets as exterior
                    from ..drawing.main_roof_sheet import sheets as roof_sheets

                    with store.lock:
                        job = M.Job.loads(store.job.dumps())
                    result = []
                    for fid in job.settings.get('frames', {}):
                        result += (
                            exterior(job, fid, parse_qs(u.query).get('lean_rake', ['model'])[0])
                            if path == '/api/customer-elevations.pdf'
                            else roof_sheets(job, fid)
                        )
                    if not result:
                        raise ValueError('No supported building model for this drawing')
                    with tempfile.TemporaryDirectory() as td:
                        file = os.path.join(td, 'views.pdf')
                        render_pdf(result, file)
                        return self._bytes(open(file, 'rb').read(), 'application/pdf', path.rsplit('/', 1)[-1])
                if path.startswith('/api/print/') or path == '/api/print-packages.zip':
                    from ..drawing.print_packets import export_packets, packet
                    from ..order_workbook import write_workbook
                    from ..purchasing import supplier_plan, write_supplier_workbook

                    with store.lock:
                        job = M.Job.loads(store.job.dumps())
                    name = path.rsplit('/', 1)[-1]
                    details_dir = os.path.join(store.dir, 'details')
                    with tempfile.TemporaryDirectory() as td:
                        if path == '/api/print-packages.zip':
                            export_packets(job, td, details_dir=details_dir)
                            buf = io.BytesIO()
                            with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
                                for fn in sorted(os.listdir(td)):
                                    z.write(os.path.join(td, fn), fn)
                            return self._bytes(buf.getvalue(), 'application/zip', 'Print-packages.zip')
                        if name == 'supplier.json':
                            return self._json(supplier_plan(job))
                        file = os.path.join(td, name)
                        if name == 'supplier.xlsx':
                            write_supplier_workbook(job, file)
                        elif name == 'pricing.xlsx':
                            from ..pricing_workbook import write_pricing_workbook

                            write_pricing_workbook(job, file)
                        elif name == 'shop.xlsx':
                            write_workbook(job, file)
                        elif name in ('supplier.pdf', 'shop.pdf', 'erection.pdf'):
                            render_pdf(packet(job, name.split('.')[0], details_dir=details_dir)[0], file)
                            if name == 'erection.pdf':
                                from ..drawing.packages import append_details

                                append_details(file, details_dir)
                        else:
                            raise ValueError('Unknown print package')
                        return self._bytes(
                            open(file, 'rb').read(),
                            'application/pdf'
                            if name.endswith('.pdf')
                            else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            name,
                        )
                if path == "/api/job-file.txt":
                    with store.lock:
                        data = store.job.dumps().encode("utf-8")
                    return self._bytes(data, "text/plain; charset=utf-8", "job_json.txt")
                if path in ("/api/jobs", "/api/job", "/api/catalog") and self._stale_page():
                    return self._json({"error": self.STALE_PAGE, "stale_page": True, "server_version": VERSION}, 409)
                if path == "/api/jobs":
                    return self._json({"jobs": store.list_jobs(), "open": store.filed_key})
                if path == "/api/jobs/next-number":
                    return self._json({"job_no": store.next_job_no()})
                if path == "/api/job/download":
                    from .job_library import library_key

                    with store.lock:
                        data = store.job.dumps().encode("utf-8")
                        name = f"Job-{library_key(store.job.job_no)}.json"
                    return self._bytes(data, "application/json", name)
                if path == "/api/jobs/file":
                    from urllib.parse import parse_qs

                    key = parse_qs(urlparse(self.path).query).get("key", [""])[0]
                    try:
                        text = store.read_entry(key)
                    except ValueError as e:
                        return self._json({"error": str(e)}, 400)
                    return self._bytes(text.encode("utf-8"), "application/json", f"Job-{key}.json")
                if path == "/api/job":
                    return self._json(self._state())
                if path == "/api/catalog":
                    return self._json(self._catalog())
                if path == "/api/plate-catalog":
                    from ..plate_rules import catalog_rows

                    return self._json(catalog_rows(store.job))
                if path == "/api/sheets":
                    return self._json(sheet_list(store.job))
                if path == "/api/drawings.pdf":
                    job = store.job
                    sheets = all_sheets(job, M.validate(job))
                    tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False).name
                    render_pdf(sheets, tmp, f"Job {job.job_no}")
                    data = open(tmp, "rb").read()
                    os.unlink(tmp)
                    return self._bytes(data, "application/pdf", f"{job.job_no}_shop_drawings.pdf")
                if path == "/api/export.zip":
                    job = store.job
                    d = tempfile.mkdtemp()
                    try:
                        export_package(job, d)
                        buf = io.BytesIO()
                        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
                            for root, _, files in os.walk(d):
                                for fn in files:
                                    full = os.path.join(root, fn)
                                    z.write(full, os.path.relpath(full, d))
                    finally:
                        shutil.rmtree(d, ignore_errors=True)
                    return self._bytes(buf.getvalue(), "application/zip", f"{job.job_no}_package.zip")
                if path.startswith("/api/contour/"):
                    from .. import contours

                    fname = path.rsplit("/", 1)[1]
                    name, ext = os.path.splitext(fname)
                    part = store.job.part(name)
                    if part.kind not in ("plate", "clip"):
                        raise ValueError("Select a plate")
                    from urllib.parse import parse_qs

                    units = parse_qs(u.query).get("units", ["inch"])[0]
                    if ext == ".svg":
                        return self._bytes(
                            contours.svg(part, units).encode(), "image/svg+xml", name + "." + units + ".review.svg"
                        )
                    if ext == ".json":
                        return self._json(contours.report(store.job, part))
                    if ext == ".dxf":
                        with tempfile.TemporaryDirectory() as td:
                            pathout = contours.dxf(part, os.path.join(td, "part.dxf"), units)
                            return self._bytes(
                                open(pathout, "rb").read(), "application/dxf", name + "." + units + ".review.dxf"
                            )
                    return self._json(
                        {"error": "Choose DXF, SVG or JSON; G-code requires the actual machine/controller."}, 400
                    )
                if path.startswith("/api/sheet/") or path.startswith("/api/preview/"):
                    parts = path.split("/")
                    kind, fname = parts[3], parts[4]
                    name, ext = os.path.splitext(fname)
                    job = store.job
                    sh = sheet_for(job, kind, name, M.validate(job))
                    if ext == ".svg":
                        return self._bytes(render_svg(sh).encode(), "image/svg+xml", f"{sh.name}.svg")
                    if ext == ".pdf":
                        tmp = tempfile.NamedTemporaryFile(suffix=".pdf", delete=False).name
                        render_pdf([sh], tmp, sh.name)
                        data = open(tmp, "rb").read()
                        os.unlink(tmp)
                        return self._bytes(data, "application/pdf", f"{sh.name}.pdf")
                    if ext == ".dxf":
                        tmp = tempfile.NamedTemporaryFile(suffix=".dxf", delete=False).name
                        render_dxf(sh, tmp)
                        data = open(tmp, "rb").read()
                        os.unlink(tmp)
                        return self._bytes(data, "application/dxf", f"{sh.name}.dxf")
                    if ext == ".png":
                        tmp = tempfile.NamedTemporaryFile(suffix=".png", delete=False).name
                        render_png([sh], tmp, dpi=110)
                        data = open(tmp, "rb").read()
                        os.unlink(tmp)
                        return self._bytes(data, "image/png")
                    return self._json({"error": "unknown format"}, 404)
                if path in ("/", "/index.html"):
                    # The page itself is never cached and every script/style link carries a stamp
                    # derived from the static files' mtimes, so an edited app.js / settings_stepper.js
                    # is picked up on a plain reload instead of being served stale for days.
                    html = open(os.path.join(STATIC, "index.html"), encoding="utf-8").read()
                    html = re.sub(r"\?v=[\w.\-]+", "?v=" + static_stamp(), html)
                    html = re.sub(r'(name="editor-version" content=")[^"]*', r"\g<1>" + VERSION, html)
                    html = re.sub(r"detailing editor v[\w.\-]+", "detailing editor v" + VERSION, html)
                    return self._bytes(html.encode("utf-8"), "text/html; charset=utf-8")
                self._static_file = True
                return super().do_GET()
            except KeyError as e:
                return self._json({"error": f"not found: {e}"}, 404)
            except Exception as e:  # surface generator errors to the UI instead of a blank page
                import traceback

                return self._json({"error": f"{type(e).__name__}: {e}", "trace": traceback.format_exc()}, 500)

        # ---- PUT / POST ----------------------------------------------------
        def do_PUT(self):
            u = urlparse(self.path)
            try:
                if self._stale_page():
                    return self._json({"error": self.STALE_PAGE, "stale_page": True, "server_version": VERSION}, 409)
                if u.path == "/api/job":
                    body = self._body()
                    base = body.get("base_revision")
                    if base:
                        # Optimistic lock: the client states the revision it edited from. Another
                        # window (or the job list) may have replaced the job since — refuse instead
                        # of silently overwriting it; the client offers to reload.
                        with store.lock:
                            current = store.job.revision()
                        if base != current:
                            return self._json(
                                {
                                    "error": "This job was changed elsewhere since you loaded it "
                                    f"(saved {current}, yours was from {base}). Reload to continue.",
                                    "conflict": True,
                                    "revision": current,
                                },
                                409,
                            )
                    job = M.Job.from_json(body.get("job", body))
                    from ..connections import rebuild
                    from ..frame import sync_frames

                    event = body.get("event", "edit")
                    notes = []
                    if event.startswith("open job file"):
                        # a file from an older installation: convert when the current rules reject it
                        from ..legacy_upgrade import open_or_upgrade

                        notes = open_or_upgrade(job)
                    else:
                        sync_frames(job)
                        rebuild(job)
                    filed_key = None
                    if body.get("library") == "replace" and event.startswith("open job file"):
                        from .job_library import library_key

                        filed_key = library_key(job.job_no)
                        store.retire_entry(filed_key)
                    store.replace(
                        job, event + (" (converted to the shop standard)" if notes else ""), filed_key=filed_key
                    )
                    st = self._state()
                    if notes:
                        st["upgraded"] = notes
                    return self._json(st)
                return self._json({"error": "unknown route"}, 404)
            except Exception as e:
                from ..diagnostics import rejected

                return self._json(
                    {"error": f"{type(e).__name__}: {e}", "diagnostic": rejected(str(e), u.path, locals().get("body"))},
                    400,
                )

        def do_POST(self):
            u = urlparse(self.path)
            try:
                if self._stale_page():
                    return self._json({"error": self.STALE_PAGE, "stale_page": True, "server_version": VERSION}, 409)
                if u.path in ('/api/supplier-products/preview', '/api/supplier-products/apply'):
                    from ..supplier_products import apply, plan

                    body = self._body()
                    with store.lock:
                        if body.get('revision') != store.job.revision():
                            raise ValueError('Job changed; reopen supplier product controls')
                        job = M.Job.loads(store.job.dumps())
                        if u.path.endswith('/preview'):
                            return self._json(plan(job, body.get('categories')))
                        job = apply(job, body.get('categories'), body.get('choices'))
                        store.replace(job, 'apply physical supplier products to all frames; regenerate model')
                    return self._json(self._state())
                if u.path in ('/api/sourcing', '/api/sourcing-preview'):
                    from ..ordering import build
                    from ..supplier_catalog import config

                    body = self._body()
                    if store.job.settings.get('frames') and (
                        store.job.settings.get('product_suppliers')
                        or body.get('sourcing', {}).get('primary')
                        != store.job.settings.get('sourcing', {}).get('primary', 'sss')
                    ):
                        raise ValueError(
                            'Supplier changes must use Supplier PRODUCTS / category overrides; label-only conversion is disabled'
                        )
                    with store.lock:
                        if body.get('revision') != store.job.revision():
                            raise ValueError('Job changed; reopen supplier settings before saving')
                        job = M.Job.loads(store.job.dumps())
                        job.settings['sourcing'] = config(body.get('sourcing'))
                        plan = build(job)
                        if u.path == '/api/sourcing-preview':
                            return self._json(plan)
                        store.replace(job, 'supplier selection / mixed sourcing (no geometry change)')
                    return self._json(self._state())
                if u.path == '/api/order-preview':
                    from ..ordering import apply_options
                    from ..ordering import build as order_plan

                    body = self._body()
                    if body.get('revision') != store.job.revision():
                        raise ValueError('Job changed; reopen Material optimizer')
                    with store.lock:
                        job = M.Job.loads(store.job.dumps())
                    return self._json(order_plan(apply_options(job, body['settings'])))
                if u.path == '/api/material-list':
                    from ..pricing import normalize as normalize_pricing

                    body = self._body()
                    if body.get('revision') and body['revision'] != store.job.revision():
                        raise ValueError('Job changed: reopen the price book before saving')
                    job = store.job
                    job.settings['material_list'] = normalize_pricing(body.get('settings', body))
                    store.replace(job, 'update price book / material list')
                    return self._json(self._state())
                if u.path == '/api/order-options':
                    from ..ordering import apply_options

                    body = self._body()
                    if body.get('revision') and body['revision'] != store.job.revision():
                        raise ValueError('Job changed: reopen order settings before saving')
                    job = apply_options(store.job, body.get('settings', body))
                    store.replace(job, 'update stock / custom ordering rules')
                    return self._json(self._state())
                if u.path == "/api/job/sample":
                    body = self._body()
                    store.open_sample(str(body.get("which", "")))
                    if body.get("customize"):
                        store.customize_geometry(body["customize"])
                    return self._json(self._state())
                if u.path == "/api/job/recover":
                    folder = os.path.join(store.dir, "recovery")
                    paths = sorted(os.listdir(folder)) if os.path.isdir(folder) else []
                    paths = [p for p in paths if p.endswith(".json")]
                    if not paths:
                        raise ValueError("No previous nonempty job is available for recovery")
                    with open(os.path.join(folder, paths[-1])) as fh:
                        job = M.Job.loads(fh.read())
                    store.replace(job, "recover previous job")
                    return self._json(self._state())
                if u.path == "/api/jobs/open":
                    notes = store.open_job(str(self._body().get("key", "")))
                    st = self._state()
                    st["upgraded"] = notes
                    return self._json(st)
                if u.path == "/api/job/upgrade":
                    # Job ▾ → Convert to shop standard (SSS): explicit conversion of the open job
                    from ..connections import rebuild
                    from ..frame import sync_frames
                    from ..legacy_upgrade import upgrade

                    with store.lock:
                        job = M.Job.loads(store.job.dumps())
                    notes = upgrade(job)
                    sync_frames(job)
                    rebuild(job)
                    if notes:
                        store.replace(job, "convert to shop standard (SSS): " + "; ".join(notes)[:300])
                    st = self._state()
                    st["upgraded"] = notes or ["Nothing to change - the job already follows the current shop standard."]
                    return self._json(st)
                if u.path == "/api/jobs/delete":
                    store.delete_job(str(self._body().get("key", "")))
                    return self._json({"jobs": store.list_jobs(), "open": store.filed_key})
                if u.path == "/api/jobs/duplicate":
                    body = self._body()
                    store.duplicate_job(str(body.get("job_no", "") or store.next_job_no()), body.get("customer"))
                    return self._json(self._state())
                if u.path == "/api/jobs/add":
                    # Add saved job files to the list without opening them (several at once).
                    body = self._body()
                    items = body.get("jobs") if isinstance(body.get("jobs"), list) else [body.get("job", body)]
                    results = []
                    for i, item in enumerate(items):
                        d = item.get("job") if isinstance(item, dict) and isinstance(item.get("job"), dict) else item
                        name = (item.get("name") if isinstance(item, dict) else None) or f"file {i + 1}"
                        try:
                            results.append(store.file_job(d, source=name))
                        except Exception as e:
                            results.append(
                                dict(
                                    status="rejected",
                                    key=None,
                                    job_no=(d or {}).get("job_no"),
                                    source=name,
                                    error=str(e)[:200],
                                )
                            )
                    return self._json({"results": results, "jobs": store.list_jobs(), "open": store.filed_key})
                if u.path == "/api/jobs/import-folder":
                    summary = store.import_folder(self._body().get("path", ""))
                    summary.update(jobs=store.list_jobs(), open=store.filed_key)
                    return self._json(summary)
                if u.path == "/api/job/new":
                    body = self._body()
                    job_no = str(body.get("job_no") or "").strip() or store.next_job_no()
                    start_from = str(body.get("start_from") or "").strip()
                    if start_from:
                        # starting option: the job begins as a copy of a standard sample
                        # (carport / roof only / three-sided / enclosed) under its own number
                        from ..samples import sample_job as build_sample

                        job = build_sample(start_from, job_no)
                        job.customer = body.get("customer", "")
                        job.building = body.get("building", "Main Bldg.")
                        job.date = body.get("date", "")
                        job.settings.pop("sample", None)
                        store.replace(job, f"new job from the {start_from} starting option")
                        return self._json(self._state())
                    job = M.Job(
                        job_no=job_no,
                        customer=body.get("customer", ""),
                        building=body.get("building", "Main Bldg."),
                        date=body.get("date", ""),
                        parts=standard_parts(),
                    )
                    job.settings.update(job_settings())
                    store.replace(job, "new job")
                    return self._json(self._state())
                if u.path == "/api/connection/delete":
                    body = self._body()
                    mark = body["mark"]
                    job = M.Job.from_json(store.job.to_json())
                    if mark not in job.settings.get("connections", {}):
                        raise ValueError("Unknown connection")
                    if job.settings["connections"][mark].get("installed"):
                        raise ValueError("This connection belongs to a managed frame; it cannot be deleted separately")
                    owned = {k for k, p in job.parts.items() if p.symbol.get("owner") == mark} | {mark}
                    if any(t.part in owned for a in job.assemblies.values() for t in a.attachments):
                        raise ValueError(
                            "Remove this connection's attachments from member assemblies before deleting it"
                        )
                    del job.settings["connections"][mark]
                    for k in owned:
                        job.parts.pop(k, None)
                    store.replace(job, "delete connection " + mark)
                    return self._json(self._state())
                if u.path == "/api/connection":
                    from ..connections import build

                    body = self._body()
                    job = M.Job.from_json(store.job.to_json())
                    if job.settings.get("connections", {}).get(body["mark"], {}).get("installed") or body.get(
                        "installed"
                    ):
                        raise ValueError("Use Edit frame geometry for frame-managed connections")
                    part = build(job, body["mark"], body)
                    store.replace(job, "generate connection " + part.mark)
                    st = self._state()
                    st["generated"] = [part.mark]
                    return self._json(st)
                if u.path == "/api/plate-rules":
                    from ..plate_rules import refresh, validate_rules

                    body = self._body()
                    job = M.Job.loads(store.job.dumps())
                    job.settings['plate_rules'] = validate_rules(body.get('rules', body))
                    refresh(job)
                    store.replace(job, "edit member-driven plate rules; regenerate linked geometry")
                    return self._json(self._state())
                if u.path == "/api/building-geometry":
                    body = self._body()
                    if body.get('revision') != store.job.revision():
                        raise ValueError('Job changed; reload geometry controls')
                    fid = body['frame_id']
                    job = M.Job.loads(store.job.dumps())
                    raw = dict(job.settings['frames'][fid])
                    raw.update(
                        {
                            k: v
                            for k, v in body['geometry'].items()
                            if k in ('width', 'length', 'eave_height', 'slope_rise')
                        }
                    )
                    generate_frame(job, FrameParams.from_json(raw))
                    store.replace(job, 'main-editor master dimensions')
                    return self._json(self._state())
                if u.path == "/api/framing-additions":
                    body = self._body()
                    if body.get('revision') != store.job.revision():
                        raise ValueError('Job changed; reopen framing additions')
                    fid = body['frame_id']
                    job = M.Job.loads(store.job.dumps())
                    params = FrameParams.from_json(job.settings['frames'][fid])
                    params.additions = body['additions']
                    generate_frame(job, params)
                    store.replace(job, 'framing additions / opening clearance')
                    return self._json(self._state())
                if u.path == '/api/grades':
                    # column grades (v0.8.43): the separate box - grade per column, cut lengths follow
                    body = self._body()
                    if body.get('revision') != store.job.revision():
                        raise ValueError('Job changed; reopen Column grades')
                    fid = body['frame_id']
                    job = M.Job.loads(store.job.dumps())
                    params = FrameParams.from_json(job.settings['frames'][fid])
                    from ..grades import normalize as normalize_grades

                    params.grades = normalize_grades(body.get('grades') or {})
                    generate_frame(job, params)
                    store.replace(job, 'column grades')
                    return self._json(self._state())
                if u.path == '/api/end-rafters':
                    body = self._body()
                    if body.get('revision') != store.job.revision():
                        raise ValueError('Job changed; reopen End rafters')
                    job = M.Job.loads(store.job.dumps())
                    fid = body['frame_id']
                    params = FrameParams.from_json(job.settings['frames'][fid])
                    if not params.endwalls.get('enabled'):
                        raise ValueError(
                            'Enable separate endwall framing in Full frame settings first; end support layout must be explicit.'
                        )
                    edits = body.get('ends')
                    if (
                        not isinstance(edits, dict)
                        or not edits
                        or not {'front_end', 'rear_end'} <= set(edits)
                        or not set(edits) <= {'front_end', 'rear_end', 'outer_front_end'}
                    ):
                        raise ValueError('End records for both end walls are required')
                    for end, r in edits.items():
                        if not set(r) <= {'rafter_override', 'roof_mode', 'post_head', 'post_head_overrides'}:
                            raise ValueError('End shortcut edits only rafter section, roof mode and corner connections')
                        if r.get('post_head_overrides') is not None and not isinstance(r['post_head_overrides'], dict):
                            raise ValueError('Per-location corner connections must be a mark-to-mode object')
                        if r.get('post_head_overrides') and any(
                            mode not in ('legacy', 'direct_welded', 'side_welded')
                            for mode in r['post_head_overrides'].values()
                        ):
                            raise ValueError('Per-location corner connection must be seat / direct weld / inside face')
                        if r.get('post_head') is not None and r['post_head'] not in (
                            'legacy',
                            'direct_welded',
                            'side_welded',
                        ):
                            raise ValueError('End corner seat must be seat / direct weld / inside face')
                        old = params.endwalls[end]
                        if r['rafter_override'] != old.get('rafter_override') and not old.get('column_override'):
                            old['column_override'] = old['resolved_column']
                        old.update(r)
                    generate_frame(job, params)
                    store.replace(job, 'independent end rafters / roof modes')
                    return self._json(self._state())
                if u.path == "/api/frame":
                    body = self._body()
                    if body.get("revision") and body["revision"] != store.job.revision():
                        raise ValueError("Job changed; reopen frame settings")
                    params = FrameParams.from_json(body)
                    job = M.Job.from_json(store.job.to_json())  # work on a copy; commit only if it generates
                    if "sourcing" in body:
                        from ..supplier_catalog import config

                        job.settings["sourcing"] = config(body["sourcing"])
                    made = generate_frame(job, params)
                    store.replace(job, f"rigid-frame wizard: {', '.join(a.mark for a in made)}")
                    st = self._state()
                    st["generated"] = [a.mark for a in made]
                    return self._json(st)
                if u.path == "/api/validate":
                    body = self._body()
                    job = M.Job.from_json(body.get("job", body))
                    return self._json({"issues": [i.to_json() for i in M.validate(job)]})
                return self._json({"error": "unknown route"}, 404)
            except Exception as e:
                from ..diagnostics import rejected

                return self._json(
                    {"error": f"{type(e).__name__}: {e}", "diagnostic": rejected(str(e), u.path, locals().get("body"))},
                    400,
                )

    return Handler


def _bom_ok(job: M.Job, a: M.Assembly) -> bool:
    try:
        M.bom(job, a)
        return True
    except Exception:
        return False


def serve(workspace: str, port: int = 8010, host: str = "0.0.0.0", seed: str = "blank") -> None:
    mimetypes.add_type("image/svg+xml", ".svg")
    store = JobStore(workspace, seed=seed, samples=True)
    httpd = ThreadingHTTPServer((host, port), make_handler(store))
    print(f"editor: http://{host}:{port}/  workspace={workspace}  job={store.job.job_no}", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser()
    ap.add_argument("--workspace", default="data/editor")
    ap.add_argument("--port", type=int, default=8010)
    a = ap.parse_args()
    serve(a.workspace, a.port)
