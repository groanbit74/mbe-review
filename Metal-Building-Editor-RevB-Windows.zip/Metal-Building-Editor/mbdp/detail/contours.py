"""Unit-explicit CAM exchange contours, not a machine postprocessor.

The same rational-derived vertices drive the web detail, DXF, SVG and coordinate
report. No kerf, lead-ins, feed, pierce height, torch commands or G-code are guessed.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from xml.sax.saxutils import escape

import ezdxf

from .connections import contour, f


def area(pts):
    return sum(x * v - u * y for (x, y), (u, v) in zip(pts, pts[1:] + pts[:1])) / 2


def cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def distance_to_segment(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    t = max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy)))
    return math.hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dy)


def inside(p, pts):
    x, y = p
    result = False
    for a, b in zip(pts, pts[1:] + pts[:1]):
        if (a[1] > y) != (b[1] > y) and x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]:
            result = not result
    return result


def validate_contour(p):
    pts = contour(p)
    n = len(pts)
    if n < 3 or any(not math.isfinite(v) for pt in pts for v in pt):
        raise ValueError('Invalid contour vertices')
    if abs(area(pts)) < 1e-8:
        raise ValueError('Contour has zero area')
    edges = list(zip(pts, pts[1:] + pts[:1]))
    for i, (a, b) in enumerate(edges):
        if math.dist(a, b) < 1e-7:
            raise ValueError('Duplicate/zero-length contour edge')
        for k, (c, d) in enumerate(edges):
            if k <= i or k in ((i + 1) % n, (i - 1) % n):
                continue
            if cross(a, b, c) * cross(a, b, d) < 0 and cross(c, d, a) * cross(c, d, b) < 0:
                raise ValueError('Self-intersecting contour')
            if (
                min(
                    distance_to_segment(c, a, b),
                    distance_to_segment(d, a, b),
                    distance_to_segment(a, c, d),
                    distance_to_segment(b, c, d),
                )
                < 1e-7
            ):
                raise ValueError('Touching or overlapping non-adjacent edges')
    holes = []
    for h in p.holes:
        center = (f(h.x), f(h.y))
        r = f(h.dia) / 2
        if r <= 0 or not inside(center, pts) or min(distance_to_segment(center, a, b) for a, b in edges) < r - 1e-7:
            raise ValueError('Hole runs outside plate contour')
        for c, rr in holes:
            if math.dist(center, c) < r + rr + 1e-7:
                raise ValueError('Overlapping/duplicate holes')
        holes.append((center, r))
    return pts


def dimensions(p):
    pts = validate_contour(p)
    orient = 1 if area(pts) > 0 else -1
    rows = []
    for i, b in enumerate(pts):
        a = pts[i - 1]
        c = pts[(i + 1) % len(pts)]
        dx, dy = c[0] - b[0], c[1] - b[1]
        incoming = (b[0] - a[0], b[1] - a[1])
        turn = math.degrees(math.atan2(incoming[0] * dy - incoming[1] * dx, incoming[0] * dx + incoming[1] * dy))
        rows.append(
            dict(
                vertex=f'P{i + 1}',
                x_in=b[0],
                y_in=b[1],
                edge_to=f'P{(i + 1) % len(pts) + 1}',
                dx_in=dx,
                dy_in=dy,
                length_in=math.hypot(dx, dy),
                direction_deg=math.degrees(math.atan2(dy, dx)) % 360,
                interior_deg=180 - orient * turn,
            )
        )
    return rows


def report(job, p):
    pts = validate_contour(p)
    return dict(
        part=p.mark,
        model_revision=job.revision(),
        status=str(job.settings.get('drawing_status', 'REVIEW')).upper(),
        interface_placement=p.symbol.get('interface_placement'),
        weld_leg=p.symbol.get('weld_size', ''),
        plate_rule_ref=p.symbol.get('plate_rule_ref', p.mark if p.symbol.get('plate_rule_generated') else ''),
        review_hold=p.symbol.get('review_hold', ''),
        units='inch',
        datum='lower-left finished contour bounding box; X right, Y up',
        precision_in=0.000001,
        stock_blank_in=[f(p.length), f(p.width)],
        thickness_in=f(p.thk),
        finished_bounds_in=[
            max(x for x, y in pts) - min(x for x, y in pts),
            max(y for x, y in pts) - min(y for x, y in pts),
        ],
        fit='tight; zero intentional clearance',
        bevel='none (plan-profile angles are not bevels)',
        kerf='not applied; set in CAM',
        gcode='not generated; machine/controller/process required',
        vertices=dimensions(p),
        holes=[dict(x_in=f(h.x), y_in=f(h.y), dia_in=f(h.dia)) for h in p.holes],
    )


def dxf(p, path, units='inch'):
    pts = validate_contour(p)
    if units not in ('inch', 'mm'):
        raise ValueError('Units must be inch or mm')
    scale = 1 if units == 'inch' else 25.4
    doc = ezdxf.new('R2013')
    doc.units = 1 if units == 'inch' else 4
    doc.header['$MEASUREMENT'] = 0 if units == 'inch' else 1
    doc.layers.new('CUT_OUTER')
    doc.layers.new('CUT_HOLES')
    doc.header['$PROJECTNAME'] = 'REVIEW ONLY - NO KERF - ' + p.mark
    m = doc.modelspace()
    m.add_lwpolyline([(x * scale, y * scale) for x, y in pts], close=True, dxfattribs={'layer': 'CUT_OUTER'})
    for h in p.holes:
        m.add_circle((f(h.x) * scale, f(h.y) * scale), f(h.dia) * scale / 2, dxfattribs={'layer': 'CUT_HOLES'})
    doc.saveas(path)
    return str(path)


def svg(p, units='inch'):
    pts = validate_contour(p)
    if units not in ('inch', 'mm'):
        raise ValueError('Units must be inch or mm')
    factor = 1 if units == 'inch' else 25.4
    suffix = 'in' if units == 'inch' else 'mm'
    pts = [(x * factor, y * factor) for x, y in pts]
    W = max(x for x, y in pts)
    H = max(y for x, y in pts)
    # Reflect Y once, about the finished height. Physical dimensions avoid the 96-DPI sizing trap.
    path = 'M ' + ' L '.join(f'{x:.8f},{H - y:.8f}' for x, y in pts) + ' Z'
    circles = ''.join(
        f'<circle cx="{f(h.x) * factor:.8f}" cy="{H - f(h.y) * factor:.8f}" r="{f(h.dia) * factor / 2:.8f}"/>'
        for h in p.holes
    )
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{W:.8f}{suffix}" height="{H:.8f}{suffix}" viewBox="0 0 {W:.8f} {H:.8f}">'
        f'<title>{escape(p.mark)} - REVIEW ONLY - verify scale in CAM</title>'
        '<desc>True-size contour. No kerf, lead-ins or machine instructions. No text is cutting geometry.</desc>'
        f'<g fill="none" stroke="black" stroke-width="{0.005 * factor:.8f}"><path id="CUT_OUTER" d="{path}"/>'
        f'<g id="CUT_HOLES">{circles}</g></g></svg>'
    )


def export(job, p, folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    files = []
    payload = report(job, p)
    for unit in ('inch', 'mm'):
        base = folder / f'{p.mark}.{unit}.review'
        files.append(dxf(p, str(base) + '.dxf', unit))
        sp = Path(str(base) + '.svg')
        sp.write_text(svg(p, unit), encoding='utf-8')
        files.append(str(sp))
    jp = folder / f'{p.mark}.geometry.json'
    jp.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    files.append(str(jp))
    cp = folder / f'{p.mark}.vertices.csv'
    with cp.open('w', newline='') as fh:
        rows = payload['vertices']
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    files.append(str(cp))
    return files
