"""Master building dimensions and stable physical-face naming.
Legacy IDs remain private setout keys so saved apertures do not change faces.
"""

import math

from .model import D

NAMES = {
    'front': 'Left endwall',
    'rear': 'Right endwall',
    'right': 'Front sidewall',
    'left': 'Back sidewall',
    'roof_right': 'Front roof',
    'roof_left': 'Back roof',
    'roof_mono': 'Mono roof',
    'roof_shared': 'Shared ridge',
    'front_end': 'Left endwall',
    'outer_front_end': 'Outer left end',
    'rear_end': 'Right endwall',
}
CODES = {k: v.lower().replace(' ', '_') for k, v in NAMES.items()}


def name(key):
    if str(key).startswith('lean_'):
        from .lean_walls import wall_name

        return wall_name(key) or key
    return NAMES.get(key, key)


def code(key):
    if str(key).startswith('lean_'):
        from .lean_walls import wall_code

        return wall_code(key) or key
    return CODES.get(key, key)


def apply(p):
    if p.length is None:
        return  # Legacy source callers retain their original rules until explicitly upgraded.
    if not 0 < p.length.inches <= 12000:
        raise ValueError('Master building length must be positive and at most1000 ft')
    if p.cladding.get('enabled'):
        p.cladding['length'] = p.length.fmt()
    if p.bay_layout.get('enabled'):
        r = p.bay_layout
        mode = r.get('layout_mode', 'count')
        if mode == 'standard':
            # Owner's rule: 20 ft bays, odd bay in the middle, never an equal subdivision
            from .standards import standard_bays

            lengths = standard_bays(p.length.inches)
            r['bay_lengths'] = [D(x).fmt() for x in lengths]
            r['bays'] = len(lengths)
            r['spacing'] = D(min(lengths)).fmt()
            r['length_basis'] = 'Standard 20 ft bays; odd bay in the middle; no equal subdivision'
            return
        if mode == 'explicit':
            lengths = [D(x).inches for x in r.get('bay_lengths', [])]
            if not lengths or sum(lengths) != p.length.inches:
                raise ValueError(
                    'Bay lengths must total the building length (Building settings > step 1 - Building & bays)'
                )
            if any(x <= 0 for x in lengths):
                raise ValueError('Every bay length must be positive')
            r['bays'] = len(lengths)
            r['spacing'] = D(min(lengths)).fmt()
            r['length_basis'] = 'Explicit longitudinal bays; no forced equal subdivision'
            return
        if mode not in ('count', 'max_spacing'):
            raise ValueError('Bay layout mode must be standard, explicit, count or max_spacing')
        if mode == 'max_spacing':
            maximum = D(r.get('max_spacing', "20'"))
            if not 0 < maximum.inches <= 1200:
                raise ValueError('Maximum bay spacing must be positive and at most100ft')
            count = math.ceil(p.length.inches / maximum.inches)
            r['bays'] = count
            r['max_spacing'] = maximum.fmt()
        else:
            try:
                count = int(r.get('bays', 0))
                if isinstance(r.get('bays'), bool) or count != float(r.get('bays', 0)):
                    raise ValueError()
            except (ValueError, TypeError, OverflowError):
                raise ValueError('Bay count must be an integer')
        if not 1 <= count <= 100:
            raise ValueError('Bay count must be1..100')
        r['layout_mode'] = mode
        r['spacing'] = D(p.length.inches / count).fmt()
        r['length_basis'] = 'MASTER building length; terminal support stations0 andL'


def finish(job, p):
    if p.length is None:
        return
    l = job.settings.get('frame_layouts', {}).get(p.column_mark)
    if l is None:
        return
    l['building_geometry'] = dict(
        width_in=float(p.width.inches),
        length_in=float(p.length.inches),
        low_eave_height_in=float(p.eave_height.inches),
        pitch_rise=float(p.slope_rise),
        shape=p.frame_type,
        orientation='Left/right endwalls; front/back eave sidewalls',
        mono_low_side='Back sidewall',
        mono_high_side='Front sidewall',
        length_basis='One master outside-wall length; terminal support stations coincide with endwall datum planes (zero offset assumption)',
        legacy_face_ids=NAMES,
    )
    # Attach human-facing orientation without changing any persisted physical setout ID.
    owner = job.assemblies[p.column_mark]
    for key, model in owner.derivation.get('endwalls', {}).items():
        model['endwall_name'] = name(key)
        for row in model['members']:
            row['endwall_name'] = name(key)
    runs = owner.derivation.get('secondary_runs', {})
    for group in ('lanes', 'pieces'):
        for row in runs.get(group, []):
            side = row.get('side', '')
            if side in ('left', 'right'):
                row['elevation'] = name(('roof_' if row.get('role') == 'purlin' else '') + side)
