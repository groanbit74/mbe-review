"""Generated purchasing workbook; no macros/external links or invented prices."""

import json

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .ordering import build, fmt


def write_workbook(job, path, plan=None):
    p = plan or build(job)
    wb = Workbook()
    wb.remove(wb.active)

    def table(name, headers, rows, widths=None):
        ws = wb.create_sheet(name)
        ws.append([str(job.job_no) + ' - ' + name + ' - MODEL ' + job.revision()])
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(headers))
        ws['A1'].font = Font(bold=True, color='FFFFFF', size=14)
        ws['A1'].fill = PatternFill('solid', fgColor='213D53')
        ws.row_dimensions[1].height = 28
        ws.append(headers)
        for cell in ws[2]:
            cell.font = Font(bold=True, color='FFFFFF')
            cell.fill = PatternFill('solid', fgColor='40667C')
        for i, row in enumerate(rows, 3):
            for j, v in enumerate(row, 1):
                cell = ws.cell(i, j, v)
                if isinstance(v, str):
                    cell.data_type = 's'  # Customer/part text must never become an Excel formula.
                cell.alignment = Alignment(vertical='top', wrap_text=True)
                if i % 2:
                    cell.fill = PatternFill('solid', fgColor='EDF3F6')
            ws.row_dimensions[i].height = 42
        ws.freeze_panes = 'A3'
        ws.auto_filter.ref = f'A2:{get_column_letter(len(headers))}{max(2, ws.max_row)}'
        for j in range(1, len(headers) + 1):
            ws.column_dimensions[get_column_letter(j)].width = (widths or {}).get(j, 24)
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.orientation = 'landscape'
        ws.page_setup.paperSize = ws.PAPERSIZE_A3
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.print_title_rows = '1:2'
        return ws

    headers = [
        'Order ID',
        'Department',
        'Material / profile reference',
        'Finish / color',
        'Grade',
        'Order length',
        'Inches',
        'Quantity',
        'Unit',
        'Order basis',
        'Status / release review',
        'Source references',
    ]

    def orderrows(rows):
        return [
            [
                r['order_id'],
                r['department'],
                r.get('display_material', r['material']),
                r['finish'],
                r['grade'],
                r['order_length'],
                r['order_length_in'],
                r['quantity'],
                r['unit'],
                r['basis'],
                r['status'] + '; ' + r.get('supplier_status', '') + '; ' + r.get('supplier_note', ''),
                r['references'],
            ]
            for r in rows
        ]

    widths = {1: 14, 2: 20, 3: 48, 4: 24, 5: 24, 6: 20, 7: 13, 8: 12, 9: 10, 10: 28, 11: 60, 12: 65}
    table('Master Order', headers, orderrows(p['items']), widths)
    for dep, name in [('Frame', 'Frame'), ('Secondaries', 'Secondaries'), ('Sheets / Trim', 'Sheets and Trim')]:
        table(name, headers, orderrows([r for r in p['items'] if r['department'] == dep]), widths)
    table(
        'Stock Patterns',
        [
            'Pattern',
            'Material',
            'Finish',
            'Grade',
            'Stock length',
            'Stock qty',
            'Blank lengths PER stock',
            'Remnant each inches',
            'Kerf each inches',
            'Stock IDs',
        ],
        [
            [
                r['pattern_id'],
                r['profile'],
                r['finish'],
                r['grade'],
                fmt(r['stock_length_in']),
                r['quantity'],
                ' + '.join(fmt(x) for x in r['cut_lengths_in']),
                r['remnant_each_in'],
                r['kerf_each_in'],
                ', '.join(r['stock_ids']),
            ]
            for r in p['patterns']
        ],
        {2: 40, 7: 70, 10: 70},
    )
    bybar = {r['stock_id']: r for r in p['bars']}
    table(
        'Cutting Plan',
        [
            'Stock ID',
            'Material',
            'Finish',
            'Stock length inches',
            'Cut sequence',
            'Owner',
            'Cut mark',
            'Instance',
            'Start inches',
            'Blank inches',
            'Blank length',
            'Source status',
        ],
        [
            [
                r['stock_id'],
                bybar[r['stock_id']]['profile'],
                bybar[r['stock_id']]['finish'],
                bybar[r['stock_id']]['stock_length_in'],
                r['cut_sequence'],
                r['owner'],
                r['cut_mark'],
                r['instance'],
                r['start_in'],
                r['blank_length_in'],
                r['blank_length'],
                r['source_status'],
            ]
            for r in p['allocations']
        ],
        {2: 40, 7: 40, 12: 65},
    )
    table(
        'Piece Trace',
        [
            'Supplier item',
            'Order ID',
            'Stock ID',
            'Cut mark',
            'Instance',
            'Physical piece ID',
            'Material',
            'Stock length',
            'Cut length',
            'Location / use',
            'Mapping',
            'Kerf loss per stock',
            'End loss per stock',
            'Remnant per stock',
        ],
        [
            [
                r['supplier_id'],
                r['order_id'],
                r['stock_id'],
                r['cut_mark'],
                r['instance'],
                r['piece_id'],
                r['material'],
                fmt(r['stock_length_in']),
                fmt(r['blank_length_in']),
                r['location'],
                r['location_status'],
                fmt(r['kerf_loss_in']),
                fmt(r['end_loss_in']),
                fmt(r['remnant_in']),
            ]
            for r in p['piece_trace']
        ],
        {4: 32, 6: 38, 7: 35, 10: 110},
    )
    table(
        'Cut Demands',
        [
            'Department',
            'Family',
            'Profile',
            'Finish',
            'Grade',
            'Owner',
            'Mark',
            'Quantity',
            'Exact long blank inches',
            'Rounded blank inches',
            'Status',
        ],
        [
            [
                r[k]
                for k in (
                    'department',
                    'family',
                    'profile',
                    'finish',
                    'grade',
                    'owner',
                    'mark',
                    'quantity',
                    'exact_blank_length_in',
                    'blank_length_in',
                    'status',
                )
            ]
            for r in p['demands']
        ],
        {3: 48, 7: 40, 11: 65},
    )
    table(
        'Holds',
        ['Department', 'Material', 'Known qty (blank = unknown)', 'Reference', 'Required length', 'Reason'],
        [
            [r['department'], r['material'], r['quantity'], r['reference'], r['required_length'], r['reason']]
            for r in p['pending']
        ],
        {2: 45, 4: 45, 6: 80},
    )
    table(
        'Stock Totals',
        [
            'Material group',
            'Department',
            'Profile',
            'Finish',
            'Grade',
            'Mode',
            'Demand qty',
            'Planned qty',
            'Stock qty',
            'Ordered LF',
            'Blank LF',
            'Kerf LF',
            'Ends LF',
            'Remnant LF',
            'Baseline LF',
        ],
        [
            [
                r[k]
                for k in (
                    'id',
                    'department',
                    'profile',
                    'finish',
                    'grade',
                    'mode',
                    'demand_quantity',
                    'planned_quantity',
                    'stock_quantity',
                )
            ]
            + [
                r[k] / 12
                for k in (
                    'ordered_length_in',
                    'blank_length_in',
                    'kerf_loss_in',
                    'end_loss_in',
                    'remnant_in',
                    'baseline_length_in',
                )
            ]
            for r in p['groups']
        ],
        {3: 44},
    )
    table(
        'Supplier selections',
        ['Setting', 'Value'],
        [[k, json.dumps(v)] for k, v in p.get('sourcing', {}).items()],
        {1: 30, 2: 120},
    )
    table(
        'Settings',
        ['Setting', 'Value'],
        [[k, json.dumps(v) if isinstance(v, (list, dict)) else str(v)] for k, v in p['config'].items()]
        + [['Job revision', p['revision']]],
        {1: 32, 2: 110},
    )
    from .pricing import material_list

    ml = material_list(job, p)
    ws = wb.create_sheet('Material List')
    ws.append(
        [
            'Quantity',
            'Length',
            'Size',
            'Shape',
            'Description',
            'Supplier',
            'Supplier item',
            'Color',
            'Label',
            'price',
            'sq.ft. price',
            'Line total',
            'Status',
            'Note',
        ]
    )
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='404040')
    editable = PatternFill('solid', fgColor='FFF2CC')
    for r in ml['rows'] + [None] + ml['job_cost_rows']:
        if r is None:
            ws.append([])
            continue
        ws.append(
            [
                r['quantity'],
                r['length'],
                r['size'],
                r['shape'],
                r['description'],
                r.get('supplier', ''),
                r.get('supplier_label', ''),
                r['color'],
                r['label'],
                r['price'],
                r['sqft_price'],
                r['extended'],
                r['status'],
                r['note'],
            ]
        )
        for col in (10, 11):
            ws.cell(row=ws.max_row, column=col).fill = editable
    ws.append([])
    ws.append(['', '', '', '', 'Material total', '', '', '', '', '', '', ml['totals']['material_total']])
    ws.append(
        ['', '', '', '', 'Job estimate lines (excl. material)', '', '', '', '', '', '', ml['totals']['job_cost_total']]
    )
    ws.append(['', '', '', '', 'GRAND TOTAL (priced lines only)', '', '', '', '', '', '', ml['totals']['grand_total']])
    ws.append(
        [
            '',
            '',
            '',
            '',
            f"{ml['totals']['unpriced_lines']} material lines UNPRICED -- fill price / sq.ft. price (yellow cells) or the job price book; unpriced lines never block the job.",
        ]
    )
    for col, width in zip('ABCDEFGHIJKLMN', (10, 14, 12, 10, 34, 18, 30, 22, 16, 12, 12, 14, 12, 30)):
        ws.column_dimensions[col].width = width
    ws.freeze_panes = 'A2'

    table(
        'Read Me',
        ['Topic', 'Instruction'],
        [
            [
                'Purpose',
                'Generated job-scoped master order. Change quantities/stock rules in the editor and regenerate; workbook edits do not write back to the model.',
            ]
        ]
        + [['Review', n] for n in p['notes']]
        + [
            [
                'Footage reduction vs one-piece stock baseline',
                f"{(p['baseline_linear_stock_in'] - p['ordered_linear_stock_in']) / 12:.2f} LF (planned linear items only).",
            ]
        ],
        {1: 32, 2: 120},
    )
    from .purchasing import supplier_plan

    sp = supplier_plan(job, p)
    byid = {r['order_id']: r for r in p['items']}
    table(
        'Supplier crosswalk',
        ['Supplier item', 'Internal order ID', 'Internal material', 'Source marks / stock IDs'],
        [
            [
                r['supplier_id'],
                r['internal_order_id'],
                byid[r['internal_order_id']]['material'],
                byid[r['internal_order_id']]['references'],
            ]
            for r in sp['crosswalk']
        ],
        {1: 18, 2: 22, 3: 65, 4: 100},
    )
    from .material_reports import report_tables

    for name, headers, rows, widths in report_tables(p):
        if rows and (p['config']['material_engine']['enabled'] or name == 'Stock vs Custom'):
            table(name, headers, rows, {i + 1: max(15, w / 5) for i, w in enumerate(widths)})
    related = []
    for item in p['items']:
        for r in item.get('uses', []):
            related.append(
                [
                    item['supplier_id'],
                    item['order_id'],
                    r['mark'],
                    r['location'],
                    (r['drawing']['kind'] + ' / ' + r['drawing']['name']) if r.get('drawing') else 'Location review',
                ]
            )
    table(
        'Use References',
        [
            'Supplier item',
            'Order ID',
            'Existing piece / source mark',
            'Related location (not extra quantity)',
            'Drawing reference',
        ],
        related,
        {1: 16, 2: 22, 3: 42, 4: 115, 5: 48},
    )
    use_lookup = {}
    for i, r in enumerate(related, 3):
        for value in r[:3]:
            use_lookup.setdefault(value, i)
    # Click purchasing/cutting references to the first matching trace row.
    lookup = {}
    for i, r in enumerate(p['piece_trace'], 3):
        for value in (r['supplier_id'], r['order_id'], r['stock_id'], r['cut_mark']):
            lookup.setdefault(value, i)
    for name in (
        'Master Order',
        'Frame',
        'Secondaries',
        'Sheets and Trim',
        'Cutting Plan',
        'Supplier crosswalk',
        'Cut Demands',
    ):
        for row in wb[name].iter_rows(min_row=3):
            for cell in row:
                if isinstance(cell.value, str) and cell.value in lookup:
                    cell.hyperlink = "#'Piece Trace'!A" + str(lookup[cell.value])
                    cell.style = 'Hyperlink'
                elif isinstance(cell.value, str) and cell.value in use_lookup:
                    cell.hyperlink = "#'Use References'!A" + str(use_lookup[cell.value])
                    cell.style = 'Hyperlink'
    wb.save(path)
    return str(path)
