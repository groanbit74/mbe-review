"""30x30 placement layout only. No toolpath, pierce point, kerf or G-code."""

import csv
import json
from pathlib import Path

from .connections import contour, f
from .model import Part


def collect(job):
    from .drawing.sheet import usage

    counts = usage(job)[1]
    result = []
    holds = []

    def add(part, qty, owner):
        if qty <= 0:
            return
        if part.kind not in ('plate', 'clip') or not all((part.thk, part.width, part.length)):
            return
        if 'formed' in part.notes.lower() or part.symbol.get('formed'):
            holds.append(
                dict(mark=part.mark, quantity=qty, reason='Formed part: developed flat pattern not established')
            )
            return
        pts = contour(part)
        if not pts:
            pts = [(0, 0), (f(part.length), 0), (f(part.length), f(part.width)), (0, f(part.width))]
        lo = min(x for x, y in pts)
        bottom = min(y for x, y in pts)
        poly = [(x - lo, y - bottom) for x, y in pts]
        result.append(
            dict(
                mark=part.mark,
                quantity=qty,
                owner=owner,
                thickness_in=f(part.thk),
                width_in=max(x for x, y in poly),
                height_in=max(y for x, y in poly),
                contour_in=poly,
                holes_in=[(f(h.x) - lo, f(h.y) - bottom, f(h.dia)) for h in part.holes],
                review_status=part.symbol.get('review_hold') or part.notes or part.source,
            )
        )

    for mark, q in counts.items():
        add(job.part(mark), q, 'PRIMARY / LOOSE PART USAGE')
    for a in job.assemblies.values():
        for mark, q in a.derivation.get('end_girt_clip_counts', {}).items():
            if mark in job.parts:
                add(job.part(mark), q, 'END GIRT CLIPS')
            elif q:
                holds.append(dict(mark=mark, quantity=q, reason='Required clip geometry unresolved'))
        for wall in a.derivation.get('endwalls', {}).values():
            rc = wall.get('ridge_face_clip')
            if rc:
                add(job.part(rc['mark']), rc['quantity'], 'ENDWALL PEAK FACE CLIP')
        for z in a.derivation.get('framing_additions', {}).get('lean_tos', []):
            roof_counts = {}
            for r in z.get('roof_clip_schedule', []):
                roof_counts[r['part_mark']] = roof_counts.get(r['part_mark'], 0) + r['quantity']
            for mark, q in roof_counts.items():
                add(job.part(mark), q, z['id'] + ' ROOF CLIPS')
            for r in z.get('low_connection_parts', []):
                add(Part.from_json(r['part']), r['quantity'], z['id'] + ' LOW')
            from .lean_connections import end_plate_part, part

            for c in z.get('flush_clips', []):
                add(part(c['mark'], c), c.get('quantity', 1), z['id'] + ' HIGH')
            if z.get('end_plate_geometry', {}) and z['end_plate_geometry']['geometry_valid']:
                add(end_plate_part(z['end_plate_geometry']), z['end_plate_geometry']['quantity'], z['id'] + ' HIGH')
    return result, holds


def pack(parts, table=30.0, gap=0.25, margin=0.5):
    if table <= 0 or gap < 0 or margin < 0 or 2 * margin >= table:
        raise ValueError('Invalid placement envelope')
    sheets = []
    placements = []
    holds = []
    for r in sorted(parts, key=lambda r: (r['thickness_in'], -max(r['width_in'], r['height_in']), r['mark'])):
        if not isinstance(r['quantity'], int) or not 0 <= r['quantity'] <= 10000:
            raise ValueError('Invalid placement quantity')
        for instance in range(1, r['quantity'] + 1):
            placed = False
            for sheet in [s for s in sheets if s['thickness_in'] == r['thickness_in']] + [None]:
                options = [(r['width_in'], r['height_in'], 0), (r['height_in'], r['width_in'], 90)]
                for w, h, rot in options:
                    if w > table - 2 * margin + 1e-8 or h > table - 2 * margin + 1e-8:
                        continue
                    if sheet is None:
                        sheet = dict(
                            number=len(sheets) + 1, thickness_in=r['thickness_in'], x=margin, y=margin, row_height=0
                        )
                        sheets.append(sheet)
                    x, y = sheet['x'], sheet['y']
                    newrow = x + w > table - margin + 1e-8
                    if newrow:
                        x = margin
                        y += sheet['row_height'] + gap
                    if y + h > table - margin + 1e-8:
                        continue

                    def turn(pt):
                        px, py = pt
                        return (x + px, y + py) if rot == 0 else (x + r['height_in'] - py, y + px)

                    q = dict(
                        sheet=sheet['number'],
                        mark=r['mark'],
                        instance=instance,
                        owner=r['owner'],
                        thickness_in=r['thickness_in'],
                        origin_x_in=x,
                        origin_y_in=y,
                        rotation_deg=rot,
                        width_in=w,
                        height_in=h,
                        contour_in=[turn(p) for p in r['contour_in']],
                        holes_in=[(*turn((hx, hy)), d) for hx, hy, d in r['holes_in']],
                        review_status=r['review_status'],
                    )
                    q['first_contour_x_in'], q['first_contour_y_in'] = q['contour_in'][0]
                    placements.append(q)
                    sheet.update(x=x + w + gap, y=y, row_height=max(0 if newrow else sheet['row_height'], h))
                    placed = True
                    break
                if placed:
                    break
            if not placed:
                holds.append(
                    dict(mark=r['mark'], quantity=1, reason='EXCEEDS usable30x30 area with stated margins; NOT split')
                )
    return dict(
        table_width_in=table,
        table_height_in=table,
        edge_margin_in=margin,
        part_spacing_in=gap,
        origin='TABLE LOWER LEFT0,0; reported part origin is rotated bounding-box LOWER LEFT, NOT a pierce/lead-in point',
        scope='MANUAL POSITIONING / CONTOUR REVIEW ONLY; margins and spacing are explicit layout assumptions, NOT kerf/torch settings; NO MACHINE COMMANDS',
        sheets=[{k: s[k] for k in ('number', 'thickness_in')} for s in sheets],
        placements=placements,
        holds=holds,
    )


def export(job, folder):
    import pymupdf as F

    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    parts, held = collect(job)
    plan = pack(parts)
    plan['holds'] += held
    paths = []
    path = folder / 'plasma_30x30_layout.json'
    path.write_text(json.dumps(plan, indent=2))
    paths.append(str(path))
    path = folder / 'plasma_30x30_positions.csv'
    keys = [
        'sheet',
        'mark',
        'instance',
        'owner',
        'thickness_in',
        'origin_x_in',
        'origin_y_in',
        'rotation_deg',
        'first_contour_x_in',
        'first_contour_y_in',
        'width_in',
        'height_in',
        'review_status',
    ]
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows({k: r[k] for k in keys} for r in plan['placements'])
    paths.append(str(path))
    pdf = F.open()
    for sheet in plan['sheets']:
        page = pdf.new_page(width=1224, height=792)
        page.insert_text(
            (45, 43),
            f'30 x30 PLASMA PLACEMENT / SHEET {sheet["number"]} / {sheet["thickness_in"]:g}in STOCK',
            fontsize=19,
        )
        page.insert_text(
            (45, 67),
            'POSITIONING ONLY - NOT A TOOLPATH OR MACHINE RELEASE. OpenBuilds software; manual torch height.',
            fontsize=11,
            color=(0.7, 0, 0),
        )
        scale = 19
        ox = 70
        oy = 690
        pt = lambda p: F.Point(ox + scale * p[0], oy - scale * p[1])
        page.draw_rect(F.Rect(ox, oy - 30 * scale, ox + 30 * scale, oy), color=(0, 0, 0))
        page.insert_text((ox - 10, oy + 20), '0,0', fontsize=12)
        page.insert_text((690, 118), 'MARK / INSTANCE      X      Y      ROTATION', fontsize=12)
        rows = [r for r in plan['placements'] if r['sheet'] == sheet['number']]
        for i, r in enumerate(rows):
            points = [pt(p) for p in r['contour_in']]
            page.draw_polyline(points + [points[0]], color=(0.1, 0.3, 0.5), width=0.7)
            for x, y, d in r['holes_in']:
                page.draw_circle(pt((x, y)), d / 2 * scale, color=(0.1, 0.3, 0.5), width=0.5)
            orig = pt((r['origin_x_in'], r['origin_y_in']))
            page.draw_circle(orig, 2, fill=(0.8, 0, 0), color=(0.8, 0, 0))
            page.insert_text((orig.x + 3, orig.y - 4), str(i + 1), fontsize=8)
            label = f'{i + 1}. {r["mark"]} #{r["instance"]} | {r["origin_x_in"]:.3f}, {r["origin_y_in"]:.3f} | {r["rotation_deg"]}deg'
            if i < 30:
                page.insert_text((690, 143 + i * 16), label, fontsize=9)
        if len(rows) > 30:
            page.insert_text(
                (690, 631),
                f'{len(rows) - 30} additional placements: see COMPLETE CSV/JSON.',
                fontsize=10,
                color=(0.7, 0, 0),
            )
        page.insert_text(
            (690, 652), 'Red = placement origin. CSV also lists first contour vertex.', fontsize=10, color=(0.7, 0, 0)
        )
        page.insert_text((690, 674), 'Layout assumptions:1/2in edge margin;1/4in part spacing.', fontsize=10)
        page.insert_text((690, 696), 'Neither point is a pierce lead-in. Check clamps and cut room.', fontsize=10)
        page.insert_text(
            (45, 758),
            'Coordinates in INCHES. Sheet groups by thickness; material grade/finish must be checked before combining stock. See JSON holds.',
            fontsize=10,
        )
    if not len(pdf):
        page = pdf.new_page()
        page.insert_text((40, 60), 'No eligible plate contours. See layout JSON holds.')
    path = folder / 'plasma_30x30_layout.pdf'
    pdf.save(path, garbage=4, deflate=True)
    paths.append(str(path))
    return paths
