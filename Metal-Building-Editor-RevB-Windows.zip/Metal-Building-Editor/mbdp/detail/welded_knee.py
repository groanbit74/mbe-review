"""Optional inside-flange knee: explicit bearing geometry, not weld design.

The rafter top remains the roof framing datum. The top strap is above that
plane; its local secondary interference is explicitly recorded, not concealed
by moving the entire roof. Column depth is a HORIZONTAL envelope dimension.
"""

import math
from fractions import Fraction

from .model import Attachment, D, Part


def geometry(column_depth, rafter_width, pitch):
    cd = float(column_depth)
    w = float(rafter_width)
    m = float(pitch) / 12
    if not all(math.isfinite(x) for x in (cd, w, m)) or cd <= 0 or w <= 0 or not -1 <= m <= 1:
        raise ValueError('Invalid inside-flange knee dimensions')
    co = 1 / math.hypot(1, m)
    sn = m * co
    t = 3 / 16
    overlap = 3.0
    inset = max(0.0, t * sn)
    bearing = (cd - inset) / co
    length = bearing + overlap
    # Local origin at outside column face / underside of plate. Actual plate
    # thickness is normal to pitch. Outer material face projects t*sin(theta).
    bottom = [(inset, inset * m), (inset + length * co, inset * m + length * sn)]
    side = [bottom[0], bottom[1], (bottom[1][0] - t * sn, bottom[1][1] + t * co), (inset - t * sn, inset * m + t * co)]
    return dict(
        column_depth_in=cd,
        width_in=w,
        thickness_in=t,
        pitch_rise=float(pitch),
        column_bearing_along_in=bearing,
        nominal_column_span_along_in=cd / co,
        bearing_inset_horizontal_in=inset,
        rafter_overlap_along_in=overlap,
        length_along_in=length,
        rafter_start_x_in=cd,
        rafter_top_at_inside_in=cd * m,
        side_contour_in=side,
        co=co,
        sn=sn,
        datum='Column/rafter contact at underside of pitched top plate; outermost material edge FLUSH with column; square thickness edges, no bevel inferred.',
        fit_notes=[
            'Top plate projects 3/16 in (plate thickness) above the rafter top flange at the knee; roof datum unchanged.',
            'Plate length = available bearing along pitch +3in overlap; square-edge thickness offset is included.',
            'Outermost square edge is flush: bearing bottom starts max(0, thickness*sin(pitch)) inward. No overhang or bevel inferred.',
        ],
    )


def part(mark, geo, frame_id=None, start_clip=None):
    d = lambda x: D(Fraction(str(x)))
    L = geo['length_along_in']
    W = geo['width_in']
    symbol = dict(
        inside_knee_top=True,
        knee_geometry=geo,
        draft_connection=True,
        cut_contour=[[d(x).to_json(), d(y).to_json()] for x, y in [(0, 0), (L, 0), (L, W), (0, W)]],
        role='3/16 pitched top bearing plate;3in rafter overlap',
        review_hold='Pitched top bearing plate; square-edge bearing inset included; 3 in rafter overlap',
    )
    if frame_id:
        symbol['welded_frame_id'] = frame_id
    p = Part(
        mark,
        'plate',
        d(geo['thickness_in']),
        d(W),
        d(L),
        holes=[],
        symbol=symbol,
        source='User optional inside-flange welded knee',
        notes='Rafter end welded at INSIDE column flange. Pitched top plate bears on column; no bolt holes.',
    )
    if start_clip:
        p.attachments = [
            Attachment(
                start_clip, 'top', D(0), note='starting PLUMB clip at column outside face; bearing plate support'
            )
        ]
        p.symbol['starting_clip'] = start_clip
    return p
