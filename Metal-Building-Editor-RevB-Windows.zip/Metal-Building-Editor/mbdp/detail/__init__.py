"""Drawing-producing detailing core.

Sub-packages:

* ``sections``   – rolled-shape geometry catalog (d, bf, tf, tw, plf)
* ``model``      – the product model the drawings are generated from (Job, Assembly, Part, Attachment)
* ``templates``  – shop-standard part library and the sample job used for golden-file comparison
* ``frame``      – rigid-frame wizard (parameters -> column and rafter assemblies with documented derivations)
* ``drawing``    – drawing engine: views, dimensions, sheet layout, PDF/SVG/DXF renderers
* ``shopdata``   – cut lists, plate lists, 1:1 plate DXF, DSTV-style NC files
* ``editor``     – web editor (model forms + live drawing preview + downloads)
"""
