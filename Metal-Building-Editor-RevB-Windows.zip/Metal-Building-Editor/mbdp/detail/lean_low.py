"""Reuse primary base/knee builders for lean low ends; no invented Cee bracket."""

import copy
import hashlib
import math
from fractions import Fraction

from .base_options import mark as base_mark
from .base_options import resolve as resolve_base
from .base_options import thickness as base_thickness
from .connections import build, f
from .model import Assembly, D, Job, MainMember, Part
from .plate_rules import make


def finish(job, p, z, rf, col):
    z['low_connection_parts'] = []
    result = dict(
        rule='SAME PRIMARY KNEE AND BASE BUILDERS / Q04',
        style=z['low_connection'],
        issues=[],
        quantity=len(z['stations']),
    )
    z['low_connection_detail'] = result
    if not rf or not col:
        return
    tmp = Job(
        job.job_no,
        job.customer,
        parts=copy.deepcopy(job.parts),
        settings={'plate_rules': copy.deepcopy(job.settings.get('plate_rules', {}))},
    )
    from . import foundation as FND

    lean_post_hole = FND.lean_is_post_footing(p, z)
    try:
        bp = resolve_base(tmp, p, col['id'], profile=None if col['family'] == 'W' else col, post_footing=lean_post_hole)
    except ValueError as e:
        result['issues'].append('Shared base rule cannot fit this column: ' + str(e))
        return
    count = len(z['stations'])
    if bp:
        z['low_connection_parts'].append(dict(part=bp.to_json(), quantity=count, role='BASE / SHARED PRIMARY RULE'))
    result.update(base_plate=base_mark(bp), base_connection=p.base_connection, base_thickness_in=base_thickness(bp))
    if col['family'] == 'HSS':
        result['notes'] = ['CLOSED TUBE COLUMN: outside-face weld geometry; nominal wall']
    if bp and bp.symbol.get('base_hole_datum') == 'HSS_UNRESOLVED_NO_HOLES':
        result['base_plate_note'] = bp.symbol['review_hold']
    plumb = rf['depth'] * math.hypot(1, z['pitch'] / 12)
    m = z['pitch'] / 12
    in_channel = bool(z.get('purlins_in_channel'))
    if z['low_connection'] in ('fully_welded', 'welded_box'):
        default_seat = z.get('rafter_seat_resolved') or p.welded_knee
        deduction = 0 if default_seat == 'inside_flange' else plumb
        long_add = col['depth'] * m
        from .framing_additions import station_rafter

        by_seat = {}
        for i, station in enumerate(z.get('stations', [])):
            rfi, _pair = station_rafter(z, rf, i, count)
            seat = station.get('rafter_seat_mode') or default_seat
            profile_id = rfi['id'] if rfi else rf['id']
            by_seat.setdefault((seat, profile_id), []).append((station, rfi))
        head_schedule = []
        resolved_seats = {mode for mode, _profile_id in by_seat}
        if any(
            mode == 'inside_flange' and rows[0][1] and rows[0][1].get('family') == 'C'
            for (mode, _profile_id), rows in by_seat.items()
        ):
            result['knee_notes'] = [
                'POST TO THE RAFTER TOP LINE (pitch-cut top, long side at the inside face)',
                'Open-face channel supports are welded to the inside face without a cap; W-rail supports retain their cap/head detail per line schedule.',
            ]
        for group_index, ((seat, _profile_id), rows) in enumerate(by_seat.items(), start=1):
            inside = seat == 'inside_flange'
            group_rf = rows[0][1] or rf
            group_open_channel = bool(group_rf.get('family') == 'C' and group_rf.get('open_face'))
            group_plumb = group_rf['depth'] * math.hypot(1, m)
            ep = None
            if inside and group_open_channel:
                pass  # The open-face channel is side-welded; no cap plate is defined.
            elif inside:
                from .welded_knee import geometry as knee_geometry
                from .welded_knee import part as knee_part

                kg = knee_geometry(col['depth'], group_rf['width'], z['pitch'])
                ep = knee_part(p.column_mark + '-' + z['id'] + '-LOW-TOP-' + str(group_index), kg)
                result.setdefault('knee_geometry_by_seat', {})[seat + ':' + _profile_id] = kg
                result.setdefault('knee_notes_by_seat', {})[seat + ':' + _profile_id] = kg['fit_notes']
            else:
                ep = Part(
                    p.column_mark + '-' + z['id'] + '-LOW-COVER-' + str(group_index),
                    'plate',
                    D('3/16'),
                    D(Fraction(str(group_rf['width']))),
                    D(Fraction(str(group_plumb + f(p.eave_plate_extension)))),
                    source='Same main welded eave cover rule',
                    notes='3/16in cover; top flush; actual plumb rafter depth plus user extension',
                )
            if ep is not None:
                z['low_connection_parts'].append(
                    dict(
                        part=ep.to_json(),
                        quantity=len(rows),
                        role=(
                            'SHARED INSIDE-FLANGE TOP PLATE'
                            if inside and len(resolved_seats) == 1
                            else 'SHARED WELDED EAVE COVER'
                            if not inside and len(resolved_seats) == 1
                            else 'LEAN INSIDE-FLANGE TOP PLATE'
                            if inside
                            else 'LEAN WELDED EAVE COVER'
                        ),
                    )
                )
            head_schedule.append(
                dict(
                    mode=seat,
                    rafter_profile=_profile_id,
                    quantity=len(rows),
                    support_marks=[x[0]['main_mark'] for x in rows],
                )
            )
        result['head_schedule'] = head_schedule
        resolved_seats = {row['mode'] for row in head_schedule}
        result['mixed_seats'] = len(resolved_seats) > 1
        if len(resolved_seats) == 1:
            result['welded_knee'] = next(iter(resolved_seats))
        if p.eave_start_clip and not in_channel:
            from .girt_clips import weld_clip

            clip = weld_clip(tmp, z['purlin_depth_in']) if p.clip_policy == 'member_sized' else tmp.part(p.purlin_clip)
            z['low_connection_parts'].append(
                dict(part=clip.to_json(), quantity=count, role='RETAINED PLUMB EAVE START CLIP')
            )
        channel_head_profiles = {
            profile_id
            for (_mode, profile_id), rows in by_seat.items()
            if rows[0][1] and rows[0][1].get('family') == 'C' and rows[0][1].get('open_face')
        }
        has_w_head_profile = any(
            rows[0][1] and not (rows[0][1].get('family') == 'C' and rows[0][1].get('open_face'))
            for (_mode, _profile_id), rows in by_seat.items()
        )
        seat_summary = (
            'RAFTER WELDED TO THE INSIDE FACE OF THE POST; post to the rafter top line'
            + (
                '; open-face channel supports have NO CAP; W supports use a cap/head detail per support schedule'
                if channel_head_profiles and has_w_head_profile
                else '; NO CAP (open-face channel)'
                if channel_head_profiles
                else '; cap plate'
            )
            if resolved_seats == {'inside_flange'}
            else 'PLUMB RAFTER FLUSH WITH OUTSIDE COLUMN'
            if resolved_seats == {'outside_seat'}
            else 'PER-SUPPORT OVERRIDES; inherited lean default where unset'
        )
        result.update(
            seat=seat_summary,
            plumb_rafter_depth_in=plumb,
            column_head_angle_deg=math.degrees(math.atan(m)),
        )
    else:
        if rf['family'] != 'W' or col['family'] != 'W':
            result['issues'].append('Shared bolted knee needs Cee/HSS adapter geometry; no W substitution made')
            return
        tmp.assemblies['L-C'] = Assembly('L-C', 'COLUMN', count, MainMember('L-C-CUT', col['id'], D(120)))
        tmp.assemblies['L-R'] = Assembly('L-R', 'RAFTER', count, MainMember('L-R-CUT', rf['id'], D(120)))
        ep = (
            make(tmp, 'K', rf['id'], col['id'], p.weld_size)
            if p.plate_mode == 'member'
            else tmp.part(p.rafter_end_plate)
        )
        mark = 'LK-' + hashlib.sha256((p.column_mark + z['id']).encode()).hexdigest()[:10].upper()
        start = (
            {
                'start_clip': dict(
                    part=p.purlin_clip, mode=z['purlin_mode'], web_y=p.purlin_web_y.fmt(), side=p.purlin_side
                )
            }
            if p.eave_start_clip
            else {}
        )
        knee = build(
            tmp,
            mark,
            dict(
                **start,
                kind='low',
                column='L-C',
                rafter='L-R',
                rise=str(z['pitch']),
                pitch_source='explicit',
                qty=count,
                bottom=p.connection_bottom.fmt(),
                bottom_mode=p.connection_bottom_mode,
                top_extension=p.top_extension.fmt(),
                flange_thk=p.flange_thk.fmt(),
                web_thk=p.web_thk.fmt(),
                weld_size=p.weld_size,
                end_plate=ep.mark,
                plate_mode=p.plate_mode,
                installed=False,
            ),
        )
        deduction = knee.symbol['h'] + f(p.column_top_gap)
        long_add = 0
        result.update(knee=knee.mark, knee_height_in=knee.symbol['h'], template_job=tmp.dumps())
        counts = {ep.mark: count}
        for a in knee.attachments:
            counts[a.part] = counts.get(a.part, 0) + count
        for key, q in counts.items():
            z['low_connection_parts'].append(
                dict(part=tmp.part(key).to_json(), quantity=q, role='SHARED PRIMARY BOLTED KNEE / MATE')
            )
    low = z['low_eave_in'] - z.get('purlin_deduction_in', z['purlin_depth_in']) - deduction
    from .grades import lean_key
    from .grades import offset as grade_offset

    y0 = FND.lean_column_bottom_in(p, z, base_thickness(bp))  # set level; per post grade below
    short = low - y0
    long = short + long_add
    if short <= 0:
        result['issues'].append('Shared deductions consume lean column height')
        return
    # Per frame line (round 11): the post of each line runs to ITS rafter top line - a W line
    # with bypass purlins is a purlin depth lower than a channel line (purlins in the channel) or
    # a flush W line; on an outside seat the post also stops under the line's own rafter depth.
    from .framing_additions import station_fit, station_rafter

    n = len(z['stations'])
    welded = z['low_connection'] in ('fully_welded', 'welded_box')
    lines = []
    for i in range(n):
        rfi, pair = station_rafter(z, rf, i, n)
        ded_i = station_fit(z, rfi, pair)[1]
        plumb_i = rfi['depth'] * math.hypot(1, m)
        seat_i = z['stations'][i].get('rafter_seat_mode') or z.get('rafter_seat_resolved') or p.welded_knee
        inside_i = welded and seat_i == 'inside_flange'
        ded_seat = (0 if inside_i else plumb_i) if welded else deduction
        low_i = z['low_eave_in'] - ded_i - ded_seat
        grade_i = grade_offset(p, lean_key(z['id'], i + 1))  # ground / slab level at this post
        y0_i = y0 + grade_i
        lines.append(
            dict(
                station=i + 1,
                frame_line=z['stations'][i].get('frame_line'),
                main_mark=z['stations'][i].get('main_mark'),
                rafter_seat_mode=seat_i,
                rafter_seat_source=z['stations'][i].get('rafter_seat_source', 'inherited'),
                profile_id=rfi['id'],
                pair=pair,
                purlin_deduction_in=ded_i,
                column_low_floor_in=low_i,
                grade_in=grade_i,
                column_bottom_in=y0_i,
                column_low_cut_in=low_i - y0_i,
                column_long_blank_in=low_i - y0_i + long_add,
            )
        )
        if low_i - y0_i <= 0:
            result['issues'].append('Line %d: shared deductions consume the lean column height' % (i + 1))
    result.update(
        column_low_floor_in=low,
        column_low_cut_in=short,
        column_long_blank_in=long,
        base_elevation_in=f(p.base_elevation),
        column_bottom_in=y0,
        foundation=FND.lean_record(p, z),
        lines=lines,
        mixed_lines=len({round(x['column_low_cut_in'], 6) for x in lines}) > 1,
        graded=any(abs(x['grade_in']) > 1e-9 for x in lines),
        status='GEOMETRY DERIVED'
        + ('; post footing embedment included' if lean_post_hole else '')
        + ('; post cut to the grade at each line' if any(abs(x['grade_in']) > 1e-9 for x in lines) else ''),
    )
    by_station = {x['station']: x for x in lines}
    for r in z['members']:
        if r['role'] == 'column':
            x = by_station.get(r.get('station')) or {}
            r.update(
                reference_length_in=x.get('column_low_cut_in', short),
                cut_length_in=x.get('column_low_cut_in', short),
                blank_length_in=x.get('column_long_blank_in', long),
                status='SHARED MAIN KNEE/BASE RULE; low cut and long blank'
                + (
                    '; HSS BASE BLANK, NO ANCHOR HOLES (anchor layout per the connection)'
                    if bp and bp.symbol.get('base_hole_datum') == 'HSS_UNRESOLVED_NO_HOLES'
                    else ''
                ),
            )
