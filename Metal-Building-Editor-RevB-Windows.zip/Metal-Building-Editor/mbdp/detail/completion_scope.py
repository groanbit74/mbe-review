"""Scope-aware completion: don't order nonexistent skins/penetration flashing.
Field-fit stock blanks remain identified as such, never exact receiving-web cuts.
"""

from .cladding import fmt


def finish(job, p, model):
    if not p.additions.get('detail_completion', False):
        return
    walls = job.assemblies[p.column_mark].derivation.get('endwalls', {})
    for wall in walls.values():
        posts = {r['mark']: r for r in wall['posts']}
        for row in wall['members']:
            if row['role'] not in ('base angle', 'endwall girt') or (
                row['role'] == 'endwall girt' and row.get('blank_length_in') is not None
            ):
                continue
            a = row['x0_in']
            b = row['x1_in']
            for key, side in (('left_support', 1), ('right_support', -1)):
                post = posts.get(row.get(key))
                if post and abs((a if side == 1 else b) - post['x']) < 1e-8:
                    # Slab angle clears the footprint. Girt meets a known web when available.
                    delta = post['width'] / 2 if row['role'] == 'base angle' else (post['profile'].get('web') or 0) / 2
                    if side == 1:
                        a += delta
                    else:
                        b -= delta
            length = b - a
            if length <= 0:
                raise ValueError('Opening/support faces consume field-fit blank')
            if row['role'] == 'base angle':
                # The owner-defined base-angle ends are the actual door/opening edge and the
                # adjacent upright edge. Keep the rendered/exported endpoints on those faces,
                # not at the supporting post centerlines used for the original setout.
                row.update(x0_in=a, x1_in=b, reference_span_in=length)
            row.update(
                blank_length_in=length,
                blank_length=fmt(length),
                reference_cut_in=length,
                reference_cut=fmt(length),
                field_fit_required=row['role'] != 'base angle',
                cut_basis=(
                    'OWNER-DEFINED DOOR/OPENING EDGE TO ADJACENT UPRIGHT EDGE; exact geometric blank length'
                    if row['role'] == 'base angle'
                    else 'STOCK BLANK to owner nominal insertion / known support envelope, not certified receiving-web contact'
                ),
                status=(
                    'BASE ANGLE: CUT FROM DOOR/OPENING EDGE TO ADJACENT UPRIGHT EDGE; ZERO-GAP SETOUT'
                    if row['role'] == 'base angle'
                    else 'FIELD-FIT BLANK: nominal2in jamb entry included; final end contact trimmed to actual receiver'
                ),
                estimated_weight_lb=round(length / 12 * row['weight_lb_ft'], 2)
                if row.get('weight_lb_ft') is not None
                else None,
            )
        for row in wall['members']:
            if row['role'] == 'base angle' and row.get('field_fit_required'):
                row['status'] = (
                    'SLAB ANGLE BLANK: known column footprints / opening envelopes cleared; junction field fit'
                )
                row['cut_basis'] = (
                    'STOCK BLANK between known column footprints / opening envelopes; slab junction field fit, no jamb insertion'
                )
        groups = {}
        for row in wall['members']:
            key = tuple(
                row.get(k) for k in ('role', 'profile_id', 'finish', 'reference_cut_in', 'blank_length_in', 'status')
            )
            if key not in groups:
                groups[key] = {
                    k: row[k]
                    for k in (
                        'role',
                        'profile_id',
                        'finish',
                        'reference_cut',
                        'reference_cut_in',
                        'blank_length',
                        'blank_length_in',
                        'status',
                    )
                }
                groups[key].update(cut_group='END-CUT-' + row['end'] + '-' + str(len(groups) + 1), quantity=0)
            groups[key]['quantity'] += row['quantity']
            row['cut_group'] = groups[key]['cut_group']
        wall['cuts'] = list(groups.values())
    for z in model['lean_tos']:
        layout = z.get('roof_purlin_layout')
        clip = job.parts.get(p.purlin_clip)
        retained = None
        welded_in = bool(layout and (layout.get('in_channel') or z.get('purlins_in_channel')))
        if welded_in:
            # Shop rule: purlins IN the rafter channel (or flush between the W flanges), welded -
            # there is no purlin clip on this lean.
            z['roof_clip_schedule'] = []
            clip = None
        if layout and p.connection_style != 'bolted' and not welded_in:
            retained = next(
                (x for x in z.get('low_connection_parts', []) if x['role'] == 'RETAINED PLUMB EAVE START CLIP'), None
            )
            if p.clip_policy == 'member_sized':
                from .girt_clips import weld_clip

                clip = weld_clip(job, z['purlin_depth_in'])
        if layout and clip and p.connection_style != 'bolted':
            z['roof_clip_schedule'] = []
            for row in layout['rows']:
                if row.get('shared_main_eave'):
                    continue
                for st in z['stations']:
                    last = st['index'] == len(z['stations'])
                    first = st['index'] == 1
                    q = 1 if first or last else 2
                    low = abs(row['horizontal_out_in'] - z['projection_in']) < 1e-6
                    shared = low and retained is not None
                    if shared:
                        q = 0  # existing low-connection clip already counted; do not add four new end clips
                    z['roof_clip_schedule'].append(
                        dict(
                            shared_low_connection=shared,
                            shared_quantity=1 if shared else 0,
                            mark=p.column_mark + '-' + z['id'] + '-RPC' + str(len(z['roof_clip_schedule']) + 1),
                            row=row['mark'],
                            station_in=st['x_in'],
                            part_mark=clip.mark,
                            quantity=q,
                            thickness_in=float(clip.thk.inches),
                            width_in=float(clip.width.inches),
                            length_in=float(clip.length.inches),
                            mount='LOW COLUMN / CAP' if low else 'RAFTER — SAME SELECTED ROOF CLIP',
                            hand='RETAINED LOW CONNECTION / COUNTED ONCE THERE'
                            if shared
                            else 'INWARD'
                            if first or last
                            else 'ONE EACH SIDE OF BUTT',
                            roof_top_in=z['high_eave_in'] - row['horizontal_out_in'] * z['pitch'] / 12,
                            status='Selected solid roof clip blank; position to actual purlin web and cap/rafter contact; no hole pattern invented',
                        )
                    )
        walls = z.get('walls') or {}
        z['open_wall_scope'] = all(walls.get(k, 'open') == 'open' for k in ('outer', 'start_end', 'finish_end'))
        if z.get('roof_continuity') == 'main_plane' and not z.get('transition_template'):
            # already resolved in framing_additions.finish (v0.8.35); kept for older saved models
            z['transition_trim'].update(
                quantity=0,
                pieces_in=[],
                status='NOT APPLICABLE: the lean roof continues the main roof plane; no wall-to-roof transition',
            )
            z['transition_not_applicable'] = True
            z['issues'] = [t for t in z['issues'] if not t.startswith('Wall-to-roof transition profile')]
        if z['open_wall_scope']:
            z['issues'] = [
                t for t in z['issues'] if 'remain unquantified' not in t and 'wall girts remain held' not in t
            ]
            z['scope_notes'] = [
                'Saved lean walls/ends OPEN: no wall panels, wall girts or wall-base/rake supports requested.',
                'Continuous roof sheet/eave/rake quantities are counted in the combined main roof, not twice.',
                'Roof purlin cuts and high/low frame cuts/plates are scheduled; connection capacity is separate; bracing BY OTHERS.',
            ]
    for o in model['openings']:
        if o.get('bearing_jambs'):
            wall = walls.get('front_end' if o['face'] == 'front' else 'rear_end', {})
            jamb_rows = [
                r
                for r in wall.get('members', [])
                if r.get('opening_id') == o['id'] and r['role'] == 'roof-bearing opening jamb'
            ]
            heads_resolved = len(jamb_rows) == 2 and all(
                (r.get('head_contact_geometry') or {}).get('geometry_status') == 'CONTACT PLANES RESOLVED'
                for r in jamb_rows
            )
            if heads_resolved:
                o['issues'] = [t for t in o['issues'] if not t.startswith('Shared roof-bearing jambs set out')]
                o['status'] = (
                    'BEARING-JAMB HEADS AND HEADER ENDS DIRECT-CONTACT SETOUT' if not o['issues'] else 'UNRESOLVED'
                )
                for m in o['members']:
                    if m.get('shared_member_ref'):
                        m['status'] = 'Shared endwall post; pitch-cut contact planes coincide; zero gap; count once'
                    elif m['role'] == 'HD':
                        m['header_end_joints'] = o.get('header_end_joints', [])
                        m['status'] = 'HEADER ENDS CUT TO SHARED-JAMB INSIDE FACES; ZERO GAP'
    for r in model.get('girt_interruptions', []):
        member = next(
            (
                m
                for w in walls.values()
                if isinstance(w, dict)
                for m in w.get('members') or []
                if m.get('mark') == r['mark']
            ),
            None,
        )
        if member and member.get('field_fit_required'):
            r.update(cut_length_in=member['blank_length_in'], status=member['status'], field_fit_required=True)
