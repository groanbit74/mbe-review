"""Owner material list and price book.

The program owns the material rows: quantity, length, size, shape, description, colour and
label.  Prices come only from a job price book (match text / supplier / basis / unit price /
sq.ft. price) or an explicit line edit.  Nothing without a price blocks a job -- the line is
simply reported UNPRICED, mirroring the ``#VALUE!`` cells in the owner's example sheet.
"""

from __future__ import annotations

import re

from .model import D

DEFAULT_JOB_COSTS = [
    "material",
    "labor",
    "walk",
    "rollup",
    "insulation",
    "wall light",
    "slab",
    "roof vent",
    "gutter",
]

_BASES = {"each", "ft", "sqft", "lb"}


def _num(value, label):
    if value in (None, ""):
        return None
    try:
        out = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be numeric: {value!r}") from exc
    if out < 0:
        raise ValueError(f"{label} cannot be negative: {value!r}")
    return out


def normalize(raw, *, strict=True):
    """Return a validated copy of a material-list / price-book settings dict."""

    raw = raw if isinstance(raw, dict) else {}
    book = []
    for i, entry in enumerate(raw.get("price_book") or []):
        if not isinstance(entry, dict) or not str(entry.get("match") or "").strip():
            if strict:
                raise ValueError(f"price book line {i + 1} needs a material match")
            continue
        basis = str(entry.get("basis") or "each").lower()
        if basis not in _BASES:
            raise ValueError(f"price book line {i + 1} basis must be one of {sorted(_BASES)}")
        book.append(
            {
                "match": str(entry["match"]).strip(),
                "supplier": str(entry.get("supplier") or "").strip().upper(),
                "basis": basis,
                "price": _num(entry.get("price"), f"price book line {i + 1} price"),
                "sqft_price": _num(entry.get("sqft_price"), f"price book line {i + 1} sq.ft. price"),
            }
        )
    edits = {}
    for key, entry in (raw.get("edits") or {}).items():
        if isinstance(entry, dict):
            edits[str(key)] = {
                "quantity": _num(entry.get("quantity"), f"line {key} quantity"),
                "price": _num(entry.get("price"), f"line {key} price"),
                "sqft_price": _num(entry.get("sqft_price"), f"line {key} sq.ft. price"),
                "label": str(entry.get("label") or ""),
                "note": str(entry.get("note") or ""),
                "removed": bool(entry.get("removed")),
            }
    custom = []
    for i, entry in enumerate(raw.get("custom_lines") or []):
        if not isinstance(entry, dict):
            continue
        custom.append(
            {
                "id": str(entry.get("id") or f"CUST-{i + 1}"),
                "quantity": _num(entry.get("quantity"), f"custom line {i + 1} quantity") or 0.0,
                "length_in": float(D(entry["length_in"]).inches) if entry.get("length_in") not in (None, "") else None,
                "size": str(entry.get("size") or ""),
                "shape": str(entry.get("shape") or ""),
                "description": str(entry.get("description") or ""),
                "color": str(entry.get("color") or ""),
                "label": str(entry.get("label") or ""),
                "price": _num(entry.get("price"), f"custom line {i + 1} price"),
                "sqft_price": _num(entry.get("sqft_price"), f"custom line {i + 1} sq.ft. price"),
                "basis": str(entry.get("basis") or "each"),
                "note": str(entry.get("note") or ""),
            }
        )
    costs = {}
    for label, value in (raw.get("job_costs") or {}).items():
        costs[str(label).strip().lower()] = _num(value, f"job cost {label}")
    return {"price_book": book, "edits": edits, "custom_lines": custom, "job_costs": costs}


def settings(job):
    return normalize((getattr(job, "settings", None) or {}).get("material_list"), strict=False)


def _size_shape(material, display, category=""):
    text = f"{material} {display}".upper()
    if category in ("plate", "clip", "flat_bar", "finished_clip"):
        return "", "Plate" if category != "finished_clip" else "Clip"
    m = re.search(r"PN(\d+(?:\.\d+)?)\s*(ZEE)?", text)
    if m:
        return f'{float(m.group(1)):g}"', "Zee" if m.group(2) else "C"
    m = re.search(r"Z-(\d+(?:\.\d+)?)X([\dP.]+)-G(\d+)", text)
    if m:
        return f'{float(m.group(1)):g}"', "Zee"
    m = re.search(r"C-(\d+(?:\.\d+)?)X([\dP.]+)-G(\d+)", text)
    if m:
        return f'{float(m.group(1)):g}"', "C"
    m = re.search(r"W(\d+)X([\d.]+)", text)
    if m:
        return f'{m.group(1)}"{float(m.group(2)):g}#', "Beam"
    m = re.search(r"HSS\s*(\d+(?:/\d+|X\d+)*)", text)
    if m:
        return m.group(1).replace("X", "x"), "Tube"
    if "CHANNEL" in text or re.search(r"\bC\d", text):
        return "", "Channel"
    if "ANGLE" in text:
        return "", "Angle"
    if any(token in text for token in ("PBR", "PNL", "RPN", "SHEET", "PANEL")):
        return "26 ga", "RPN"
    if "CLIP" in text:
        return "", "Clip"
    if "TRIM" in text or re.search(r"(^|\s)TR[A-Z]{2,}", text) or re.search(r"\bFL-\d", text):
        return "", "Trim"
    return "", ""


_TRIM_WORDS = (
    ("CORNER", "Corner Trim"),
    ("RAKE", "Rake Trim"),
    ("RIDGE", "Ridge Trim"),
    ("EAVE", "Eave Trim"),
    ("JAMB", "Jamb Trim"),
    ("HEAD", "Head Trim"),
    ("BASE", "Base Angle"),
    ("GUTTER", "Gutter"),
    ("DOWNSPOUT", "Downspout"),
)


def _description(row, material, display):
    text = f"{material} {display} {row.get('category') or ''}".upper()
    for token, word in _TRIM_WORDS:
        if token in text:
            return word
    category = str(row.get("category") or "")
    if category == "panel":
        return "Panel sheet"
    if category == "trim":
        return "Trim"
    text = display or material
    if " | AS DRAWN:" in text:
        text = text.split(" | AS DRAWN:")[0]
    if " | " in text:
        text = text.split(" | ", 1)[1]
    return text


def _label_for(references):
    text = " ".join(str(x or "") for x in references).upper()
    if "ROOF" in text and ("SHEET" in text or "PBR" in text):
        return "Roof sheet"
    if "SIDEWALL" in text:
        return "Side Wall"
    if "ENDWALL" in text:
        return "End Wall"
    if any(token in text for token in ("PURLIN", "-P-", "ROOF PURLIN")):
        return "Roof Purlin"
    if "GIRT" in text:
        return "Side girt"
    if "EAVE" in text:
        return "Eave strut"
    if any(str(r or "").strip().upper().startswith("COL-") for r in references):
        return "Column"
    if "RF-" in text or "RAFTER" in text:
        return "Rafter"
    if "ROOF" in text or text.startswith("RP"):
        return "Roof sheet"
    if "WALL" in text:
        return "Side Wall"
    if "END" in text:
        return "End wall"
    return ""


def _price_for(row, material, cfg):
    hay = f"{row.get('supplier') or ''} {material} {row.get('display_material') or ''}".upper()
    for entry in cfg["price_book"]:
        if entry["supplier"] and entry["supplier"] not in str(row.get("supplier") or "").upper():
            continue
        if entry["match"].upper() in hay:
            return entry
    return None


def _extended(row, quantity, length_in, price, sqft_price, basis):
    if price is None and sqft_price is None:
        return None
    length_ft = (length_in or 0.0) / 12.0
    total = 0.0
    if price is not None:
        if basis == "ft":
            total += price * quantity * length_ft
        elif basis == "sqft":
            total += price * quantity * length_ft * 3.0  # PBR coverage width
        else:
            total += price * quantity
    if sqft_price is not None:
        total += sqft_price * quantity * length_ft * 3.0
    return round(total, 2)


def material_list(job, plan=None):
    """Build owner-style material-list rows from a supplier plan (built if not given)."""

    from .ordering import build, fmt

    plan = plan or build(job)
    from .purchasing import supplier_plan

    sp = supplier_plan(job, plan)
    cfg = settings(job)
    internal = {item.get("order_id"): item for item in plan.get("items", [])}
    by_supplier = {}
    for link in sp.get("crosswalk", []):
        by_supplier.setdefault(link["supplier_id"], []).append(link["internal_order_id"])
    # CAB1 / 2x4 angle is bought for two different jobs: base angle (slab) and rake angle
    # (bypass end walls).  On a post-hole building there is no base angle at all.
    _has_base = False
    _has_rake = False
    for asm in (getattr(job, "assemblies", None) or {}).values():
        fa = (asm.derivation or {}).get("framing_additions") or {}
        _has_base = (
            _has_base
            or bool(fa.get("base_supports"))
            or any(
                pc.get("role") == "base_angle"
                for pc in ((asm.derivation or {}).get("secondary_runs") or {}).get("pieces", [])
            )
        )
        _has_rake = _has_rake or bool(fa.get("rake_angles"))
    rows = []
    for order in sp.get("rows", []):
        order = dict(order, order_ids=by_supplier.get(order.get("supplier_id"), []))
        material = order.get("material") or order.get("supplier_id") or ""
        display = order.get("display_material") or material
        size, shape = _size_shape(material, display, str(order.get("category") or ""))
        lengths = order.get("lengths") or [
            {"quantity": order.get("quantity") or 0, "length_in": order.get("length_in")}
        ]
        for slot, entry in enumerate(lengths):
            quantity = float(entry.get("quantity") or 0)
            if not quantity:
                continue
            length_in = entry.get("length_in")
            key = f"{material}|{length_in if length_in is not None else ''}|{slot}"
            refs = []
            for order_id in order.get("order_ids", []):
                item = internal.get(order_id) or {}
                refs.append(item.get("references") or "")
                refs.extend(f"{use.get('mark', '')} {use.get('location', '')}" for use in item.get("uses") or [])
            label = _label_for(refs)
            matched = _price_for(order, material, cfg)
            edit = cfg["edits"].get(key) or {}
            if edit.get("removed"):
                continue
            quantity = edit.get("quantity") if edit.get("quantity") is not None else quantity
            price = edit.get("price") if edit.get("price") is not None else (matched or {}).get("price")
            sqft_price = (
                edit.get("sqft_price") if edit.get("sqft_price") is not None else (matched or {}).get("sqft_price")
            )
            basis = (matched or {}).get("basis") or "each"
            rows.append(
                {
                    "key": key,
                    "quantity": quantity,
                    "length_in": length_in,
                    "length": fmt(length_in) if length_in is not None else "",
                    "size": size,
                    "shape": shape,
                    "description": (
                        ("Rake Angle" if _has_rake and not _has_base else "Base Angle")
                        if ("CAB" in material or "Angle-2x4" in material)
                        else label or _description(order, material, display)
                    ),
                    "color": order.get("finish") or "",
                    "label": edit.get("label") or label,
                    "price": price,
                    "sqft_price": sqft_price,
                    "basis": basis,
                    "extended": _extended({}, quantity, length_in, price, sqft_price, basis),
                    "supplier": order.get("supplier") or "",
                    "supplier_label": (
                        f"{order['supplier_code']} — {order['supplier_item']}"
                        if order.get("supplier_code")
                        and order.get("supplier_item")
                        and order["supplier_code"] not in order["supplier_item"]
                        else order.get("supplier_item") or order.get("supplier_code") or material
                    ),
                    "material": material,
                    "note": edit.get("note") or ("price book" if matched else ""),
                    "status": "PRICED" if (price is not None or sqft_price is not None) else "UNPRICED",
                }
            )
    for entry in cfg["custom_lines"]:
        rows.append(
            {
                "key": entry["id"],
                "quantity": entry["quantity"],
                "length_in": entry["length_in"],
                "length": fmt(entry["length_in"]) if entry["length_in"] is not None else "",
                "size": entry["size"],
                "shape": entry["shape"],
                "description": entry["description"],
                "color": entry["color"],
                "label": entry["label"],
                "price": entry["price"],
                "sqft_price": entry["sqft_price"],
                "basis": entry["basis"],
                "extended": _extended(
                    {}, entry["quantity"], entry["length_in"], entry["price"], entry["sqft_price"], entry["basis"]
                ),
                "supplier": "",
                "supplier_label": "",
                "material": entry["id"],
                "note": entry["note"] or "manual line",
                "status": "PRICED" if (entry["price"] is not None or entry["sqft_price"] is not None) else "UNPRICED",
            }
        )
    job_rows = []
    for label in DEFAULT_JOB_COSTS:
        amount = cfg["job_costs"].get(label)
        job_rows.append(
            {
                "key": f"job|{label}",
                "quantity": 1,
                "length_in": None,
                "length": "",
                "size": "",
                "shape": "",
                "description": label,
                "color": "",
                "label": label,
                "price": amount,
                "sqft_price": None,
                "basis": "each",
                "extended": amount,
                "supplier": "",
                "supplier_label": "",
                "material": "",
                "note": "job estimate line (not material)",
                "status": "PRICED" if amount is not None else "UNPRICED",
                "job_cost": True,
            }
        )
    material_total = round(sum(r["extended"] or 0 for r in rows), 2)
    job_cost_total = round(sum(r["extended"] or 0 for r in job_rows if r["description"] != "material"), 2)
    return {
        "rows": rows,
        "job_cost_rows": job_rows,
        "totals": {
            "material_total": material_total,
            "job_cost_total": job_cost_total,
            "grand_total": round(material_total + job_cost_total, 2),
            "priced_lines": sum(1 for r in rows if r["status"] == "PRICED"),
            "unpriced_lines": sum(1 for r in rows if r["status"] == "UNPRICED"),
        },
        "price_book": cfg["price_book"],
    }
