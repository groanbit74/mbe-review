"""Read-only purchasing -> stock -> existing cut mark -> physical location links.
No invented install locations. Ambiguous lots remain explicitly unresolved.
"""

import re
from collections import defaultdict

from .ordering import fmt
from .purlin_lay import bays_text


def enrich(job, p):
    from .purchasing import supplier_plan

    sp = supplier_plan(job, p)
    sid = {r['internal_order_id']: r['supplier_id'] for r in sp['crosswalk']}
    locations = defaultdict(list)

    def add(owner, mark, where, piece='', drawing=None):
        locations[(owner, mark)].append(dict(location=where, piece_id=piece or mark, drawing=drawing))

    for fid, cfg in job.settings.get('frames', {}).items():
        a = job.assemblies.get(fid)
        if not a:
            continue
        d = a.derivation
        layout = job.settings.get('frame_layouts', {}).get(fid, {})
        stations = d.get('bay_zones', {}).get('primary_frame_stations_in')
        if stations is None:
            stations = [r['station_in'] for r in d.get('secondary_runs', {}).get('support_lines', [])[1:-1]]
        for kind in ('columns', 'rafters'):
            for station in stations:
                for r in layout.get(kind, []):
                    asm = job.assemblies.get(r['mark'])
                    if asm:
                        add(
                            asm.mark,
                            asm.main.mark,
                            f'{fid} main {kind[:-1]}, {r["side"]} across frame; line at {fmt(station)} from outer left end',
                            drawing=dict(kind='frame', name=fid),
                        )
        for key, w in d.get('endwalls', {}).items():
            for r in w['members']:
                for n in range(r.get('quantity', 1)):
                    add(
                        fid,
                        r['mark'],
                        f'{w.get("endwall_name", key)}, station {fmt(w.get("station_in", 0))}; {r["role"]}, transverse X {fmt(r["x0_in"])} to {fmt(r["x1_in"])}',
                        drawing=dict(kind='endwall', name=fid + '~' + key),
                    )
        for r in d.get('secondary_runs', {}).get('pieces', []):
            add(
                fid,
                r.get('cut_mark', ''),
                f'{r.get("elevation", r["side"])} {r["role"]}; bay {bays_text(r)}, stations {fmt(r["support_start_in"])}–{fmt(r["support_end_in"])}; row {r["run_id"]}, elevation {fmt(r["floor_y_in"])}',
                r['piece_id'],
                dict(kind='runs', name=fid),
            )
        for r in d.get('secondary_runs', {}).get('pieces', []):
            if r.get('cut_mark') != r['piece_id']:
                source = locations[(fid, r.get('cut_mark', ''))]
                match = next(x for x in source if x['piece_id'] == r['piece_id'])
                locations[(fid, r['piece_id'])].append(dict(match))
        for r in d.get('framing_additions', {}).get('rake_angles', []) + d.get('framing_additions', {}).get(
            'base_supports', []
        ):
            for n in range(r.get('quantity', 1)):
                add(
                    fid,
                    r['mark'],
                    f'{r.get("owner", fid)} / {r.get("face", "wall")} / sheet support',
                    drawing=dict(kind='building', name=fid),
                )
        for i, z in enumerate(d.get('framing_additions', {}).get('lean_tos', [])):
            owner = fid + ' ' + z['id']
            for r in z['members']:
                matches = [
                    st
                    for st in z['stations']
                    if r['mark'].startswith(fid + '-' + z['id'] + '-' + str(st['index']) + '-')
                ]
                for n in range(r.get('quantity', 1)):
                    if len(matches) == 1:
                        where = f'{z["id"]} {z["face"]} lean, {r["role"]}; station {fmt(matches[0]["x_in"])} along attachment wall'
                        for own in (owner, fid):
                            add(
                                own,
                                r['mark'],
                                where,
                                drawing=dict(kind='additions', name=fid + '~lean~' + str(i) + '~1'),
                            )
            for r in z.get('roof_purlin_layout', {}).get('pieces', []):
                for own in (owner, fid):
                    add(
                        own,
                        r['mark'],
                        f'{z["id"]} roof purlin row {r["row"]}, bay {bays_text(r)}; {fmt(r["start_in"])}–{fmt(r["end_in"])} along wall, {fmt(r["horizontal_out_in"])} out',
                        drawing=dict(kind='additions', name=fid + '~lean~' + str(i) + '~1'),
                    )
        for o in d.get('framing_additions', {}).get('openings', []):
            for r in o['members']:
                if r.get('shared_member_ref'):
                    continue
                for own in (fid, fid + ' ' + o['id']):
                    add(
                        own,
                        r['mark'],
                        f'Opening {o["id"]}, {o["face"]} wall; {r.get("role", "opening member")}',
                        drawing=dict(kind='frame', name=fid),
                    )

    def resolve(owner, mark, instance, quantity):
        rows = locations.get((owner, mark), [])
        if len(rows) == quantity and 0 < instance <= len(rows):
            return dict(rows[instance - 1], location_status='RESOLVED')
        return dict(
            location='LOCATION REVIEW: ' + owner + ' / ' + mark + '; physical instance assignment not resolved',
            piece_id=mark + ' #' + str(instance),
            drawing=None,
            location_status='UNRESOLVED',
        )

    demands = {(r['owner'], r['mark']): r for r in p['demands']}
    bystock = {}
    for item in p['items']:
        item['supplier_id'] = sid[item['order_id']]
        for ref in item['references'].split('; '):
            if ref.startswith('STOCK-'):
                bystock[ref] = item
    rows = []
    for bar in p['bars']:
        item = bystock.get(bar['stock_id'])
        if not item:
            raise ValueError('Stock has no purchasing reference: ' + bar['stock_id'])
        bar['supplier_id'] = item['supplier_id']
        bar['order_id'] = item['order_id']
        for cut in bar['cuts']:
            demand = demands[(cut['owner'], cut['cut_mark'])]
            cut.update(resolve(cut['owner'], cut['cut_mark'], cut['instance'], demand['quantity']))
            cut.update(supplier_id=item['supplier_id'], order_id=item['order_id'])
            rows.append(
                dict(
                    cut,
                    stock_length_in=bar['stock_length_in'],
                    material=bar['profile'],
                    remnant_in=bar['remnant_in'],
                    kerf_loss_in=bar['kerf_loss_in'],
                    end_loss_in=bar['end_loss_in'],
                )
            )
    # Exact/custom linear orders have no stock bar, but retain their marks and locations.
    for item in p['items']:
        mark = item.get('custom_mark')
        if not mark:
            continue
        ds = [d for d in p['demands'] if d['mark'] == mark and d['material_group'] == item['material_group']]
        for d in ds:
            for n in range(1, d['quantity'] + 1):
                rows.append(
                    dict(
                        supplier_id=item['supplier_id'],
                        order_id=item['order_id'],
                        stock_id='CUSTOM',
                        cut_mark=mark,
                        owner=d['owner'],
                        instance=n,
                        cut_sequence=n,
                        start_in=0,
                        blank_length_in=d['blank_length_in'],
                        stock_length_in=item['order_length_in'],
                        material=d['profile'],
                        remnant_in=0,
                        kerf_loss_in=0,
                        end_loss_in=0,
                        **resolve(d['owner'], mark, n, d['quantity']),
                    )
                )
    # Nonlinear goods retain source marks and related assemblies/physical setouts.
    uses = defaultdict(list)
    for fid, asm in job.assemblies.items():
        d = asm.derivation
        for r in d.get('wall_girt_connections', []):
            if r['quantity']:
                uses[r['clip']].append(
                    dict(
                        mark=r['mark'],
                        location=r['face']
                        + ' wall / '
                        + r['main_mark']
                        + ' / face coordinate '
                        + fmt(r['station_in'])
                        + ', elevation '
                        + fmt(r['elevation_in']),
                        drawing=dict(kind='frame', name=fid),
                    )
                )
        for panel in d.get('cladding', {}).get('panels', []):
            use = dict(
                mark=panel['mark'],
                location=panel.get('elevation', panel['surface'])
                + ' / sheet X '
                + fmt(panel['x0_in'])
                + '–'
                + fmt(panel['x1_in']),
                drawing=dict(kind='building', name=fid),
            )
            uses[panel.get('order_group', panel['mark'])].append(use)
            uses[panel['mark']].append(use)
        runs = {r['mark']: r for r in d.get('cladding', {}).get('trim_runs', [])}
        for r in d.get('cladding', {}).get('trim_pieces', []):
            run = runs.get(r['run_mark'], {})
            uses[r['mark']].append(
                dict(
                    mark=r['mark'],
                    location=r.get('elevation', r['surface'])
                    + ' / '
                    + run.get('location', r['role'])
                    + ' / run '
                    + r['run_mark']
                    + ' / cut '
                    + r['cut_length'],
                    drawing=dict(kind='building', name=fid),
                )
            )
        for o in d.get('framing_additions', {}).get('openings', []):
            uses[fid + ' ' + o['id']].append(
                dict(
                    mark=o['id'],
                    location=o.get('elevation', o['face'])
                    + ' / opening X '
                    + fmt(o['x_in'])
                    + '; clear '
                    + fmt(o['width_in'])
                    + ' x '
                    + fmt(o['height_in']),
                    drawing=dict(kind='frame', name=fid),
                )
            )
        for i, z in enumerate(d.get('framing_additions', {}).get('lean_tos', [])):
            for r in z.get('roof_clip_schedule', []):
                uses[r['part_mark']].append(
                    dict(
                        mark=r['mark'],
                        location=z['id']
                        + ' roof clip / row '
                        + r['row']
                        + ' / station '
                        + fmt(r['station_in'])
                        + ' / '
                        + r['hand'],
                        drawing=dict(kind='additions', name=fid + '~lean~' + str(i) + '~1'),
                    )
                )
            for r in z.get('low_connection_parts', []):
                for st in z['stations']:
                    uses[r['part']['mark']].append(
                        dict(
                            mark=r['part']['mark'],
                            location=z['id'] + ' outer-column low connection at station ' + fmt(st['x_in']),
                            drawing=dict(kind='additions', name=fid + '~low_detail~' + str(i) + '~1'),
                        )
                    )
    for mark, part in job.parts.items():
        owner = part.symbol.get('owner')
        cfg = job.settings.get('connections', {}).get(owner or mark, {})
        if owner and cfg:
            uses[mark].append(
                dict(
                    mark=mark,
                    location='Connection '
                    + owner
                    + ' / frame '
                    + str(cfg.get('frame_id', ''))
                    + '; see connection detail',
                    drawing=dict(kind='connection', name=owner),
                )
            )
        else:
            for asm in job.assemblies.values():
                if any(att.part == mark for att in asm.attachments):
                    uses[mark].append(
                        dict(
                            mark=mark,
                            location='Assembly template '
                            + asm.mark
                            + ' (reference, not extra quantity); '
                            + (
                                '; '.join(r['location'] for r in locations.get((asm.mark, asm.main.mark), []))
                                or 'physical stations require review'
                            ),
                            drawing=dict(kind='assembly', name=asm.mark),
                        )
                    )
    for item in p['items']:
        refs = item['references'] + ' ' + item['material']
        related = []
        for key, records in uses.items():
            if re.search(r'(?<![A-Za-z0-9_-])' + re.escape(key) + r'(?![A-Za-z0-9_-])', refs):
                related.extend(records)
        unique = {(r['mark'], r['location']): r for r in related}
        item['uses'] = list(unique.values())
        item['location_status'] = (
            'RELATED REFERENCES' if unique else 'SEE STOCK CUTS' if 'STOCK-' in refs else 'LOCATION REVIEW'
        )
    p['piece_trace'] = rows
    p['trace_note'] = (
        'Supplier/stock IDs apply to this job revision. Existing fabrication marks retained. Unresolved physical locations are explicit review entries, not guessed assignments. Nonlinear goods keep their source references in the supplier crosswalk.'
    )
    return p
