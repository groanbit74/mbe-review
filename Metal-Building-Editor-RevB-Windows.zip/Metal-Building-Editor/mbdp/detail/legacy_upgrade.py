"""Open jobs saved by older versions and convert them to the current shop standard (v0.8.41).

Two entry points:

* :func:`upgrade` - rewrites the saved frame parameters of a job in place (lean-to high
  connection, products of another supplier, stale rule stamps) and regenerates every frame.
  Returns the list of human-readable changes; an empty list means nothing had to change.
* :func:`open_or_upgrade` - what the editor does when a job is opened or filed: try the job as
  saved; when the current rules reject it, upgrade it and try again.  The changes are kept in
  ``job.settings['upgrade_log']`` so the owner can see what the program did to the job.

Rules applied (each one is reported):

* MBCI (or any non-SSS) secondary profiles, panels, colors and trims are replaced by the SSS
  product of the same family and depth - the unique match the *Supplier products* preview would
  suggest, else the shop standard for that role (Z purlin of the same depth, 8 in eave strut,
  CAB1 base angle, PBR panel, shop colors, the standard trim of that role).  The job-wide
  supplier policy becomes SSS primary.
* A lean-to whose high connection was the pre-0.8.34 clip (``high_clip_fit`` ``legacy`` /
  ``gap_overlap``) is set to the standard: rafter welded directly to the main column.  The
  2 in clip stays selectable as the option in the lean-to dialog.
* A bay layout stamped with an older lap-rule hash is re-applied with the current rules.
* Frames are regenerated with the current rules; nothing else in the inputs is touched - girt
  lines, openings, bays, colors the user chose stay as entered.
"""

from __future__ import annotations

import copy

from .model import Job

LEGACY_CLIP_FITS = ('legacy', 'gap_overlap')

# shop standard per surface when a color of another supplier has no SSS namesake
STANDARD_COLORS = {
    'wall_finish': 'SSS / Light Stone',
    'roof_finish': 'SSS / Galvalume Plus',
    'trim_finish': 'SSS / Burnished Slate',
}
STANDARD_TRIMS = {
    'corner': 'SSS-TRCRS',
    'rake': 'SSS-TRRKTSTD',
    'eave': 'SSS-TRETSTD',
    'high_eave': 'SSS-TRETHS',
    'ridge': 'SSS-TRRCF',
    'jamb': 'SSS-TRDJMBT',
    'head': 'SSS-TRDHT',
}


def _standard_secondary(old: dict) -> str:
    """The SSS product that stands in for a non-SSS secondary profile."""
    family = old.get('family')
    depth = float(old.get('nominal_depth_in') or 8)
    nearest = min((4, 6, 8, 10), key=lambda d: abs(d - depth))
    if family == 'Z':
        return 'SSS-PN%dZEE-F2' % nearest
    if family == 'C':
        return 'SSS-PN%d' % nearest if nearest != 4 else 'SSS-PN42'
    if family == 'Channel':
        return 'SSS-SS%d214' % nearest
    if family == 'Eave':
        kind = str(old.get('eave_kind') or old.get('id') or '')
        return 'SSS-PN8SSES-high_single' if 'high' in kind else 'SSS-PN8SSES-low_single'
    if family == 'Angle':
        return 'SSS-CAB1'
    return 'SSS-PN%dZEE-F2' % nearest


def _choices(proposal: dict) -> tuple[dict, list[str]]:
    """Pick the SSS replacement for every field of a *Supplier products* proposal."""
    choices, notes = {}, []
    for f in proposal['fields']:
        ids = {o['id'] for o in f['options']}
        new = f.get('suggested') or ''
        if f['type'] == 'color':
            name = str(f['old']).split('/', 1)[-1].strip()
            same = next((i for i in ids if i.split('/', 1)[-1].strip().lower() == name.lower()), '')
            surface = next((u.split('/')[-2] for u in f['uses'] if '/' in u), 'wall_finish')
            new = same or STANDARD_COLORS.get(surface, STANDARD_COLORS['wall_finish'])
            if new not in ids:
                new = next(iter(sorted(ids)), '')
        elif f['type'] == 'trim':
            role = f['uses'][0].split('/')[-1] if f['uses'] else ''
            if not new:
                new = STANDARD_TRIMS.get(role, '')
            if new not in ids:
                new = next((i for i in sorted(ids) if i != '__PENDING__'), '__PENDING__')
        else:
            if not new:
                from .secondary_catalog import get

                try:
                    new = _standard_secondary(get(f['old']))
                except Exception:
                    new = ''
            if new not in ids:
                new = next(iter(sorted(ids)), '')
        if not new:
            raise ValueError('No SSS product stands in for ' + str(f['old']) + ' (' + f['category'] + ')')
        choices[f['key']] = new
        notes.append(
            '%s %s -> %s%s'
            % (
                f['type'].upper(),
                f['old'],
                'not ordered (pending)' if new == '__PENDING__' else new,
                ' (used by %s)' % ', '.join(f['uses'][:3]) if f.get('uses') else '',
            )
        )
    return choices, notes


def _frame_rules(raw: dict, fid: str) -> list[str]:
    """Parameter rewrites that need no catalog: lean-to high connection, stale stamps."""
    notes = []
    for z in (raw.get('additions') or {}).get('lean_tos') or []:
        if not isinstance(z, dict):
            continue
        if z.get('high_connection') == 'clip' and z.get('high_clip_fit', 'owner_gap') in LEGACY_CLIP_FITS:
            z['high_connection'] = 'welded_direct'
            notes.append(
                '%s lean-to %s: high connection was the pre-0.8.34 clip (%s) - set to the shop standard, '
                'rafter welded directly to the main column (the 2 in welded clip stays available as the option)'
                % (fid, z.get('id') or '?', z.get('high_clip_fit'))
            )
    layout = raw.get('bay_layout')
    if isinstance(layout, dict) and layout.get('rule_sha256'):
        from .secondary_runs import evidence

        if layout['rule_sha256'] != evidence()['sha256']:
            layout.pop('rule_sha256', None)
            notes.append('%s: bay layout re-applied with the current lap rules (older rule stamp dropped)' % fid)
    return notes


def upgrade(job: Job) -> list[str]:
    """Convert *job* to the current shop standard in place; returns the change list."""
    from . import supplier_products as SP
    from .frame import FrameParams, generate_frame

    notes: list[str] = []
    frames = job.settings.get('frames') or {}
    for fid, raw in frames.items():
        notes.extend(_frame_rules(raw, fid))
    policy = job.settings.get('product_suppliers') or {}
    cfg = {'primary': 'sss', 'secondaries': 'sss', 'sheets': 'sss', 'trim': 'sss'}
    proposal = SP.plan(job, cfg) if frames else {'fields': []}
    if proposal['fields'] or policy.get('primary') not in (None, 'sss'):
        choices, product_notes = _choices(proposal)
        work = SP.apply(job, cfg, choices)
        job.settings = work.settings
        job.parts = work.parts
        job.assemblies = work.assemblies
        notes.extend(product_notes)
        if policy.get('primary') not in (None, 'sss'):
            notes.append('supplier policy %s -> SSS primary' % (policy.get('primary') or 'none'))
    else:
        for fid, raw in list(frames.items()):
            generate_frame(job, FrameParams.from_json(copy.deepcopy(raw)))
    if notes:
        from .. import __version__

        log = job.settings.setdefault('upgrade_log', [])
        log.append({'version': __version__, 'changes': notes})
    return notes


def open_or_upgrade(job: Job) -> list[str]:
    """Prepare a saved job for the editor: as saved when the current rules accept it, otherwise
    upgraded.  Returns the change list (empty when the job opened as saved)."""
    from .connections import rebuild
    from .frame import sync_frames

    try:
        sync_frames(job)
        rebuild(job)
        return []
    except Exception as first:
        saved = job.dumps()
        try:
            notes = upgrade(job)
            sync_frames(job)
            rebuild(job)
        except Exception as second:
            restored = Job.loads(saved)
            job.settings, job.parts, job.assemblies = restored.settings, restored.parts, restored.assemblies
            raise ValueError(
                'This job was saved by an older version and cannot be opened as saved (%s); the automatic '
                'conversion to the shop standard failed too (%s). Open it in the version that saved it, or '
                'rebuild it from a sample.' % (first, second)
            ) from second
        return notes or ['regenerated with the current rules (the saved version was rejected: %s)' % first]
