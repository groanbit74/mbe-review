"""Owner-selected FL-1010 reference, modified A=4; formed-to-length order, not NC blank."""

ID = 'OWNER-FL1010-A4'


def profile():
    return dict(
        id=ID,
        role='rake',
        label='CUSTOM FL-1010 residential rake / A=4in',
        stock_length_in=246,
        pdf_page=54,
        default_gauge=26,
        signature300_gauge=26,
        custom_length_only=True,
        face_a_in=4,
        top_leg_in=3,
        roof_leg_in=1.75,
        toe_in=0.75,
        top_hem_in=0.5,
        bottom_return_in=0.625,
        bottom_hem_in=0.5,
        reference_girth_in=11.125,
        source_face_a_in=3.6875,
        source_girth_in=10.8125,
        source_roof_pitch='3-4:12 catalog FL-1010; OWNER CUSTOM A=4 formed for job pitch',
        note='Owner FL-1010 reference with A=4. Other legs per MBCI printed54. Exact lengths/max20ft6 are owner order rules, not catalog stock SKU. Supplier develops bend allowances; no machine flat blank.',
        source='docs/reference/mbci/pbr/PBR-Panels-and-Trim-Catalog-Extract.pdf page5 / printed54 /2026-03-04',
    )
