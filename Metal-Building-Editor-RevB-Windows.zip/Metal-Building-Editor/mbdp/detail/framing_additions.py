"""User-directed lean-to setout, upright clearance and opening member references.
No capacity selection, primary cutting or silent structural splice. All coordinates inches.
"""

import copy
import math
import re

from .building import name as face_name
from .cladding import EPS, fmt, inch
from .endwalls import TUBE_SIZES, WALLS, rafter_profile, wprofile
from .secondary_catalog import get as secondary

FACES = ('front', 'rear', 'left', 'right')


def profile(value):
    value = str(value).strip()
    if not value:
        return None
    if value.upper().startswith('W'):
        return wprofile(value)
    if value.startswith('UNLIPPED:'):
        p = profile(value.split(':', 1)[1])
        return dict(p, id=value, open_face=True, weight_lb_ft=None)
    if value.startswith(('MBCI-', 'SSS-')):
        p = secondary(value)
        if p['family'] not in ('C', 'Channel'):
            raise ValueError('Select an open Cee, not Zee/eave/angle, for this member')
        return dict(
            id=value,
            family='C',
            depth=p['nominal_depth_in'],
            width=max(p['flanges_in']),
            wall=str(p['gauge']) + ' ga',
            weight_lb_ft=p['weight_lb_ft'],
            open_face=p.get('open_face', False),
            doubled=bool(p.get('doubled')),
            single=p.get('single') or value,
        )
    m = re.fullmatch(r'HSS\s+(\d+x\d+)\s+x\s+(.+)', value, re.I)
    if not m:
        raise ValueError('Profile must be a catalog W, MBCI Cee ID, or HSS 4x4 x 1/4 (for example)')
    size = m[1].lower()
    wall = m[2].strip()
    if size not in TUBE_SIZES or wall not in WALLS:
        raise ValueError('Unsupported requested HSS size/wall label')
    a, b = map(float, size.split('x'))
    return dict(id='HSS ' + size + ' x ' + wall, family='HSS', depth=b, width=a, wall=wall, weight_lb_ft=None)


def station_rafter(r, rf, i, n):
    """Rafter section at lean frame line ``i`` (0-based of ``n``): ``(profile, pair)``.

    A ``special_open_c`` end is always a single open-face channel matched to the lean purlin
    depth and supplier.  This endpoint rule is independent of the default/interior rafter and of
    the purlin bypass/flush setting.  Elsewhere, ``rafter_lines`` may select a W, single channel,
    or doubled channel; the default rafter is used when no per-line selection is saved.
    """
    if n > 1 and i in (0, n - 1) and r.get('end_rafter_style') == 'special_open_c':
        from .standards import channel_end_rafter

        purlin_id = str((r.get('roof_purlins') or {}).get('profile_id') or '')
        supplier = 'mbci' if purlin_id.upper().startswith('MBCI-') else 'sss'
        channel_id = channel_end_rafter(float(r.get('purlin_depth_in') or 0), supplier)
        return profile(channel_id), 1
    pick = str((r.get('rafter_lines') or {}).get(str(i + 1), '') or '').strip()
    if pick:
        pr = profile(pick)
        if pr and pr.get('doubled'):
            return dict(profile(pr['single']), line_pick=pick), 2
        return pr, 1
    if not rf:
        return None, 1
    return rf, (2 if rf['family'] == 'C' and 0 < i < n - 1 else 1)


def station_fit(r, pr, pair):
    """Purlin fit at one lean frame line: ``(in_channel, deduction_in, kind)``.

    Open-face channels (single or doubled) ALWAYS carry the purlins IN the channel - rafter top =
    roofline, no deduction.  A W (or lipped Cee) follows the lean's roof secondary fit: flush =
    purlins between the flanges welded to the web (rafter top = roofline), bypass = purlins over
    the rafter (rafter top = roofline - purlin depth).
    """
    if not pr:
        return False, 0.0, ''
    if pr['family'] == 'C' and (pr.get('open_face') or pr.get('doubled') or pair == 2):
        return True, 0.0, 'channel'
    if r.get('purlin_mode', 'flush') == 'flush':
        return False, 0.0, 'flush'
    return False, float(r['purlin_depth_in']), 'bypass'


def rafter_line_options(r, rf, n):
    """Per-line summary used by the drawings / UI: one record per lean frame line."""
    out = []
    for i in range(n):
        pr, pair = station_rafter(r, rf, i, n)
        in_channel, ded, kind = station_fit(r, pr, pair)
        special_end = bool(r.get('end_rafter_style') == 'special_open_c' and n > 1 and i in (0, n - 1))
        out.append(
            dict(
                station=i + 1,
                profile_id=pr['id'] if pr else '',
                family=pr['family'] if pr else '',
                pair=pair,
                depth_in=pr['depth'] if pr else 0.0,
                in_channel=in_channel,
                purlin_deduction_in=ded,
                fit=kind,
                special_open_c=special_end,
                override=bool((r.get('rafter_lines') or {}).get(str(i + 1))) and not special_end,
                label=(
                    '' if not pr else (pr['id'] + ' x2 (two welded back to back, I shape)' if pair == 2 else pr['id'])
                ),
            )
        )
    return out


def width(p, face):
    return (
        float(p.width.inches)
        if face in ('front', 'rear')
        else float(p.length.inches)
        if p.length
        else float(p.cladding.get('length_in', 0))
    )


def roof_height(p, face, x):
    W = float(p.width.inches)
    H = float(p.eave_height.inches)
    m = float(p.slope_rise) / 12
    if face == 'left':
        return H
    if face == 'right':
        return H + (W * m if p.frame_type == 'monoslope' else 0)
    u = W - x if face == 'rear' else x
    return H + m * (u if p.frame_type == 'monoslope' else min(u, W - u))


def _end_rafter(end):
    """The end rafter at an end-wall station: depth and whether it sits ON the posts (bypass)
    or the posts run to its top line (flush channel)."""
    cfg = end.get('config') or {}
    rid = cfg.get('resolved_rafter') or ''
    if not rid:
        return None
    try:
        pr = rafter_profile(rid)
    except Exception:
        return None
    flush = (end.get('roof_mode') or cfg.get('roof_mode')) == 'flush'
    return dict(id=rid, depth=float(pr['depth']), on_top=not flush, in_channel=flush)


def _frame_rafter(job, p):
    """The main rigid-frame rafter: depth and whether it sits ON the column (outside seat) or runs
    between the column flanges (inside flange, column to the rafter top line)."""
    a = job.assemblies.get(p.rafter_mark)
    if a is None:
        return None
    try:
        pr = rafter_profile(a.main.section)
    except Exception:
        return None
    # Round 14: a WELDED main frame always carries its purlins FLUSH to the top of the rafter, so the
    # rafter top (its plumb end at the wall) IS the roof line - exactly like an open-face channel with
    # the purlins in it.  Only a bolted bypass frame tops out one purlin depth under the roof line.
    # ``in_channel`` here means "no purlin deduction at this rafter top".
    in_channel = p.connection_style != 'bolted' or (pr.get('family') == 'Channel' and p.purlin_mode == 'flush')
    return dict(
        id=a.main.section, depth=float(pr['depth']), on_top=p.welded_knee == 'outside_seat', in_channel=in_channel
    )


def uprights(job, p, face):
    """Projected envelopes in the SAME outside-view coordinates as the panel opening."""
    a = job.assemblies[p.column_mark]
    out = []
    W = width(p, face)
    if face in ('front', 'rear', 'outer_front'):
        end = a.derivation.get('endwalls', {}).get(
            'outer_front_end' if face == 'outer_front' else 'front_end' if face == 'front' else 'rear_end', {}
        )
        end_rafter = _end_rafter(end)
        for r in end.get('posts', []):
            x = W - r['x'] if face == 'rear' else r['x']
            pr = r['profile']
            out.append(
                dict(
                    opening_id=r.get('opening_id'),
                    opening_side=r.get('opening_side'),
                    roles=r.get('roles', []),
                    mark=r['mark'],
                    x=x,
                    width=r['width'],
                    face_width=pr['width'],
                    bottom=r['bottom'],
                    top=r['top_low'],
                    profile=pr['id'],
                    main_rafter=end_rafter,
                    roofline=roof_height(p, face, x),
                )
            )
    else:
        lines = a.derivation.get('secondary_runs', {}).get('support_lines', [])
        for line in lines:
            s = line['station_in']
            x = W - s if face == 'left' else s
            # Actual terminal endwall corner profiles, when separately modeled.
            from .bay_zones import framing_key

            end = a.derivation.get('endwalls', {}).get(framing_key(p, s) or '', {})
            corner = (end.get('posts') or [])[(-1 if face == 'right' else 0)] if end.get('posts') else None
            col = job.assemblies[p.high_column_mark] if face == 'right' and p.frame_type == 'monoslope' else a
            pr = wprofile(col.main.section)
            out.append(
                dict(
                    mark=(corner['mark'] if corner else p.column_mark + '@' + str(line['line'])),
                    frame_line=int(line.get('line') or 0),
                    x=x,
                    width=(corner['profile']['depth'] if corner else pr['width']),
                    face_width=(corner['profile']['depth'] if corner else pr['width']),
                    bottom=(corner['bottom'] if corner else float(p.base_elevation.inches)),
                    top=(
                        corner['top_low']
                        if corner
                        else float(p.base_elevation.inches) + float(col.main.cut_length.inches)
                    ),
                    profile=(corner['profile']['id'] if corner else pr['id']),
                    main_rafter=_end_rafter(end) if corner else _frame_rafter(job, p),
                    roofline=roof_height(p, face, x),
                )
            )
    return sorted(out, key=lambda r: r['x'])


def bounded(x, lo, hi, label):
    n = inch(x)
    if not lo <= n <= hi:
        raise ValueError(label + ' must be between ' + str(lo) + ' and ' + str(hi) + ' inches')
    return n


def apply(p):
    cfg = copy.deepcopy(p.additions)
    if not isinstance(cfg, dict):
        raise ValueError('Framing additions must be an object')
    for k in ('opening_auto', 'rake_angles', 'detail_completion'):
        if k in cfg and not isinstance(cfg[k], bool):
            raise ValueError(k + ' must be boolean')
    cfg.setdefault('opening_auto', False)
    cfg['rake_angles'] = True
    members = cfg.get('opening_members', {})
    if not isinstance(members, dict):
        raise ValueError('Opening members must be keyed by opening ID')
    for oid, rec in members.items():
        if not isinstance(rec, dict):
            raise ValueError('Opening member specification must be an object')
        for k in ('jamb', 'header', 'sill'):
            profile(rec.get(k, ''))
        for k in ('jamb_face', 'header_face', 'sill_face'):
            if rec.get(k) not in ('', None):
                bounded(rec[k], 0.0625, 48, k)
    cfg['opening_members'] = members
    raw = cfg.get('lean_tos', [])
    if not isinstance(raw, list) or len(raw) > 20:
        raise ValueError('Maximum20 lean-tos')
    ids = set()
    clean = []
    for r in raw:
        if not isinstance(r, dict):
            raise ValueError('Lean-to must be an object')
        r = copy.deepcopy(r)
        id = str(r.get('id', ''))
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,25}', id) or id in ids:
            raise ValueError('Unique lean-to ID: letters, digits, hyphen, underscore; max25')
        ids.add(id)
        face = r.get('face', 'right')
        if face not in FACES:
            raise ValueError('Select one of the four attachment faces')
        if not p.length:
            raise ValueError('Lean-tos require authoritative main-building length')
        r['face'] = face
        from .lean_walls import normalize as normalize_walls
        from .lean_walls import resolve_bays

        normalize_walls(p, r)
        if r.get('bays'):
            resolve_bays(p, r)
        elif r.get('full_length'):
            if face not in ('left', 'right'):
                raise ValueError('Full-length lean applies to sidewalls only')
            r['start'] = '0'
            r['length'] = str(float(p.length.inches))
        for key, lo, hi, default in [
            ('start', 0, width(p, face), 0),
            ('length', 0.0625, width(p, face), width(p, face)),
            ('projection', 1, 1200, 144),
            ('low_eave', 1, 1200, 120),
            ('purlin_depth', 1, 24, 8),
        ]:
            r[key + '_in'] = bounded(r.get(key, default), lo, hi, key)
            r[key] = fmt(r[key + '_in'])
        # Do not quantize the authoritative geometry to display precision.
        for key in ('start', 'length', 'projection', 'low_eave', 'purlin_depth'):
            r[key] = str(r[key + '_in'])
        if r['start_in'] + r['length_in'] > width(p, face) + EPS:
            raise ValueError(id + ': lean-to exceeds attachment face')
        r['pitch'] = bounded(r.get('pitch', 1), 0, 12, 'pitch rise /12')
        r['roof_continuity'] = r.get('roof_continuity') or 'separate'
        if r['roof_continuity'] not in ('separate', 'main_plane'):
            raise ValueError('Unknown lean roof continuity')
        # doubled open-face interior rafters: (a) welded back to back (standard) or
        # (b) a 1/8 in plate the width of the open face sandwiched full length
        r['doubled_rafter'] = r.get('doubled_rafter') or 'welded'
        if r['doubled_rafter'] not in ('welded', 'spacer'):
            raise ValueError('Unknown doubled lean rafter build')
        # lean END rafter: standard single, or the special open-C build-up (C purlin
        # into the main end rafter + open-face Cee stopping 1/2 in from the sheet)
        r['end_rafter_style'] = r.get('end_rafter_style') or 'standard'
        if r['end_rafter_style'] not in ('standard', 'special_open_c'):
            raise ValueError('Unknown lean end rafter style')
        r['roof_overhang_in'] = bounded(r.get('roof_overhang') or '8', 0, 48, 'lean roof overhang along slope')
        r['roof_overhang'] = str(r['roof_overhang_in'])
        if r['roof_continuity'] == 'main_plane':
            if p.frame_type != 'gable' or face not in ('left', 'right'):
                raise ValueError('Continuous main-plane roof currently supports gable sidewall leans only')
            r['pitch'] = float(p.slope_rise)
            low = float(p.eave_height.inches) - r['projection_in'] * r['pitch'] / 12
            if low <= 0:
                raise ValueError('Continuous main roof reaches floor before lean support')
            r['low_eave_in'] = low
            r['low_eave'] = str(low)
        if p.cladding.get('owner_length_rules'):
            from .cladding import owner_edge

            if r['roof_continuity'] == 'main_plane':
                r['roof_overhang_in'] = owner_edge(p.cladding, 'roof_' + face, r['pitch'])
            else:
                e = r.get('roof_edge', {})
                if not isinstance(e, dict) or any(
                    not isinstance(e.get(k, False), bool) for k in ('gutter', 'wall_sheets')
                ):
                    raise ValueError('Lean roof-edge gutter/wall sheets must be boolean')
                r['roof_overhang_in'] = owner_edge(
                    {'roof_edges': {'roof_mono': e}, 'walls': r['walls']['outer'] == 'sheeted'},
                    'roof_mono',
                    r['pitch'],
                )
            r['roof_overhang'] = str(r['roof_overhang_in'])
        # Shop standard (v0.8.34): the lean rafter is cut plumb and welded directly to the
        # outside face of the main column (no gap, no clip part).  A welded clip with the
        # owner's 2 in gap is the option; the bolted end plate stays for legacy jobs.
        r['high_connection'] = r.get('high_connection', 'welded_direct')
        if r['high_connection'] not in ('welded_direct', 'clip', 'double_angle', 'end_plate'):
            raise ValueError('Unknown high connection')
        high_overrides = r.get('high_connection_overrides') or {}
        if not isinstance(high_overrides, dict):
            raise ValueError(id + ': high_connection_overrides must map support station numbers to modes')
        clean_high_overrides = {}
        for station, mode in high_overrides.items():
            if not re.fullmatch(r'[1-9][0-9]{0,2}', str(station)):
                raise ValueError(id + ': high connection override keys are 1-based support station numbers')
            if mode in ('', None, 'inherit'):
                continue
            if mode not in ('welded_direct', 'clip', 'end_plate'):
                raise ValueError(id + ': high support mode must be welded_direct, clip or end_plate')
            clean_high_overrides[str(station)] = mode
        r['high_connection_overrides'] = clean_high_overrides
        r['high_clip_fit'] = r.get('high_clip_fit', 'owner_gap')
        if r['high_clip_fit'] not in ('legacy', 'gap_overlap', 'owner_gap'):
            raise ValueError('Unknown high clip fit rule')
        r['rafter_seat'] = r.get('rafter_seat', 'inside_flange')
        if r['rafter_seat'] not in ('inherit', 'inside_flange', 'outside_seat'):
            raise ValueError('Lean rafter seat must be inherit, inside_flange or outside_seat')
        seat_overrides = r.get('rafter_seat_overrides') or {}
        if not isinstance(seat_overrides, dict):
            raise ValueError(id + ': rafter_seat_overrides must map support station numbers to modes')
        clean_seat_overrides = {}
        for station, mode in seat_overrides.items():
            if not re.fullmatch(r'[1-9][0-9]{0,2}', str(station)):
                raise ValueError(id + ': rafter seat override keys are 1-based support station numbers')
            if mode in ('', None, 'inherit'):
                continue
            if mode not in ('inside_flange', 'outside_seat'):
                raise ValueError(id + ': support rafter seat must be inside_flange or outside_seat')
            clean_seat_overrides[str(station)] = mode
        r['rafter_seat_overrides'] = clean_seat_overrides
        r['clip_hand'] = r.get('clip_hand', 'positive')
        if r['clip_hand'] not in ('positive', 'negative'):
            raise ValueError('Clip hand must be positive or negative')
        for field, low, high, default in [
            ('clip_weld_size', 0.0625, 0.5, 0.25),
            ('cee_web_thickness', 0.001, 1, None),
            ('rafter_peak_height', 1, 2400, None),
        ]:
            value = r.get(field, default)
            if field == 'clip_weld_size' and value in ('', None):
                value = default
            if value not in ('', None):
                r[field] = str(bounded(value, low, high, field))
        r['bolt_preset'] = r.get('bolt_preset', '')
        if r['bolt_preset'] not in ('', '1277345-R5-SP2'):
            raise ValueError('Unknown bypass bolt preset')
        if (
            r['bolt_preset']
            and r['high_connection'] != 'end_plate'
            and 'end_plate' not in r.get('high_connection_overrides', {}).values()
        ):
            raise ValueError(
                'SP2 preset applies only where an end-plate connection is selected, not welded clip/angles'
            )
        r['low_connection'] = r.get('low_connection', p.connection_style)
        if r['low_connection'] not in ('bolted', 'fully_welded', 'welded_box'):
            raise ValueError('Use an existing monoslope low-eave style')
        if r.get('rafter_seat_overrides') and r['low_connection'] == 'bolted':
            raise ValueError(
                id + ': per-support rafter seat overrides are only defined for welded low-eave connections'
            )
        # Lean girts have their own setting (owner, 2026-10-15): flush by default under the
        # main-wall shop rules; the purlin mode follows the main roof unless chosen.
        r['purlin_mode'] = r.get('purlin_mode', p.purlin_mode)
        r['girt_mode'] = r.get('girt_mode') or 'flush'
        for mode in ('purlin_mode', 'girt_mode'):
            if r[mode] not in ('flush', 'bypass'):
                raise ValueError('Choose flush or bypass')
        # Open-face channel lines always carry the purlins IN the channel (station_fit); the roof
        # secondary fit setting applies to W / lipped-Cee lines only, so it is kept as entered.
        lines = r.get('rafter_lines') or {}
        if not isinstance(lines, dict):
            raise ValueError(id + ': rafter_lines must map lean frame line numbers to sections')
        clean_lines = {}
        for key, pick in lines.items():
            pick = str(pick or '').strip()
            if not re.fullmatch(r'[1-9][0-9]{0,2}', str(key)):
                raise ValueError(id + ': rafter line numbers are 1, 2, 3 ... from the start of the lean')
            if not pick:
                continue
            lp = profile(pick)
            if not lp or lp['family'] not in ('W', 'C'):
                raise ValueError(id + ': line ' + str(key) + ': rafter must be a W or a channel section')
            if lp['family'] == 'C' and not 6 <= lp['depth'] <= (
                10.5 if lp.get('open_face') or lp.get('doubled') else 8
            ):
                raise ValueError(id + ': line ' + str(key) + ': channel rafter 6-10 in open face or 6-8 in Cee')
            clean_lines[str(key)] = pick
        r['rafter_lines'] = clean_lines
        # Foundation of the lean posts (v0.8.43): as the main building, or its own slab / post
        # holes - the owner's lean posts go in augered holes while the main building sits on a slab.
        from . import foundation as FND

        r['foundation'] = str(r.get('foundation') or 'main').strip() or 'main'
        for key in ('footing_depth', 'footing_diameter'):
            r[key] = str(r.get(key) or '').strip()
        fnd_errors = FND.validate_lean(r)
        if fnd_errors:
            raise ValueError('; '.join(fnd_errors))
        # Owner rule (2026-10-15): the roofline ALWAYS follows the top of purlin.  Purlins in an
        # open-face channel rafter stay in the channel (rafter top = roofline); a bypass rafter's
        # top is the bottom of the purlin.  This holds for a lean roof that continues the main
        # roof plane as well - the lean rafter simply rises to the roofline at the main column.
        for key in ('rafter', 'column'):
            pr = profile(r.get(key, ''))
            if (
                pr
                and key == 'rafter'
                and (
                    pr['family'] not in ('W', 'C')
                    or (
                        pr['family'] == 'C'
                        and not 6 <= pr['depth'] <= (10.5 if pr.get('open_face') or pr.get('doubled') else 8)
                    )
                )
            ):
                raise ValueError('Lean-to rafter must be W, an open-face channel 6–10 in or an open Cee 6–8 in')
            if pr and key == 'column' and pr['family'] not in ('W', 'HSS') and not pr.get('open_face'):
                raise ValueError('Lean-to column must be W, HSS or an open-face channel (all column options)')
        rp = profile(r.get('rafter', ''))
        cp = profile(r.get('column', ''))
        if rp and cp and (r['projection_in'] <= cp['depth'] or r['low_eave_in'] <= r['purlin_depth_in'] + rp['depth']):
            raise ValueError(id + ': nominal member envelopes consume projection or low-eave height')
        for key in ('hole_gauge', 'hole_pitch', 'hole_diameter', 'plate_width', 'plate_height', 'plate_thickness'):
            if r.get(key) not in ('', None):
                r[key] = str(bounded(r[key], 0.0625, 48, key))
        for q in clean:
            if (
                q['face'] == face
                and min(q['start_in'] + q['length_in'], r['start_in'] + r['length_in'])
                > max(q['start_in'], r['start_in']) + EPS
            ):
                raise ValueError('Overlapping lean-to runs on the same face')
        from .lean_purlins import apply as apply_lean_purlins

        apply_lean_purlins(p, r)
        clean.append(r)
    if (clean or members or (cfg['opening_auto'] and p.cladding.get('openings'))) and not p.auto_connections:
        raise ValueError('Framing additions require managed frame geometry')
    cfg['lean_tos'] = clean
    p.additions = cfg
    from .opening_rules import apply as apply_openings

    apply_openings(p)
    from .erection_templates import validate

    validate(p)


def subtract(intervals, lo, hi):
    """Subtract forbidden OPEN interval; equality at required clearance is legal."""
    out = []
    for a, b in intervals:
        if hi <= a or lo >= b:
            out.append((a, b))
            continue
        if lo >= a:
            out.append((a, min(b, lo)))
        if hi <= b:
            out.append((max(a, hi), b))
    return [(a, b) for a, b in out if b >= a - EPS]


def member_specs(p, o):
    spec = p.additions['opening_members'].get(o['id'], {})
    result = {}
    for role in ('jamb', 'header', 'sill'):
        if role in ('jamb', 'header'):
            from .opening_rules import section_for

            gr = 'endwall_girt' if o.get('surface') in ('front', 'rear') else 'girt'
            pr = section_for(p, spec, role, gr)
        else:
            pr = profile(spec.get(role, ''))
        face = spec.get(role + '_face')
        # Conservative envelope if orientation has not been explicitly supplied.
        result[role] = dict(
            profile=pr,
            face=inch(face) if face not in ('', None) else max(pr['depth'], pr['width']) if pr else 0,
            orientation_confirmed=face not in ('', None),
        )
    return result


def opening_finish(job, p, model):
    ops = p.cladding.get('openings', [])
    byface = {s: uprights(job, p, s) for s in FACES}
    rows = []
    for o in ops:
        from .opening_rules import locate

        bay = locate(p, o, byface[o['surface']])
        face = o['surface']
        x = o['x_in']
        w = o['width_in']
        height = o['y_in'] + o['height_in']
        limit = width(p, face)
        if (
            x + w > limit + EPS
            or height
            > min(roof_height(p, face, x), roof_height(p, face, x + w))
            + inch(p.cladding.get('wall_top_allowance', 0))
            + EPS
        ):
            raise ValueError(
                o['id'] + ': opening outside building envelope; relocate/remove explicitly before shrinking geometry'
            )
        s = member_specs(p, o)
        jw = s['jamb']['face']
        hw = s['header']['face']
        sw = s['sill']['face'] if o['kind'] not in ('door', 'overhead') else 0
        rec = p.additions['opening_members'][o['id']]
        # Shop door standard: header = wall girt above the head (walk door) / jambs full height
        # (overhead door).  Girt elevations are the sidewall lines (end walls use the same lines).
        header_girt = None
        if rec.get('header_mode') == 'girt' and not rec.get('jamb_role') == 'roof_bearing':
            head = o['y_in'] + o['height_in']
            above = sorted(float(e.inches) for e in p.girt_elevations if head - EPS <= float(e.inches) <= head + 12)
            if above:
                header_girt = above[0]
        jamb_top = None
        if rec.get('jamb_extent') == 'full' and not rec.get('jamb_role') == 'roof_bearing':
            m_ = float(p.slope_rise) / 12
            end_ = (
                job.assemblies[p.column_mark]
                .derivation.get('endwalls', {})
                .get('front_end' if face == 'front' else 'rear_end' if face == 'rear' else '', {})
            )
            if face in ('front', 'rear') and end_:
                under0 = end_['roof_left_in'] - rafter_profile(end_['config']['resolved_rafter'])['depth']
                W_ = width(p, face)

                def under(xx):
                    return under0 + m_ * (xx if p.frame_type == 'monoslope' else min(xx, W_ - xx))

                jamb_top = min(under(x), under(x + w))
            else:
                jamb_top = roof_height(p, face, 0) - float(p.eave_strut_depth.inches)
            if jamb_top <= height + EPS:
                jamb_top = None
        row = dict(
            bearing_jambs=rec.get('jamb_role') == 'roof_bearing',
            jamb_section=s['jamb']['profile'],
            header_direction=rec.get('header_orientation', 'up'),
            id=o['id'],
            face=o['surface'],
            requested_x_in=o['x_in'],
            x_in=o['x_in'],
            y_in=o['y_in'],
            width_in=o['width_in'],
            height_in=o['height_in'],
            members=[],
            issues=[],
            moves=[],
            spec=s,
            bay=bay,
            section=s['header']['profile'],
            wall_inset_in=float(p.girt_depth.inches) if p.inset_for_bypass else 0,
            girt_mode=p.girt_mode,
            header_orientation='CEE / FLANGES ' + rec.get('header_orientation', 'up').upper(),
            jamb_orientation='VERTICAL C / OPEN TOWARD GIRT RECEIVER'
            if inch(rec.get('girt_insertion', '0'))
            else 'VERTICAL C / OPEN TOWARD APERTURE',
        )
        if o.get('relocation'):
            row['previous_move'] = copy.deepcopy(o['relocation'])
        row['left_pad'] = max(6, jw)
        row['right_pad'] = max(6, jw)
        row['jamb_face'] = jw
        row['header_face'] = hw
        row['sill_face'] = sw
        row['bottom'] = 0 if s['jamb']['profile'] else o['y_in']
        row['top'] = o['y_in'] + o['height_in'] + hw
        if header_girt is not None:
            row['header_girt_in'] = header_girt
            row['header_note'] = 'HEADER = WALL GIRT @ ' + fmt(header_girt) + ' (no separate header member)'
            row['top'] = max(row['top'], header_girt)
        if jamb_top is not None:
            # Member extent only: the roof-bound / clash checks keep the header top, because
            # full-height jambs reach the roof member by definition.
            row['jamb_top_in'] = jamb_top
            row['jamb_note'] = (
                'FULL-HEIGHT JAMBS TO '
                + ('END RAFTER' if face in ('front', 'rear') else 'EAVE STRUT')
                + ' @ '
                + fmt(jamb_top)
            )
        if header_girt is not None and jamb_top is None:
            row['jamb_top_in'] = header_girt
        rows.append(row)
    # Reserve all other aperture/member rectangles, not only previously visited openings.
    for iteration in range(max(1, len(rows))):
        changed = False
        for row, o in zip(rows, ops):
            W = width(p, row['face'])
            w = row['width_in']
            jw = row['jamb_face']
            required = row['top']
            x = row['x_in']
            intervals = [(jw, W - w - jw)] if W >= w + 2 * jw else []
            if row.get('bay'):
                bay = row['bay']
                lo = bay['left_edge_in'] + row['left_pad']
                hi = bay['right_edge_in'] - w - row['right_pad']
                intervals = [(max(a, lo), min(b, hi)) for a, b in intervals if max(a, lo) <= min(b, hi) + EPS]
            # Roof bound on BOTH outer framing edges, not just aperture corners.
            face = row['face']
            H = float(p.eave_height.inches)
            m = float(p.slope_rise) / 12
            end = (
                job.assemblies[p.column_mark]
                .derivation.get('endwalls', {})
                .get('front_end' if face == 'front' else 'rear_end' if face == 'rear' else '', {})
            )
            if end:
                H = end['roof_left_in'] - rafter_profile(end['config']['resolved_rafter'])['depth']
            ceiling_side = roof_height(p, face, 0) - float(p.eave_strut_depth.inches)
            if face in ('front', 'rear') and m > 0:
                d = max(0, (required - H) / m)
                if p.frame_type == 'gable':
                    intervals = [(max(a, d + jw), min(b, W - d - w - jw)) for a, b in intervals]
                elif face == 'front':
                    intervals = [(max(a, d + jw), b) for a, b in intervals]
                else:
                    intervals = [(a, min(b, W - d - w - jw)) for a, b in intervals]
            elif required > (ceiling_side if face in ('left', 'right') else H) + EPS:
                intervals = []
            intervals = [(a, b) for a, b in intervals if a <= b + EPS]
            steel = byface[face]
            for u in steel:
                if row['bearing_jambs'] and u.get('opening_id') == row['id']:
                    continue
                if u['top'] <= row['bottom'] or u['bottom'] >= row['top']:
                    continue
                intervals = subtract(
                    intervals, u['x'] - u['width'] / 2 - row['right_pad'] - w, u['x'] + u['width'] / 2 + row['left_pad']
                )
            for other in rows:
                if (
                    other is row
                    or other['face'] != face
                    or other['top'] <= row['bottom']
                    or other['bottom'] >= row['top']
                ):
                    continue
                intervals = subtract(
                    intervals,
                    other['x_in'] - other['jamb_face'] - w - jw,
                    other['x_in'] + other['width_in'] + other['jamb_face'] + jw,
                )
            if not steel:
                row['issues'] = ['UPRIGHT LAYOUT MISSING: enable bays for sidewalls / endwalls for ends']
                continue
            valid = any(a - EPS <= x <= b + EPS for a, b in intervals)
            if (
                not valid
                and p.additions['opening_auto']
                and intervals
                and not row['bearing_jambs']
                and p.additions['opening_members'][row['id']]['placement'] != 'wall_centered'
            ):
                # Snap outward inside allowed interval, never round toward a steel obstruction.
                candidates = []
                for a, b in intervals:
                    a = math.ceil((a - EPS) * 16) / 16
                    b = math.floor((b + EPS) * 16) / 16
                    if a <= b:
                        candidates.append(min(max(x, a), b))
                if candidates:
                    new = min(candidates, key=lambda n: (abs(n - x), n))
                    row['moves'].append(dict(from_in=x, to_in=new))
                    row['x_in'] = new
                    o['x_in'] = new
                    o['x'] = str(new)
                    o['relocation'] = dict(
                        from_in=row['requested_x_in'],
                        to_in=new,
                        clearance_in=6,
                        rule='6in aperture-to-upright FACE; selected member envelope also clear',
                    )
                    changed = True
                    valid = True
            row['issues'] = (
                []
                if valid
                else [
                    'NO VALID POSITION: opening and selected framing remain in conflict'
                    if p.additions['opening_auto']
                    else 'CLASH: enable auto relocation or reposition opening'
                ]
            )
        if not changed:
            break
    for row, o in zip(rows, ops):
        rec = p.additions['opening_members'][row['id']]
        x = row['x_in']
        y = row['y_in']
        w = row['width_in']
        h = row['height_in']
        spec = row.pop('spec')
        jw = row['jamb_face']
        hw = row['header_face']
        sw = row['sill_face']
        tag = p.column_mark + '-OP-' + row['id']
        if y < sw - EPS:
            row['issues'].append('SILL BELOW FLOOR: revise selected sill/orientation or opening height')

        def member(role, spec, x0, y0, x1, y1, length):
            pr = spec['profile']
            if not pr:
                return
            if not spec['orientation_confirmed']:
                row['issues'].append(role + ': member face orientation UNCONFIRMED; conservative envelope shown')
            row['members'].append(
                dict(
                    mark=tag + '-' + role,
                    role=role,
                    profile=pr['id'],
                    family=pr['family'],
                    quantity=1,
                    x0_in=x0,
                    y0_in=y0,
                    x1_in=x1,
                    y1_in=y1,
                    reference_length_in=length,
                    section=copy.deepcopy(pr),
                    orientation=row['header_orientation']
                    if role == 'HD'
                    else row['jamb_orientation']
                    if role in ('JL', 'JR')
                    else 'SILL REFERENCE',
                    status='CUT PENDING DETAIL',
                )
            )

        if row['bearing_jambs']:
            for role in ('JL', 'JR'):
                u = next(
                    u for u in byface[row['face']] if u.get('opening_id') == row['id'] and u.get('opening_side') == role
                )
                member(
                    role, spec['jamb'], u['x'] - jw / 2, u['bottom'], u['x'] + jw / 2, u['top'], u['top'] - u['bottom']
                )
                row['members'][-1].update(
                    mark=u['mark'],
                    shared_member_ref=u['mark'],
                    quantity=0,
                    quantity_scope='physical member counted once in endwall schedule',
                    status='ROOF-BEARING JAMB / ENDWALL POST (see endwall schedule)',
                )
        else:
            jt = row.get('jamb_top_in', y + h + hw)
            member('JL', spec['jamb'], x - jw, 0, x, jt, jt)
            member('JR', spec['jamb'], x + w, 0, x + w + jw, jt, jt)
        if row.get('header_girt_in') is None:
            member('HD', spec['header'], x, y + h, x + w, y + h + hw, w)
        header = next((m for m in row['members'] if m['role'] == 'HD'), None)
        joints = []
        if (
            header
            and row['face'] in ('front', 'rear')
            and row.get('header_girt_in') is None
            and rec.get('opening_mode') != 'walk_slip_in'
        ):
            if row['bearing_jambs']:
                jambs = {
                    u['opening_side']: u
                    for u in byface[row['face']]
                    if u.get('opening_id') == row['id'] and u.get('opening_side') in ('JL', 'JR')
                }
            else:
                jambs = {m['role']: m for m in row['members'] if m['role'] in ('JL', 'JR')}
            for side, header_x in (('JL', header['x0_in']), ('JR', header['x1_in'])):
                jamb = jambs.get(side)
                if jamb is None:
                    continue
                if row['bearing_jambs']:
                    jamb_face_x = jamb['x'] + jamb['width'] / 2 if side == 'JL' else jamb['x'] - jamb['width'] / 2
                    jamb_mark = jamb['mark']
                else:
                    jamb_face_x = jamb['x1_in'] if side == 'JL' else jamb['x0_in']
                    jamb_mark = jamb['mark']
                offset = header_x - jamb_face_x
                gap = 0.0 if abs(offset) <= EPS else None
                joints.append(
                    dict(
                        opening_id=row['id'],
                        header_mark=header['mark'],
                        header_profile_id=header['profile'],
                        header_end='left' if side == 'JL' else 'right',
                        jamb_mark=jamb_mark,
                        jamb_side=side,
                        support_face='OPENING-SIDE INSIDE FACE OF JAMB',
                        header_end_plane_x_in=header_x,
                        jamb_inside_face_x_in=jamb_face_x,
                        reference_alignment_offset_in=offset,
                        physical_gap_in=gap,
                        connection_method='DIRECT END-TO-FACE CONTACT' if gap == 0 else 'SET OUT MISALIGNED',
                        geometry_status='DIRECT CONTACT / ZERO GAP' if gap == 0 else 'MEMBER PLANES MISALIGNED',
                        fit_status='Header end cut to shared-jamb inside-face setout; no gap.'
                        if gap == 0
                        else 'Header end and jamb inside-face setouts differ; align from actual opening geometry.',
                    )
                )
            header['end_joint_references'] = joints
            if len(joints) == 2:
                header['cut_length_in'] = header['reference_length_in']
                header['cut_length'] = fmt(header['cut_length_in'])
                header['physical_end_gaps_in'] = [j['physical_gap_in'] for j in joints]
                header['status'] = (
                    'HEADER CUT TO JAMB INSIDE FACES; ZERO GAP'
                    if all(j['physical_gap_in'] == 0 for j in joints)
                    else 'HEADER END SETOUT MISALIGNED'
                )
            row['header_end_joints'] = joints
        if o['kind'] not in ('door', 'overhead'):
            member('SL', spec['sill'], x, y - sw, x + w, y, w)
        for role in ('jamb', 'header'):
            if not spec[role]['profile']:
                row['issues'].append(role.upper() + ' MEMBER NOT SELECTED')
        # Intercepted girts are cut at the jamb faces by erection_templates.interrupt_girts /
        # interrupt_endwall_girts (source kit when selected, project default otherwise).
        cut_to = row['jamb_top_in'] if row.get('jamb_top_in') is not None and row.get('jamb_top_in') > y + h else y + h
        row['intercepted_girts'] = [
            fmt(float(elev.inches))
            for elev in p.girt_elevations
            if y < float(elev.inches) < cut_to - EPS and not row['bearing_jambs']
        ]
        if row.get('bay'):
            row['bay']['actual_offset_in'] = row['x_in'] - row['bay']['centered_x_in']
        row['status'] = 'UNRESOLVED' if row['issues'] else 'RELOCATED' if row['moves'] else 'CLEAR'
        row['uprights'] = byface[row['face']]
        row['elevation'] = face_name(row['face'])
    model['openings'] = rows


def finish(job, p):
    a = job.assemblies[p.column_mark]
    layout = job.settings.get('frame_layouts', {}).get(p.column_mark)
    if layout is None:
        return
    model = dict(
        lean_tos=[],
        openings=[],
        rake_angles=[],
        warnings=[],
    )
    if p.cladding.get('openings'):
        opening_finish(job, p, model)
    for r in p.additions['lean_tos']:
        face = r['face']
        start = r['start_in']
        end = start + r['length_in']
        P = r['projection_in']
        H = r['low_eave_in']
        m = r['pitch'] / 12
        high = H + P * m
        rf = profile(r.get('rafter', ''))
        col = profile(r.get('column', ''))
        allposts = uprights(job, p, face)
        posts = [u for u in allposts if start - EPS <= u['x'] <= end + EPS]
        seat_overrides = r.get('rafter_seat_overrides') or {}
        support_keys = {str(int(u.get('frame_line') or i + 1)) for i, u in enumerate(posts)}
        stale_seats = sorted(set(seat_overrides) - support_keys, key=int)
        if stale_seats:
            raise ValueError(
                r['id']
                + ': rafter seat override refers to support line(s) not present in this lean: '
                + ', '.join(stale_seats)
            )
        stale_high = sorted(set(r.get('high_connection_overrides', {})) - support_keys, key=int)
        if stale_high:
            raise ValueError(
                r['id']
                + ': high connection override refers to support line(s) not present in this lean: '
                + ', '.join(stale_high)
            )
        issues = []
        # An end-attached lean hangs on the end-wall posts the same way a side lean hangs
        # on the main columns: the rafter's plumb end welds to the post's outside face (or
        # sits on its seat) - resolved per station by the connection builder, not held.
        if len(posts) < 2:
            issues.append('At least TWO existing upright stations required. No transfer member invented.')
        if not posts or (
            start < posts[0]['x'] - float(posts[0].get('width') or 0) / 2 - EPS
            or end > posts[-1]['x'] + float(posts[-1].get('width') or 0) / 2 + EPS
        ):
            # lean ends are OUT-TO-OUT at the corners: the corner upright's centre is
            # inset half its width, which is coincidence, not an unsupported end
            issues.append(
                'Lean-to ends do not coincide with upright centers; unsupported ends / overhang support must be resolved.'
            )
        if not rf or not col:
            issues.append('Select rafter AND outer-column profiles before member takeoff')
        from .ordering import config as order_config
        from .ordering import trim_lengths

        trim = order_config(job)
        lengths = trim_lengths(r['length_in'], inch(p.cladding.get('trim_lap', 2)), trim['trim_max_in'])
        if (
            r['high_connection'] == 'end_plate' or 'end_plate' in r.get('high_connection_overrides', {}).values()
        ) and rf:
            mode = r.get('plate_width_rule', 'round_up')
            if mode not in ('exact', 'round_up'):
                raise ValueError('End-plate width rule must be exact or round_up')
            auto = set(r.get('plate_auto_fields', []))
            previous = r.get('plate_auto_resolved', {})
            resolved = {}
            for key, val in [
                ('plate_width', math.ceil(rf['width']) if mode == 'round_up' else rf['width']),
                ('plate_height', rf['depth']),
                ('plate_thickness', 0.5),
            ]:
                if r.get(key) in ('', None) or (
                    key in auto and previous.get(key) is not None and abs(inch(r[key]) - inch(previous[key])) < 1e-9
                ):
                    r[key] = str(val)
                    auto.add(key)
                    resolved[key] = r[key]
                else:
                    auto.discard(key)
            r['plate_auto_fields'] = sorted(auto)
            r['plate_auto_resolved'] = resolved
            r['plate_size_basis'] = 'Q05 rafter envelope / explicit overrides retained'
        z = copy.deepcopy(r)
        from .lean_walls import mirror_legacy

        mirror_legacy(z)
        # Owner (2026-10-15): no flashing when the lean roof follows the main roofline; a lowered
        # lean roof on the sidewall gets the custom-formed wall-to-roof transition (trim list).
        continuous = r.get('roof_continuity') == 'main_plane' and not r.get('transition_template')
        z['transition_trim'] = dict(
            profile='NOT APPLICABLE / CONTINUOUS ROOF'
            if continuous
            else 'CUSTOM WALL-TO-ROOF TRANSITION (26 ga, job pitch)',
            pieces_in=[] if continuous else lengths,
            quantity=0 if continuous else len(lengths),
            lap_in=inch(p.cladding.get('trim_lap', 2)),
            pitch=r['pitch'],
            finish=p.cladding.get('trim_finish', {}),
            material_gauge=26,
            fabrication='NONE' if continuous else 'CUSTOM FORMED',
            status='NOT APPLICABLE: the lean roof continues the main roof plane; no wall-to-roof transition'
            if continuous
            else 'Ordered on the trim list as CUSTOM FORMED wall-to-roof transition (26 ga, job pitch); run = lean length, max 20 ft 6 in pieces',
        )
        if continuous:
            z['transition_not_applicable'] = True
        # Shop rules (v0.8.34): resolve the rafter seat at the lean post, the purlin deduction
        # (purlins IN the channel of an open-face rafter sit flush with the rafter top) and
        # the horizontal gap at the main column before any detail module runs.
        open_channel = bool(rf and rf['family'] == 'C' and (rf.get('open_face') or rf.get('doubled')))
        special_open_c_ends = r.get('end_rafter_style') == 'special_open_c' and len(posts) > 1
        seat = r.get('rafter_seat', 'inside_flange')
        if seat == 'inherit':
            seat = p.welded_knee
        continued = r.get('roof_continuity') == 'main_plane'
        # purlins ALWAYS in an open-face channel; a W follows the roof secondary fit (station_fit)
        in_channel = open_channel
        line_recs = rafter_line_options(r, rf, len(posts))
        any_channel = any(rec['in_channel'] for rec in line_recs)
        any_open_channel_line = any(rec['family'] == 'C' and rec['in_channel'] for rec in line_recs)
        any_nonchannel_line = any(not (rec['family'] == 'C' and rec['in_channel']) for rec in line_recs)
        if seat == 'inside_flange' and any_open_channel_line and any_nonchannel_line:
            low_seat_note = 'LOW END: open-face channel supports side-weld without a cap; W supports retain cap/head detail per line schedule.'
        elif seat == 'inside_flange' and any_open_channel_line:
            low_seat_note = 'LOW END: post runs to rafter top line; open-face channel rafter side-welded without a cap.'
        elif seat == 'inside_flange':
            low_seat_note = 'LOW END: post runs to rafter top line; cap plate/head detail at W supports.'
        else:
            low_seat_note = 'LOW END: rafter seat and post cut are assigned per support; see low connection schedule.'
        gap_h = 0.0
        if r['high_connection'] == 'clip' or 'clip' in r.get('high_connection_overrides', {}).values():
            fit = r.get('high_clip_fit', 'owner_gap')
            gap_h = 2.0 if fit == 'owner_gap' else (1.5 / math.hypot(1, m) if fit == 'gap_overlap' else 0.0)
        z.update(
            elevation=face_name(face),
            high_eave_in=high,
            roof_slope_length_in=P * math.hypot(1, m),
            stations=[],
            members=[],
            holes=[],
            issues=issues,
            rafter_seat_resolved=seat,
            open_face_rafter=open_channel or special_open_c_ends,
            doubled_rafter=r['doubled_rafter'],
            end_rafter_style=r['end_rafter_style'],
            purlins_in_channel=bool(line_recs) and all(rec['in_channel'] for rec in line_recs),
            purlin_deduction_in=station_fit(r, rf, 1)[1] if rf else r['purlin_depth_in'],
            any_channel_line=any_channel,
            special_open_c_ends=special_open_c_ends,
            rafter_lines_resolved=line_recs,
            mixed_rafter_lines=len({(rec['profile_id'], rec['pair']) for rec in line_recs}) > 1,
            high_gap_in=gap_h,
        )
        if open_channel and rf.get('id', '').startswith('SSS-'):
            cls = secondary(rf['id']).get('nominal_depth_class_in') or rf['depth']
            if abs(cls - r['purlin_depth_in']) > 1e-6:
                issues.append(
                    'Lean rafter channel depth %g in differs from the %g in lean purlin: channel depth = purlin depth (SSS-SS%d214)'
                    % (cls, r['purlin_depth_in'], int(round(r['purlin_depth_in'])))
                )
        for i, u in enumerate(posts):
            rfi, pair = station_rafter(r, rf, i, len(posts))
            in_i, ded_i, fit_i = station_fit(r, rfi, pair)
            seat_key = str(int(u.get('frame_line') or i + 1))
            station = dict(
                index=i + 1,
                frame_line=int(seat_key),
                main_mark=u['mark'],
                x_in=u['x'],
                rafter_seat_mode=r.get('rafter_seat_overrides', {}).get(seat_key) or seat,
                rafter_seat_source='override' if seat_key in r.get('rafter_seat_overrides', {}) else 'inherited',
                high_connection_mode=r.get('high_connection_overrides', {}).get(seat_key) or r['high_connection'],
                high_connection_source='override'
                if seat_key in r.get('high_connection_overrides', {})
                else 'inherited',
                main_face_width_in=u['face_width'],
                rafter_profile=rfi['id'] if rfi else '',
                rafter_pair=pair,
                purlins_in_channel=in_i,
                purlin_deduction_in=ded_i,
                purlin_fit=fit_i,
                roofline_fit='flush' if in_i else fit_i,
                special_open_c_end=bool(
                    r.get('end_rafter_style') == 'special_open_c'
                    and i in (0, len(posts) - 1)
                    and rfi
                    and rfi['family'] == 'C'
                    and rfi.get('open_face')
                ),
            )
            z['stations'].append(station)
            center = (inch(r['rafter_peak_height']) if r.get('rafter_peak_height') else high - ded_i) - (
                rfi['depth'] * math.hypot(1, m) / 2 if rfi else 0
            )
            tag = p.column_mark + '-' + r['id'] + '-' + str(i + 1)
            if high > roof_height(p, face, u['x']) + EPS:
                issues.append(
                    tag
                    + ': lean-to roof meets ABOVE main roof line - the lean high eave '
                    + fmt(high)
                    + ' exceeds the main roofline '
                    + fmt(roof_height(p, face, u['x']))
                    + ' at the wall; lower the lean eave or continue the main roof plane'
                )
            if (center > u['top'] or center < u['bottom']) and station['high_connection_mode'] != 'welded_direct':
                # (the direct weld resolves face / seat per station itself; the eave strut zone above
                # the column top is part of the column line - roofline = top of purlin)
                issues.append(tag + ': high attachment center outside existing column height')
            if rfi and col:
                q = pair
                _end_line = i in (0, len(posts) - 1)
                _special = (
                    _end_line
                    and r['end_rafter_style'] == 'special_open_c'
                    and bool(rfi and rfi['family'] == 'C' and rfi.get('open_face'))
                )
                z['members'].append(
                    dict(
                        mark=tag + '-RF',
                        profile=rfi['id'],
                        family=rfi['family'],
                        quantity=q,
                        reference_length_in=P * math.hypot(1, m) + rfi['depth'] * m,
                        role='rafter',
                        status='LONG ENVELOPE ONLY: high/low connection cut planes unresolved',
                        paired_webs='CONTACT / BACK-TO-BACK' if q == 2 else 'SINGLE',
                        station=i + 1,
                        purlin_fit=fit_i,
                        section_depth_in=rfi['depth'],
                        end_buildup='special_open_c' if _special else '',
                    )
                )
                if _special:
                    # the C purlin of the pair: cut to pitch, flush-welded to the low
                    # lean column, running into the main building's open-face end
                    # rafter against its flat face (owner 0.8.54)
                    _cp = (r.get('roof_purlins') or {}).get('profile_id') or rfi['id']
                    z['members'].append(
                        dict(
                            mark=tag + '-RF-C',
                            profile=_cp,
                            family='C',
                            quantity=1,
                            reference_length_in=P * math.hypot(1, m) + rfi['depth'] * m,
                            role='rafter',
                            status='SPECIAL OPEN-C END RAFTER: C purlin cut to pitch, flush-welded to the low lean column, '
                            'extending into the main open-face end rafter against its flat face',
                            station=i + 1,
                            purlin_fit=fit_i,
                            section_depth_in=rfi['depth'],
                            end_buildup='special_open_c_c_purlin',
                        )
                    )
                # Low column is NOT fabricated from a guessed bracket deduction.
                z['members'].append(
                    dict(
                        mark=tag + '-COL',
                        profile=col['id'],
                        family=col['family'],
                        quantity=1,
                        reference_length_in=None,
                        role='column',
                        status='LOW-POINT CUT HOLD: selected monoslope low seat, base/floor and wall inset fit required',
                        station=i + 1,
                    )
                )
            if station['high_connection_mode'] == 'end_plate':
                keys = ('hole_gauge', 'hole_pitch', 'hole_diameter')
                if all(r.get(k) for k in keys):
                    gauge, pitch, dia = (inch(r[k]) for k in keys)
                    if gauge + dia > u['face_width'] + EPS:
                        issues.append(tag + ': bolt holes extend outside column face')
                    if center - pitch / 2 - dia / 2 < u['bottom'] or center + pitch / 2 + dia / 2 > u['top']:
                        issues.append(tag + ': bolt holes extend outside column height')
                    if r.get('plate_width') and gauge + dia > inch(r['plate_width']):
                        issues.append(tag + ': holes extend outside end plate width')
                    if r.get('plate_height') and pitch + dia > inch(r['plate_height']):
                        issues.append(tag + ': holes extend outside end plate height')
                    for dx, dy in (
                        (-gauge / 2, -pitch / 2),
                        (gauge / 2, -pitch / 2),
                        (-gauge / 2, pitch / 2),
                        (gauge / 2, pitch / 2),
                    ):
                        z['holes'].append(
                            dict(
                                connection=tag,
                                main_mark=u['mark'],
                                station_in=u['x'],
                                face='OUTSIDE COLUMN FACE',
                                x_from_face_center_in=dx,
                                x_from_face_left_in=u['face_width'] / 2 + dx,
                                edge_center_distance_in=(u['face_width'] - gauge) / 2,
                                y_above_floor_in=center + dy,
                                diameter_in=dia,
                                status='COORDINATE REVIEW ONLY; NOT APPLIED TO COLUMN NC; bolt edge distances/grade/design pending',
                            )
                        )
                else:
                    issues.append(tag + ': FOUR holes intended; gauge, pitch and diameter pending')
        from .lean_connections import attach as attach_high_connection

        attach_high_connection(p, r, z, rf, posts, p.column_mark)
        from .lean_connections import end_plate as make_end_plate

        if not r.get('high_connection_overrides'):
            make_end_plate(r, z, p.column_mark)
        if r['walls']['main_below'] == 'open':
            if not p.cladding.get('walls'):
                issues.append('Main-wall open-below has no effect: main wall sheeting disabled')
            if high > min(roof_height(p, face, start), roof_height(p, face, end)) + EPS:
                raise ValueError(r['id'] + ': open-below region extends above main wall')
            for o in p.cladding.get('openings', []):
                if (
                    o['surface'] == face
                    and min(o['x_in'] + o['width_in'], end) > max(o['x_in'], start) + EPS
                    and o['y_in'] < high
                ):
                    raise ValueError(
                        r['id'] + ': an opening overlaps the proposed unsheeted main wall; resolve explicitly'
                    )
        if r.get('high_connection_overrides'):
            z['notes'] = [
                'HIGH END: physical support schedule selects direct weld, welded clip or explicit end plate per main frame line; see high_connection_schedule and connection details.',
                low_seat_note,
            ]
        elif r['high_connection'] in ('welded_direct', 'clip'):
            z['notes'] = [
                (
                    'HIGH END: rafter cut PLUMB and welded directly to the outside face of the main column; no gap, no clip.'
                    if r['high_connection'] == 'welded_direct'
                    else 'HIGH END: welded clip option; rafter plumb end %g in clear of the main column face, clip welded to the column face and the rafter web.'
                    % gap_h
                ),
                low_seat_note
                if seat == 'inside_flange'
                else 'LOW END: rafter seated on the lean post (plumb cut flush with the post outside face).',
                (
                    'ROOF PURLINS: special open-C ends are flush in-channel; W rafters use their per-line fit.'
                    if any_open_channel_line and any_nonchannel_line
                    else 'ROOF PURLINS sit FLUSH IN the rafter channel, 1/4 in from the web, welded to the channel flanges top and bottom'
                    + ('; the rafter top is the roofline (continued main roof plane).' if continued else '.')
                    if in_channel
                    else (
                        'ROOF PURLINS FLUSH with the W rafter top, between the flanges, welded to the web (rafter top = roofline)'
                        if r['purlin_mode'] == 'flush'
                        else 'ROOF PURLINS BYPASS over the W rafter (rafter top = roofline - purlin depth)'
                    )
                    + ('; roofline = top of purlin, continued from the main roof.' if continued else '.')
                ),
            ]
            if z.get('mixed_rafter_lines'):
                z['notes'].append(
                    'RAFTER BY FRAME LINE: '
                    + '; '.join(
                        'line %d %s - %s'
                        % (
                            rec['station'],
                            rec['label'],
                            'purlins flush in the open-face channel'
                            if rec['in_channel']
                            else 'purlins flush, web-welded'
                            if rec['fit'] == 'flush'
                            else 'purlins bypass over the rafter',
                        )
                        for rec in line_recs
                    )
                    + '. Each line keeps its own rafter blank and post cut (see the lean rafter and post sheets).'
                )
        else:
            issues += [
                'Low-eave style '
                + r['low_connection']
                + ' uses shared primary builders; see low_connection_detail for resolved cuts and any adapter/base fit issue.',
                'High connection '
                + r['high_connection']
                + ': bolt/plate/angle fit, edge distances, grade and load path require detailing.',
            ]
        # The wall-to-roof transition of a lowered (separate-plane) lean roof is taken off in the
        # sheet / trim list as a custom-formed trim (v0.8.35); a main-plane lean needs none.
        from .lean_low import finish as low_finish

        low_finish(job, p, z, rf, col)
        from .lean_cuts import finish as finish_lean_cuts

        finish_lean_cuts(p, z, rf, col)
        from .lean_purlins import finish as finish_lean_purlins

        finish_lean_purlins(job, p, z)
        from .lean_walls import finish as finish_lean_walls

        finish_lean_walls(job, p, z, rf, col, posts)
        model['lean_tos'].append(z)
    from .sheet_supports import finish as finish_supports

    finish_supports(job, p, model)
    from .erection_templates import finish as template_finish

    template_finish(job, p, model)
    from .endwall_supports import coordinate_opening_runs

    coordinate_opening_runs(job, p, model)
    from .walk_slip import finish as finish_walk_slip

    finish_walk_slip(job, p, model)
    from .completion_scope import finish as finish_completion

    finish_completion(job, p, model)
    job.settings['frames'][p.column_mark]['additions'] = copy.deepcopy(p.additions)
    a.derivation['framing_additions'] = model
    layout['framing_additions'] = model
    return model
