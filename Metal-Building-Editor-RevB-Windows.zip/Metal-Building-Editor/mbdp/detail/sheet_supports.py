"""Standard sheet support angles: rake at top, base at bottom; no optional rake."""

import copy
import math

from .cladding import EPS, fmt
from .secondary_catalog import get


def finish(job, p, model):
    pr = get(p.base_angle.get('profile_id', 'MBCI-Angle-2x4-G14'))
    if pr['id'] not in (
        'MBCI-Angle-2x4-G14',
        'MBCI-Angle-2x4-G16',
        'SSS-CAB1',
        'SSS-CAB125',
        'SSS-CAB1GALV',
        'SSS-CAB125GALV',
    ):
        raise ValueError('Sheet support requires2x4 angle')
    model['rake_angles'] = []
    model['base_supports'] = []

    def pieces(role, owner, face, run, **more):
        remain = run
        i = 0
        while remain > EPS:
            cut = min(240, remain)
            i += 1
            extra = dict(more)
            extra['x_start_in'] = float(extra.get('x_start_in', 0.0)) + run - remain
            extra['x_end_in'] = extra['x_start_in'] + cut
            rec = dict(
                mark=p.column_mark + '-' + owner + '-' + role + '-' + face + '-' + str(i),
                face=face,
                owner=owner,
                profile=pr['id'],
                quantity=1,
                length_in=cut,
                run_length_in=run,
                finish=p.base_angle.get('finish', 'Red Oxide'),
                status='STANDARD SHEET SCREW SUPPORT /20ft stock segmentation; joint support, fasteners and end fits reviewed separately',
                **extra,
            )
            model['rake_angles' if role == 'RA' else 'base_supports'].append(rec)
            remain -= cut

    if p.cladding.get('walls'):
        W = float(p.width.inches)
        m = float(p.slope_rise) / 12
        ends = getattr(p, 'endwalls', {}) or {}
        for face in ('front', 'rear'):
            # Shop standard: the rake angle sits on top of the purlins of a BYPASS end wall (4 in leg
            # down over the purlin ends) and carries the end-wall sheets.  A flush channel end wall
            # has no purlin ends to close (sheets stop under the roof line) and an OPEN end wall has
            # no sheets: neither gets a rake angle.
            cfg = ends.get('front_end' if face == 'front' else 'rear_end') or {}
            if cfg and (cfg.get('roof_mode') == 'flush' or cfg.get('enclosure') == 'open'):
                continue
            from .enclosure import is_open

            if is_open(p, face):
                continue
            spans = [W] if p.frame_type == 'monoslope' else [W / 2, W / 2]
            for i, span in enumerate(spans):
                pieces(
                    'RA',
                    'MAIN' + str(i + 1),
                    face,
                    span * math.hypot(1, m),
                    top_leg_in=2,
                    down_leg_in=4,
                    screw_support='TOP',
                )
        # Slab base angles are already in run/endwall schedules: do not count twice.
        covered = trim_existing_bases(job, p, model)
        # Base angle is a SLAB detail: post-hole buildings get no base angle anywhere
        # (first girt 12 in up instead).  Without this guard the material list bought
        # CAB1 for post-footing jobs that have no slab (owner round 17).
        if str(getattr(p, 'foundation', 'slab')) != 'post_footing':
            for face, L in [
                ('front', W),
                ('rear', W),
                ('left', float(p.length.inches) if p.length else 0),
                ('right', float(p.length.inches) if p.length else 0),
            ]:
                if face in covered:
                    continue
                from .bay_zones import active, intervals
                from .enclosure import is_open

                if is_open(p, face):
                    continue  # open wall: no sheets, no base support
                spans = intervals(p, face) if active(p) and face in ('left', 'right') else [(0, L)]
                # Leave the aperture and jamb envelopes open at the floor.
                for o in model['openings']:
                    if o['face'] == face and o['y_in'] <= EPS:
                        a = o['x_in'] - o['jamb_face']
                        b = o['x_in'] + o['width_in'] + o['jamb_face']
                        spans = [
                            seg
                            for lo, hi in spans
                            for seg in ([(lo, min(hi, a))] if lo < a else []) + ([(max(lo, b), hi)] if hi > b else [])
                            if seg[1] > seg[0] + EPS
                        ]
                for z in model['lean_tos']:
                    if z['face'] == face and z['walls']['main_below'] == 'open':
                        a = z['start_in']
                        b = a + z['length_in']
                        spans = [
                            seg
                            for lo, hi in spans
                            for seg in ([(lo, min(hi, a))] if lo < a else []) + ([(max(lo, b), hi)] if hi > b else [])
                            if seg[1] > seg[0] + EPS
                        ]
                for i, (lo, hi) in enumerate(spans):
                    pieces(
                        'BA',
                        'MAIN' + str(i + 1),
                        face,
                        hi - lo,
                        vertical_leg_in=2,
                        horizontal_leg_in=4,
                        screw_support='BOTTOM',
                        x_start_in=lo,
                    )
    from .foundation import lean_is_post_footing

    for z in model['lean_tos']:
        post_footing = lean_is_post_footing(p, z)  # per lean (v0.8.43): post holes get no base angle
        walls = z.get('walls') or {}
        for face in ('start_end', 'finish_end'):
            if walls.get(face, 'open') != 'sheeted':
                continue
            pieces('RA', z['id'], face, z['roof_slope_length_in'], top_leg_in=2, down_leg_in=4, screw_support='TOP')
            if not post_footing:
                pieces(
                    'BA',
                    z['id'],
                    face,
                    z['projection_in'],
                    vertical_leg_in=2,
                    horizontal_leg_in=4,
                    screw_support='BOTTOM',
                )
        if z['walls']['outer'] == 'sheeted' and not post_footing:
            pieces(
                'BA',
                z['id'],
                'outer_wall',
                z['length_in'],
                vertical_leg_in=2,
                horizontal_leg_in=4,
                screw_support='BOTTOM',
            )


def trim_existing_bases(job, p, model):
    """Retain existing slab schedules, cutting support stock around floor apertures.
    No source joint gap is invented. Jamb outer face is the net support boundary.
    """
    owner = job.assemblies[p.column_mark]
    covered = set()

    def spans(face, lo, hi):
        result = [(lo, hi)]
        obstacles = [
            (o['x_in'] - o['jamb_face'], o['x_in'] + o['width_in'] + o['jamb_face'])
            for o in model['openings']
            if o['face'] == face and o['y_in'] <= EPS
        ]
        obstacles += [
            (z['start_in'], z['start_in'] + z['length_in'])
            for z in model['lean_tos']
            if z['face'] == face and z['walls']['main_below'] == 'open'
        ]
        for a, b in obstacles:
            result = [
                s
                for lo, hi in result
                for s in ([(lo, min(hi, a))] if lo < a else []) + ([(max(lo, b), hi)] if hi > b else [])
                if s[1] > s[0] + EPS
            ]
        return result

    runs = owner.derivation.get('secondary_runs', {})
    new = []
    changed = False
    L = runs.get('support_length_in', 0)
    for r in runs.get('pieces', []):
        if r['role'] != 'base_angle':
            new.append(r)
            continue
        face = r['side']
        covered.add(face)
        if r.get('start_in') is None:
            new.append(r)
            continue
        reverse = face == 'left'
        a, b = (L - r['end_in'], L - r['start_in']) if reverse else (r['start_in'], r['end_in'])
        remaining = spans(face, a, b)
        if remaining == [(a, b)]:
            new.append(r)
            continue
        changed = True
        for i, (lo, hi) in enumerate(remaining, 1):
            q = copy.deepcopy(r)
            q.update(
                piece_id=r['piece_id'] + '-BA' + str(i),
                start_in=L - hi if reverse else lo,
                end_in=L - lo if reverse else hi,
                cut_length_in=hi - lo,
                cut_length=fmt(hi - lo),
                pattern='BASE SUPPORT / FLOOR APERTURE',
                status='NET BASE SUPPORT CUT TO JAMB OUTSIDE FACE; end/joint fasteners pending',
            )
            new.append(q)
    if changed:
        runs['pieces'] = new
        from .erection_templates import regroup

        regroup(job, p, runs)
    for end, wall in owner.derivation.get('endwalls', {}).items():
        face = 'front' if end == 'front_end' else 'rear'
        W = wall['width_in']
        new = []
        changed = False
        for r in wall['members']:
            if r['role'] != 'base angle':
                new.append(r)
                continue
            covered.add(face)
            if r['reference_cut_in'] is None:
                new.append(r)
                continue
            a = r['x0_in'] + 0.25
            b = r['x1_in'] - 0.25
            reverse = face == 'rear'
            lo, hi = (W - b, W - a) if reverse else (a, b)
            remaining = spans(face, lo, hi)
            if remaining == [(lo, hi)]:
                new.append(r)
                continue
            changed = True
            for i, (lo, hi) in enumerate(remaining, 1):
                q = copy.deepcopy(r)
                q.update(
                    mark=r['mark'] + '-BA' + str(i),
                    x0_in=W - hi if reverse else lo,
                    x1_in=W - lo if reverse else hi,
                    reference_cut_in=hi - lo,
                    blank_length_in=hi - lo,
                    reference_cut=fmt(hi - lo),
                    blank_length=fmt(hi - lo),
                    estimated_weight_lb=(hi - lo) / 12 * r['weight_lb_ft'] if r['weight_lb_ft'] is not None else None,
                    status='NET BASE SUPPORT CUT TO JAMB OUTSIDE FACE; end/joint fasteners pending',
                )
                new.append(q)
        if changed:
            wall['members'] = new
            groups = {}
            for r in new:
                key = (r['role'], r['profile_id'], r['finish'], r['reference_cut'], r['blank_length'], r['status'])
                if key not in groups:
                    groups[key] = {
                        k: r[k]
                        for k in (
                            'role',
                            'profile_id',
                            'finish',
                            'reference_cut',
                            'reference_cut_in',
                            'blank_length',
                            'blank_length_in',
                            'status',
                        )
                    }
                    groups[key].update(cut_group='EW-BASE-' + end + '-' + str(len(groups) + 1), quantity=0)
                groups[key]['quantity'] += 1
                r['cut_group'] = groups[key]['cut_group']
            wall['cuts'] = list(groups.values())
    return covered
