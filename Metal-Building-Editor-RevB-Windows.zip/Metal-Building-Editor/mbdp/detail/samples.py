"""The four standard sample jobs / starting options (owner decisions, 2026-10-15).

Every workspace carries them on the SSS shop standard (``standards.SSS_STANDARD``
and the layout rules in ``standards``):

======  ===================================  ==================================
job no  building                             walls / foundation
======  ===================================  ==================================
356     Carport 20 x 40 x 8 (mono-slope)     roof only; 2 bays @ 20 ft, 1:12;
                                             4x4x11 ga tube posts, interior
                                             rafter two SS6214 open-face
                                             channels welded back to back (I),
                                             single SS6214 end rafters, 6 in
                                             purlins inside the channels
                                             (20'-0 less 1/2); post footings
357     Roof only 40 x 60 x 12               rigid frames at both ends, no
                                             walls or girts; post footings
358     Three-sided (implement shed)         both end walls + back sidewall
        40 x 60 x 12                         sheeted, front sidewall open;
                                             post footings, girts 1'-0 /
                                             4'-8 / 8'-4, no base angle
359     Fully enclosed 40 x 60 x 12          all four walls sheeted; slab,
                                             base angle + girts 4'-0 / 8'-0
======  ===================================  ==================================

The 40 x 60 buildings: 3 bays at 20 ft, 1:12 roof, W12X14 frames from the 40 ft
width preset, purlins evenly spaced at 5 ft maximum, W8X10 bypass end rafters
with a centre end-wall post (40 ft -> 20/20).  Since v0.8.39 every sample (and
every new job) is FULLY WELDED - rafters welded to the INSIDE flange of the
columns (columns at eave height, the round-14 standard; the outside seat is the
option), purlins flush to the top of the rafter, flush girts welded to the column
webs, one-piece cut-and-fold ridge; bolted brackets are the option.

Job numbers 356-359 are reserved for them; the first real job proposed by the
editor is 360 (``job_library.next_job_no``).  The hand-modelled Clark Jordan
reference (``templates.sample_job``, 1277345) stays available separately and
never advances the job counter.  Samples are recognised in a job list by
customer ``SAMPLE`` and the tag in the building name (``tag``), so a workspace
filed before the carport existed keeps its numbers.
"""

from __future__ import annotations

import copy

from . import model as M
from .standards import frame_defaults, girt_lines_text, job_settings

CUSTOMER = 'SAMPLE'

# Wizard defaults (editor ``app.js``) for a 40 x 60 x 12 building; the SSS
# standard products are merged in by :func:`params`.
_BASE = dict(
    additions={'opening_auto': True},
    auto_roof_spacing=True,  # purlins evenly spaced at 5 ft maximum, eave strut to ridge purlin
    starting_wall_run=True,
    starting_run='0"',
    slab=True,  # base angle at the floor on every sheeted wall (owner standard SSS-CAB1)
    welded_knee='inside_flange',  # round 14: welded inside flange is the shop standard (outside seat = option)
    base_connection='base_plate',
    clip_policy='member_sized',
    # Owner (round 10 + round 15): every new job starts FULLY WELDED with the rafter welded to the
    # column INSIDE flange and BYPASS purlins (purlin bearing on the rafter top flange, eave purlin
    # on the column seat - the standard: column = eave height - purlin depth); flush mount purlins
    # (column at eave height, eave purlin welded to the outside of the column flange), the outside
    # seat, bolted brackets and the shared ridge plate stay options.
    connection_style='fully_welded',
    girt_attachment='web_weld',
    ridge_fabrication='standard',
    purlin_depth='8"',
    eave_plate_extension='3"',
    inset_for_bypass=False,
    girt_depth='8"',
    frame_type='gable',
    high_column_mark='COL-2',
    high_column_cut_mark='RF-102',
    high_column_section='',
    high_girt_elevations='',
    prefix='RF1',
    frames=2,
    width="40'",
    eave_height="12'",
    slope_rise='1',
    length="60'",
    column_mark='COL-1',
    rafter_mark='RF1-1',
    column_cut_mark='RF-100',
    rafter_cut_mark='RF-101',
    base_plate='B-14',
    knee_bracket='BR14HE1',
    rafter_end_plate='K-14',
    column_top_gap='0"',
    knee_setback='0"',
    ridge_half_gap='0"',
    girt_clip='PC8D',
    girt_elevations='',  # filled per foundation by params(): standards.girt_lines
    purlin_clip='PC8D',
    first_purlin='4\'-10"',
    first_purlin_datum='outside_column',
    purlin_spacing='4\'-4"',
    flange_brace_clip='CLF2',
    flange_brace_at='0, 2, 4',
    flange_brace_y='11"',
    eave_strut_depth='8"',
    base_elevation='0"',
    foundation='slab',
    footing_depth="3'",
    footing_diameter='18"',
    box_height='14"',
    height_mode='top_eave_strut',
    auto_connections=True,
    eave_start_clip=True,
    apex_bottom_half='6"',
    peak_clip_edge='11"',
    apex_reference_half=None,
    connection_bottom_mode='column_depth',
    connection_bottom='10 1/2"',
    top_extension='0"',
    flange_thk='1/4"',
    web_thk='3/16"',
    weld_size='1/4"',
    plate_mode='member',
    girt_mode='flush',  # welded standard: girts flush, welded to the column web
    purlin_mode='bypass',  # round 15: the standard fit - purlins bear on the rafter top flange
    girt_web_y='4"',
    purlin_web_y='4"',
    girt_side='NS',
    purlin_side='NS',
    section_defaults={'enabled': True},  # 40 ft width preset -> W12X14 column and rafter
    bay_layout=dict(
        enabled=True,
        layout_mode='standard',  # shop rule: 20 ft bays, odd bay in the middle (never an equal subdivision)
        bays=3,
        spacing="20'",
        front_clearance='1/4"',
        rear_clearance='1/4"',
        purlin_pattern='A_butt',
        girt_pattern='A_butt',
        purlin_direction='forward',
        girt_direction='forward',
    ),
    endwalls={'enabled': True},
)


def _zoned(front: str, back: str) -> dict:
    return dict(
        enabled=True,
        enclosed_start_line=0,
        bays=[dict(length="20'", left=back, right=front) for _ in range(3)],
    )


SAMPLES = {
    '356': dict(
        key='carport',
        tag='CARPORT',
        building='SAMPLE 356 - 20x40x8 CARPORT',
        description='Carport (mono-slope): roof only, 2 bays @ 20 ft, 4x4x11 ga tube posts, doubled open-face channel I-rafter inside, single channel end rafters, 6 in purlins inside the channels; post footings 18 in x 3 ft.',
        foundation='post_footing',
        walls='none',
    ),
    '357': dict(
        key='roof_only',
        tag='ROOF ONLY',
        building='SAMPLE 357 - 40x60x12 ROOF ONLY',
        description='Roof only: rigid frames at both ends, no walls or girts; post footings 18 in x 3 ft.',
        foundation='post_footing',
        walls='none',
    ),
    '358': dict(
        key='three_sided',
        tag='THREE-SIDED',
        building='SAMPLE 358 - 40x60x12 THREE-SIDED',
        description='Implement shed: both end walls and the back sidewall sheeted, front sidewall open; post footings 18 in x 3 ft.',
        foundation='post_footing',
        walls='three',
    ),
    '359': dict(
        key='enclosed',
        tag='ENCLOSED',
        building='SAMPLE 359 - 40x60x12 ENCLOSED',
        description='Fully enclosed: all four walls sheeted; slab with base plates.',
        foundation='slab',
        walls='all',
    ),
}
BY_KEY = {v['key']: k for k, v in SAMPLES.items()}


def which_of(key_or_no: str) -> str:
    """Sample number from a number or a key (``carport`` -> ``356``)."""
    k = str(key_or_no or '').strip()
    if k in SAMPLES:
        return k
    if k.lower() in BY_KEY:
        return BY_KEY[k.lower()]
    raise ValueError('Unknown sample job: ' + k)


def is_sample(row, which: str) -> bool:
    """True when a job-list row is this sample, whatever its number: the ``sample`` key the
    job carries in its settings, or - for copies filed before 0.8.31 - customer SAMPLE with
    the tag in the building name."""
    spec = SAMPLES[which_of(which)]
    if row.get('sample'):
        return row['sample'] == spec['key']
    return str(row.get('customer', '')).strip().upper() == CUSTOMER and spec['tag'] in str(
        row.get('building', '')
    ).upper().replace('THREE SIDED', 'THREE-SIDED')


def carport_params() -> dict:
    """Frame-wizard parameters of the standard carport (``standards.CARPORT_STANDARD``)."""
    from .standards import CARPORT_STANDARD as C

    P = copy.deepcopy(_BASE)
    P.update(frame_defaults())
    P['cladding'].update(enabled=True, walls=False, roof=True)
    P.update(
        frame_type=C['frame_type'],  # mono-slope standard (v0.8.34); gable stays selectable
        high_column_mark=C['high_column_mark'],
        high_column_cut_mark=C['high_column_cut_mark'],
        width=C['width'],
        length=C['length'],
        eave_height=C['eave_height'],
        slope_rise=C['slope_rise'],
        frames=C['bays'] - 1,
        section_defaults={'enabled': False},
        column_section=C['column_section'],
        rafter_section=C['rafter_section'],
        connection_style='fully_welded',  # open-face channel rafters are welded frames
        welded_knee='inside_flange',  # carport: every rafter welded to the inside face of its column, no cap
        purlin_mode='flush',  # purlins inside the channel, 1/4 in from the web
        purlin_depth=C['purlin_depth'],
        girt_depth=C['purlin_depth'],
        foundation='post_footing',
        slab=False,
        starting_wall_run=False,
        girt_elevations='',
        endwalls={
            'enabled': True,
            # single channel end rafters welded to the inside face of the corner tubes (columns
            # to the roof line, no cap), 3/16 x 5 x 7 splice plate welded to the channel faces at
            # the ridge (owner carport detail)
            'front_end': {
                'rafter_override': 'channel',
                'enclosure': 'open',
                'post_head': 'side_welded',
                'ridge_joint': 'face_clip',
            },
            'rear_end': {
                'rafter_override': 'channel',
                'enclosure': 'open',
                'post_head': 'side_welded',
                'ridge_joint': 'face_clip',
            },
        },
    )
    for role in ('purlin', 'girt', 'eave'):
        P['secondary'][role]['profile_id'] = C['purlin']  # 6 in Z everywhere, eave member included
    P['bay_layout'].update(bays=C['bays'], spacing=C['spacing'])
    return P


def params(which: str) -> dict:
    """Frame-wizard parameters of a sample, ready for ``FrameParams.from_json``."""
    which = which_of(which)
    spec = SAMPLES[which]
    if spec['key'] == 'carport':
        return carport_params()
    P = copy.deepcopy(_BASE)
    P.update(frame_defaults())
    P['cladding'].update(enabled=True, walls=True, roof=True)
    P['foundation'] = spec['foundation']
    # Shop girt rule: slab -> base angle + even lines at 5 ft maximum (12 ft: 4'-0 / 8'-0);
    # post footing -> no base angle, first girt 12 in above the floor (12 ft: 1'-0 / 4'-8 / 8'-4).
    P['girt_elevations'] = girt_lines_text(144, spec['foundation'])
    if spec['foundation'] == 'post_footing':
        P.update(slab=False, starting_wall_run=False)
    if spec['walls'] == 'none':
        # No walls: no end-wall framing, no girts, no base angle; the end lines
        # are two more frames of the lot (4 identical rigid frames).
        P.update(frames=4, girt_elevations='', starting_wall_run=False, slab=False, endwalls={'enabled': False})
        P['bay_layout'].update(front_end={'type': 'rigid_frame'}, rear_end={'type': 'rigid_frame'})
        P['cladding'].update(walls=False)
    elif spec['walls'] == 'three':
        P['bay_zones'] = _zoned(front='open', back='sheeted')
    else:
        P['bay_zones'] = _zoned(front='sheeted', back='sheeted')
    return P


def sample_job(which: str, job_no: str | None = None) -> M.Job:
    """A generated sample job (frame, secondaries, cladding, release checks run by the caller)."""
    from .frame import FrameParams, generate_frame
    from .templates import standard_parts

    which = which_of(which)
    spec = SAMPLES[which]
    job = M.Job(job_no=str(job_no or which), customer=CUSTOMER, building=spec['building'], parts=standard_parts())
    job.settings.update(job_settings())
    job.settings['sample'] = spec['key']
    generate_frame(job, FrameParams.from_json(params(which)))
    return job


def sample_jobs() -> dict:
    return {k: sample_job(k) for k in SAMPLES}
