"""Deterministic PBR envelope takeoff, separate from structural fabrication.

Coverage strips, NOT net-area purchasing. Single-piece roof runs. Wall strips
may be interrupted by full-width apertures; partial apertures retain a blank.
No offcut sharing, engineered connections, panel end laps, or automatic splices.
"""

import copy
import json
import math
from fractions import Fraction
from pathlib import Path

from .building import code as face_code
from .building import name as face_name
from .model import D

EPS = 1e-8
SURFACES = ('front', 'rear', 'left', 'right', 'roof_left', 'roof_right', 'roof_mono')
DEFAULTS = {
    'wall_bottom_clearance': '0',
    'wall_top_allowance': '0',
    'roof_eave_extension': '0',
    'roof_ridge_cutback': '0',
    'roof_high_cutback': '0',
    'roof_front_overhang': '0',
    'roof_rear_overhang': '0',
    'trim_lap': '2',
    'trim_end_allowance': '0',
}
STOCK = {
    'corner': 'FL-830',
    'base': 'FL-530',
    'rake': 'FL-16',
    'high_eave': 'FL-17',
    'eave': 'FL-19',
    'jamb': 'FL-23',
    'head': 'FL-26',
    'ridge': 'FL-38',
    'sill': '',
    # Wall-to-roof transition of a lowered lean roof: custom formed when no stock id is chosen.
    'transition': '',
}


def catalog(supplier="mbci"):
    from .residential_rake import profile

    data = json.loads((Path(__file__).parent / 'data/mbci_pbr.json').read_text())
    data['trims'].append(profile())
    from .product_library import colors, trims

    if supplier == 'all':
        data['colors'] += colors()
        data['trims'] += trims()
    return data


def inch(x):
    if isinstance(x, bool):
        raise ValueError('Dimension cannot be boolean')
    try:
        n = float(Fraction(str(x).strip().rstrip(chr(34))))
    except (ValueError, ZeroDivisionError):
        n = float(D(x).inches)
    if not math.isfinite(n):
        raise ValueError('Dimension must be finite')
    return n


def fmt(n):
    return D(Fraction(round(n * 16), 16)).fmt()


def fmt_signed(x):
    from .grades import fmt_grade

    return fmt_grade(x)


def ceil16(n):
    return math.ceil(n * 16 - EPS) / 16


def selection(name, gauge, trim=False, where=''):
    c = next((x for x in catalog('all')['colors'] if x['name'] == name), None)
    if not c:
        at = (' for ' + where) if where else ''
        if not name:
            raise ValueError(
                'No sheet color selected'
                + at
                + ': choose a supplier color (Building settings > step 5 - Sheets & trim). Colors are never chosen for you.'
            )
        raise ValueError('Unknown current MBCI color' + at + ': ' + str(name))
    try:
        g = int(gauge)
    except (ValueError, TypeError):
        raise ValueError('PBR gauge must be26,24,22')
    if g != float(gauge) or g not in (26, 24, 22):
        raise ValueError('Current PBR chart permits26,24,22;29ga is not offered here')
    coat = c['coating']
    if c.get('supplier') == 'sss':
        if g != 26:
            raise ValueError('Supplied SSS sheet/trim catalog requires 26ga; select an available product')
        return dict(
            color=name,
            coating=coat,
            gauge=g,
            hex=c['hex'],
            supplier='sss',
            availability='Supplier color selection; confirm physical samples and branch availability',
        )
    if trim:
        g = 24 if coat.startswith('Signature 300') else 26
    if coat == 'Signature 300 Metallic' and g != 24:
        raise ValueError('Copper Metallic requires24 gauge')
    status = 'STANDARD; confirm availability at order entry'
    if coat.startswith('Signature'):
        if g == 24 or (g == 26 and coat != 'Signature 200'):
            status = 'NONSTANDARD: special pricing, minimum quantity and extended lead time'
        if g == 22:
            whites = ('Polar White', 'Bright White', 'White', 'Snow White', 'Bone White')
            status = (
                'SELECT WHITE: extended lead time'
                if name in whites
                else 'NONSTANDARD: special pricing, minimum quantity and extended lead time'
            )
    return dict(color=name, coating=coat, gauge=g, hex=c['hex'], availability=status)


def owner_edge(c, sid, pitch):
    """Along-slope sheet extension; gutter projection measured from outside wall plane."""
    e = c.get('roof_edges', {}).get(sid, {})
    if not e.get('gutter', False):
        return 8.0
    return (2.0 + (1.5 if e.get('wall_sheets', c.get('walls', True)) else 0.0)) * math.hypot(1, float(pitch) / 12)


def apply(p):
    raw = p.cladding
    if not isinstance(raw, dict):
        raise ValueError('Cladding must be an object')
    if not isinstance(raw.get('enabled', False), bool):
        raise ValueError('Cladding enabled must be boolean')
    if not raw.get('enabled'):
        p.cladding = {}
        return
    if not p.auto_connections or p.height_mode != 'top_eave_strut':
        raise ValueError('PBR envelope requires managed roof/eave datum')
    cfg = copy.deepcopy(raw)
    for k in ('owner_length_rules', 'slab_jamb_lug'):
        if not isinstance(cfg.get(k, False), bool):
            raise ValueError(k + ' must be boolean')
    edges = cfg.get('roof_edges', {})
    if not isinstance(edges, dict) or any(k not in ('roof_left', 'roof_right', 'roof_mono') for k in edges):
        raise ValueError('Unknown roof edge')
    for edge in edges.values():
        if not isinstance(edge, dict) or any(
            not isinstance(edge.get(k, False), bool) for k in ('gutter', 'wall_sheets')
        ):
            raise ValueError('Roof gutter / wall sheets must be boolean')
    for key in ('walls', 'roof'):
        if not isinstance(cfg.get(key, True), bool):
            raise ValueError(key + ' enabled must be boolean')
        cfg.setdefault(key, True)
    # Eave and base trim are an OPTION, never automatic (owner 0.8.55).
    if not isinstance(cfg.get('eave_base_trim', False), bool):
        raise ValueError('eave_base_trim must be boolean')
    cfg.setdefault('eave_base_trim', False)
    if not cfg['walls'] and not cfg['roof']:
        raise ValueError('Enable walls and/or roof for PBR takeoff')
    if cfg['roof'] and float(p.slope_rise) < 0.5:
        raise ValueError('PBR roof minimum slope is0.5:12; use walls-only or revise slope')
    # Explicit outside-wall length avoids silently treating frame CL spacing as skin length.
    L = inch(cfg.get('length', '0'))
    if not 0 < L <= 12000:
        raise ValueError('Enter outside-wall BUILDING LENGTH, positive and at most1000 ft')
    cfg['length'] = str(Fraction(L).limit_denominator(100000000)) + '"'
    cfg['length_in'] = L
    for k, v in DEFAULTS.items():
        n = inch(cfg.get(k, v))
        if abs(n) > 120 or (k != 'wall_top_allowance' and n < 0):
            raise ValueError(k + ' is outside allowed allowance range')
        cfg[k] = str(Fraction(n).limit_denominator(100000)) + '"'
    for role, default in [('wall', 'Light Stone'), ('roof', 'Polar White'), ('trim', 'Burnished Slate')]:
        s = cfg.get(role + '_finish', {})
        if not isinstance(s, dict):
            raise ValueError('Finish selections must be objects')
        cfg[role + '_finish'] = selection(
            s.get('color', default), s.get('gauge', 26), role == 'trim', role.upper() + ' default finish'
        )
    over = cfg.get('surface_finishes', {})
    if not isinstance(over, dict) or any(k not in SURFACES for k in over):
        raise ValueError('Unknown surface finish override')
    cfg['surface_finishes'] = {
        k: selection(v['color'], v.get('gauge', 26), where=k.replace('_', ' ') + ' surface finish')
        for k, v in over.items()
    }
    ts = cfg.get('trim_stock', {})
    if not isinstance(ts, dict):
        raise ValueError('Trim stock must be an object')
    profiles = {x['id']: x for x in catalog('all')['trims']}
    cfg['trim_stock'] = {**STOCK, **ts}
    for role, id in cfg['trim_stock'].items():
        if (
            role not in STOCK
            or (id and (id not in profiles or profiles[id]['role'] != role))
            or (not id and role not in ('sill', 'transition') and not cfg.get('supplier_products'))
        ):
            raise ValueError('Invalid trim stock/profile for ' + role)
        if (
            id
            and profiles[id].get('panel_compatibility')
            and not cfg.get('panel_profile_id', 'MBCI-PBR').endswith(profiles[id]['panel_compatibility'])
        ):
            raise ValueError(
                role
                + ': selected trim is for '
                + profiles[id]['panel_compatibility']
                + '; select a trim compatible with the sheet profile'
            )
        if id and inch(cfg['trim_lap']) >= profiles[id]['stock_length_in']:
            raise ValueError('Trim lap must be less than stock length')
    ops = cfg.get('openings', [])
    if not isinstance(ops, list) or len(ops) > 100:
        raise ValueError('Openings must be a list, maximum100')
    clean = []
    ids = set()
    for i, o in enumerate(ops):
        if not isinstance(o, dict):
            raise ValueError('Opening must be an object')
        id = str(o.get('id', 'O' + str(i + 1)))
        if not id or len(id) > 30 or id in ids:
            raise ValueError('Opening IDs must be unique and1–30 characters')
        ids.add(id)
        s = o.get('surface')
        kind = o.get('kind', 'door')
        if s not in SURFACES[:4] or kind not in ('door', 'overhead', 'window', 'fixed_glass'):
            raise ValueError('Opening needs wall elevation and door/window/fixed_glass type')
        rec = dict(id=id, surface=s, kind=kind)
        if o.get("relocation") and abs(inch(o.get("x", 0)) - o["relocation"].get("to_in", -1000)) < EPS:
            rec["relocation"] = copy.deepcopy(o["relocation"])
        for key in ('x', 'y', 'width', 'height'):
            rec[key + '_in'] = inch(o.get(key, 0))
        if min(rec['x_in'], rec['y_in']) < 0 or min(rec['width_in'], rec['height_in']) <= 0:
            raise ValueError('Opening positions must be nonnegative and sizes positive')
        rec.update(
            {k: str(Fraction(rec[k + '_in']).limit_denominator(100000000)) + '"' for k in ('x', 'y', 'width', 'height')}
        )
        clean.append(rec)
    if ops and not cfg['walls']:
        raise ValueError('Wall openings require wall panels enabled')
    cfg['openings'] = clean
    p.cladding = cfg


def finish(job, p):
    from .product_library import panel

    panel_spec = panel(p.cladding.get('panel_profile_id', 'MBCI-PBR'))
    owner = job.assemblies[p.column_mark]
    layout = job.settings.get('frame_layouts', {}).get(p.column_mark, {})
    owner.derivation.pop('cladding', None)
    layout.pop('cladding', None)
    job.settings['frames'][p.column_mark]['cladding'] = copy.deepcopy(p.cladding)
    if not p.cladding:
        return
    c = p.cladding
    W = float(p.width.inches)
    L = c['length_in']
    H = float(p.eave_height.inches)
    m = float(p.slope_rise) / 12
    slope = math.hypot(1, m)
    mono = p.frame_type == 'monoslope'
    a = {k: inch(c[k]) for k in DEFAULTS}
    bottom = a['wall_bottom_clearance']
    top = a['wall_top_allowance']
    # H is the entered envelope top-of-eave datum, not rafter or inset column top.
    roof = lambda x: H + m * (x if mono else min(x, W - x))
    wallprofiles = {
        'front': [(0, roof(0)), (W, roof(W))] if mono else [(0, H), (W / 2, roof(W / 2)), (W, H)],
        'rear': [(0, roof(W)), (W, roof(0))] if mono else [(0, H), (W / 2, roof(W / 2)), (W, H)],
        'left': [(0, H), (L, H)],
        'right': [(0, roof(W)), (L, roof(W))],
    }
    datums = {
        'front': 'LEFT ENDWALL outside view: x=0 BACK sidewall; x toward FRONT sidewall',
        'rear': 'RIGHT ENDWALL outside view: x=0 FRONT sidewall; x toward BACK sidewall',
        'left': 'BACK SIDEWALL outside view: x=0 RIGHT endwall; x toward LEFT endwall',
        'right': 'FRONT SIDEWALL outside view: x=0 LEFT endwall; x toward RIGHT endwall',
    }
    surfaces = []
    panels = []
    groups = []
    trims = []
    trim_pieces = []
    warnings = [
        'PLANNING TAKEOFF, NOT RELEASED FOR PURCHASE/FABRICATION. Verify wall planes, roof datum, edge allowances and opening flashing details.',
        'Building outside-wall length is explicit; quantities count ONE building envelope, not frame lot quantity.',
        'Panel procurement blanks rounded UP to1/16 in; exact lengths and all aperture cuts retained. No scrap/offcut reuse or automatic panel end laps.',
        'Trim lap is an EDITABLE PROJECT ASSUMPTION (initial default2 in), NOT an MBCI requirement. Confirm laps, returns, miters, end caps, closures and sealants.',
        'Openings cut CLADDING ONLY: framing/header/jamb/secondary conflicts, structural design and endwall connections remain deferred.',
        'Base clearance and sheeting notch need review; avoid unprotected panel contact with concrete. Screen colors approximate; use metal chips.',
    ]
    if c.get('owner_length_rules'):
        warnings.append(
            'OWNER LENGTHS: sheets ordered to calculated blank lengths; trim exact lengths / max20ft6in. Standard eave8in ALONG slope; gutter edges2in horizontal beyond outside building plus1.5in if wall sheets, converted to slope. Slab-level door jamb trim+1.5in lug; head trim+3in TOTAL out-to-out. Explicit general trim end allowance remains additional.'
        )

    def height(poly, x):
        for (u, y), (v, z) in zip(poly, poly[1:]):
            if u - EPS <= x <= v + EPS:
                return y + (z - y) * (x - u) / (v - u)
        raise ValueError('Position outside elevation')

    def profile_points(poly, x0, x1):
        return (
            [(x0, height(poly, x0))] + [(x, y) for x, y in poly if x0 + EPS < x < x1 - EPS] + [(x1, height(poly, x1))]
        )

    for sid, poly0 in wallprofiles.items():
        if not c['walls']:
            continue
        poly = [(x, y + top) for x, y in poly0]
        width = poly[-1][0]
        ops = [o for o in c['openings'] if o['surface'] == sid]
        for lean in owner.derivation.get('framing_additions', {}).get('lean_tos', []):
            if lean['face'] == sid and lean['walls']['main_below'] == 'open':
                ops.append(
                    dict(
                        id='OPEN-BELOW-' + lean['id'],
                        surface=sid,
                        kind='lean_open',
                        x_in=lean['start_in'],
                        y_in=0,
                        width_in=lean['length_in'],
                        height_in=lean['high_eave_in'],
                    )
                )
        if min(y for x, y in poly) <= bottom:
            raise ValueError('Wall allowances consume elevation height')
        for o in ops:
            x = o['x_in']
            y = o['y_in']
            w = o['width_in']
            h = o['height_in']
            if x + w > width + EPS or y + h > min(height(poly, x), height(poly, x + w)) + EPS:
                raise ValueError(o['id'] + ': opening extends outside ' + sid + ' wall')
            for q in ops:
                if q is o:
                    break
                if (
                    min(x + w, q['x_in'] + q['width_in']) > max(x, q['x_in']) + EPS
                    and min(y + h, q['y_in'] + q['height_in']) > max(y, q['y_in']) + EPS
                ):
                    raise ValueError('Overlapping openings: ' + o['id'] + ' / ' + q['id'])
        finish = c['surface_finishes'].get(sid, c['wall_finish'])
        from .bay_zones import active as zones_active
        from .bay_zones import intervals as zone_intervals
        from .bay_zones import wall_station
        from .enclosure import is_open as wall_is_open

        ranges = zone_intervals(p, sid) if zones_active(p) and sid in ('left', 'right') else [(0, width)]
        open_end = sid in ('front', 'rear') and (
            ((getattr(p, 'endwalls', {}) or {}).get('front_end' if sid == 'front' else 'rear_end', {}) or {}).get(
                'enclosure'
            )
            == 'open'
            or wall_is_open(p, sid)
        )
        open_side = sid in ('left', 'right') and not zones_active(p) and wall_is_open(p, sid)
        if open_end or open_side:
            # Open wall (framing only): no sheets, base or corner trim on this wall (v0.8.35:
            # every wall is an explicit sheeted / open choice, Building settings > step 1).
            ranges = []
            if ops:
                raise ValueError(
                    ops[0]['id']
                    + ': opening is on an OPEN '
                    + ('end wall' if open_end else 'sidewall')
                    + ' (no sheets). Sheet that wall (Building settings > step 1 - Building & bays > Walls) or remove the opening.'
                )
        for o in ops:
            if not any(lo - EPS <= o['x_in'] and o['x_in'] + o['width_in'] <= hi + EPS for lo, hi in ranges):
                from .building import name as face_label

                sheeted = ', '.join(fmt(lo) + ' to ' + fmt(hi) for lo, hi in ranges) or 'none'
                raise ValueError(
                    o['id']
                    + ': opening is on an open/future bay of the '
                    + face_label(sid)
                    + ' (sheeted X ranges, outside view: '
                    + sheeted
                    + '). Move its X into a sheeted bay (Building settings > step 3 - Endwalls & openings) or sheet that bay (step 1 - Building & bays); nothing is relocated for you.'
                )
        gross = sum(
            (v - u) * ((y + z) / 2 - bottom)
            for lo, hi in ranges
            for (u, y), (v, z) in zip(profile_points(poly, lo, hi), profile_points(poly, lo, hi)[1:])
        )
        net = gross - sum(o['width_in'] * max(0, o['y_in'] + o['height_in'] - max(bottom, o['y_in'])) for o in ops)
        surfaces.append(
            dict(
                sheeted_intervals=ranges,
                open_end=open_end,
                open_wall=bool(open_end or open_side or not ranges),
                station_in=wall_station(p, sid) if sid in ('front', 'rear') else None,
                id=sid,
                kind='wall',
                width_in=width,
                top_profile=poly,
                bottom_in=bottom,
                openings=ops,
                datum=datums[sid],
                finish=finish,
                gross_area_sqft=gross / 144,
                net_area_sqft=net / 144,
            )
        )
    # Sheeted OUTER end of a roof-only extension (owner): its own sheet surface at
    # station 0, in addition to the junction wall ('front') further along.
    from .bay_zones import active as _zones_active

    if _zones_active(p) and (getattr(p, 'bay_zones', {}) or {}).get('outer_front_state') == 'sheeted' and c['walls']:
        poly = [(x, y + top) for x, y in wallprofiles['front']]
        gross = sum((v - u) * ((y + z) / 2 - bottom) for (u, y), (v, z) in zip(poly, poly[1:]))
        surfaces.append(
            dict(
                id='outer_front',
                kind='wall',
                sheeted_intervals=[(0, poly[-1][0])],
                open_wall=False,
                open_end=False,
                station_in=0.0,
                width_in=poly[-1][0],
                top_profile=poly,
                bottom_in=bottom,
                openings=[],
                datum=datums['front'],
                finish=c['surface_finishes'].get('front', c['wall_finish']),
                gross_area_sqft=gross / 144,
                net_area_sqft=gross / 144,
            )
        )
    if c['roof']:
        length = (
            (W if mono else W / 2) * slope
            + a['roof_eave_extension']
            - (a['roof_high_cutback'] if mono else a['roof_ridge_cutback'])
        )
        if length <= 0:
            raise ValueError('Roof edge allowances consume panel run')
        width = L + a['roof_front_overhang'] + a['roof_rear_overhang']
        for sid in ['roof_mono'] if mono else ['roof_left', 'roof_right']:
            face = sid.replace('roof_', '')
            combined = [
                z
                for z in owner.derivation.get('framing_additions', {}).get('lean_tos', [])
                if z.get('roof_continuity') == 'main_plane' and z['face'] == face
            ]
            face_overhang = a['roof_eave_extension']
            face_length = length
            rake_length = (W if mono else W / 2) * slope + a['roof_eave_extension']
            continuous_id = None
            if c.get('owner_length_rules'):
                face_overhang = owner_edge(c, sid, p.slope_rise)
                rake_length = (W if mono else W / 2) * slope + face_overhang
                face_length = rake_length - (a['roof_high_cutback'] if mono else a['roof_ridge_cutback'])
            top_profile = [(0, face_length), (width, face_length)]
            rake_left = rake_right = rake_length
            step_rakes = []
            eave_runs = []
            if combined:
                # Continued main roof plane: the sheets run ridge-to-lean-eave over the bays the
                # lean covers.  A full-length lean lengthens the whole slope; a lean over SOME bays
                # (owner, round 11) steps the sheet length inside its extent - the main eave runs
                # on outside it and the lean roof ends in a rake down each open lean end.
                # Lean coordinates are the OUTSIDE view of the face (the back sidewall runs from
                # the right end); this unfolded slope runs from the LEFT end on both sides, so a
                # back-side lean is mirrored into the surface datum.
                steps = []
                for z in sorted(combined, key=lambda q: q['start_in']):
                    long_rake = (W / 2 + z['projection_in']) * slope + z['roof_overhang_in']
                    lo = z['start_in'] if face == 'right' else L - z['start_in'] - z['length_in']
                    x0 = lo + a['roof_front_overhang']
                    x1 = x0 + z['length_in']
                    at_left = abs(lo) < 1e-6
                    at_right = abs(lo + z['length_in'] - L) < 1e-6
                    if at_left:
                        x0 = 0.0
                        rake_left = long_rake
                    if at_right:
                        x1 = width
                        rake_right = long_rake
                    steps.append((x0, x1, long_rake - a['roof_ridge_cutback'], z))
                    for at_end, x in ((at_left, x0), (at_right, x1)):
                        if not at_end:
                            step_rakes.append(
                                dict(
                                    lean_id=z['id'],
                                    x_in=x,
                                    length_in=z['projection_in'] * slope + z['roof_overhang_in'],
                                )
                            )
                    eave_runs.append(dict(x0_in=x0, x1_in=x1, label=z['id'] + ' lean eave', lean_id=z['id']))
                    warnings.append(
                        z['id']
                        + ': roof sheets continuous ridge-to-lean over x='
                        + fmt(x0)
                        + ' to '
                        + fmt(x1)
                        + '; lean ALONG-slope overhang replaces main eave extension there. No automatic splice.'
                    )
                full = len(steps) == 1 and steps[0][0] <= 1e-6 and steps[0][1] >= width - 1e-6
                continuous_id = steps[0][3]['id'] if full else None
                if full:
                    rake_length = rake_left
                    face_length = steps[0][2]
                    face_overhang = steps[0][3]['roof_overhang_in']
                    top_profile = [(0, face_length), (width, face_length)]
                    eave_runs = []
                else:
                    pts = []
                    x = 0.0
                    for x0, x1, fl, z in steps:
                        if x0 > x + 1e-6:
                            pts += [(x, face_length), (x0, face_length)]
                        pts += [(x0, fl), (x1, fl)]
                        x = x1
                    if x < width - 1e-6:
                        pts += [(x, face_length), (width, face_length)]
                    top_profile = pts
                    # main eave runs between / beside the lean intervals
                    runs = []
                    x = 0.0
                    for x0, x1, fl, z in steps:
                        if x0 > x + 1e-6:
                            runs.append(dict(x0_in=x, x1_in=x0, label='main eave', lean_id=None))
                        x = x1
                    if x < width - 1e-6:
                        runs.append(dict(x0_in=x, x1_in=width, label='main eave', lean_id=None))
                    eave_runs = sorted(runs + eave_runs, key=lambda q: q['x0_in'])
            surfaces.append(
                dict(
                    effective_eave_overhang_in=face_overhang,
                    continuous_lean_id=continuous_id,
                    continued_leans=[z['id'] for z in combined],
                    rake_length_in=rake_length,
                    rake_left_in=rake_left,
                    rake_right_in=rake_right,
                    step_rakes=step_rakes,
                    eave_runs=eave_runs,
                    id=sid,
                    kind='roof',
                    width_in=width,
                    top_profile=top_profile,
                    bottom_in=0,
                    openings=[],
                    datum='UNFOLDED SLOPE: x from LEFT end overhang toward RIGHT end; y from '
                    + ('LOW EAVE to HIGH EAVE' if mono else 'EAVE to RIDGE'),
                    finish=c['surface_finishes'].get(sid, c['roof_finish']),
                    gross_area_sqft=sum(
                        (x1 - x0) * (y0 + y1) / 2 for (x0, y0), (x1, y1) in zip(top_profile, top_profile[1:])
                    )
                    / 144,
                    net_area_sqft=sum(
                        (x1 - x0) * (y0 + y1) / 2 for (x0, y0), (x1, y1) in zip(top_profile, top_profile[1:])
                    )
                    / 144,
                )
            )
    # Lean-to walls and separate-plane lean roofs (v0.8.35): every lean wall is an explicit
    # sheeted / open choice; a sheeted wall is taken off like a main wall (sloped end walls),
    # a separate-plane lean roof is one slope from the low eave up to the main wall.
    from .lean_walls import roof_surface as lean_roof_surface
    from .lean_walls import surfaces as lean_wall_surfaces

    for z in owner.derivation.get('framing_additions', {}).get('lean_tos', []):
        if 'walls' not in z:
            continue  # lean sheet surfaces are face-local; end-attached leans included
        if c['walls']:
            for s in lean_wall_surfaces(z, top, bottom):
                poly = s['top_profile']
                if min(y for x, y in poly) <= bottom:
                    raise ValueError(z['id'] + ': wall allowances consume the lean wall height')
                gross = sum((v - u) * ((y + w) / 2 - bottom) for (u, y), (v, w) in zip(poly, poly[1:]))
                s.update(
                    openings=[],
                    sheeted_intervals=[(0, s['width_in'])],
                    open_wall=False,
                    finish=c['surface_finishes'].get(z['face'], c['wall_finish']),
                    gross_area_sqft=gross / 144,
                    net_area_sqft=gross / 144,
                )
                surfaces.append(s)
        if c['roof']:
            s = lean_roof_surface(z, a['roof_front_overhang'], a['roof_rear_overhang'])
            if s:
                fl = s['face_length_in']
                s.update(
                    top_profile=[(0, fl), (s['width_in'], fl)],
                    bottom_in=0,
                    openings=[],
                    finish=c['surface_finishes'].get('roof_' + z['face'], c['roof_finish']),
                    gross_area_sqft=s['width_in'] * fl / 144,
                    net_area_sqft=s['width_in'] * fl / 144,
                    effective_eave_overhang_in=z['roof_overhang_in'],
                )
                surfaces.append(s)
    # Column grades (v0.8.43): wall sheets of a bay follow the slab / ground step of that bay.
    from .grades import step_offset

    grade = owner.derivation.get('column_grades') or {}
    grade_steps = grade.get('base_steps') or {}
    grade_rule = grade.get('mixed_bay', 'lower')
    for s in surfaces:
        width = s['width_in']
        poly = s['top_profile']
        b0 = s['bottom_in']
        own = []
        steps = grade_steps.get(s['id']) or []
        if steps:
            s['base_steps'] = [list(x) for x in steps]
        panel_spans = [
            (lo + i * 36, min(hi, lo + (i + 1) * 36))
            for lo, hi in s.get('sheeted_intervals', [(0, width)])
            for i in range(math.ceil((hi - lo - EPS) / 36))
        ]
        for i, (x0, x1) in enumerate(panel_spans):
            points = profile_points(poly, x0, x1)
            hi = max(y for x, y in points)
            holes = [o for o in s['openings'] if o['x_in'] < x1 - EPS and o['x_in'] + o['width_in'] > x0 + EPS]
            segments = [(b0 + step_offset(steps, x0, x1), hi)]
            for o in holes:
                if o['x_in'] <= x0 + EPS and o['x_in'] + o['width_in'] >= x1 - EPS:
                    lo = o['y_in']
                    up = lo + o['height_in']
                    nexts = []
                    for b, t in segments:
                        if lo >= t - EPS or up <= b + EPS:
                            nexts.append((b, t))
                            continue
                        if lo > b + EPS:
                            nexts.append((b, min(lo, t)))
                        if up < t - EPS:
                            nexts.append((max(up, b), t))
                    segments = nexts
            for j, (b, t) in enumerate(segments):
                actual = min(t, hi) - b
                if actual <= EPS:
                    continue
                cutouts = [
                    dict(
                        opening_id=o['id'],
                        x0_in=max(x0, o['x_in']),
                        x1_in=min(x1, o['x_in'] + o['width_in']),
                        y0_in=max(b, o['y_in']),
                        y1_in=min(t, o['y_in'] + o['height_in']),
                    )
                    for o in holes
                    if o['y_in'] < t - EPS and o['y_in'] + o['height_in'] > b + EPS
                ]
                n = ceil16(actual)
                status = []
                if panel_spec.get('min_published_length_in') and n < panel_spec['min_published_length_in']:
                    status.append('SHORT: below published5ft; special-order or shop-cut stock confirmation required')
                if n > panel_spec['max_published_length_in']:
                    status.append(
                        'LONG: exceeds supplier maximum '
                        + str(panel_spec['max_published_length_in'] / 12)
                        + ' ft; review; NOT SPLIT'
                    )
                if cutouts:
                    status.append('FIELD CUTOUT: retain full-width blank')
                if x1 - x0 < 36 - EPS:
                    status.append('LAST STRIP: full panel purchased; rip to coverage width')
                if max(y for x, y in points) - min(y for x, y in points) > EPS and abs(t - hi) < EPS:
                    status.append('SLOPED TOP: blank uses highest point, not strip center')
                if steps and abs(b - b0) > EPS:
                    status.append(
                        (
                            'BASE AT %s (SLAB / GROUND STEP - ORDERED LONG, CUT TO FIT AT THE STEP)'
                            if grade_rule == 'lower'
                            else 'BASE AT %s (SLAB / GROUND STEP - LOWER SLAB OF THIS BAY)'
                        )
                        % fmt_signed(b - b0)
                    )
                if not status:
                    status = ['RECTANGULAR BLANK']
                r = dict(
                    mark='PBR-'
                    + p.column_mark
                    + '-'
                    + face_code(s['id']).upper()
                    + '-'
                    + str(i + 1).zfill(3)
                    + chr(65 + j),
                    surface=s['id'],
                    strip=i + 1,
                    quantity=1,
                    x0_in=x0,
                    x1_in=x1,
                    bottom_in=b,
                    top_in=t,
                    top_profile=[(x, min(y, t)) for x, y in points],
                    coverage_width_in=x1 - x0,
                    exact_blank_length_in=actual,
                    order_length_in=n,
                    order_length=fmt(n),
                    profile=c.get('panel_profile_id', 'MBCI-PBR'),
                    **s['finish'],
                    cutouts=cutouts,
                    status='; '.join(status),
                    supply_length_review=bool(
                        panel_spec.get('min_published_length_in') and n < panel_spec['min_published_length_in']
                    )
                    or n > panel_spec['max_published_length_in'],
                )
                panels.append(r)
                own.append(r)
        s['panel_marks'] = [r['mark'] for r in own]
        s['panel_quantity'] = len(own)
        s['ordered_coverage_blank_sqft'] = sum(36 * r['order_length_in'] / 144 for r in own)
        # Group by purchase blank only; unique field cuts remain per-piece, never lost.
        grouped = {}
        for r in own:
            key = (r['order_length_in'], r['color'], r['gauge'])
            if key not in grouped:
                g = {
                    k: r[k]
                    for k in (
                        'surface',
                        'profile',
                        'color',
                        'coating',
                        'gauge',
                        'order_length',
                        'order_length_in',
                        'availability',
                        'supply_length_review',
                    )
                }
                g.update(
                    group='PBR-' + face_code(s['id']).upper() + '-G' + str(len(grouped) + 1).zfill(2),
                    quantity=0,
                    marks=[],
                )
                grouped[key] = g
            g = grouped[key]
            g['quantity'] += 1
            g['marks'].append(r['mark'])
            r['order_group'] = g['group']
        s['groups'] = list(grouped.values())
        groups.extend(s['groups'])
    from .ordering import config as order_config
    from .ordering import trim_lengths

    order = order_config(job)
    profiles = {x['id']: x for x in catalog('all')['trims']}
    lap = a['trim_lap']
    extra = a['trim_end_allowance']

    lean_models = [z for z in owner.derivation.get('framing_additions', {}).get('lean_tos', []) if 'walls' in z]

    def trim(surface, role, net, label, force_pending=False, owner_allowance=0, pitch_rise=None):
        if net <= EPS:
            return
        id = c['trim_stock'].get(role, '')
        part = profiles.get(id)
        run = net + 2 * extra + owner_allowance
        tag = 'TR-' + p.column_mark + '-' + str(len(trims) + 1).zfill(3)
        # The wall-to-roof transition of a lowered lean roof has no stock SKU in the supplier
        # pages on file: it is a custom-formed 26 ga trim to the job pitch, ordered by length.
        custom = role == 'transition' and not id
        pending = force_pending or (not part and not custom)
        # A role left blank under the supplier product policy is a deliberate
        # "not ordered" (e.g. SSS has no base trim: the base angle closes the
        # panel), not a missing input.
        not_ordered = not force_pending and not id and not custom and bool(c.get('supplier_products'))
        maximum = (
            order['trim_max_in']
            if order['trim_policy'] == 'exact_short_max_long'
            else (part['stock_length_in'] if part else order['trim_max_in'])
        )
        if part and part.get('supplier') == 'sss' and part.get('catalog_length_verified'):
            maximum = min(maximum, part['stock_length_in'])
        if role == 'ridge' and not pending:
            # Ridge trim: EQUAL lengths, maximum 20'-6", 6 in overlap (owner 0.8.57).
            _max, _lap = 246.0, 6.0
            _n = max(1, math.ceil((run - _lap) / (_max - _lap) - 1e-9))
            lengths = [(run + (_n - 1) * _lap) / _n] * _n
        else:
            lengths = [] if pending else trim_lengths(run, lap, maximum)
        n = None if pending else len(lengths)
        limit = (
            None
            if pending
            else (ceil16(lengths[0]) if n == 1 and order['trim_policy'] == 'exact_short_max_long' else maximum)
        )
        status = (
            'NOT ORDERED — no ' + role + ' trim in the selected supplier program'
            if not_ordered
            else 'CUSTOM FORMED wall-to-roof transition, 26 ga trim stock to the job pitch (no stock SKU in the supplier pages on file); exact pieces / max 20 ft 6 in'
            if custom
            else 'PROFILE PENDING — no stock quantity'
            if pending
            else (
                'USER EXACT TRIM / MAX20ft6in; profile ID is reference, NOT catalog custom-length SKU; verify supply/laps/returns'
                if order['trim_policy'] == 'exact_short_max_long'
                else 'CATALOG STOCK / PROJECT LAP; verify fit'
            )
        )
        rec = dict(
            mark=tag,
            surface=surface,
            role=role,
            location=label,
            profile_id='' if pending else id,
            net_run_in=net,
            net_run=fmt(net),
            end_allowance_each_in=extra,
            owner_length_allowance_in=owner_allowance,
            required_run_in=run,
            lap_in=6.0 if role == 'ridge' else lap,
            stock_length_in=limit,
            catalog_stock_length_in=part['stock_length_in']
            if part and part.get('catalog_length_verified', True)
            else None,
            stock_quantity=0 if not_ordered else n,
            not_ordered=not_ordered,
            custom_formed=custom,
            **c['trim_finish'],
            status=status,
        )
        if custom and pitch_rise is not None:
            rec['formed_pitch_rise'] = float(pitch_rise)
        if part and part.get('custom_length_only'):
            rec.update(formed_pitch_rise=float(p.slope_rise), formed_profile=copy.deepcopy(part))
            rec['status'] += (
                '; CUSTOM FL-1010 A=4 / '
                + str(float(p.slope_rise))
                + ':12 JOB PITCH; supplier formed, not stock FL-1010'
            )
        trims.append(rec)
        for i, cut in enumerate(lengths):
            stock = ceil16(cut) if order['trim_policy'] == 'exact_short_max_long' else maximum
            trim_pieces.append(
                dict(
                    mark=tag + '-' + str(i + 1),
                    run_mark=tag,
                    surface=surface,
                    role=role,
                    profile_id=id,
                    quantity=1,
                    exact_cut_length_in=cut,
                    cut_length_in=ceil16(cut),
                    cut_length=fmt(ceil16(cut)),
                    stock_length_in=stock,
                    **c['trim_finish'],
                    status=rec['status'],
                )
            )

    for s in surfaces:
        sid = s['id']
        if s['kind'] == 'wall':
            intervals = list(s.get('sheeted_intervals', [(0, s['width_in'])]))
            for o in s['openings']:
                if o['y_in'] <= bottom + EPS and o['y_in'] + o['height_in'] > bottom:
                    out = []
                    x = o['x_in']
                    end = x + o['width_in']
                    for lo, hi in intervals:
                        if end <= lo or x >= hi:
                            out.append((lo, hi))
                            continue
                        if x > lo:
                            out.append((lo, x))
                        if end < hi:
                            out.append((end, hi))
                    intervals = out
                if o['kind'] == 'lean_open':
                    continue
                lug = (
                    1.5
                    if c.get('owner_length_rules')
                    and c.get('slab_jamb_lug')
                    and o['kind'] in ('door', 'overhead')
                    and abs(o['y_in']) < EPS
                    else 0
                )
                head = 3.0 if c.get('owner_length_rules') else 0
                trim(sid, 'jamb', o['height_in'], o['id'] + ' LEFT jamb', owner_allowance=lug)
                trim(sid, 'jamb', o['height_in'], o['id'] + ' RIGHT jamb', owner_allowance=lug)
                trim(sid, 'head', o['width_in'], o['id'] + ' head', owner_allowance=head)
                if o['kind'] not in ('door', 'overhead'):
                    trim(sid, 'sill', o['width_in'], o['id'] + ' sill', o['kind'] != 'fixed_glass')
            if c.get('eave_base_trim'):
                for lo, hi in intervals:
                    trim(sid, 'base', hi - lo, 'Base x=' + fmt(lo) + ' to ' + fmt(hi))
            if sid in ('front', 'rear', 'outer_front') and not s.get('open_end'):
                for edge in (0, s['width_in']):
                    trim(sid, 'corner', height(s['top_profile'], edge) - bottom, 'Outside corner at x=' + fmt(edge))
            if s.get('lean_wall') == 'outer':
                # Outside corners of the lean where a sheeted end wall meets the outer wall.
                z = next(q for q in lean_models if q['id'] == s['lean_id'])
                for key, edge in (('start_end', 0), ('finish_end', s['width_in'])):
                    if z['walls'].get(key) == 'sheeted':
                        trim(
                            sid,
                            'corner',
                            height(s['top_profile'], edge) - bottom,
                            'Lean outside corner at x=' + fmt(edge),
                        )
        else:
            if c.get('eave_base_trim'):
                if s.get('eave_runs'):
                    # continued-plane lean over some bays: main eave beside it, lean eave inside it
                    for run in s['eave_runs']:
                        trim(
                            sid,
                            'eave',
                            run['x1_in'] - run['x0_in'],
                            run['label'] + ' x=' + fmt(run['x0_in']) + ' to ' + fmt(run['x1_in']),
                        )
                else:
                    trim(sid, 'eave', s['width_in'], 'LOW / EAVE edge')
                if sid == 'roof_mono':
                    trim(sid, 'high_eave', s['width_in'], 'HIGH edge')
            rake_length = s.get('rake_length_in', (W if mono else W / 2) * slope + a['roof_eave_extension'])
            trim(sid, 'rake', s.get('rake_left_in', rake_length), 'LEFT END rake')
            trim(sid, 'rake', s.get('rake_right_in', rake_length), 'RIGHT END rake')
            for sr in s.get('step_rakes') or []:
                # the lean roof ends inside the building length: rake from the main eave line
                # down the lean slope to the lean eave
                trim(sid, 'rake', sr['length_in'], sr['lean_id'] + ' lean end rake at x=' + fmt(sr['x_in']))
            if s.get('lean_wall') == 'roof':
                # Lowered lean roof on a sidewall: wall-to-roof transition trim at the main wall
                # (owner: no flashing when the lean follows the main roofline).
                z = next(q for q in lean_models if q['id'] == s['lean_id'])
                trim(
                    sid, 'transition', z['length_in'], 'Wall-to-roof transition at the main wall', pitch_rise=z['pitch']
                )
    if c['roof'] and not mono:
        trim(
            'roof_shared',
            'ridge',
            L + a['roof_front_overhang'] + a['roof_rear_overhang'],
            'ONE shared ridge, not once per slope',
        )
    warnings.append(
        'Trim procurement follows job order settings: exact shorter pieces / maximum20ft6in segments by default; source profiles are references only. Generic window sills stay pending; FL-848 is fixed-glass only. Peak boxes/rake end caps, gutters/downspouts, closures, fasteners and sealants are NOT included.'
    )
    trim_groups = {}
    for r in trim_pieces:
        key = (r['surface'], r['role'], r['profile_id'], r['cut_length_in'], r['color'], r['gauge'])
        if key not in trim_groups:
            trim_groups[key] = {
                k: r[k]
                for k in (
                    'surface',
                    'role',
                    'profile_id',
                    'cut_length_in',
                    'cut_length',
                    'stock_length_in',
                    'color',
                    'coating',
                    'gauge',
                )
            }
            trim_groups[key].update(group='TR-CUT-' + str(len(trim_groups)).zfill(3), quantity=0, marks=[])
        g = trim_groups[key]
        g['quantity'] += 1
        g['marks'].append(r['mark'])
        r['cut_group'] = g['group']
    for rows in (surfaces, panels, groups, trims, trim_pieces, list(trim_groups.values()), c['openings']):
        for r in rows:
            sid = r.get('surface', r.get('id'))
            r['elevation'] = face_name(sid)
            if getattr(p, 'bay_zones', {}).get('enabled') and p.bay_zones.get('enclosed_start_line') and sid == 'front':
                # only when roof-only bays stand in front of the enclosed block; at line 0 the
                # front wall is simply the left end wall
                r['elevation'] = 'Inside wall (enclosed junction) at ' + fmt(wall_station(p, 'front'))
    result = dict(
        config=copy.deepcopy(c),
        profile=panel_spec,
        source_revision=catalog()['revision'],
        surfaces=surfaces,
        panels=panels,
        groups=groups,
        trim_runs=trims,
        trim_pieces=trim_pieces,
        trim_groups=list(trim_groups.values()),
        warnings=warnings,
        quantity_scope='ONE BUILDING ENVELOPE; INDEPENDENT OF FRAME LOT',
        width_in=W,
        length_in=L,
        eave_datum_in=H,
        pitch_rise=float(p.slope_rise),
        frame_type=p.frame_type,
    )
    owner.derivation['cladding'] = result
    layout['cladding'] = result
