"""Global frame setout from the SAME connection planes and member cut drivers.

X = horizontal from outside of low/left column; Y = above floor, all inches.
Stored geometry is design setout; nearest-1/16 shop-cut residuals are explicit.
"""

import math

from .base_options import thickness as base_thickness
from .connections import f


def build_layout(job, p, low, far, column, rafter, high_column=None):
    mono = high_column is not None
    W = f(p.width)
    m = float(p.slope_rise) / 12
    co = 1 / math.sqrt(1 + m * m)
    sn = m * co
    from . import foundation as FND

    base = f(p.base_elevation)
    gap = f(p.column_top_gap)
    strut = f(p.eave_strut_depth)
    low_bp = job.parts.get(column.derivation['resolved_base_plate'])
    low_y = FND.column_bottom_in(p, base_thickness(low_bp)) + column.derivation['column_cut_unrounded_in'] + gap
    roof0 = low_y + low.symbol['h']
    columns = [
        dict(
            mark=column.mark,
            side='left',
            x0=0.0,
            x1=column.main.sec.d,
            y0=FND.column_bottom_in(p, base_thickness(low_bp)),
            y1=low_y - gap,
            base_thickness=base_thickness(low_bp),
            design_length=column.derivation['column_cut_unrounded_in'],
            shop_cut=column.main.cut_length.fmt(),
            rounding_residual_in=f(column.main.cut_length) - column.derivation['column_cut_unrounded_in'],
        )
    ]
    if mono:
        high_bp = job.parts.get(high_column.derivation['resolved_base_plate'])
        far_y = (
            FND.column_bottom_in(p, base_thickness(high_bp)) + high_column.derivation['column_cut_unrounded_in'] + gap
        )
        far_x = W
        far_sign = -1
        columns.append(
            dict(
                mark=high_column.mark,
                side='right',
                x0=W - high_column.main.sec.d,
                x1=W,
                y0=FND.column_bottom_in(p, base_thickness(high_bp)),
                y1=far_y - gap,
                base_thickness=base_thickness(high_bp),
                design_length=high_column.derivation['column_cut_unrounded_in'],
                shop_cut=high_column.main.cut_length.fmt(),
                rounding_residual_in=f(high_column.main.cut_length) - high_column.derivation['column_cut_unrounded_in'],
            )
        )
    else:
        far_x = W / 2
        far_y = roof0 + m * W / 2 - far.symbol['h']
        far_sign = -1
        columns.append({**columns[0], 'side': 'right', 'x0': W - column.main.sec.d, 'x1': W})
    connections = [
        dict(mark=low.mark, x=0.0, y=low_y, mirror=1, roof_clips=low.symbol.get('roof_clips', [])),
        dict(
            mark=far.mark, x=far_x, y=far_y, mirror=far_sign if mono else 1, roof_clips=far.symbol.get('roof_clips', [])
        ),
    ]
    if not mono:
        connections.append(dict(mark=low.mark, x=W, y=low_y, mirror=-1, roof_clips=low.symbol.get('roof_clips', [])))
    et = f(job.part(low.mark + '-END').thk)
    ft = f(job.part(far.mark + '-END').thk)
    E = low.symbol['rafter_top_xy']
    F = far.symbol['rafter_top_xy']
    near_allow = f(p.knee_setback)
    far_allow = f(p.knee_setback) if mono else f(p.ridge_half_gap)
    start = [E[0] + 2 * et * co + near_allow, low_y + E[1] + 2 * et * sn + near_allow * m]
    end = [far_x - F[0] - 2 * ft * co - far_allow, far_y + F[1] - 2 * ft * sn - far_allow * m]
    exact = math.dist(start, end)
    if end[0] <= start[0]:
        raise ValueError('Connection envelopes consume the roof span')
    if abs((end[1] - start[1]) - (end[0] - start[0]) * m) > 1e-6:
        raise ValueError('Rafter end planes do not share the roof top line')
    if abs(exact - rafter.derivation['rafter_cut_unrounded_in']) > 1e-6:
        raise ValueError('Frame setout and rafter cut deductions disagree')
    roofs = [
        dict(
            mark=rafter.mark,
            side='low-to-high' if mono else 'left',
            top_start=start,
            top_end=end,
            direction=[co, sn],
            normal=[-sn, co],
            design_length=exact,
            shop_cut=rafter.main.cut_length.fmt(),
            rounding_residual_in=f(rafter.main.cut_length) - exact,
        )
    ]
    if not mono:
        roofs.append(
            {
                **roofs[0],
                'side': 'right',
                'top_start': [W - start[0], start[1]],
                'top_end': [W - end[0], end[1]],
                'direction': [-co, sn],
                'normal': [sn, co],
            }
        )
    schedule = [
        dict(
            mark=column.mark,
            role='low column' if mono else 'columns',
            per_frame=1 if mono else 2,
            total=column.qty,
            section=column.main.section,
            cut=column.main.cut_length.fmt(),
        ),
        dict(
            mark=rafter.mark,
            role='rafter' if mono else 'rafters',
            per_frame=1 if mono else 2,
            total=rafter.qty,
            section=rafter.main.section,
            cut=rafter.main.cut_length.fmt(),
        ),
    ]
    if mono:
        schedule.insert(
            1,
            dict(
                mark=high_column.mark,
                role='high column',
                per_frame=1,
                total=high_column.qty,
                section=high_column.main.section,
                cut=high_column.main.cut_length.fmt(),
            ),
        )
    schedule += [
        dict(
            mark=low.mark,
            role='low knee' if mono else 'knees',
            per_frame=1 if mono else 2,
            total=(1 if mono else 2) * p.frames,
            section='connection',
            cut='see detail',
        ),
        dict(
            mark=far.mark,
            role='high knee' if mono else 'apex',
            per_frame=1,
            total=p.frames,
            section='connection',
            cut='see detail',
        ),
    ]
    return dict(
        clip_clearances=rafter.derivation.get('clip_clearances', []),
        clip_warnings=rafter.derivation.get('clip_warnings', []),
        peak_clip=rafter.derivation.get('peak_clip'),
        version=7,
        frame_id=p.column_mark,
        frame_type=p.frame_type,
        frames=p.frames,
        width_in=W,
        low_eave_in=roof0 + strut,
        high_eave_in=roof0 + strut + m * W if mono else roof0 + strut,
        ridge_top_in=None if mono else roof0 + m * W / 2,
        slope_rise=str(p.slope_rise),
        strut_depth_in=strut,
        roof_left_in=roof0,
        base_elevation_in=base,
        foundation=FND.record(p),
        columns=columns,
        rafters=roofs,
        connections=connections,
        schedule=schedule,
        allowances=dict(near_horizontal=near_allow, far_horizontal=far_allow, column_top_gap=gap),
        status='GEOMETRY SETOUT',
        datum='outside low/left column face X=0; floor Y=0; eave heights to TOP of eave strut',
        rounding_note='Design endpoints shown. Shop cuts/stations round to nearest 1/16; residuals retained, not silently absorbed.',
    )
