"""Explicit lean roof purlin layout and physical bay-piece takeoff.
Owner zero-gap end rule only; no lap, hole, load-capacity or clip-fit inference.
"""

import math

from .cladding import fmt, inch
from .secondary_catalog import get


def apply(p, r):
    c = r.setdefault('roof_purlins', {})
    if not isinstance(c, dict) or not isinstance(c.get('enabled', False), bool):
        raise ValueError('Lean roof purlins must have a boolean enabled setting')
    if not c.get('enabled'):
        return
    # side- AND end-attached leans: the layout below runs in the lean's own face-local
    # coordinates (along the attachment face / out), whichever wall it hangs on
    welded_lean = r.get('low_connection', p.connection_style) in ('fully_welded', 'welded_box')
    if not welded_lean and (p.connection_style == 'bolted' or not p.welded_fit_rules.get('enabled')):
        raise ValueError('Lean purlin adapter requires the explicit welded zero-gap end rule')
    c['profile_id'] = c.get('profile_id') or p.secondary.get('purlin', {}).get('profile_id')
    pr = get(c['profile_id'])
    c['finish'] = c.get('finish') or p.secondary.get('purlin', {}).get('finish', 'Red Oxide')
    if pr['family'] not in ('C', 'Z') or c['finish'] not in pr['finishes']:
        raise ValueError('Choose an actual C/Z purlin and listed finish for lean roof')
    if abs(pr['nominal_depth_in'] - r['purlin_depth_in']) > 1e-8:
        raise ValueError('Lean purlin depth must match selected profile; roof datum will not be silently changed')
    spacing = inch(c.get('max_spacing') or '60')
    if not 1 <= spacing <= 120:
        raise ValueError('Lean purlin planning maximum spacing must be1–120in; not capacity checked')
    c['max_spacing'] = str(spacing)
    # A separate-plane lean roof has its own top purlin row at the main wall; the high
    # boundary is shared with the main eave member only for a continued main roof plane.
    c.setdefault('share_main_eave', r.get('roof_continuity') == 'main_plane')
    if not isinstance(c['share_main_eave'], bool):
        raise ValueError('Share main eave must be boolean')
    if c['share_main_eave'] and r.get('roof_continuity') != 'main_plane':
        c['share_main_eave'] = False
    if c['share_main_eave']:
        ep = p.secondary.get('eave', {}).get('profile_id')
        if not ep or get(ep)['family'] not in ('C', 'Z', 'Eave'):
            raise ValueError('Shared high boundary requires an actual main eave member')
        # (a lean over SOME bays shares the main eave strut over those bays - the strut runs the
        # full length anyway; nothing to count twice)


def finish(job, p, z):
    c = z.get('roof_purlins', {})
    if not c.get('enabled'):
        return
    pr = get(c['profile_id'])
    slope = math.hypot(1, z['pitch'] / 12)
    P = z['projection_in']
    pitch = z['pitch'] / 12
    stations = sorted(s['x_in'] for s in z['stations'])
    start = z['start_in']
    end = start + z['length_in']
    # an enclosed-junction frame line inside the run (a roof-only extension bay
    # outside an inside wall) is a break: purlins do not run through the wall
    junction_xs = []
    try:
        from . import frame_lines as _FL

        for _fid, _lay in (job.settings.get('frame_layouts') or {}).items():
            if any(
                zz is z or zz.get('id') == z.get('id')
                for zz in (_lay.get('framing_additions') or {}).get('lean_tos', [])
            ):
                _L = _FL.length_in(job, _fid)
                for _rec in _FL.lines(job, _fid):
                    _sx = float(_rec['station_in'])
                    # lean x is the attachment wall's OUTSIDE VIEW: the back (left)
                    # wall is mirrored against the frame datum
                    _jx = _L - _sx if z.get('face') == 'left' else _sx if z.get('face') == 'right' else None
                    if (
                        _jx is not None
                        and _rec['kind'] == 'end'
                        and _rec.get('wall_key') in ('front_end', 'rear_end')
                        and start + 1 < _jx < end - 1
                    ):
                        junction_xs.append(_jx)
    except Exception:
        junction_xs = []
    if not junction_xs:
        # at finish time the layout may not be stored yet: the junction station is
        # the enclosed start line of the bay zones, in the frame datum
        try:
            bz = p.bay_zones if isinstance(p.bay_zones, dict) else {}
            k = int(bz.get('enclosed_start_line') or 0)
            bays = bz.get('bays') or []
            if 0 < k < len(bays):
                _sx = sum(inch(b.get('length')) for b in bays[:k])
                _L = sum(inch(b.get('length')) for b in bays)
                _jx = _L - _sx if z.get('face') == 'left' else _sx if z.get('face') == 'right' else None
                if _jx is not None and start + 1 < _jx < end - 1:
                    junction_xs = [_jx]
        except Exception:
            pass
    junction_xs = sorted(set(junction_xs))
    if junction_xs:
        stations = sorted(set(stations) | set(junction_xs))
    if len(stations) < 2 or stations[0] < start - 1e-7 or stations[-1] > end + 1e-7:
        # pieces run station to station; the lean's out-to-out ends at a corner upright
        # (centre inset half its width) still land on their end rafters
        raise ValueError('Lean purlin run ends require aligned end rafters; no unsupported end span invented')
    # If any support is an open-face channel, keep the edge rows inside the channel end planes;
    # each bay end still uses the actual support fit (channel clearance, flush weld, or bypass).
    by_x = {round(float(st['x_in']), 3): st for st in z['stations']}
    station_fits = [st.get('purlin_fit') for st in z['stations']]
    any_channel = bool(z.get('any_channel_line')) or any(fit == 'channel' for fit in station_fits)
    all_channel = bool(station_fits) and all(fit == 'channel' for fit in station_fits)
    cut = z.get('rafter_cut_detail')

    def fit_at(index):
        st = by_x.get(round(stations[index - 1], 3)) or {}
        return st.get('purlin_fit') or ('channel' if all_channel else 'bypass')

    def end_setback(index, which):
        """Piece end deduction from the frame line ``index`` (1-based) for a piece leaving
        ('start') or arriving ('end'): channel (single or doubled) 1/4 in from the web; W flush
        half web + 1/8 in (web weld, as the flush girts); W bypass centre butt (zero gap)."""
        st = by_x.get(round(stations[index - 1], 3)) or {}
        fit = fit_at(index)
        if fit == 'channel':
            return 0.25
        if fit == 'flush':
            from .framing_additions import profile as fprofile

            pr = fprofile(st.get('rafter_profile') or z.get('rafter') or '') or {}
            return (pr.get('web') or 0.0) / 2 + 0.125
        return 0.0

    if any_channel and cut:
        # Shop rule: purlins IN the rafter channel.  The eave (low) row hugs the rafter's
        # low end and the top row hugs the main column face: web centre = 1/4 in clearance
        # plus half the purlin flange from the plumb end cut.  Rows evenly spaced, max spacing.
        edge = 0.25 + max(pr['flanges_in']) / 2
        x_hi = cut['high_cut_x_in'] + edge
        # The lowest row is supported at the lean post, not inside the rafter channel.
        # Keep its outside face flush with the post/column datum even when an endpoint
        # rafter is an open-face channel; only the high/top row uses the channel setback.
        x_lo = P
        if x_lo - x_hi < 12:
            raise ValueError('Lean rafter too short for a low-eave post row and a top row in the channel')
        run = (x_lo - x_hi) * slope
        n = max(1, math.ceil(run / inch(c['max_spacing'])))
        xs = [x_hi + (x_lo - x_hi) * i / n for i in range(n + 1)]
    else:
        run = P * slope
        n = math.ceil(run / inch(c['max_spacing']))
        xs = [P * i / n for i in range(n + 1)]
    rows = []
    pieces = []
    # Owner (round 16): stock lengths land on the rafter centres - one stick spans every whole bay it can
    # (15 + 15 -> one 30 ft stick) and no purlin is spliced between rafters.  A joint that sits in a
    # channel or beside a flush rafter cannot be passed.
    from .ordering import stock_lengths_in
    from .purlin_lay import lay, note

    try:
        stocks = stock_lengths_in(job, 'purlin', pr['id'])
    except ValueError:
        stocks = []
    cfg_lay = ((p.bay_layout if isinstance(p.bay_layout, dict) else {}) or {}).get('purlin_lay', 'span')
    may_join = [
        fit_at(k + 1) == 'bypass' and round(stations[k], 3) not in {round(jx, 3) for jx in junction_xs}
        for k in range(1, len(stations) - 1)
    ]
    for i, x in enumerate(xs):
        shared = i == 0 and c['share_main_eave'] and not any_channel
        mark = p.column_mark + '-' + z['id'] + '-LP' + str(i).zfill(2)
        if i == n:
            support = 'LOW EAVE OUTSIDE FACE FLUSH WITH COLUMN/POST; DIRECT-WELD TO THE COLUMN/POST'
        elif any_channel and not all_channel:
            support = 'CHANNEL AT SPECIAL OPEN-C ENDS; W SUPPORTS USE THEIR LINE FIT'
        elif all_channel:
            support = 'TOP ROW in the rafter channel at the main column' if i == 0 else 'IN the rafter channel'
        else:
            support = 'Main eave shared' if shared else 'Lean rafter; clip/weld fit held'
        row = dict(
            mark=mark,
            row=i,
            horizontal_out_in=x,
            along_slope_in=(x - xs[0]) * slope,
            roof_top_in=z['high_eave_in'] - x * pitch,
            profile_id=p.secondary['eave']['profile_id'] if shared else pr['id'],
            shared_main_eave=shared,
            quantity_scope='REFERENCE ONLY: counted in main eave run'
            if shared
            else 'ONE LEAN; one physical piece per bay',
            support=support,
        )
        rows.append(row)
        if shared:
            continue
        per_bay = []
        for bay, (a, b) in enumerate(zip(stations, stations[1:]), 1):
            fit_a, fit_b = fit_at(bay), fit_at(bay + 1)
            # The low-eave purlin bears on the post/column. It is not a purlin seated
            # inside the rafter channel, so retain the direct-weld, zero-clearance fit.
            sa = sb = 0.0 if i == n else None
            if i != n:
                sa = end_setback(bay, 'start')
                sb = end_setback(bay + 1, 'end')
            L = b - a - sa - sb
            if i == n:
                support_status = (
                    'LOW EAVE OUTSIDE FACE FLUSH WITH COLUMN/POST; DIRECT WELD TO THE COLUMN/POST; ZERO END CLEARANCE'
                )
            elif fit_a == fit_b == 'channel':
                support_status = (
                    'IN CHANNEL: 1/4 in from each rafter channel web; welded to channel flanges top and bottom'
                )
            elif any(fit == 'channel' for fit in (fit_a, fit_b)):
                support_status = 'LINE-SPECIFIC SUPPORT FITS: %s / %s' % (fit_a.upper(), fit_b.upper())
            else:
                support_status = 'OWNER WELDED END CUT: outside end edges / interior center butts; ZERO end clearance. Attachment fit/capacity held.'
            if L <= 0:
                raise ValueError('Duplicate lean support stations')
            per_bay.append(
                dict(
                    mark=mark + '-B' + str(bay),
                    run_id=mark,
                    row=i,
                    bay=bay,
                    profile_id=pr['id'],
                    finish=c['finish'],
                    quantity=1,
                    start_in=a + sa,
                    end_in=b - sb,
                    cut_length_in=L,
                    cut_length=fmt(L),
                    horizontal_out_in=x,
                    along_slope_in=row['along_slope_in'],
                    weight_lb_ft=pr['weight_lb_ft'],
                    weight_lb=L / 12 * pr['weight_lb_ft'] if pr['weight_lb_ft'] is not None else None,
                    status=support_status,
                )
            )
        laid = per_bay if cfg_lay == 'per_bay' else lay(per_bay, stocks, may_join)
        if junction_xs:
            # the piece on the roof-only side of the inside wall lands on a clip
            # protruding from that wall; it keeps its station length while the bay
            # measures 1.5 in more for the sheets (owner 0.8.53)
            for rec in laid:
                _at = (
                    abs(rec['start_in'] - junction_xs[0]) < 0.01
                    if z.get('face') == 'left'
                    else abs(rec['end_in'] - junction_xs[0]) < 0.01
                )
                if _at:
                    rec['status'] += (
                        ' AT THE INSIDE WALL IT LANDS ON A CLIP PROTRUDING FROM THE WALL; the purlin stays '
                        + fmt(rec['cut_length_in'])
                        + ' while the bay measures '
                        + fmt(rec['cut_length_in'] + 1.5)
                        + ' outside edge of the end frame to inside edge of the inside wall FOR THE SHEETS.'
                    )
        for rec in laid:
            if rec.get('span_bays', 1) > 1:
                rec.pop('fit_status', None)
                rec.update(
                    mark=mark + '-B' + str(rec['bay']) + '-' + str(rec['bay_last']),
                    cut_length=fmt(rec['cut_length_in']),
                    quantity=1,
                    weight_lb=(
                        rec['cut_length_in'] / 12 * pr['weight_lb_ft'] if pr['weight_lb_ft'] is not None else None
                    ),
                    status=note(rec['bay'], rec['bay_last'], rec['cut_length_in'], rec.get('stock_length_in'))
                    + '; '
                    + rec['status'],
                )
            pieces.append(rec)
    z['roof_purlin_layout'] = dict(
        rows=rows,
        pieces=pieces,
        junction_note=(
            'LT ROOF AT THE INSIDE WALL: BAY '
            + fmt(((end - junction_xs[0]) if z.get('face') == 'left' else (junction_xs[0] - start)) + 1.5)
            + ' OUTSIDE EDGE OF FRAME LINE 1 TO INSIDE EDGE OF THE INSIDE WALL FOR SHEETS; PURLINS '
            + fmt((end - junction_xs[0]) if z.get('face') == 'left' else (junction_xs[0] - start))
            + ' ON A CLIP PROTRUDING FROM THE INSIDE WALL'
            if junction_xs
            else ''
        ),
        intervals=n,
        spacing_along_in=run / n,
        in_channel=all_channel,
        any_channel_support=any_channel,
        mixed_support_fit=any_channel and not all_channel,
        scope='ONE LEAN; '
        + (
            'purlins in the rafter channel at every support'
            if all_channel
            else 'channel at special open-C ends; W supports use their own line fit'
            if any_channel
            else 'shared main boundary counted only in main eave runs'
        ),
        end_rule=(
            'CHANNEL ROWS: 1/4 in from each channel web; low-eave row direct-welded to the post/column'
            if all_channel
            else 'LINE-SPECIFIC FIT: 1/4 in at channel ends; W bypass/flush fit applied at each W support'
            if any_channel
            else 'WELDED OUTSIDE END EDGES / INTERIOR CENTER BUTTS / ZERO GAP'
        ),
        status=(
            'CUT LENGTHS / COUNTS GENERATED (shop rule: purlins in the channel)'
            if all_channel
            else 'CUT LENGTHS / COUNTS GENERATED with channel end clearances and per-line W support fits; capacity not assessed'
            if any_channel
            else 'CUT LENGTHS / COUNTS GENERATED; clip placement, weld fit, lateral restraint and capacity not approved'
        ),
    )
    if not any_channel:
        z['issues'] = [
            s.replace(
                'lean purlin/girt bay lengths, roof/wall sheets and eave trim remain unquantified; bracing BY OTHERS.',
                'lean wall-girt bays, outer-wall sheets and eave trim remain unquantified; roof purlin schedule now generated; bracing BY OTHERS.',
            )
            for s in z['issues']
        ]
        z['issues'].append(
            'Lean roof purlin lengths/counts generated separately; boundary row shared with main eave only when explicitly selected. Low eave seat, weld/clip quantities, bracing and wall girts remain held.'
        )
