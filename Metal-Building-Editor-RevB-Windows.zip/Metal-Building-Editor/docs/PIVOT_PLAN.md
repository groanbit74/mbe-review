# Pivot plan: from "coordination/checking platform" to "drawing-producing detailing software"

Target restated: software that takes a building/assembly model and **produces shop drawings
comparable to the three uploaded packages** (assembly sheets with elevation, section/end views,
running dimensions, callouts, BOM and title block; piece/plate sheets; brackets; order summary).

Side-by-side of where we are: `docs/gap_mb1-1_target_vs_generated.png`
(top = fabricator's MB1-1 sheet, bottom = what the current `draw_assembly_pdf` emits).

## 1. Verdict

**No restart needed, but the centre of gravity moves.** The current code base is the
"back office" of a detailing system (exact dimensions, marks/piece hierarchy, BOM/weight math,
job/revision/release control, PDF/DXF writers, importers). It is missing the **detailing core**:
a geometry kernel, a parametric connection/part library, a building-level modeler and,
above all, a **drawing engine** (views, dimensioning, callouts, sheet layout). Those four
things are the bulk of the remaining work; nothing built so far has to be thrown away, and
the importer becomes the regression oracle for the generator.

## 2. What the current version already gives the new goal

| Existing module | Role in a drawing-producing system |
|---|---|
| `dims.py` (exact Fraction inches, ft-in parse/format) | Every dimension string on every sheet; no float drift on 20'-2 3/8" style text |
| `catalog.py` (W-shape plf, plate density, rounding policy) | Weights in BOM tables; must be **extended with section geometry** (d, bf, tf, tw) |
| `model.py` (Project, MemberInstance, Assembly, CutPart, BOMLine, PiecePart, Hole/HolePattern, Attachment, Connection) | The product model the generator draws from; needs geometry fields (see §3) |
| BOM / weight logic (verified against all 20 BOMs in the samples to 0.01 lb) | Generated BOM tables will match this shop's rounding conventions out of the box |
| `store.py`, `release.py` (revision hash, audit log, gates, hashed release packages) | Document control for issued drawings; keep as is |
| `exports.py` (PyMuPDF PDF, DXF R12, cut list, nested BOM, model JSON) | Skeleton of the output layer; the drawing engine replaces `draw_assembly_pdf` |
| `extract/*` (parsers for order summary, assembly sheets, BOMs, callouts, piece tables, eng title blocks, member schedules, grids) | (a) **Golden-file tests**: regenerate MB1-1 / RF1-9 / HPC-4 from a model and diff BOM rows, dimension strings and callouts against the originals automatically. (b) Optional seed of the building model from engineering drawings |
| `rules/*` (30 checks) | Pre-release checker that runs on the generated set (still useful, no longer the headline) |
| `web/server.py` + static UI | Starting point for a model editor / drawing preview |

## 3. What has to be built

### 3.1 Geometry kernel (2D-first, positioned in 3D)
* Section profiles with real geometry: W (d, bf, tf, tw), C/Z (purlin/girt), angle, flat plate,
  built-up tapered web (rigid-frame columns/rafters).
* Member = profile extruded along an axis with **end cuts** (square, mitre/bevel angle, cope, notch),
  giving cut length, assembled length, shipping length from geometry instead of typed values.
* Plate = outline polygon (rectangle, trapezoid like PPL-2, clipped corners) + thickness + holes.
* Placement = part → (station along member, face top/bottom/web, side NS/FS, rotation, offsets),
  e.g. PC8D at 1'-1 3/16", 3'-1 3/16" … on the top flange, 90° to the member.
* Hole layout = gauge / pitch / edge distance patterns; diameters as exact dims (D = 9/16").

### 3.2 Parametric part & connection library (the shop's standards, data-driven)
Templates that emit parts + placements + welds from a few parameters:
end plates (EP12), purlin clips (PC8D and spacing from purlin layout), flange braces (CLF/FB),
base plates (B-14), stub beams (MB-2/MB-3 with copes), haunch/knee brackets (HBR/BR, HPC with
PPL-1/PPL-2), splice plates, sag-rod/bracing clips. Stored as JSON/YAML so a shop can edit
gauges, edge distances and naming without code changes.

### 3.3 Building-level modeler
Inputs: frame lines and bay spacing, eave height, roof slope, column/rafter sizes and lengths,
purlin/girt spacing, bracing, openings. Output: member instances placed in the building,
connections assigned, identical assemblies collapsed into marks with quantities
(MB1-1 ×2 vs MB1-2 ×3 falls out of geometry differences, not typing).
Seed options: forms/spreadsheet, JSON, or the existing engineering-drawing importer.

### 3.4 Drawing engine (the visible product)
* Views: elevation, plan of top flange, end/section views, detail views of sub-parts (MB-2, MB-3),
  rotated part views ("SECTION A-A"), simplified hidden-line handling.
* **Automatic dimensioning**: running dims from a datum ("Tape (Typ)"), overall length,
  hole spacing/edge distances, angles, with collision-free placement of dimension text.
* Annotations: part callouts with leaders, hole-diameter notes, NS/FS labels, centre lines,
  weld ticks / weld symbols, view labels and section markers, "View for Sections" arrow.
* Tables: BOM (PART/QNT/DESCRIPTION/WEIGHT + total), piece table
  (ITEM/QTY/MARK/WIDTH/LENGTH/THICK/WEIGHT), order summary page.
* Sheet layout: title block matching the sample, automatic view placement and scale selection,
  multi-view sheets, sheet numbering, revision clouds later.
* Output: PDF (PyMuPDF, already wired), DXF with proper layers and DIMENSION entities
  (upgrade from R12 lines), SVG for the web preview.

### 3.5 Editor UI
Model editor (building parameters, frame/member browser, connection assignment, attachment tables),
live drawing preview with regenerate, issue panel from the existing rule engine, release packaging.

## 4. Status after the first build session

Decisions taken (user): web editor from the start, rigid frames first, PDF + DXF + shop data, match the
sample sheets.  Implemented in `mbdp/detail/` (see README part 1):

* Geometry: W-shape catalog with d/bf/tf/tw, members with square/bevel ends, plates with hole tables,
  clips, stubs with their own parts, bracket symbols, web hole groups.  (§3.1 partly - no tapered
  built-up sections, no true 3D placement yet.)
* Part library: PC8D, CLF2/4/12, EP10/12, B-8/10/14, K-10/14, MB-2/MB-3, bracket weights (§3.2 - data
  in `templates.py`, editable in the UI; hole layouts flagged where assumed).
* Wizard: rigid-frame column + rafter with documented formulas (§3.3 partly - no secondary framing,
  endwalls or bracing yet).
* Drawing engine: elevation / section / stub details / plate faces / cut sheets / piece sheets,
  ordinate + linear dims with collision avoidance, leaders, BOM, title block, PDF / SVG / DXF with
  DIMENSION entities (§3.4 largely - bracket weldment sheets, revision clouds and multi-sheet
  assemblies remain).
* Shop data: cut list, plate list, 1:1 plate DXF, DSTV-style NC1, hashed manifest.
* Editor: full model editing with live preview, downloads, package export (§3.5 first version).

## 5. Suggested order (each phase ends with sheets that can be compared to the samples)

| Phase | Deliverable | Why first |
|---|---|---|
| 1 | Piece/plate sheets (HPC-4 / PPL-1 / PPL-2 style) + mezzanine beam sheets (MB1-1/MB1-2) regenerated from the model with running dims, end-plate views, section, BOM table and title block | Pure 2D, small part set, exercises the whole drawing engine (views, dims, leaders, tables); golden-file diff against SHOP1 p4 and SHOP2 p10 |
| 2 | Rigid-frame columns/rafters (RF1-x) with stubs, brackets, base plates, bevel cuts, haunch brackets; bracket sheets (HBR/BR) | Adds angled geometry, sub-part detail views, weld ticks, multi-view layout |
| 3 | Building modeler + secondary framing (endwall columns, girts/purlins, bracing) and order summary / shipping list generation | Turns "draw an assembly" into "detail a job" |
| 4 | Editor UI, DXF layers/dimension entities, revision compare/issue control on drawings | Productisation |

Phases 1 and 2 are where the geometry kernel and drawing engine are built; 3 and 4 are mostly
data modelling and UI on top of them. The existing rule engine keeps running before every
release so the "no best-guess release" principle survives the pivot.

## 6. Decisions (answered)

1. Where does the model come from first: typed/JSON input, spreadsheet, or import from engineering drawings?
2. Which sheet family first: piece sheets and mezzanine beams (fast), or rigid frames (harder, higher value)?
3. Output formats required on day one: PDF only, or DXF/DWG for CAD editing as well?
4. Style: replicate this fabricator's sheet style exactly (the samples become the template), or a generic style with a configurable title block?
5. Interface: keep CLI + JSON models for the engine work and add the editor UI later, or UI from the start?
