# Visual closeout review — confirmed answers

Recorded 2026-10-02. These answers govern the next implementation pass; recording them does NOT mean the application or released086 packages have been updated. Original review/source PDFs are unchanged.

## Q01 — actual inside-face opening dimensions
Door and window dimensions are actual entered inside-face dimensions. User example12ft x12ft means12ft between opening-side jamb faces and12ft floor to opening-side header face. Not nominal product size or panel cutout. Do not consume the specified clear opening with framing/connection allowances.

## Q02 — manufacturer-dependent clearances
There is no universal SD87 dimension independent of clip. Manufacturer clip dimensions govern;1/8in is the user's general clearance rule when no more specific detail controls. Preserve separately defined joint-specific clearances (including explicitly shown source gaps and previously specified TOTAL flush-run clearances); do not apply another1/8in per end silently. Do not turn SD87's variable reference dimension into a fixed clear-gap dimension without its reference face.

## Q03 — manufacturer-dependent connection parts
Same rule as Q02: actual manufacturer/part dimensions vary. Use the applicable actual clip/connection geometry and editable dimensions, not a mandatory universal JH-8/GC-8 kit. No further demand for the user to choose one universal vendor kit.

## Q04 — reuse main-frame rules for lean low connections and bases
Lean-to knee uses the SAME main-rafter connection detail in welded and bolted configurations. Lean base plates use the SAME base-plate rules. Implement reusable geometry/rules, not an independent, permanently unresolved lean system. Do not insist on additional LR/LC shop sheets as a prerequisite to implementing this rule. Paired-Cee connection fabrication still needs source/geometry reconciliation where not established; do not invent stitch pattern/capacity.

## Q05 — high bypass plate envelope
Thickness1/2in. Width and height follow the rafter; width may be increased to the next whole inch (user example5.5in flange ->6in plate width). Do not silently round HEIGHT or invent hole pattern from this envelope rule. Preserve exact-width and round-up width behavior as allowed, with the choice visible. Reconcile selected source holes and placement separately.

## Q06 — clips and rotated endwall columns
- PC8D:8in girt, FLANGE-mounted on sidewall or endwall.
- CLF12:8in girt at endwall corner where the web is PARALLEL to the girt.
- Endwall wide-flange columns are rotated90degrees / perpendicular to rafter. Model actual orientation, not merely relabel a clip.
- HSS columns: treat connection as FLANGE clip, not an invented HSS web clip.
-6in girt plate geometry follows MBCI6in punching layout; adjust plate envelope around the real pattern, not by uniformly shrinking8in hole coordinates.
- User directs use of RF1-5 column shop sheet and BR10LN2 high-side bypass reference.
- Existing inward-end/both-interior flush rules remain, applied to actual member orientation and selected clip family rather than every location receiving PC8D.

## Q07 — welded contact resolved by column cut-height calculation
User: rafter is plumb cut and flush with column OUTSIDE edge; the clip at the top of the rafter is plumb as well. Difference between nominal rafter depth and the pitched/plumb depth is INCLUDED in the column cut-height dimension.
This supersedes the software's unresolved nominal-depth seat overlap. Preserve eave/rafter datum and include the geometric pitch-depth correction in the column cut; do not ask the user to accept overlap. The Q7 eave/top clip must be drawn plumb. Do not silently reinterpret this as changing every unrelated roof clip. Other settled ridge/eave rules stand.

## Q08 — MBCI channel reference supplied
https://www.mbci.com/products/channels/
Use actual channel product geometry/data; do not assign lipped-Cee properties to unlipped channels. Source nominal-depth class and actual dimensions must be distinguished. Current page lists channel8-1/8x2, for example, not the lipped Cee8x2-1/2 envelope. Preserve exact source dimensions and finish/gauge-specific weights, and show the actual product selection. User supplied this as the channel specification reference, not a request for an invented unverified channel.

## Q09 — trim field-fabricated,26ga
Trim is field fabricated from26ga material. Stop asking whether it is bought formed. Show formed profiles, field-fit references and net quantities. Do not claim exact brake-developed blanks or a26ga numeric thickness/bend allowance unless those actual data are established; a field-fit drawing need not wait for CNC trim development.

## Q10 — plasma setup / manual placement
- Shop-built JD's Garage CNC plasma.
- OpenBuilds controller SOFTWARE; actual firmware/post and torch command interface not yet verified.
- Manual torch height.
-30in x30in machine capacity.
- If nesting is supplied, show starting positions relative to0,0 so user can place machine there.
Provide30x30 layout sheets with explicit part local origins/start coordinates and rotations. Distinguish placement origin from a cutting pierce/lead-in point. Fit checks include allowances when known; no automatic splitting/welding of oversized parts. No assumed GRBL firmware or machine-ready G-code solely from the software name. Machine configuration is still being completed; this is not a blocker to ordinary PDF/DXF/layout work.

## Source verification performed this turn
1. Uploaded MAIN shop PDF page2, RF1-5, visually shows PC8D3/16x6x7 and CLF12 3/16x6x11; Section A-A and its BOM label the high bracket BR10LN3, NOT BR10LN2. BR10LN2 is separately present on RF1-7 (PDF9), RF1-8 (PDF10), and EC-2 (PDF26). Retain identities and reconcile intended orientation; do not silently rename or equate these brackets. This is a source-tracking correction, not a demand for a new broad user decision.
2. User-linked CI manual was downloaded. Actual punching sheet is PDF19, printed CI-19, REV00.02 (TOC in web extraction says CI-21). Both6in and8in web patterns show4in between hole rows; web-edge offsets are1in for6in and2in for8in. Pattern G common-end distance is1-3/4in. Bottom notes state holes5/8in and slots5/8x3/4in. Keep manufacturer SECONDARY punching distinct from source clip holes9/16in; do not automatically replace one with the other. Saved extract Q06-MBCI-Punching-CI19.pdf.
3. Channel page was successfully read through fetch tool; direct HTML retrieval returned403. Saved factual excerpt rather than pretending an HTML snapshot was obtained.

## Status
Q01-Q10 now have user answers. Remaining work is implementation/source reconciliation/testing, not another blanket clarification round. Specific manufacturing geometry still must not be invented. Current086 examples/Windows package are unchanged by this recording pass.
