> Historical v0.2 implementation notes. For current behavior, see [v0.3 guide](V03_FABRICATION.md).

# Connection designer — v0.2

## Confirmed requirements
- Single-web plate construction, not a closed two-sided box.
- Low eave: HBR10E1 family. High eave: HBR10HE1 family for a mono-slope roof.
- Apex: mirror high-eave halves into one continuous web, with mating plates both ends.
- Bracket width follows column flange width; body depth follows rafter depth.
- Top follows rafter pitch; bottom horizontal as in the provided examples.
- Bottom length is an editable input, initially 10 1/2 inches per half.
- Column assembly marks use COL-1, COL-2, etc. Rafter marks stay unchanged.

## Source evidence
`Clark Jordan 1277345 - Shop Dwgs Copy.pdf`, pages 1–4:
- Page 1 HBR10E1: top 1/4 x 5 x 15; back 1/4 x 5 x 11 7/8;
  one web 3/16 x 10 x 12 7/8; bottom 1/4 x 5 x 10 1/2; K-10 1/2 x 6 x 17 1/4.
- Page 2 HBR10HE1: top 1/4 x 5 x 11 5/8; back 1/4 x 5 x 14 1/4;
  one web 3/16 x 11 1/2 x 14 1/4; shared bottom and K-10.
- Pages 3–4: back-plate holes D=9/16; gauge 2 1/4 centered in 5-inch width;
  one row 2 inches from end. Those hole parameters are retained during resizing.
- Assembly callouts and BOM have inconsistent HBR/BR spellings. Source PDFs
  remain unmodified. New generated KB/APEX marks deliberately avoid silently
  resolving those original identifiers.
- These pages do not specify complete welds, connection capacities, full K-plate
  hole dimensions or web cutting vertices. No capacity has been inferred.

## Geometry convention (derived, not a reproduction of source cut sizes)
Coordinates: column-side body datum x=0, bottom y=0, mating bottom x=B.
Rafter depth d is normal to roof pitch; t is top/bottom/back thickness.
Theta = atan(rise/12). The selected column flange width and rafter depth are
rounded to the shop's 1/16-inch display/cut grid and explicitly marked derived.

Low eave: top mating point (B - d*sin(theta), d*cos(theta));
column-side top height h=(d - B*sin(theta))/cos(theta).
High eave: top mating point (B + d*sin(theta), d*cos(theta));
h=(d + B*sin(theta))/cos(theta).
Web contour is inset from the outside top/bottom/back faces by plate thickness.
Apex mirrors the high-eave web across x=0, omits the center back plate, and joins
both halves as a single plate. Apex presently assumes identical left/right
rafter profiles and equal pitch; it is NOT a validated detail from the uploads.

Low-eave extra top length is independently editable, initially zero and flagged
for confirmation. The uploaded low-eave example has an overhang; its relationship
to the selected column is not dimensioned sufficiently to assume an automatic rule.
Plate end bevels and ridge miter edge preparation are not modelled (square cuts are detailed).

End-plate dimensions/holes are copied unchanged from the chosen library plate
(default K-14), with identical loose mating plates provided for rafter sides.
This preserves pattern identity but does NOT validate that pattern, capacity,
edge clearance or size for the newly selected member. Interface plates are
shown centered on rafter depth: this placement is also a review assumption.
Existing library K-14/K-10 layouts are labeled assumed-layout.

## Use
1. In the web editor choose **Connection designer**.
2. Select low, high or apex; select the column and rafter driving its dimensions.
3. Set bottom length, pitch, thicknesses, mating pattern, and standalone quantity.
4. Generate; inspect the weldment and each plate using the tabs.
5. To resize, use **Edit connection / resize**, or change the selected member section.
   Generated pieces are read-only outside this editor to avoid overwritten manual edits.

Three separate example lots ship with the package: KB-LOW, KB-HIGH, APEX-1,
one each. They are examples to review, not three connections installed in the
sample building. The existing RF1-2 station edit is preserved.

## Outputs and holds
- Weldment sheets, individual part sheets including continuous-web vertices,
  PDF / SVG / drawing DXF; gross plate weights (no hole deductions), with web
  weights based on cut polygon area rather than bounding rectangle.
- Weldment BOM excludes the separately listed loose rafter mating plates.
- Plate totals and connection_bom.csv apply the standalone quantity multiplier.
- New connection plate NC1 and 1:1 cutting DXF are deliberately withheld. There
  is no approval toggle pretending to supply the missing design information.
- All new connection sheets are DRAFT / NOT FOR FABRICATION, and the package
  status is BLOCKED. Original unrelated part exports retain their existing behavior.

## Remaining work
- Confirm low-eave top overhang and all fabrication fits/edge preparations.
- Supply/confirm full mating-plate hole dimensions, bolt specification, material
  grades and weld details for the intended sections/loads.
- Confirm the derived apex configuration; support unequal pitches if needed.
- Install these connections into full frame geometry, revise member cuts/quantities,
  and replace the old symbolic attachments. For now they are independent lots:
  do not count them twice if you manually attach a generated bracket to a member.
- Validate future released cutting exports against shop equipment/importers.

## Tests
69 automated tests: includes family topology, single-web apex, quantities,
section-driven resizing, JSON stability, contour weights, invalid-input rejection,
API resize and cutting-output suppression. Playwright smoke is available in
`tests/ui_connections_check.py` (requires an editor on port 8010).
