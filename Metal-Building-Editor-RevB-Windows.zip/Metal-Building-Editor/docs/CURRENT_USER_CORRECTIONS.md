# User corrections after v0.8.5 — authoritative; implementation status in V086_CORRECTION_REVIEW.md

Supersedes conflicting earlier requirements/templates. v0.8.5 door/front-sidewall example is NOT accepted by user.

- No mandatory post at ridge on any endwall. Bay count/layout controls post count; odd bay counts permitted. Do not force even counts or add a ridge post. Unequal layout must be supported when specified.
- CLARIFIED: Header is ALWAYS an inverted Cee, matching the nominal width/depth of other wall girts; do NOT use a Zee header merely because wall girts are Zee. Jambs are matching vertical Cees. Not restricted to8in. Study BOTH erection sets and preserve actual orientation/attachments. CONFIRMED via clarification: "open face Cee" checkbox means UNLIPPED channel (no inward return lips), applied to BOTH header and jambs. It is NOT an orientation-only switch. Standard option remains lipped Cee. Match wall-girt nominal width/depth; no section capacity equivalence or thickness inferred by simply deleting lips.
- Source buildings: one welded mainframe with bolted connections, other bolted frame. BOTH show inset columns. Draw header/jamb/girt geometry relative to actual inset steel and wall planes. Previous door/front-sidewall illustration rejected.
- CLARIFIED: Roll-up openings START centered in their bay, but user may move them within that SAME bay down to6in minimum clearance from upright. Centering is a default, not a lock. Retain aperture-edge-to-upright-edge minimum plus framing-envelope protection, and never cut/move upright.
- Rake angle standard for EVERY sheeted endwall, MAIN AND LEAN-TO, not optional selection.2in top/4in down rule retained. Rake is top sheet screw support; base angle bottom screw support. These are attachment supports, not decorative trim.
- Lean-to dialog contains only lean-to settings. Main building/openings/endwall settings belong in main dialog. Show attached lean-to geometry on whole frame/building plan as well as dedicated detail sheets.
- Flush/non-bypass: remove exterior/bypass column clips. Web clips only on inward-facing side of end columns and both sides of interior columns. Do not interpret this as no flush web clips.
- Endwall girt connections same as main: bypass clip on outside of column; flush clips aligned flush with outside. Maintain consistent main/endwall datum.
- Welded ridge plate LENGTH = ACTUAL pitch-cut depth +1in, not nominal beam depth. For symmetric rafters/plumb ridge, actual cut depth = actual section depth /cos(roof angle). CONFIRMED: extra1in is SPLIT,1/2in above and1/2in below actual rafter pitch-cut length. No further question on that placement.

User asks: after these corrections, what still needs confirmation? Most remaining work is implementation/source reconciliation, NOT repeated questions about settled rules. Latest reply confirms ridge split, Cee-only header/jamb rule and movable-in-bay doors. Only actual unresolved dimensions/source conflicts should become specific questions. Machine/controller information still required before machine-ready code, not before ordinary drawing work.

## Visual review Q01 — confirmed user response

"opening dimensions whether window or door are always actual dimensions entered. measurements are for inside edge of header and jamb. So a 12'x12' opening is 12' wide from face of cee to face of cee. and 12' tall from floor to face of cee."

Treat specified opening dimensions as actual inside-face framing dimensions, not nominal product sizes or panel-cutout sizes. For the stated floor-level example:144in between jamb opening faces and144in floor to header opening face. Keep connection/member allowances outside the specified clear opening. Q01 is answered; editor/drawing wording and coordinated opening/panel geometry need implementation review before claiming applied.

## Visual review Q02-Q10 — confirmed and controlling
See REVIEW_ANSWERS_Q01_Q10.md for full answers and source checks. In particular Q07 supersedes the prior unresolved nominal-depth seat treatment: preserve datum and include pitch/plumb-depth difference in COLUMN CUT HEIGHT; eave/top rafter clip is plumb. Q04 reuses main knee/base rules for lean structures. Q06 supplies clip families, rotated endwall WF orientation and HSS flange attachment. Q09 field-fab26ga; Q10 plasma30x30/manual THC/OpenBuilds, coordinate layout before verified machine code. Manufacturer dimensions controlQ02/Q03; general clearance1/8in is not an override of already specified joint-specific or TOTAL clearances. No new changes to application geometry have been validated in this answer-recording turn.
