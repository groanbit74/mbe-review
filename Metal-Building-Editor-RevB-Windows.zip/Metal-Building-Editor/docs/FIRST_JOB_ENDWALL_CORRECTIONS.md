## UPDATED: owner JSON and PDF received; v0.8.9 review update implemented

See V089_ENDWALL_REVIEW.md and root MBDP-HANDOFF.md. The awaiting-file status below is HISTORICAL. Original upload and working copy preserved. Shared bearing-jamb topology/post stations/opening views now implemented; final endwall connection fabrication still unfinished.

---

# First-job entry issues — latest user confirmation

Status: diagnosis / awaiting the user's CURRENT SAVED JOB JSON (not yet supplied). Do not modify demonstration jobs and call them this job. User reports missing/unusable endwall upright/opening/girt controls, cannot reposition posts, cannot select open-channel end rafters as intended. These include actual software limitations, not presumed input mistakes.

## Confirmed this exchange
-20ft wide ×30ft long ×12ft eave,1:12 gable.
- Main center rafter W6×9, bypass roof purlins. Main columns remain W6×9.
-4×4 tubing is LEAN COLUMNS ONLY. Wall thickness was not supplied in the answer; do NOT import the demonstration's1/4in assumption.
- Open/unlipped channel endwall rafters, roof purlins inset between flanges. Independent end versus interior roof fit remains required. Preserve actual profile and unresolved fit conflicts; do not substitute W sections.
- Full30ft side lean,18ft horizontal projection,8in along-roof overhang (prior confirmed datum).
- Flat residential rake trim with4in face at both ends. Top leg/hem/returns/developed blank have not been specified. Do not reuse commercial rake2top/4down as a verified residential profile just because face height matches.

## Endwall / door layout
User selected:10×10 door CENTERED ON ENTIRE20ft ENDWALL, not centered in a default10ft post bay.
- Looking from OUTSIDE the roll-up-door end: clear roll-up aperture X=5ft through15ft; sill atfloor; head10ft.
-3×7 walk door centered in remaining left5ft wall strip: provisional CLEAR aperture X=1ft through4ft. These values exclude any trim/frame allowances and must be checked against actual job profiles.
- Opposite endwall: one3×7 walk door physically aligned down the building with that front walk door. When viewing the opposite end from OUTSIDE, it appears on the RIGHT: provisional X=16ft through19ft. Do not mirror twice.
-6in OPEN CHANNEL jambs support the roof around the10×10 opening, and receive wall girts directly. These are shared structural post/jamb members, NOT separate ordinary jambs duplicated beside obstructing generic uprights.
- User also specified6in C for the door header. Keep Cee header distinct from actual unlipped channel jamb profile; which header records/gauges the current job uses must be inspected from saved JSON. Do not infer missing gauge/finish, capacity or an unsupported punching/clip pattern.

## Needed software work
- Actual roof-bearing opening-jamb role, shared post/member identity, quantities counted once, direct girt attachment topology and post head/end-rafter cuts.
- Editable endwall post positions/role labels independent of equal-bay presets; preserve building width and explicit aperture faces.
- Shared bearing jambs are opening boundaries, not unrelated obstacles requiring6in separation from themselves. Retain clearance checking against OTHER uprights; never silently cut/move an unrelated post.
- Make these members/girts visible in endwall and shop views; not just schematic panel apertures.
- Diagnose channel selector availability/preset override from current saved job and screenshot before asserting user has old version or entered it incorrectly.
- Current v0.8.8 separate endwall knee/ridge fabrication adapter was explicitly unfinished. This issue now takes priority; don't relabel it as missing user approval.

## Next step
Ask user to attach saved job JSON (already requested) and optional screenshots of endwall and section selector. Work on a copy with originals retained. No need to repeat the confirmed dimensions/layout/column question. Girt levels/sections, actual saved framing settings, jamb/header gauge and tube wall can be read from that file or flagged if genuinely absent.
