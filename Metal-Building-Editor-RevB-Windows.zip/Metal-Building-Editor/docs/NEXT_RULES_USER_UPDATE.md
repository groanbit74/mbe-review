# User-directed next build — supersedes v0.8.7 where stated

Status: recorded requirements, NOT yet implemented. User asks to update the reusable rules/editor first, then they will enter their complicated first job and report needed revisions. Stop the pre-entry clarification round. Do not substitute a demo job or invent missing job data.

## New requested rules/options
1. Lean welded high end: stop rafter 1.5in from main-column attachment face measured ALONG rafter; clip bridges this gap and overlaps another6in into rafter web. Prior blanket6in total projection is superseded for this option.
2. Bolted lean high: BR10LN connector,12in long × rafter size. Reconcile actual source variants; no invented hole gauge/plate thickness or silent BR/HBR renaming.
3. Clips always follow actual selected purlin/girt size. Resize bolted clips for4–8in members using real punching, not uniform scaling.
4. Welded frames use solid3/16in weld clips:8in member→5×7in;6in→3×5in;4in→3×3in. Intermediate-size rule and plate orientation not explicitly specified. No invented holes in solid clips.
5. Selectable eave purlin4–8in instead of eave strut; also explicitly provide6in eave-strut option.
6. Optional no column base plate: weld directly to floor/embedded weld plate; separate top-of-weld-plate elevation datum, not inferred slab welding.
7. NEW OPTIONAL welded knee (retain previous seat): rafter welded directly to inside column flange;3/16in top plate, width=rafter width, spans column depth and extends3in inward over rafter. Its outer edge bears on pitch-cut column flush with outside column flange. User confirmed plate length measured ALONG pitch; keep column-depth-versus-sloping-bearing coverage physically reconciled, not silently shortening bearing.
8. Main-building rafters may be actual MBCI open/unlipped channel. Independent end-frame flush/bypass roof framing setting versus interior rafters.
9. Girt clips movable with explicit stations/offsets and geometry/edge checks.
10. Header purlin flange faces UP, not down, for ordinary framed openings.
11. Opening jamb top attachment choice: bottom of eave strut/purlin; bottom of rafter (standard); or bay-spanning header with jambs attached to it. Bolted uses clips; welded attaches purlin directly.
12. Separate walk-door header-only option, no jambs: girt legs DOWN. For Zee: outside flange down, inside flange up. Do not confuse with ordinary opening header-up rule.
13. Show actual trim profile shape on all sheeted views, in chosen color. Developed bends/profiles not established by26ga alone: retain source/custom profile distinction.
14. Calculate lean rafter lengths/heights per job from actual connection/end-cut datums. No automatic machine release.

## First-job facts supplied (not complete job; user will enter in updated editor)
- Main20ft wide ×30ft long ×12ft finished-floor to roof-framing top at outside-wall eave.
- Gable1:12 roof. Frame lines0,15,30ft.
- W6×9 main columns and center main rafter. Actual6⅛×2 MBCI unlipped channel end rafters,14ga.
- All these rafters welded to inside of pitched columns using new optional knee.
- End rafters receive6in purlins,14ga, flush/inset; center roof frame bypass. Separate settings required.
- User requested1/4in TOTAL fit clearance but has not distinguished depth vs end-length. IMPORTANT: actual6in-deep purlin cannot have1/4in vertical clearance within a6⅛in OUTSIDE-depth channel. Flag actual fit; do not silently change selected sections or fake clearance.
-18ft horizontal-projection lean along30ft sidewall, continuing same1:12 roof plane; roof sheets continuously from main ridge through lean to8in overhang measured ALONG slope.
- Lean frame spacing matches0,15,30ft. Lean columns4×4 tube; wall thickness, lean rafter choices and attachment face to be entered by user. Do not substitute W columns.
- No separate column base plates; tops of embedded floor weld plates at finished-floor elevation.
- Lean roof datum at support would be10ft6in IF the18ft support projection begins at main outside-wall eave datum. Actual cuts must account for selected profiles, eave system and new knee plate thickness.

## Work approach confirmed by user
“i would rather wait for you to update rules and changes and let me input into the new version. if something needs revision i will communicate this to you. agreed?”

Proceed with reusable editor/model changes, preserve originals and prior options. Present genuine completed version with validation and honest remaining constraints. Do not claim this requirements record implements the changes, or claim job fabrication/CAM readiness. Avoid further broad questions before user can enter their job.
