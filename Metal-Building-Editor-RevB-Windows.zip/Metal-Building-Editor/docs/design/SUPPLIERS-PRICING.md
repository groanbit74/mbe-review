# Suppliers, pricing and editable order spreadsheets — design proposal (round 16, NOT built yet)

Owner, 17 Oct 2026: *"As a general rule SSS steel is used for welded buildings and MBCI is used for bolt
buildings. In the future I'd like an option to add supplier data and pricing, as well as being able to edit
order spreadsheets for special cases."*

Status: proposal for the owner to confirm; nothing here ships until the drawing-observation release unless
he says otherwise. Release policy still applies: **pricing never blocks COMPLETE** - a missing price is an
`UNPRICED` mark on an order line, never a hold.

## 1. What exists today (read from the code, 0.8.45)

* `ordering.build(job)` -> proposed order: demands (cut pieces) -> stock bars (`pack`) -> `items` (stock
  lengths x quantity), per material group, with the stock lengths the product is bought in
  (`ordering.stock_lengths_in`: SSS catalog lengths when the SSS policy is on, else Order settings).
* `purchasing.supplier_plan(job)` -> the supplier request rows (material, finish, grade, lengths x qty,
  supplier name / catalog code / page) and `purchasing.write_supplier_workbook`; `order_workbook.write_workbook`
  -> `master_order.xlsx`; CSVs through `ordering.export_order_files`. **No prices anywhere** (by design so far).
* `job.settings.product_suppliers` (primary / secondaries / sheets / trim) and `job.settings.sourcing`
  (primary + per-line overrides). Only an SSS standard product set is preselected
  (`standards.SSS_STANDARD`); there is no MBCI standard.

## 2. Supplier book (shop-wide, not per job)

Stored in the workspace (`<workspace>/supplier_book.json`, written atomically, backed up on every save,
opened by name from *Job > Suppliers & prices*). A job keeps only a **snapshot of the prices it used** when
an order is exported, so a later price change never rewrites an old order.

```
supplier:  id (slug), name, code (SSS / MBCI), contact, account no., terms, freight rule, tax %, notes,
           default_for: ["welded"] | ["bolted"]          <- the owner's rule, editable
price:     supplier id, key (catalog code or profile id: SSS-PN8ZEE, MBCI-Z-8x2p5-G14, W6X9,
           HSS 4x4 x 11 ga, SSS-PBR 26 ga ...), description, finish/colour, unit basis,
           price, per-stick overrides {"21'": 97.40}, minimum order, cut charge, lead days,
           valid from / to, quote ref
unit basis: per ft | each (stick / sheet / piece) | per lb | per cwt | per sq ft | per sheet length
```

* Price lists enter three ways: type a row, paste rows from Excel (tab separated), import a CSV/xlsx; export
  the book back to xlsx so the shop keeps its own copy.
* The two catalogs already in the program carry **no prices**; nothing is invented. A line with no matching
  price shows `UNPRICED` and the totals say "n lines unpriced".

## 3. Pricing the order

For each supplier-plan row and each (length, quantity): stick price = per-stick override, else per-ft x
length, else each, else per-lb x catalog weight, else per-sq-ft x panel area. Extended = stick x quantity.
Totals per supplier: subtotal, freight, tax, grand total; per job: all suppliers. Stock lengths and cut
sheets are unchanged; pricing only reads them. Output columns are added to the existing workbooks, and
one workbook per supplier (a purchase order in the supplier's column order when the shop supplies a form).

## 4. Editing the order for special cases (the owner's second ask)

An overlay on the generated order, kept in `job.settings.order_edits`, never a copy of it:

* **Line key** = supplier + material + finish + grade + order length (stable across regeneration).
* **Edits**: quantity, length, unit price, note, *remove*, *restore*; **custom lines** (free text: supplier,
  description, quantity, unit, price, note) for things the model does not know (extra stock, a special order).
* The workbook/CSV/PDF show each edited line with the **program's value and the edited value side by side**
  and an `EDITED` / `CUSTOM` tag; the on-screen order dialog shows the same and a one-click *Restore program
  value*.
* Edits whose line no longer exists after a model change are listed as "no longer matches" and are NOT applied.
* Edits never change geometry, cut lists or drawings - the shop set always shows what the model says; the
  order shows what the shop decided to buy.

## 5. Supplier rule by construction

`welded -> SSS`, `bolted -> MBCI` becomes a data table (`standards.SUPPLIER_BY_CONSTRUCTION`), editable in the
supplier book (*default for*). Choosing **bolted** on a new job then offers the MBCI product set in one
click (the same product replacement the *Supplier products* dialog already performs). That needs the owner's
**MBCI standard product set** (proposal below), because only SSS is preselected today.

Proposed MBCI standard (from the MBCI Pricing Guide Rev P data already in the program - to confirm):
Z purlin / girt 8 x 2 1/2 x 14 ga (`MBCI-Z-8x2p5-G14`), eave strut 8 x 5 x 3-3/8 x 14 ga low single
(`MBCI-Eave-8x5x3p375-G14-low_single`), base angle 2 x 4 x 14 ga (`MBCI-Angle-2x4-G14`), PBR 26 ga, wall /
roof / trim colours to be named.

## 6. Questions for the owner (answers shape the build)

1. How do you price today - per foot / per stick from SSS and MBCI lists, per lb for W shapes and tube, per
   sheet or sq ft for panel? Do you have the price lists as xlsx / PDF (upload) or quote by quote?
2. Should prices only total the purchase orders, or also feed a job cost (markup, labour, freight, tax)?
3. Which order spreadsheets do you edit by hand now (the SSS order form? your own)? Upload one so the export
   matches its columns.
4. Is the MBCI standard above right for a bolted job, and what colours?
5. Zee lap at a rafter: how long (12" total, centred on the rafter?), and should a Zee lap by default?

## 7. Build order (each step stays COMPLETE-safe and tested)

1. `supplier_book.py` (model, validation, atomic save, CSV/xlsx import-export) + API + *Suppliers & prices* form.
2. Pricing engine + price columns in the existing workbooks + per-supplier workbook.
3. `order_edits` overlay + order-lines dialog + workbook diff columns.
4. Supplier-by-construction defaults + MBCI standard product set.
