# Historical release-scope note — superseded by v0.8.62

This earlier scope brief is retained for historical context. The per-location connection-override work described in the v0.8.62 changelog and `V0.8.62_RELEASE.md` is implemented and verified. Other deferred items below are not claims about v0.8.62 scope.

User: “if it makes it simpler i just need 1-4 required implementations in next version. welded options only don't need to figure lean-to bolt yet.”

Interpret items1–4 against docs/V088_WORK_IN_PROGRESS.md Required next implementation, excluding bolted work as explicitly directed.

NEXT RELEASE:
1. Optional inside-column-flange welded knee: pitch-cut column, rafter at inside flange,3/16in top bearing plate of rafter width with3in inward extension, actual cuts/parts/drawings; retain previous seat.
2. Actual MBCI channel main/end rafter support and independent end-frame flush/inset versus interior bypass roof framing; physical fit validation, no W substitution.
3. WELDED lean high and low details and job-specific rafter cuts/heights.1.5in along-slope high gap plus6in web overlap; continuous main-to-lean roof sheet run and8in along-slope overhang for this requested configuration. BR10LN/lean bolted implementation is deferred.
4. Welded/member-sized solid clips, eave purlin4–8in choice and6in eave strut, independently movable girt clips. Bolted4in punching development is deferred.
Keep already implemented optional floor-weld bases and welded clip controls.

DEFER from this release: new bolted lean/BR10LN development and new bolted clip patterns; new opening/header/jamb modes (item5); new all-view actual-profile/color trim display (item6). Preserve existing released features and old bolted options without claiming new compatibility.

This is a historical planning brief, not a current release checklist. The v0.8.66 work and its verification are recorded in `docs/V0.8.66_RELEASE.md`; later work should be scoped from the current user request rather than treating this archived list as an active commitment. Do not include owner jobs, uploads, or generated customer drawings in application packages.
