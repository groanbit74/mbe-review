# Rule catalog (rules-2025.09.1+aisc-nominal-2024.09)

Severity: **error** = release blocked; **warning** = documented disposition required; **info** = informational difference.
`requires` = minimum approver role that can close the issue (checker < engineer).

| Rule | v | Severity | Requires | Title |
|---|---|---|---|---|
| `IDN-001` | 1.0 | error | checker | Sheet lacks a valid job identifier (attributed by binding only) |
| `IDN-002` | 1.0 | warning | checker | Package contains sheets dated after its release date / mixed dates |
| `IDN-003` | 1.0 | info | checker | Title-block ISSUE code differs from revision table |
| `DB-001` | 1.0 | error | engineer | No confirmed engineering design basis for fabrication project |
| `DB-002` | 1.0 | error | engineer | Design member schedule disagrees with fabrication package |
| `GEO-001` | 1.0 | error | checker | Grid dimensions do not sum to the out-to-out dimension |
| `GEO-002` | 1.0 | error | engineer | Declared roof slope differs from slope depicted in sections |
| `MBR-001` | 1.0 | error | checker | BOM cut-member mark disagrees with cut sheet (profile/length) |
| `MBR-002` | 1.0 | error | checker | Cut-sheet quantity does not reconcile with assemblies using the cut member |
| `MBR-003` | 1.0 | warning | checker | Documented member weight inconsistent with profile x length |
| `BOM-001` | 1.0 | error | checker | BOM line weights do not sum to the stated total |
| `BOM-002` | 1.0 | warning | checker | Same part mark carries inconsistent unit weight across sheets |
| `BOM-003` | 1.0 | warning | checker | Same part mark carries different descriptions (or description belongs to another mark) |
| `BOM-004` | 1.0 | info | checker | Plate weight differs from rectangular blank weight by more than 15% |
| `ORD-001` | 1.0 | error | checker | Order line disagrees with assembly sheet (qty / profile / weight) |
| `ORD-002` | 1.0 | error | checker | Order total does not equal the sum of its lines |
| `ORD-003` | 1.0 | warning | checker | Sheet in package is not covered by the order (orphan / later release scope) |
| `ORD-004` | 1.0 | info | checker | Shipping length vs cut length (explained by end plates or not) |
| `MRK-001` | 1.0 | warning | checker | Different marks with identical fabrication content (or mirror pair) |
| `MRK-002` | 1.0 | error | checker | Same piece mark used for non-identical members |
| `MRK-003` | 1.0 | warning | checker | Drawing callout references a mark that is not in the sheet's BOM |
| `MRK-004` | 1.0 | info | checker | Assembly mark and piece mark share the same string (namespace collision) |
| `PP-001` | 1.0 | error | checker | Bracket referenced in a BOM has no bracket/piece drawing in the package |
| `PP-002` | 1.0 | error | checker | Bracket sub-part listed in BOM has no piece drawing |
| `PP-003` | 1.0 | warning | checker | Piece part / plate group is not referenced by any assembly (orphan) |
| `PP-004` | 1.0 | info | checker | Plate-table item numbers repeat |
| `INST-001` | 1.0 | error | checker | Member instances have no location (no erection information) |
| `CONN-001` | 1.0 | error | engineer | Connection has no approved detail reference |
| `CONN-002` | 1.0 | error | checker | Mating hole patterns do not agree (or cannot be verified) |
| `CONN-003` | 1.0 | warning | checker | No weld or fastener specification found for welded/bolted parts |

Rule ids and issue ids are stable across runs (issue id = hash of rule id + project + subject key), so dispositions survive re-checks; a rule version bump is the mechanism for changing what a rule means.
