# MASTER BUILD PROMPT
## Metal Building Detailing, Layout, Shop Drawings & Material Planning Software

**Requirements consolidated:** October 5, 2026  
**Purpose:** A standalone specification for rebuilding the software from scratch, preserving confirmed requirements and completing unfinished work.  
**How to use:** Give the entire document to the development agent/team. Supply the original reference PDFs and any saved project JSON separately when available. The prompt does not require access to the earlier conversation.

---

# BEGIN PROMPT

You are the lead software architect, computational-geometry developer, fabrication-detailing developer, and QA lead for a Windows-first metal-building detailing application. Build a real, reusable application—not a demonstration for one building and not merely a proposal. Work incrementally, deliver running software, and verify the complete user workflow.

Use the following requirements as the controlling product specification. Retain confirmed alternatives instead of replacing earlier options with the latest option. Treat genuinely missing manufacturing information as specific, visible holds, not permission to invent dimensions. Do not repeatedly ask the owner to reconfirm decisions recorded here.

## 1. Product objective and boundaries

Create a deterministic, local-first application for configuring metal buildings and generating coordinated:

- Building plans, elevations, sections, member layouts, and connection details.
- Mainframes, separate endwall framing, lean-tos, roof purlins, wall girts, openings, panels, and trim.
- Member cut schedules, long-blank requirements, plate/clip drawings, hole schedules, and assembly BOMs.
- PDF review/shop sets, dimensioned DXF drawings, appropriately qualified 1:1 part DXFs, SVG previews, CSV/JSON data, and XLSX/PDF material orders.
- Linear-stock cutting plans and reference plate layouts for a 30 × 30 inch plasma table.
- Traceable checks, unresolved issues, revisions, and source references.

The application is a **detailing and coordination tool**, not an automatic structural engineer. Do not infer capacities, certify load resistance, design foundations, invent connection adequacy, or substitute members because a preset exists. Store the applicable engineering basis and approved member/connection references where supplied. Missing engineering information must not prevent ordinary layout and clearly labeled review work; it must prevent unsupported release claims.

**No automatic fabrication or machine release.** Do not output machine-ready G-code or NC1 merely because the geometric model renders successfully.

### Requirement labels

- **CONFIRMED:** Owner requirement; implement as stated.
- **PENDING:** Required capability not finished in the prior application; implement and test, do not relabel it as a missing owner decision.
- **DEFERRED:** Still part of the eventual product, but explicitly outside the first welded-focused milestone.
- **RECOMMENDED:** Workflow or software-quality enhancement added in this specification. It is not a newly approved physical building detail.
- **UNKNOWN:** Specific missing job, source, manufacturing, or machine information. Preserve a null/unknown state and identify exactly what it blocks.

A feature may be confirmed in intent while pending in implementation.

## 2. Non-negotiable behavior

1. Preserve original uploads and saved jobs. Never overwrite source PDFs or silently normalize their marks.
2. Keep distinct source projects distinct. Similar-looking details from different jobs are not automatically interchangeable.
3. Every derived dimension, quantity, and drawing must come from the same authoritative model—not independent spreadsheet arithmetic or separate drawing-only geometry.
4. Preserve selected sections when detecting conflicts. Never silently replace a channel with a W section, change a gauge, resize an opening, move a post, or relax clearance.
5. Editing is transactional: invalid changes do not partially alter the saved model or dependent exports.
6. Store exact internal dimensions; round only for declared display, stock-planning, or output policies. No accumulating rounding drift.
7. Separate nominal depth, actual outside depth, inside clear dimensions, centerlines, faces, physical cut lengths, long blanks, assembly lengths, and shipping lengths.
8. A missing feature must be labeled **Not implemented**, not **Needs engineering approval**. A missing material property must not be disguised as zero.
9. Scope every quantity: individual physical instance, assembly lot, building total, purchased stock, or source-document quantity. Never multiply a building-total secondary count again by frame count.
10. Do not make a global clearance or clip rule override a more specific applicable manufacturer or joint rule.
11. All assumptions, overrides, and source conflicts must be visible, searchable, and exportable.
12. Deliver accurate scope notes. A schematic endwall is not a completed endwall fabrication adapter.

## 3. Platform and architecture

### Required deployment

- Windows-first installation and launcher; browser UI served locally, with optional LAN access.
- Usable without a cloud account or continuous Internet access after installation.
- Intentional **New job**, **Open job**, and **Resume last job** choices. Do not silently load an old demonstration as the user's new building.
- Human-readable, versioned project data; import/export of saved JSON.
- A documented backup and upgrade path that preserves all job data.
- Clear startup errors, port-conflict handling, logs, and shutdown instructions.

### Recommended implementation organization

Choose and document a maintainable stack. Python geometry/export services plus a typed browser frontend are a reasonable default, but framework choice must not dominate the work.

Separate modules for:

1. Units, dimensions, coordinate systems, and geometric primitives.
2. Versioned project schema and migrations.
3. Section/catalog/source libraries.
4. Building datums, grids, and frame instances.
5. Mainframe and endwall member geometry.
6. Connection families and explicit compatibility adapters.
7. Lean-tos.
8. Purlins, girts, clips, and support topology.
9. Openings and shared bearing jambs.
10. Panels, trim, and roof/wall surfaces.
11. Validation and issue/disposition management.
12. Fabrication derivation, BOMs, purchasing, and stock planning.
13. Drawing/export services.
14. UI/API, deployment, and QA.

Use one typed member/section interface. A rafter-capable resolver must support its allowed W, channel, or Cee types without passing valid rafters to a W-only column validator. Section support and connection support are separate compatibility questions.

**RECOMMENDED:** A dependency graph should regenerate only affected geometry while maintaining deterministic final results. Store schema version, calculation/rule version, source-library hashes, and export revision in the project/export manifest. The same inputs and pinned libraries must produce equivalent geometry and stable marks; normalize volatile metadata when testing deterministic files.

## 4. Project model and units

Use stable internal IDs distinct from visible marks. Suggested entities:

- Project, revision, source document, source detail, material/section, building surface.
- Datum plane, gridline, support station, physical member instance, assembly definition/lot.
- Connection, interface, plate, clip, hole group, weld callout.
- Opening, opening boundary, support role, girt/purlin run, panel strip, trim run.
- Cut demand, purchased stock, stock assignment, export package, issue, disposition.

A physical member can have multiple roles—for example **endwall roof post + roll-up jamb + girt receiver**—but is still one member and is counted once.

Each physical instance needs a location and orientation. An assembly definition may be reused only when fabrication content is genuinely identical. Changing one physical member must not silently change all members sharing its previous mark.

### Dimension entry

- Accept feet/inches, decimals, and fractions such as `20'`, `12' 3-1/2"`, `3/16`, and signed offsets.
- Always show the interpreted unit and value before applying an ambiguous input.
- Label horizontal distance, vertical distance, along-slope distance, and normal-to-member dimensions distinctly.
- Allow configurable display precision; retain unrounded calculations internally.
- Distinguish TOTAL joint clearance from clearance per end.
- Represent gauge, numeric thickness, grade, finish, bend radius, and weight provenance separately. Gauge alone does not authorize inventing thickness or section capacity.

## 5. Organized workflow and main interface

**CONFIRMED:** Keep **Width · Length · Eave height · Roof pitch · Roof shape** permanently visible across the top of the main editor, not buried only inside a frame wizard.

**RECOMMENDED workflow/navigation:**

1. **Project & references** — identity, units, revision, engineering/source records.
2. **Building & grids** — master dimensions, roof shape, frame lines, datums.
3. **Mainframes** — columns, rafters, knees, ridge, bases.
4. **Endwalls & openings** — explicit posts, bearing jambs, headers, doors/windows.
5. **Lean-tos** — attachments, supports, rafters, connections, roof continuity.
6. **Secondaries** — roof purlins, wall girts, eaves, clips, laps, adjustments.
7. **Panels & trim** — face coverage, colors, lengths, opening cutouts, trim profiles.
8. **Coordination & checks** — clash/fit review and unresolved issues.
9. **Shop details & cuts** — member and connection fabrication views.
10. **Materials & stock** — master order and stock allocation.
11. **Export & revisions** — review packages, controlled output, change report.

Maintain a model tree, a property inspector, and coordinated visual selection. Selecting a member in a view should identify its physical location, visible mark, roles, assembly group, section, source, and issues. A selected issue should highlight the affected geometry and relevant input.

The lean-to dialog contains only lean-to settings. Main-building, endwall, and opening settings belong in their own areas.

### Useful additions — recommended

- Undo/redo; autosave snapshots; recovery after abnormal shutdown.
- A preview of dependent changes before applying a major edit.
- Lockable user-controlled stations, levels, and section choices.
- Explicit **Edit this instance** versus **Edit all identical assemblies**.
- **Reset to preset** as an explicit action; never overwrite manual overrides on unrelated edits.
- Numeric editing plus drag handles with snapping and dimension feedback.
- Layer toggles for frame steel, secondaries, connections, cladding, dimensions, and holds.
- Search by mark, location, part type, source sheet, and issue ID.
- Visual distinctions between confirmed geometry, reference-only envelopes, and unknown dimensions.
- A read-only print/review mode and a clear indication of unsaved changes.

## 6. Coordinate conventions, faces, and labels

**CONFIRMED physical naming:** Left/right endwalls are the gable ends. Front/back sidewalls are the eave sides. Do not let historic internal `front`/`rear` strings confuse the displayed building orientation.

**RECOMMENDED new canonical convention:**

- X = building length, left endwall at X=0 and right endwall at X=L.
- Y = building width, back sidewall at Y=0 and front sidewall at Y=W.
- Z = elevation from the declared finished-floor datum.
- Plan views show the axis triad and four wall names.
- Every elevation states **Viewed from outside** or **Viewed from inside** and shows its local horizontal origin.

If importing legacy jobs, preserve their physical placement using explicit transforms:

| Legacy face key | Human-readable physical face | Outside-view horizontal origin |
|---|---|---|
| `front` / `front_end` | Left endwall | Back sidewall |
| `rear` / `rear_end` | Right endwall | Front sidewall |
| `right` | Front sidewall | Left endwall |
| `left` | Back sidewall | Right endwall |
| `roof_right` | Front roof slope | Left end toward right end |
| `roof_left` | Back roof slope | Left end toward right end |

Do not bulk-swap legacy face strings. Preserve opening and color locations through an explicit, tested migration. Opposite-end elevations reverse the observer's left/right; do not mirror a placement twice.

### Marks and drawing organization

**CONFIRMED:** Use `COL-1`, `COL-2`, etc. for column assembly marks. Retain existing rafter marks. Preserve source `BR`/`HBR` names; do not quietly rename or merge them.

**RECOMMENDED new-job labels:**

- Independent location IDs, e.g. `Frame F02 / Front sidewall`, not encoded only in a fabrication mark.
- Faces: `EW-L`, `EW-R`, `SW-F`, `SW-B`; roof slopes named explicitly.
- Openings: `DOOR-01`, `WALK-01`, `WIN-01`.
- Trim/profile and panel-run IDs separate from actual fabrication piece marks.
- Display shared member roles: `COL-7 — EW-L roll-up left jamb / roof-bearing post`.
- Suggested sheet groups: `G` general/datum, `E` erection/layout, `F` frames, `EW` endwalls/openings, `LT` lean-tos, `S` secondaries, `C` connections, `P` plate parts, `CL` cladding/trim, `M` materials.

Do not change imported marks to fit a new naming scheme. Keep an alias/location layer and a mark-conflict report. Do not reuse a released mark for changed fabrication content without an explicit revision/variant policy.

## 7. Building dimensions, bays, and section presets

Support gable and monoslope buildings.

- Master building length controls frame stations, secondary runs, and cladding extents. No competing hidden length fields.
- Provide equal-bay count mode and automatic mode from a maximum planning spacing: `count = ceil(length / maximum)` and `spacing = length / count`.
- Support explicit unequal bay widths and editable frame stations. Their sum must equal the unchanged master length.
- Maximum planning spacing is not a structural capacity assertion.
- Support odd bay counts. Never force a post at the ridge or force an even number of bays.
- Show end-frame offsets and support face/centerline datums explicitly; do not permanently assume zero end offset.
- For monoslope: high eave = low eave + width × pitch/12, using consistent defined roof datums.
- Separate finished floor, slab, base-plate underside/top, embedded weld-plate top, column end, roof framing top, and finished roof surface.
- Label legacy eave conventions: bolted top-of-eave-strut and welded top-of-purlin/roof-framing as applicable. A mode switch must reveal the resulting datum change rather than silently moving the roof.

Optional owner width presets, **not engineered sizing**:

| Exact width | Main column/rafter default |
|---|---|
| 20 ft | W8×10 |
| 30 ft | W10×12 |
| 40 ft | W12×14 |
| 50 ft | W12×19 |

Provide independent manual column and rafter overrides. Do not interpolate unspecified widths. End-frame default W8×10 through 40 ft and W10×12 above 40 ft, with independent overrides. Reduced/bearing endwall selections must not change the interior frame selection.

Endwall post choices include applicable 6–8 inch wide-flange sections, matching Cee options, HSS 4×4 through 4×8 and rectangular 2×4 through 2×8, with listed 14 gauge through 1/4 inch choices only where actual records support them. Treat the requested 20 ft bearing-post planning maximum as a layout check, not capacity approval.

## 8. Section and manufacturer libraries

Support W sections, lipped Cees, Zees, genuine unlipped/open channels, HSS/tube, angles, plates, and eave-strut references. Preserve actual orientation and attachment faces.

Source records must include supplier/source, edition or revision, page/detail identifier, exact designation, nominal class, actual known dimensions, finish, gauge/thickness state, available lengths, published weight, and unknown fields.

### Actual MBCI unlipped channels

Reference: `https://www.mbci.com/products/channels/`

Recorded product envelopes:

- 4-1/8 × 2 inch: 16 and 14 gauge.
- 6-1/8 × 2, 8-1/8 × 2, and 10-1/8 × 2 inch: 16, 14, and 12 gauge.
- Listed stock lengths: 20 and 25 ft.
- Recorded girths by ascending depth: 7-15/16, 9-15/16, 11-15/16, 13-15/16 inches.
- Example 6-1/8 × 2, 14 gauge red-oxide weight: 46.63 lb per 20 ft, or 2.3315 lb/ft. Keep finish-specific weights distinct.

Reverify source records when importing the catalog; pin their revision. These are not 6/8 inch lipped Cees with the lips graphically erased. Do not invent flange/web thickness, radius, steel grade, or section capacity from the available envelope/weight data.

Selecting a valid channel as an end or primary rafter must not produce the old error: **“Column/post reference must be W; channel option is for rafters.”** Apply validators to the actual member role. Preserve appropriate restrictions on genuinely W-only options.

### Secondary catalog and eave choices

- Support actual MBCI C/Z and applicable eave records with gauge/finish-specific availability.
- Optional eave C/Z purlin in the 4–8 inch range instead of an eave strut.
- Include the owner's 6 inch eave-strut option. If no verified supplier geometry is available, label it **User nominal 6 inch reference**, not a resized verified 8 inch product.
- Unsupported catalog finish/gauge combinations remain invalid; no automatic substitution.
- A catalog change requires explicit migration/review, not hidden geometry changes to an old job.

## 9. Mainframe connections: welded and bolted

Build reusable connection families with explicit compatibility for mainframes, separate end frames, and lean low ends. Unsupported combinations must be stated precisely, with the rest of the model still usable for review.

### A. Retained outside-seat welded knee

- Rafter is plumb-cut at the column outside edge, on the pitch-cut column.
- No bolted knee bracket in this option.
- The relevant top/eave clip is plumb.
- Compute the actual pitched/plumb rafter depth; include the correction in the column cut-height deduction instead of accepting steel overlap.
- Retain the 3/16 inch cover-plate option with top flush and default 3 inch extension below the actual plumb rafter underside; show its controlling datums.
- Report the column long blank separately from short/low-point dimensions and base/floor deductions.

### B. Optional inside-flange welded knee

- Rafter terminates at the inside column flange.
- Top plate: 3/16 inch thick, width equal to rafter width, bearing over the pitch-cut column and extending 3 inches inward **along the roof pitch** over the rafter.
- Outermost plate material edge is flush with the outside column face, including plate thickness and square-edge geometry.
- No invented bevel or hidden outside overhang.
- Column top meets the bearing-plate underside; do not apply the outside-seat full-rafter-depth deduction here.
- Preserve the roof datum and check local plate/weld/secondary interference.

Reference geometric construction for positive inward-rising local slope:

`theta = atan(pitch/12)`; `t = 3/16`; `cd = actual horizontal column depth`.

`inset = max(0, t*sin(theta))`  
`bearing_along_slope = (cd - inset)/cos(theta)`  
`plate_length = bearing_along_slope + 3 inches`

The bottom bearing begins at `(inset, inset*tan(theta))`; the upper surface offsets by `(-t*sin(theta), t*cos(theta))`. Use signed local transforms for other roof directions. Test actual contact and the outermost edge at both gable/mono/lean ends; do not blindly reuse unsigned formulas.

### C. Welded ridge alternatives

- Option A: shared 1/2 inch ridge plate.
- Option B: bolt-free apex box with 1/2 inch rafter end plates.
- Ridge plate length = actual pitch-cut rafter depth + 1 inch, split 1/2 inch above and 1/2 inch below the actual cut.
- For a symmetric plumb ridge, actual cut depth is section depth / cos(theta).
- Do not substitute nominal depth for cut depth or invent bolt holes in welded-only details.

### D. Bolted mainframe families

Retain bolted mainframe options; new bolted lean/punching development is deferred to a later milestone.

- Single-web bracket construction, not a closed double-sided box.
- Bracket width follows column flange width; body height/depth follows the rafter; top follows roof pitch.
- Column-side weld and rafter-side mating bolts are distinct interfaces.
- Preserve HBR10E1 low-eave and HBR10HE1 high-eave source identities and applicable BR variants.
- Apex mirrors high-eave geometry into one continuous web with mating plates at both ends.
- BOT length follows actual column depth plus mating-plate thickness unless manually overridden.
- K plate atop BOT, outward face flush; MATE outside; BACK atop BOT. Show interfaces, not merely overlapping rectangles.
- Tight-fit default, optional explicit overhang, no silently invented bevel; retain the owner's 1/4 inch fillet-weld rule where applicable and show the scope of the callout.
- Bolted column height starts from floor-to-top-strut and explicitly deducts selected 6/8 inch strut, bracket/base, and floor terms as applicable.
- Keep B/K/R member/connection reference labels in applicable details; define them visibly rather than silently changing their meaning.
- Anchor reference: 2-1/2 inches inward from the outside flange where this owner rule applies; do not invent bolt diameter, embedment, or foundation adequacy.
- Apex underside follows the rafters. Horizontal half-length must be positive; 6 inches is a default, not a minimum.
- Peak-edge distance defaults to 11 inches measured along slope and is editable. Warn when a clip is within 3 inches of mating/overlap geometry; do not automatically relocate it.

Source-specific bolt/hole/weld unknowns remain explicit. A resized plate envelope does not establish a verified new bolt pattern.

## 10. Base and floor-weld options

- Conventional base-plate mode with explicit plate dimensions, thickness, elevations, and source-controlled holes.
- **Floor-weld mode:** no separate column base plate; column welds to an existing floor/embedded steel weld plate.
- Input is **TOP of embedded/floor weld plate**, not “weld to concrete slab.”
- Apply the same base rules to main columns, supported endwall posts, and lean columns.
- Do not silently design, add, or quantity embedded plates/anchors unless they are explicitly in project scope.
- Show every cut-height deduction and datum on review details.

## 11. Endwalls and roof-bearing opening jambs — highest unfinished priority

Separate endwall geometry must be real model geometry, not a schematic cladding aperture.

Required controls:

- Independently select left/right endwall post sections, positions, roles, orientations, and end rafters.
- Edit exact post stations without requiring equal bays or a ridge post.
- Keep building width fixed when moving an interior endwall post.
- Provide independent end-rafter flush/bypass settings, separate from interior rafters.
- Display posts, jambs, headers, girts, clips, end rafters, and roof support relationships in end elevations and fabrication details.
- Implement final endwall knee/ridge/post-head adapters, plate geometry, cuts, and quantities—not indefinitely reference-only lengths.

### Shared structural jamb/post role

The owner requires open-channel roll-up jambs that support the roof and receive wall girts directly.

- Model the jamb as one physical member with multiple roles.
- Connect roof support and girt endpoints directly to the selected member faces.
- Do not create a duplicate ordinary jamb next to an obstructing generic roof post.
- Extend the bearing jamb to the required roof support; the door header at opening-head elevation does not terminate the roof-bearing post.
- Resolve post-head/rafter contact, orientation, clips/direct welds, base, and cuts through the same connection engine used elsewhere.
- When roles are shared, BOMs, stock demands, labels, and drawing references must count the physical member once.
- Distinguish shared opening boundaries from unrelated uprights in the clearance validator.

**RECOMMENDED:** Offer an explicit “Use this post as opening jamb” action and a reviewed “Propose post layout around opening” action. Show before/after dimensions; never silently move existing posts.

## 12. Openings, headers, jambs, and clearance

- Door/window dimensions mean actual **clear inside-face dimensions**.
- Width is between opening-side jamb faces. Height is sill/floor to the opening-side header face.
- Frame, clip, trim, and panel-cut allowances are outside these entered clear dimensions.
- Provide roll-up doors, walk doors, windows, custom openings, and visible sill/head elevations.

### Ordinary framed openings

- Header is an inverted Cee, matching the applicable wall-girt nominal size—not a Zee solely because the girts are Zees.
- Ordinary header flange/leg orientation is **UP**.
- Standard jambs are matching vertical Cees, with explicit exceptions for the owner's structural open-channel bearing jambs.
- Support both lipped Cee and actual unlipped-channel choices for **both header and jamb**. “Open/unlipped” is a profile choice, not merely rotation.
- Jamb top attachment options: underside of eave strut/purlin; underside of rafter (standard); or a bay-spanning header carrying the jambs.
- Bolted attachment uses applicable clips. Welded attachment allows direct member connection according to the selected rule.

### Walk-door header-only mode

- Separate option with no jamb members.
- Header/girt legs **DOWN**.
- If a Zee is used in this specific mode, outside flange down and inside flange up.
- Do not confuse this option with the ordinary Cee-header-up rule.

### Placement and collisions

- Default ordinary roll-up placement may start centered within its selected bay; allow movement within that bay.
- Owner's actual building is an explicit whole-endwall-centered opening, not locked to a default bay; coordinate the supporting jamb/posts accordingly.
- Preserve at least 6 inches between opening clear edges and **unrelated** upright edges, plus actual framing-envelope checks.
- Do not apply that unrelated-post clearance against the opening's own shared bearing jamb.
- Never silently cut, remove, or move an unrelated upright to accommodate an opening.
- Check header/jamb/clip envelopes, roof clearance, girt termination, trim, and panel cutouts against the same opening geometry.
- Ordinary panel cutouts must not be falsely reported as completed opening framing.

## 13. Secondaries, clips, laps, and movable girts

### Roof framing and datums

- Purlins may bypass rafters or fit flush/inset, as selected.
- End rafters can be flush/inset while the interior frame is bypass.
- Main-column bypass inset follows **wall-girt depth**, not roof-purlin depth or a flange guess. Keep wall planes and roof pitch fixed.
- Bypass starting clips are column-owned where applicable; flush clips are rafter-web-owned. Do not count a clip as an extra C/Z member.
- First purlin station is measured along slope from outside column reference minus the specified setback. Default owner spacing/station input is 4 ft 10 in, editable and explicitly labeled.
- Optional equalized roof layout from eave station 0 to peak, with maximum 5 ft spacing.
- Retain applicable hole stations 2, 5-1/2, L−5-1/2, L−2 inches and 1-1/2 inch side offsets where the owner's specific pattern applies; hole diameter remains held unless established. Do not apply this as a universal manufacturer pattern.

### Flush-run lengths

- Use actual support/interface planes and correct member orientations.
- Owner baseline where applicable: centerline span minus half of each receiving web thickness minus **1/8 inch TOTAL** clearance.
- Support independently specified end/intermediate clearances.
- Do not subtract 1/8 inch at both ends when the rule is total.
- Unknown web thickness or receiving face must block an exact final cut, not be silently treated as zero.

### Girts and base angle

- Sidewall starting elevation defaults to 0 and is adjustable.
- A lowest girt at slab level becomes a 2 × 4 inch angle: 2 inch leg vertical, 4 inch leg on slab.
- Roof-eave members remain separate from wall base/girt logic.
- Support continuous, segmented, and opening-interrupted girt runs according to actual support topology.
- Girts terminate/attach to bearing jambs directly where specified.
- Show girt levels and lengths in wall views and shop schedules.

### Welded clips

Solid 3/16 inch plates, no invented bolt holes:

| Supported member nominal depth | Plate envelope |
|---|---|
| 4 in | 3 × 3 in |
| 6 in | 3 × 5 in |
| 8 in | 5 × 7 in |

Resolve plate orientation visibly. Intermediate-size rules are not supplied; do not interpolate them as approved fabrication details. Eave clip size follows the eave member independently of ordinary roof purlin size.

### Girt clip adjustment

- Support exact station or signed-offset edits with bounds, collision, edge-distance, and connection checks.
- Regenerate offsets from original reference levels; repeated saves must not accumulate movement.
- Offer explicit lot-wide and per-physical-instance scope. A per-instance change creates a fabrication variant when necessary.
- Propagate the change to physical girts, endpoint elevations, drawings, cuts, BOMs, and stock demand.
- If unequal endpoint heights create an unsupported slope/twist/interface, report it rather than drawing a falsely horizontal member.
- The old implementation moved all copies of one column lot and did not move independent endwall girts; complete those missing capabilities.

### Actual bolted clip routing and punching

- Bypass: outside-column clip where applicable.
- Flush: no exterior bypass clips; inward-facing web clips at ends, both relevant sides at intermediate columns.
- Model endwall W-column rotation of 90 degrees; route attachment by actual flange/web orientation.
- HSS attachment is flange/face-style, not an invented HSS web connection.
- PC8D is an 8 inch girt flange-mounted clip; CLF12 is the relevant endwall corner clip where the web is parallel to the girt.
- Source examples: PC8D 3/16 × 6 × 7 inches; CLF12 3/16 × 6 × 11 inches, with source-specific 4 × 4 inch hole spacing and 9/16 inch holes. Preserve source offsets and applicability.
- Resize 4–8 inch bolted clips using actual punching—not uniform geometric scaling. New bolted punching development is deferred to the later milestone.

### MBCI punching source

`https://www.mbci.com/wp-content/uploads/Widen%20Assets/ManualsCI-Manual.pdf`

Recorded edition: actual PDF page 19, printed CI-19, REV 00.02, “PUNCHING PATTERNS FOR CEES AND ZEES.” Verify diagrams against the actual supplied edition.

- Recorded 6 inch web pattern: 1–4–1 inches.
- 8 inch: 2–4–2; 10 inch: 3–4–3.
- Recorded pattern G common-end reference: 1-3/4 inches; apply only to that pattern.
- Manufacturer notes: 5/8 inch holes; 5/8 × 3/4 inch slots; flange punching D uses web A and E uses web B; no flange punching for 4 inch or smaller in that source.
- These secondary-member hole sizes differ from the shop clip's 9/16 inch holes. Preserve the conflict/distinction; do not overwrite both with one “standard.”

Use verified MBCI lap conditions for run counts, lengths, details, and hole placement. Do not fabricate unsupported lap patterns. Eave-secondary exact cut lengths remain held until the applicable source/interface geometry is actually resolved.

## 14. Lean-tos

Support attachment to all four building faces, with corresponding geometry and compatibility checks—not merely a renamed sidewall case.

- Controls for attachment face, start/end extent, horizontal projection, frame alignment, support stations, low eave height, pitch, high datum, and roof overhang with measurement direction.
- Main frame/grid geometry remains visible with the lean attached.
- Permit explicit alignment of lean uprights with main frame lines.
- Support appropriate W/Cee rafter choices, single end members and paired intermediate Cees with touching webs, plus HSS/W columns. Unknown paired-member stitch/connection details remain explicit.
- Lean low knees and bases reuse the same mainframe connection/base rules in welded and applicable bolted configurations.
- Do not require another source drawing merely to implement the confirmed shared-rule behavior.

### Welded high attachment

- Stop the rafter 1-1/2 inches from the main-column attachment face, measured **along the rafter**.
- Clip bridges that gap and overlaps another 6 inches into the rafter web.
- Gap and overlap are distinct; this replaces the old blanket 6 inch horizontal rule for the new option.
- Clip: 1/2 inch thick; height = nominal rafter depth minus 2 inches; centered on web; pitched edges; owner default 1/4 inch weld, editable and scoped.
- Check actual main-column inset/attachment face, rafter end plane, clip contact, weld access, and collisions.

### Lean cuts and roof continuity

- Derive cuts and long blanks from actual high/low connection planes, member depth, plate thickness, and base/floor datums.
- Show top-line, short/long edge, and cut-angle information independently.
- A manually entered high roof elevation that disagrees with the selected main-plane continuation causes a visible conflict, not silent movement of the low support.
- Main-plane continuation must use the actual roof datum, not only nominal column heights.
- Support the owner's full-length gable-side continuous roof as an early priority.
- Eventually complete partial-length transitions, end-attached lean conditions, and applicable monoslope high-side continuation; mark unsupported combinations until actually implemented.
- Complete lean secondary layout, bracing representation, outer/endwall panels, openings, trim, and material quantities. Bracing capacity/design must come from supplied design rules, not invention.
- If main wall is open beneath a lean, retain the required wall above the lean and show transition/flashing geometry.

### Deferred bolted high lean family

- BR10LN connector: requested 12 inch length × rafter size. Reconcile actual source variants, plate thicknesses, holes, and attachment orientation.
- Do not equate BR10LN2 and BR10LN3 or silently rename them.
- High bypass/end plate envelope: 1/2 inch thick, width/height follow rafter. Optional width rounding UP to next whole inch; do not silently round height or invent holes.
- Source SP2 uses four A325 5/8 × 2 inch bolts; make applicable selections explicit. SP1 and other details are not interchangeable.
- Implementation remains deferred until after the welded and urgent endwall/opening milestone.

## 15. Panels, roof sheets, and trim

### Panels

- PBR panels with editable colors per physical face, panel coverage/counts, and visible seams.
- Wall panels vertical; roof panels measured along the roof slope.
- Model actual profile/coverage records and explicit installation allowances.
- Default to single-piece strips/runs where specified. Do not automatically splice oversized sheets.
- Editable roof/eave/ridge/end boundaries, cutback, overhang, and opening allowances.
- Identify supplier-length conflicts and proposed splices as unresolved choices.
- Coordinate panel cutouts with clear-opening framing and trim offsets.
- Preserve face-specific colors and physical placement during imports/mirroring.
- Show panels and trim on every applicable sheeted view, including lean surfaces.

### Continuous main-to-lean roofing

For the owner's full-length side lean, continuous sheets run from main ridge through the lean to the lean eave. The lean's 8 inch along-slope overhang replaces the main-eave extension on that continuous side—it is not added a second time. Use explicit ridge cutback and end overhangs.

### Trim and supports

- Show the selected actual formed trim profile and color on sheeted views; do not use only symbolic lines.
- Trim is field-fabricated from 26 gauge material for the owner's requested work.
- Provide formed-profile/reference drawings and net material quantities without pretending exact brake-developed blanks are known.
- Exact developed blanks require actual thickness, bend radii, bend allowance/deduction, hems, returns, and material data.
- General owner endwall rake support rule: 2 inch top × 4 inch down, at every sheeted main/lean endwall. It supports top sheet screws; base angle supports bottom screws.
- **Actual first job exception:** flat residential rake trim with 4 inch face at both ends. Do not call the commercial 2-top/4-down trim a verified residential profile. Top leg/hem/returns/development remain unknown.
- Model structural rake support and decorative/weather trim separately when they are different physical parts; do not duplicate them if one verified part fulfills both roles.
- Show ridge, rake, eave, base, corner, jamb/head, transition, and gutter trim as applicable, with source/custom profile labels.
- Short trim runs: exact lengths. Long trim runs: maximum 20 ft 6 in segments with explicit overlap and exact remainder. This is an owner purchasing policy, not a manufacturer SKU claim.
- Gutter size, outlets, downspouts, and drainage capacity are not established. Provide explicit inputs without inventing them.

## 16. Reference-source handling

Preserve source project identities, revision, sheet IDs, PDF page indices, quantities, and marks. Record when a detail is owner-derived versus manufacturer-derived versus copied from a specific shop source.

Expected source set, if supplied:

1. `Erection Dwgs.pdf` — recorded 30-page job 1277345, revision C, 8/17/23.
2. Separate erection set for job 1273522; do not merge it with job 1277345.
3. `1st Release Clark Jordan 1277345 -Main Bldg. Shop Dwgs.pdf` — recorded 26 pages.
4. `Clark Jordan 1277345 - Shop Dwgs Copy.pdf` — recorded 11 pages, includes HBR10E1/HBR10HE1 and related plates.
5. MBCI CI manual and channel catalog referenced above.

Recorded reference distinctions to preserve and recheck against actual files:

- Job 1277345 erection R5/PDF7: LR-1/LR-3 W10×15 and LC-2 W10×15; R6/PDF8 includes LR-2/HSS conditions. Erection lengths are not automatically bare cuts.
- D2/PDF22 SD52 is a simple-span girt detail; SD77 base angle; SD85A/B mezzanine details are not ground-floor substitutes.
- D3/PDF23 SD85C is a ground jamb-base detail; SD87 GC-8 reference dimension says “Varies.”
- D4/PDF24 SD95 JH-8 header/jamb 1/4 inch gap is a different condition from SD87's variable reference dimension.
- D8/PDF28 TD51/52 opening trims; D9/PDF29 TD250 formed paired closures are not verified flat developments.
- D10/PDF30 upper-right T4 free high-eave condition differs from lower-left penetration detail.
- Other erection job: SD10 PDF12/D1 and TD35 PDF18/D7; CL100/103/J100 are not automatic replacements for GC-8/JH-8.
- Main shop PDF2/RF1-5 contains PC8D/CLF12 and labels BR10LN3, not BR10LN2.
- BR10LN2 occurs on RF1-7/PDF9, RF1-8/PDF10, and EC-2/PDF26.
- RF-500 example: bare cut 13 ft 3-11/16 in, assembly 13 ft 5-15/16 in, shipping 14 ft 3-1/4 in. Keep these different dimension types distinct.

If source files are absent, record them as unavailable. Do not claim visual verification, recreate missing source dimensions from memory, or block unrelated editor development while waiting for them.

**RECOMMENDED:** Reference import/indexing and drawing/BOM comparison should flag identity, mark, quantity, length, weight, and mating-pattern discrepancies. Do not promise reliable automatic extraction of every PDF detail; preserve human verification and source overlays.

## 17. Exact first-job acceptance fixture

Create a clearly labeled **Owner first-job configuration — unresolved fields retained**. This is a test fixture from known requirements, not the owner's actual saved project unless that JSON is supplied.

### Main building

- 20 ft wide × 30 ft long × 12 ft eave.
- Gable roof, 1:12 pitch.
- Frame lines at 0, 15, and 30 ft.
- Main columns: W6×9. Center/interior rafter: W6×9.
- Owner manual selections override the optional 20 ft width preset.
- End rafters: actual MBCI 6-1/8 × 2 inch unlipped channel, 14 gauge.
- Interior roof framing bypass; end roof framing flush/inset between channel flanges.
- Roof purlins nominal 6 inch, 14 gauge.
- Optional inside-flange welded knee selected, including end-frame implementation when completed.
- Floor-weld bases; top of embedded floor weld plates at finished-floor elevation. No separate base plate.

### Mandatory fit conflict

The requested 1/4 inch TOTAL fit clearance has not been resolved as depth versus end-length clearance. Even before flange thickness, 6 inch purlin + 1/4 inch vertical clearance = 6.25 inches, greater than the channel's 6.125 inch OUTSIDE depth.

Retain selected profiles, expose separate depth/end-fit controls, and show the conflict. Do not increase channel depth, reduce purlin size, fabricate inside dimensions, or lower the clearance without explicit input. The correct acceptance result can be a usable model with a truthful hold—not a falsely green project.

### Roll-up endwall

Looking from outside the designated roll-up end:

- 10 × 10 ft clear roll-up opening centered on the entire 20 ft wall.
- Clear horizontal aperture: 5 ft to 15 ft; head 10 ft above floor.
- 3 × 7 ft walk door centered in the remaining left 5 ft strip.
- Provisional clear horizontal walk aperture: 1 ft to 4 ft, before external frame/trim-envelope checks.
- Roll-up jambs: nominal 6 inch OPEN CHANNEL, roof-bearing, directly receiving wall girts.
- Header: nominal 6 inch Cee, distinct from the open-channel bearing jambs.
- Jamb/header exact section/gauge/finish/orientation beyond these facts must be supplied or marked unknown. Do not assume the end-rafter catalog selection automatically applies to them.

### Opposite endwall

- One 3 × 7 ft walk door physically aligned down the building with the first walk door.
- From outside the opposite end it appears on the right: provisional clear aperture 16 ft to 19 ft.
- Test physical alignment in plan and opposite outside-elevation mirroring.

### Lean-to

- Full 30 ft length along a sidewall; 18 ft horizontal projection.
- Supports aligned to 0, 15, 30 ft where applicable.
- Same 1:12 roof plane; continuous roof sheets from main ridge to lean eave.
- 8 inch overhang measured along roof slope.
- Lean columns: 4 × 4 tube **only for the lean**. Wall thickness is unknown; do not assume 1/4 inch from a demonstration.
- Lean rafter selection and exact attachment face remain unknown unless supplied.
- If the 18 ft projection starts at the main outside-wall eave datum, theoretical roof datum at lean support is 10 ft 6 in. This is not a column/rafter cut dimension; actual cuts include profiles and connection datums.
- Flat residential rake with 4 inch face at both ends; unprovided top leg/hem/returns remain unknown.

The attached side, detailed girt schedule, jamb/header gauge, tube wall, lean rafter, and manufacturing fit resolution should be taken from the owner's saved JSON if available. Otherwise ask only those targeted questions when needed. Do not substitute a large demonstration building for this fixture.

## 18. Fabrication derivation and drawing requirements

Every assembly/member sheet should show, as applicable:

- Job, revision, mark, physical locations/quantity, section, material/finish, status, and source references.
- Overall geometry and datum planes; actual orientation and handedness.
- Top/short/long edge lengths, long blank, cut angles, and end-condition dimensions.
- Actual contact planes, plate thicknesses, gaps, overlaps, weld callouts, and attachment faces.
- Hole diameters/slots, pattern references, edge distances, and orientation when established.
- Itemized BOM with quantities that reconcile to the model.
- Reference-only or unknown fields conspicuously labeled.

Required coordinated views:

- Building datum/orientation plan and full frame/grid plan.
- Mainframe elevation for each distinct configuration.
- Both endwall elevations with actual posts, doors, headers, girts, and rafters.
- Sidewalls with openings, girt levels, and lean interfaces.
- Lean overall and high/low connection details.
- Knee, ridge/apex, base, bearing-jamb head, girt/clip, and opening details.
- Roof purlin and wall girt layouts, spans/laps, clip stations.
- Panel elevations/roof layouts and trim profile/cut references.
- Member cut sheets, plate/clip part sheets, material summaries, and stock patterns.

**RECOMMENDED:** Add coordinated 3D/isometric inspection for fit and orientation, but never let an attractive 3D viewer substitute for numeric geometry or dimensioned shop details. Include exploded connection views, section cuts, print-legible lineweights, and label-collision avoidance.

All drawing annotations must use the same effective overhang, datum, and cut values as the model. Review and 1:1 cutting DXFs must be clearly different export types. Never mix annotation lines with a supposedly clean cut contour.

## 19. Master material order and stock planning

Top-level departments:

1. **Frame** — main/end/lean steel and applicable fabricated components.
2. **Secondaries** — purlins, girts, eaves, angles, relevant accessories.
3. **Sheets / Trim** — panels and formed/field-fabricated trim.

Provide XLSX and PDF plus machine-readable CSV/JSON. Suggested workbook tabs: Summary, Frame, Secondaries, Sheets-Trim, Plates-Clips, Hardware-Weld References, Cut Demands, Stock Patterns, Individual Stock Bars, Holds, Settings, Source Notes.

Owner defaults:

| Family | Stock lengths |
|---|---|
| W beams | 20, 30, 40, 50, 60 ft |
| C/Z purlins | 20, 25, 30 ft |
| HSS | 20, 24, 40 ft |
| Actual MBCI open channels | Source-listed 20, 25 ft |
| Trim | Exact short pieces; maximum 20 ft 6 in segments under owner policy |

- Support exact/custom orders by family or individual material.
- Separating-cut allowance: 1/4 inch. Additional stock-end allowance default zero, editable, explicitly applied at both ends.
- Separate profile, gauge/thickness, grade, finish, and purchasing unit in grouping keys.
- Use physical long blanks, not column low-point dimensions. Owner planning policy may round required blanks UP to 1/16 inch without changing theoretical geometry.
- Do not invent structural splices for oversized members; offer custom stock or a hold.
- Deterministic stock allocation; disclose heuristic status rather than claiming guaranteed optimum.
- Show purchased length, assigned marks, cuts/allowances, remnant, and waste per bar.
- Do not count held demand again as an additional order line.
- Reconcile instance quantities, assembly lots, endwall pieces, and physical secondary runs without duplication.
- Plates/clips counted by actual parts; raw-plate nesting is separate from linear stock planning.
- Unknown cut lengths or weights remain unknown, with qualified totals—not completed zero-weight rows.
- Separate bare cut, assembly, and shipping length throughout purchasing and reporting.

**RECOMMENDED:** Optional verified inventory/remnant library, supplier availability limits, prices, cost estimates, and pick lists. These must be opt-in inputs, not assumed inventory/pricing. Add QR/barcode member labels only as an optional workflow aid, not a replacement for readable marks.

## 20. Plasma layout and machine safeguards

Owner setup:

- Shop-built JD's Garage CNC plasma.
- OpenBuilds controller **software**.
- Manual torch height.
- 30 × 30 inch table capacity.
- User manually establishes machine 0,0.
- Firmware/post and torch command interface are not yet verified.

Required now:

- Reference layouts within 30 × 30 inches.
- Explicit table origin, part local origins, translations, and rotations.
- Part marks, thickness/material, bounding dimensions, quantity, and scale.
- Oversize detection; no automatic splitting/welding of large parts.
- Collision/edge/allowance checks using known settings.
- Distinguish **placement origin** from **pierce/lead-in point**.
- Distinguish the linear-stock 1/4 inch cut allowance from a plasma kerf or nesting gap; do not assume they are equal.

Before any future machine-ready export, require verified firmware/post, units, axis conventions, torch on/off behavior, feed/cut parameters, kerf, pierce/lead-in strategy, manual-height workflow, and machine validation. Do not assume GRBL solely from OpenBuilds software. No automatic sending of code to a machine.

Missing machine setup does not block ordinary PDF, dimensioned DXF, or reference layout work. Release-safe export directories must not include stale machine files from a prior run.

## 21. Validation, issue labels, and release workflow

**RECOMMENDED issue types:**

- `INPUT` — malformed/missing required input.
- `GEOMETRY` — clash, invalid contact, negative length, out-of-bounds position.
- `FIT` — clearance or interface mismatch.
- `SOURCE` — missing/conflicting catalog or detail information.
- `IMPLEMENTATION` — unsupported/unimplemented software adapter.
- `FABRICATION` — unresolved exact cut, hole, weld, grade, or manufacturing detail.
- `ENGINEERING` — missing design basis/approval where applicable.
- `MACHINE` — unknown or unvalidated controller/post/process.

Each issue includes stable ID, rule/version, severity, physical subject, explanation, measured versus required values, source, affected outputs, and an actionable next step.

Separate these status dimensions rather than using one misleading green check:

1. **Model validity** — inputs/geometry consistent?
2. **Detail completeness** — fabrication information complete?
3. **Engineering/design authorization** — required design basis supplied/approved?
4. **Human release state** — draft, reviewed, released, superseded?
5. **Machine compatibility** — separately verified?

A user's “acknowledge warning” action cannot fabricate missing geometry or turn a blocking error into a valid cut. Changing relevant geometry invalidates the affected review/disposition.

Required checks include:

- Grid sums/master dimensions and roof slopes.
- Unintended steel collisions, unsupported endpoints, and incorrect member orientation.
- Channel fit and mixed flush/bypass receiving faces.
- Opening clear faces, unrelated-upright clearance, roof/headroom, and shared-role duplication.
- Member/assembly/BOM/order quantity and cut-length reconciliation.
- Same mark used for nonidentical fabrication; missing referenced marks or source drawings.
- Mating-hole mismatch and unresolved bolt/slot diameters.
- Missing grades/weld/hardware specifications where needed for release.
- Unsupported source-detail combinations, catalog drift, and source revision conflicts.
- Stock oversize, panel-length conflicts, trim unresolved geometry, and table-fit limits.

**RECOMMENDED release workflow:** Draft → Model checked → Detail review → Authorized issue. Record reviewer, timestamp, revision, and scope. Releasing a review package is not the same as authorizing fabrication or machine operation.

## 22. Persistence, LAN access, and operational safeguards — recommended

- Atomic save and export; retain last known-good job on validation or disk-write failure.
- Schema validation, explicit migrations, migration preview, and rollback copies.
- Preserve original imported JSON and generate a migration report.
- Multi-tab/LAN edit version checks to prevent one browser silently overwriting another's work.
- Safe LAN mode with documented authentication/access settings; no unintended public exposure.
- Restrict file upload/extraction paths and prevent path traversal. Do not execute source-document content.
- Store export manifests and checksums with the exact model/rule/library versions.
- Export to a fresh revision folder or clean validated staging area, then publish atomically.
- A “diagnostic bundle” containing versions/logs/non-sensitive error context; require consent before including job/source files.
- Usability at normal shop-laptop screen sizes; keyboard-accessible numeric controls and high-contrast printable drawings.

## 23. Required acceptance and regression tests

Maintain a traceability matrix mapping each requirement to implementation, UI control, output, and tests. Test geometry numerically and inspect actual drawings; tests that only assert a file exists are insufficient.

At minimum:

1. Fresh launch starts an intentional new/open/resume workflow; demo data is never silently the user's job.
2. Exact unit/fraction input, signed offsets, and bay sums round-trip without drift.
3. Master length drives grids, secondaries, and panels together.
4. Gable and mono roof datums/cut planes are correct at both ends.
5. Presets never override explicitly chosen W6×9 owner members.
6. Channel primary-rafter override works through all preset/generation paths.
7. Channel end rafter with an opening on either endwall generates without the old W-only validator crash.
8. A genuinely unsupported column/connection combination still fails atomically with a useful explanation.
9. End flush and interior bypass coexist without changing each other.
10. Six inch purlin plus 1/4 inch vertical clearance in a 6-1/8 inch outside-depth channel remains a visible conflict.
11. Inside-flange plate has exactly 3 inches along-slope overlap and its outermost material edge is flush, for both gable ends, mono, and supported lean low ends.
12. Outside-seat column cut uses actual plumb rafter depth; no residual seat overlap.
13. Welded ridge plate extends exactly 1/2 inch beyond the actual cut at both ends.
14. Floor-weld removes separate base parts and uses embedded-plate top elevation correctly.
15. Bearing roll-up jambs are roof posts/girt receivers, are not duplicated, and receive correct head/base geometry and quantities.
16. Owner 10 × 10 roll-up is centered on the entire 20 ft end, not an arbitrary default bay.
17. Opposite 3 × 7 walk doors physically align; outside elevations show the second on the opposite apparent side.
18. Opening clear dimensions remain unchanged by member/trim thickness.
19. Shared jambs are exempt from unrelated-post clearance; unrelated posts still trigger checks.
20. Ordinary Cee header-up and header-only walk-door down/Zee orientation are separate tested modes.
21. Explicit post station edits preserve width, opening boundaries, stable IDs, and quantities.
22. Girt adjustments do not accumulate; instance-only edits do not silently alter all copies.
23. Correct flush/bypass clip sides and rotated W/HSS attachment routing are visible and tested.
24. Actual source punching is preserved; conflicting hole diameters are not silently unified.
25. Lean high attachment has 1-1/2 inch along-slope gap plus 6 inch overlap; cuts include actual support faces.
26. Lean 4×4 tube selection never replaces main W6×9 columns; unknown wall remains unknown.
27. Continuous roof counts one continuous strip per coverage run; 8 inch lean overhang is not double-added.
28. Residential 4 inch rake is not falsely replaced by commercial trim; unknown development blocks only dependent blank output.
29. Physical member, BOM, master order, and stock counts reconcile; shared-role members are counted once.
30. Long-blank versus low-point cuts drive the correct stock demand.
31. Save/reopen/regenerate is stable; migrations preserve physical face placement and old marks.
32. Invalid edits preserve the prior job, and validation errors survive into review outputs.
33. Review DXFs and cutting DXFs have distinct status/layers/units; clean contours are checked where emitted.
34. 30 × 30 layouts expose origins/rotations and reject oversize; no unverified machine code appears.
35. All drawings/schedules show matching revision and actual current geometry, not stale cached values.
36. Test packaged Windows launcher and at least two browser clients on LAN. Report honestly if native Windows testing has not occurred.

Add property-based geometry tests, mirrored-orientation cases, save/restore tests, browser interaction tests, source fixture tests, and deterministic export comparisons. Keep regression fixtures small and clearly distinct from actual customer projects.

## 24. Implementation sequence and unfinished-work priorities

Do not use the breadth of this specification as a reason to delay all useful delivery. Build vertical slices that include model, UI, drawings, quantities, persistence, and tests.

### Milestone 0 — foundation

Versioned schema, units, coordinates, source records, stable marks, job save/open/backup, main dimension bar, geometry/validation architecture, Windows/local launcher.

### Milestone 1 — mainframe and known welded rules

Main gable/mono frames, existing bolted mainframe baseline, both welded knees, ridge alternatives, floor-weld base, real channel selectors, independent end/interior roof modes, solid member-sized clips, and eave choices.

### Milestone 2 — urgent exact-job endwall/opening completion

Editable endwall posts; shared roof-bearing open-channel jambs; real header/girt connections; complete separate endwall knee/ridge/post-head adapters and cuts; opening modes; physical endwall views and coordinated quantities. Owner first-job fixture must be usable without W-only channel crashes or duplicate posts. Preserve the unresolved channel fit honestly.

### Milestone 3 — welded lean and complete envelope/takeoff

Actual high/low lean connections and cuts, continuous main-to-lean roof, lean secondaries/outer/endwall envelope, actual residential rake and all-view trim display, coordinated material counts.

### Milestone 4 — production workflow

Per-instance clip/girt variants, comprehensive shop sheets, stock plans, master order, source reconciliation, controlled exports, revisions, plate layouts, Windows/LAN verification, migration tests.

### Milestone 5 — deferred bolted expansion

BR10LN lean adapters, source-verified 4–8 inch bolted clip punching, paired-Cee connection details where unresolved, and broader lean compatibility. Do not let this delay the welded/endwall milestones.

### Milestone 6 — optional machine integration

Only after verified machine configuration and deliberate authorization. No promise of automatic G-code based on the current information.

The old narrow welded release deferred openings and trim; the owner subsequently explicitly required them for actual job entry. They are now required work, not permanently excluded scope. Bolted lean/new bolted punching remain intentionally later priority.

## 25. Additional useful capabilities to plan, not silently assume

These are recommendations, not approved construction details:

- A project completeness checklist for hardware, closures, sealants, fasteners, bracing, gutters/downspouts, insulation interfaces, penetrations, and shipping/handling limits. Mark unselected items “Not specified / not included,” not zero-complete.
- Distinct construction clearance, manufacturing tolerance, thermal/erection allowance, and display precision fields where relevant; do not invent numeric defaults beyond those supplied.
- Change-impact report listing altered members, cuts, plate contours, counts, purchased stock, and superseded sheets between revisions.
- A “why this dimension?” inspector showing the calculation chain and source/datums.
- Controlled reusable shop templates, with explicit scope and version, rather than hidden hard-coded special cases.
- Fabrication versus erection views and shipping labels, with no confusion between bare cut and assembly/shipping length.
- Optional supplier order formatting and remnant reuse, without unverified stock availability or prices.
- Performance benchmarks with declared representative job sizes; keep editing responsive without skipping validation.
- Documented recovery and support procedures so an upgrade or crash does not jeopardize active work.

Do not add automatic engineering optimization, member capacity selection, foundations, structural splices, or machine commands under the guise of a convenience feature.

## 26. Required deliverables and working instructions

At the outset:

1. Create a requirement/feature matrix with statuses: Not started, In progress, Implemented, Tested, Source-held, or Explicitly deferred.
2. Provide a concise architecture, schema, UI/navigation plan, and coordinate convention.
3. Identify only genuinely missing inputs that block the immediate slice. Do not restart a broad clarification round.
4. Start implementing the first vertical slice; do not stop after writing a plan.

For each milestone deliver:

- Complete source code and dependency/version information.
- Running local application and a Windows distribution/launcher.
- Tests with results and actual visual review evidence.
- User instructions, sample fixtures, and an honest scope/limitations document.
- Versioned schema and migration/backup instructions.
- Representative PDF/DXF/CSV/XLSX outputs with status labels and consistent quantities.
- Updated requirement traceability matrix and remaining-work list.
- Changelog identifying changed geometry rules and impacted saved jobs.

If porting from earlier software, inspect it for useful rules and data but do not preserve its architectural defects. The previous application reached a v0.8.8 review release, and a later two-file channel-validator hotfix passed 545 tests. That history is context, not proof that this new build works. Do not claim those tests validate new code.

**Completion means the actual specified editor workflows work from fresh job through saved model, coordinated drawings, accurate quantities, truthful holds, and packaged deployment. It does not mean every held fabrication or machine question has been magically resolved.**

Build faithfully, label clearly, preserve the owner's design choices, and make every unresolved item specific and actionable.

# END PROMPT
