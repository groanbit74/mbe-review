# Building Settings Console Revamp

## Decisions confirmed with the owner

- New or unset settings start **fully welded**. Bolted construction remains an explicit alternative, and a deliberate bolted choice persists when settings are reopened.
- No legacy-job migration/compatibility pass is required. The current standard supplies defaults; saved user choices are not reset each time the console is reopened.
- The Owner welded fit is a **rule**, not an opt-in checkbox. A nonstandard fit is an explicit override scoped per frame.
- Automatic roof and wall secondary generation is the default; users should not need to enable the standard workflow. Start with automatic equal building bays; a particular building bay length may be made nonstandard.
- New buildings start with the current width-based member table, editable after creation:
  - 20 ft: W8×10
  - 30 ft: W10×12
  - 40 ft: W12×14
  - 50 ft: W12×19
- Stock door placement asks for elevation and bay, centers in that bay by default, supports an offset or exact X, and previews placement before save.
- “Left/Right endwall support” fields are run-support assumptions; they do not generate endwall members.

## Implemented task-oriented steps

1. **Building & bays** — dimensions, roof shape, standard grid, editable individual bay lengths, enclosure.
2. **Main frames** — schedule-selected starting sections, editable sections, construction and frame-connection details.
3. **Roof & secondaries** — roof-slope purlin mode/setout, peak clip location, products, and automatic secondary runs. The UI distinguishes along-building bays from roof-slope purlin spacing.
4. **Endwalls** — endwall posts, rafters, girts, support assumptions, and endwall fit.
5. **Openings** — all door/window presets and records, elevation, bay, centered default, offset/exact X, dimensions, clearance, and live placement preview.
6. **Sheets & trim** — envelope products, colors, trim, and takeoff settings only.
7. **Review & save** — effective welded rule/override, width-table reference, roof-spacing mode, secondary-run mode, bay lengths, and opening placements before saving.

## Implementation details and safeguards

- New-building main sections follow the width table until a user manually changes either member selection; manual resizing then remains in control.
- The welded-fit override is one per-frame checkbox, unchecked by default. It is disabled for bolted construction, which is called out as a separate option.
- Equal-bay run generation and automatic equal roof spacing start enabled. Roof-row spacing is separate from longitudinal building bay/run layout.
- Door and overhead-door presets default to centered in bay 1 on the selected elevation, with wall, bay, placement mode, offset, and dimensions editable. The opening preview is a **schematic location aid**, not a framing, connection, or engineering design; actual geometry is still validated by the existing generator.
- Endwall support-assumption fields retain a direct note that they do not create endwall members; endwall setout and counts remain in the Endwalls step.
- No engineering or calculation rules were intentionally rewritten for this console reorganization beyond the confirmed defaults and placement workflow.

## Validation

- JavaScript syntax checks: `node --check` passed for `app.js`, `settings_stepper.js`, and the UI smoke test.
- UI smoke test passed against a fresh editor workspace, checking welded/automatic defaults, the 50 ft width schedule, schedule update on width change, the explicit per-frame welded override, the dedicated Openings step, centered-bay default and preview, Review facts, and existing editor controls.
- Full Python suite: **814 passed, 252 skipped**. The 252 skips are due to 16 private fixture files not stored in this checkout.
